"""Repository-root import shim for file_index_sop.

Works when the project root, not memory/, is on sys.path.
"""
from __future__ import annotations

import os
import sys

_ROOT = os.path.dirname(os.path.abspath(__file__))
_MEM = os.path.join(_ROOT, "memory")
if _MEM not in sys.path:
    sys.path.insert(0, _MEM)

from file_index_sop import *  # noqa: F401,F403,E402
