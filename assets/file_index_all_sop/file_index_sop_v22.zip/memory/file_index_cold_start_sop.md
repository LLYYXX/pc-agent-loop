# file_index_cold_start_sop v22 — cold start SOP

Use this only when the user asks to build an initial index for a scope such as `F:\`.

Cold start is Agent-led. Helper provides candidates, evidence, session status, and storage. It does not generate semantic route tags.

## Flow

```python
from file_index import *
ensure_search_ready(start=True, patch=True)
init_db()
res = begin_cold_start(scope=r"F:\", target_nodes=1000)
sid = res["session_id"]
```

Collect candidates:

```python
collect_cold_start_entries(sid)
batch = cold_start_batch(sid, batch_size=8)
```

For each item, read the evidence packet. The Agent decides:

- apply as entry;
- skip;
- defer and gather more evidence using `path_evidence(path)` or `search_to_evidence(...)`.

Example plan item:

```python
{
  "path": item["path"],
  "role": "entry",
  "tier": "warm",
  "brief": "...Agent-written one-line scope description...",
  "tags": ["accurate-route-tag"],
  "evidence_note": "Based on cold_start_batch evidence: children_sample..., document_heads...",
  "leaf_candidates": [ ... optional representative paths ... ]
}
```

Apply:

```python
apply_index_plan(plan, session_id=sid)
```

Repeat collect/batch/apply until enough useful entries are indexed.

Finish:

```python
finish_cold_start(sid)
audit_index()
index_summary()
```

If `finish_cold_start` returns `status="partial"` or `ok=False`, report partial status honestly. Do not say the index is fully established.

## Candidate policy

- hard-ignore only high-confidence dependency/system/build dirs from policy;
- cache/tmp/log/backup-like names are soft downrank only, not exclusion;
- default queries and marker file names are candidate-discovery signals only;
- they must not become route tags automatically.

## Do not

- do not write case-specific rules;
- do not auto-generate route tags from path names;
- do not accept an index with only files and no meaningful entries;
- do not use raw SQL for status inspection.
