"""Agent-facing helper surface for file_index_sop v22.

No semantic route-tag inference. Use `from file_index import *`.
"""
from __future__ import annotations

import json
import os
from collections import Counter
from typing import Any, Dict, List, Optional, Sequence

from . import everything
from .policy import load_index_policy, policy_paths, audit_policy, update_local_policy_patch
from .store import (
    init_db, reset_db, annotate_entry, annotate_leaf, attach_leaf, apply_index_plan as _store_apply_index_plan,
    recall as _recall, begin_file_task, record_task_hits, finalize_file_task,
    draft_update_plan, apply_update_plan, list_pending_update_plans, stats, audit_index,
    virtual_tree, alias_lookup, node, get_node, list_nodes, list_entries, list_leaf, top_tags, index_summary,
    rebalance_tiers,
)
from .ensure_es import ensure_ready as ensure_search_ready
from .cold_start import (
    begin_cold_start, collect_cold_start_entries, cold_start_batch,
    cold_start_evidence_batch, cold_start_status, mark_candidates, finish_cold_start
)


def print_json(obj: Any) -> Any:
    print(json.dumps(obj, ensure_ascii=False, indent=2))
    return obj


def search_files(query: str, scope: Optional[str] = None, limit: int = 50, *, task_id: Optional[str] = None) -> List[Dict[str, Any]]:
    rows = everything.search(query, scope=scope, limit=limit)
    if task_id:
        record_task_hits(task_id, filesystem_hits=rows, fallback_used=True, dirty=True)
    return rows


def search_files_detailed(query: str, scope: Optional[str] = None, limit: int = 50, *, task_id: Optional[str] = None) -> Dict[str, Any]:
    res = everything.search_detailed(query, scope=scope, limit=limit)
    if task_id:
        record_task_hits(task_id, filesystem_hits=res.get("hits") or [], fallback_used=True, dirty=bool(res.get("hits")))
    return res


def last_search_diagnostic() -> Dict[str, Any]:
    return everything.last_search_diagnostic()


def recent_files(scope: Optional[str] = None, limit: int = 200) -> List[Dict[str, Any]]:
    return everything.recent(scope=scope, limit=limit)


def _norm(p: str) -> str:
    return os.path.normpath(os.path.abspath(str(p).strip().strip('"').strip("'")))


def _hard_ignored(path: str, policy: Optional[Dict[str, Any]] = None) -> bool:
    p = policy or load_index_policy()
    cd = p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}
    hard = set(str(x).lower() for x in cd.get("hard_ignore_dirs", []))
    parts = [x.lower() for x in path.replace("/", "\\").split("\\") if x]
    return any(part in hard for part in parts)


def _read_head(path: str, max_chars: int) -> Optional[str]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            txt = f.read(max_chars)
        return txt.replace("\x00", "").strip()
    except Exception:
        return None


def _entry_type(path: str) -> str:
    if os.path.isdir(path):
        return "dir"
    if os.path.isfile(path):
        return "file"
    return "missing"


def path_evidence(path: str, *, max_children: Optional[int] = None, max_heads: Optional[int] = None) -> Dict[str, Any]:
    """Return factual evidence for a path. No semantic tag inference."""
    pol = load_index_policy()
    p = _norm(path)
    max_children = int(max_children if max_children is not None else pol.get("evidence_max_children", 80))
    max_heads = int(max_heads if max_heads is not None else pol.get("evidence_max_heads", 3))
    max_head_chars = int(pol.get("text_head_max_chars", 1200))
    cd = pol.get("candidate_discovery", {}) if isinstance(pol.get("candidate_discovery"), dict) else {}
    text_exts = set(str(x).lower() for x in cd.get("text_extensions", []))
    doc_exts = set(str(x).lower() for x in cd.get("document_extensions", []))
    ev: Dict[str, Any] = {"path": p, "node_type": _entry_type(p), "exists": os.path.exists(p)}
    try:
        st = os.stat(p, follow_symlinks=False)
        ev.update({"size": int(st.st_size), "mtime_ns": int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))})
    except OSError as e:
        ev["stat_error"] = str(e)
        return ev
    if os.path.isfile(p):
        ext = os.path.splitext(p)[1].lower()
        ev["extension"] = ext
        ev["is_document_ext"] = ext in doc_exts
        if ext in text_exts:
            head = _read_head(p, max_head_chars)
            if head:
                ev["content_head"] = head
                ev["content_head_note"] = "Use only as evidence for this file itself; distinguish self-description from external references/examples."
        return ev
    if not os.path.isdir(p):
        return ev
    children: List[Dict[str, Any]] = []
    heads: List[Dict[str, Any]] = []
    ext_counter: Counter[str] = Counter()
    dir_count = 0
    file_count = 0
    try:
        with os.scandir(p) as it:
            for ent in it:
                if len(children) >= max_children:
                    break
                ep = ent.path
                if _hard_ignored(ep, pol):
                    continue
                is_dir = ent.is_dir(follow_symlinks=False)
                is_file = ent.is_file(follow_symlinks=False)
                if is_dir:
                    dir_count += 1
                if is_file:
                    file_count += 1
                ext = os.path.splitext(ent.name)[1].lower() if is_file else ""
                if ext:
                    ext_counter[ext] += 1
                item: Dict[str, Any] = {"name": ent.name, "path": os.path.normpath(ep), "is_dir": is_dir, "is_file": is_file, "extension": ext}
                try:
                    st = ent.stat(follow_symlinks=False)
                    item["size"] = int(st.st_size)
                    item["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
                except OSError:
                    pass
                children.append(item)
                if is_file and len(heads) < max_heads and ext in text_exts:
                    head = _read_head(ep, max_head_chars)
                    if head:
                        heads.append({"path": os.path.normpath(ep), "name": ent.name, "head": head, "note": "Evidence for this child only; do not treat external references/examples as parent route tags."})
    except OSError as e:
        ev["scandir_error"] = str(e)
        return ev
    ev.update({
        "dir_count_sampled": dir_count,
        "file_count_sampled": file_count,
        "file_type_mix_sampled": dict(ext_counter.most_common(20)),
        "children_sample": children,
        "document_heads": heads,
        "annotation_contract": [
            "Agent decides brief/route_tags; helper does not infer semantics.",
            "Route tags must describe this path's main search use.",
            "Do not use sibling/neighbor project semantics as evidence.",
            "Do not turn external references, badges, templates, examples, or dependencies into parent route tags.",
            "If evidence is insufficient, gather more evidence or skip."
        ]
    })
    return ev


def search_to_evidence(query: str, scope: Optional[str] = None, limit: int = 20, evidence_limit: int = 8) -> Dict[str, Any]:
    res = search_files_detailed(query, scope=scope, limit=limit)
    packets = [path_evidence(row["path"]) for row in (res.get("hits") or [])[: max(0, int(evidence_limit))]]
    return {"ok": res.get("ok"), "query": query, "scope": scope, "search": res, "evidence_packets": packets}


def explore_scope(scope: str, *, recent_limit: int = 100, top_level: bool = True) -> Dict[str, Any]:
    """Factual starting point for Agent-led cold start. No semantic judgment."""
    p = _norm(scope)
    out: Dict[str, Any] = {"ok": os.path.exists(p), "scope": p, "top_level": [], "recent": [], "notes": ["Use this to choose candidate entries; do not treat it as an index plan."]}
    if top_level and os.path.isdir(p):
        try:
            with os.scandir(p) as it:
                for ent in it:
                    if _hard_ignored(ent.path):
                        continue
                    item: Dict[str, Any] = {"name": ent.name, "path": os.path.normpath(ent.path), "is_dir": ent.is_dir(follow_symlinks=False), "is_file": ent.is_file(follow_symlinks=False)}
                    try:
                        st = ent.stat(follow_symlinks=False)
                        item["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
                    except OSError:
                        pass
                    out["top_level"].append(item)
        except OSError as e:
            out["top_level_error"] = str(e)
    try:
        out["recent"] = recent_files(scope=p, limit=recent_limit)
    except Exception as e:
        out["recent_error"] = str(e)
    return out


def recall(query: str, limit: int = 20, include_cold: bool = False, *, task_id: Optional[str] = None) -> Dict[str, Any]:
    tid = task_id or begin_file_task(query).get("task_id")
    alias = alias_lookup(query)
    hits: List[Dict[str, Any]] = []
    if alias:
        n = node(alias["path"])
        if n:
            n["alias_hit"] = True
            hits.append(n)
    hits.extend(_recall(query, limit=limit, include_cold=include_cold))
    dedup: List[Dict[str, Any]] = []
    seen = set()
    for h in hits:
        if h.get("path") not in seen:
            seen.add(h.get("path"))
            dedup.append(h)
    record_task_hits(tid, semantic_hits=dedup, dirty=False)
    return {"ok": True, "task_id": tid, "query": query, "hits": dedup[:limit], "finalize_required": True}


def locate(query: str, *, scope: Optional[str] = None, limit: int = 20, include_cold: bool = False, fallback_files: bool = True) -> Dict[str, Any]:
    r = recall(query, limit=limit, include_cold=include_cold)
    tid = r["task_id"]
    fs: List[Dict[str, Any]] = []
    fallback_used = False
    if fallback_files and not r["hits"]:
        try:
            fs = search_files(query, scope=scope, limit=limit, task_id=tid)
            fallback_used = bool(fs)
        except Exception as e:
            return {**r, "filesystem_hits": [], "fallback_used": False, "error": str(e)}
    return {**r, "filesystem_hits": fs, "fallback_used": fallback_used, "finalize_required": True}


def apply_index_plan(plan: Sequence[Dict[str, Any]], *, session_id: Optional[str] = None) -> Dict[str, Any]:
    res = _store_apply_index_plan(plan)
    rejected = res.get("rejected") or []
    if rejected and all((r.get("reason") in ("skip", "defer")) for r in rejected if isinstance(r, dict)):
        res["ok"] = True
    if session_id:
        applied_paths = [x.get("path") for x in res.get("applied", []) if x.get("path")]
        skipped_paths = []
        for item in plan or []:
            if str(item.get("action") or "apply").lower() in ("skip", "defer") and item.get("path"):
                skipped_paths.append(item.get("path"))
        try:
            res["cold_start_mark"] = mark_candidates(session_id, applied_paths=applied_paths, skipped_paths=skipped_paths)
        except Exception as e:
            res["cold_start_mark_error"] = str(e)
    return res


__all__ = [
    "ensure_search_ready", "init_db", "reset_db", "search_files", "search_files_detailed", "last_search_diagnostic",
    "recent_files", "explore_scope", "begin_cold_start", "collect_cold_start_entries", "cold_start_batch", "cold_start_evidence_batch", "cold_start_status", "finish_cold_start", "path_evidence", "search_to_evidence", "annotate_entry", "annotate_leaf",
    "attach_leaf", "apply_index_plan", "recall", "locate", "begin_file_task", "finalize_file_task",
    "draft_update_plan", "apply_update_plan", "list_pending_update_plans", "stats", "audit_index", "virtual_tree", "rebalance_tiers",
    "get_node", "list_nodes", "list_entries", "list_leaf", "top_tags", "index_summary",
    "load_index_policy", "policy_paths", "audit_policy", "update_local_policy_patch", "print_json"
]
