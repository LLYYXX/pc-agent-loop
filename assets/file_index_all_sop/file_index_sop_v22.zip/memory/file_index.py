"""Stable import shim for file_index_sop.

Agent code should use:
    from file_index import *
"""
from __future__ import annotations

import os
import sys

_THIS = os.path.dirname(os.path.abspath(__file__))
if _THIS not in sys.path:
    sys.path.insert(0, _THIS)

from file_index_sop import *  # noqa: F401,F403,E402
