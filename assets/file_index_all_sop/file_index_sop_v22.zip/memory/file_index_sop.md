# file_index_sop v22 — runtime SOP

This SOP is for ordinary local-file tasks. Cold start is separate; read `file_index_cold_start_sop.md` only when the user asks to build/rebuild an index.

## Import

Always start with:

```python
from file_index import *
```

Do not import modules from `memory/file_index_sop/` directly unless debugging the package itself.

## Runtime flow

1. Try semantic recall/locate first:

```python
res = recall(user_query)
# or
res = locate(user_query)
```

2. If recall is insufficient, use factual search:

```python
hits = search_files(user_query, scope=optional_scope, limit=50)
```

`search_files` is a thin Everything/es.exe wrapper. It must not be used as a semantic reranker. Use `search_files_detailed` when search behavior is suspicious; it exposes argv/scope/encoding/stderr/hit_count.

3. Use normal Agent tools to read/list/summarize files.

4. Before final answer, call `finalize_file_task` if the task used local paths:

```python
finalize_file_task(
    task_id=res.get("task_id"),
    query=user_query,
    used_paths=[...],
    found_paths=[...],
    rejected_paths=[...],
    fallback_used=bool(res.get("fallback_used")),
    mode="draft",
)
```

Behavior:

- used indexed paths are warmed and rebalanced;
- indexed paths can become active, but active/warm caps are enforced;
- external paths generate a draft update plan;
- draft plans do not invent route tags.

## Database inspection

Do not write raw SQL during normal use. Use:

```python
index_summary()
list_entries()
list_nodes(role="entry", tier="warm")
list_leaf(entry_path)
top_tags()
get_node(path)
audit_index()
rebalance_tiers()
```

## Route tag rule

Agent writes route tags. Helper never infers them.

A route tag must describe the current entry's main search use, not a neighboring project, dependency, external reference, or generic category. Every tagged entry must include an evidence note.

## Tier rule

- active: small hot set from real use;
- warm: stable semantic entry layer;
- cold: support leaves and low-frequency candidates.

`rebalance_tiers()` enforces max_active/max_warm/max_nodes. Do not manually set many nodes to active.
