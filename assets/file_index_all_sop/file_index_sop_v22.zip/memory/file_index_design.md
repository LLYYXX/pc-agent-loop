# file_index_sop v22 design note

file_index is Agent L5 memory: a lightweight SQLite semantic overlay over Everything/es.exe.

L1 triggers the SOP; L2 stores environment facts such as `LOCAL_TOOLS/es.exe`; L3 stores this SOP and code; L5 stores nodes/tags/aliases/update plans/usage.

The project intentionally does less in Python: the Agent judges semantics from evidence, while helper code handles search, evidence packaging, storage, status, and tier rebalance.
