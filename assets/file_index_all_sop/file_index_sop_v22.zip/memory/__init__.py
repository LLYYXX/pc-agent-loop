# Memory package marker for file_index import shim.
