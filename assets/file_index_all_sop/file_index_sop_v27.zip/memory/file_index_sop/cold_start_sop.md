# file_index_sop v27 — cold start SOP

Use this only when the user asks to build or rebuild an initial index for a scope such as `F:\`.

Cold start is Agent-led and transaction-oriented. Helper provides candidates, rough evidence, expanded evidence, session status, validation, and storage. It does not generate semantic route tags.

## Import and start

```python
from file_index_sop import *
ensure_search_ready(start=True, patch=True)
init_db()
res = begin_cold_start(scope="F:\\", target_nodes=1000)
sid = res["session_id"]
collect_cold_start_entries(sid)
```

`target_nodes` is a budget/cap hint, not a required commit count.

## Candidate loop

```python
batch = cold_start_batch(sid, batch_size=6)
items = batch["items"]
```

`cold_start_batch` is rough triage only. Do not apply route tags from rough evidence alone. Do not write path/extension/children_count if-elif classifiers over the batch.

For each candidate, first expand:

```python
expanded = expand_candidate(sid, item["path"])
ev = expanded["item"]["evidence"]
```

Then choose one action.

### Preferred commit path

Use `commit_candidate`, not raw bulk `apply_index_plan`, for cold-start commits:

```python
commit_candidate(
    session_id=sid,
    path=item["path"],
    brief="Agent-written one-line scope description",
    tags=["specific-route-tag"],
    facets=["python-project"],        # optional type/technology/file-form signals
    evidence_note="Based on expanded evidence: README head says..., representative file X is...",
    evidence_refs=["document_heads[0].path", "representative_files:README.md"],
    leaf_candidates=[...],
)
```

Rules:
- `evidence_refs` are required for commit.
- type/file-form labels alone (`python-project`, `document-archive`, `pdf-documents`, `web-development`) are facets, not route tags.
- if only weak labels are available, defer instead of committing.

### Defer or skip

```python
defer_candidate(sid, path, reason="evidence insufficient after expansion; keep as unknown")
```

Skip only for specific confirmed reasons such as duplicate/already-indexed, out-of-scope, system/dependency/build, confirmed-noise, user-excluded, or not-useful-after-expanded-evidence:

```python
skip_candidate(sid, path, reason="duplicate: already covered by parent entry")
```

Rejected apply results are not progress. If helper says `needs_verification`, rewrite using concrete expanded evidence, or defer. Do not lower standards to increase entry count.

## Finish

```python
finish = finish_cold_start(sid)
audit = audit_index()
summary = index_summary()
```

Finish status semantics:
- `complete`: broad verified coverage; may be reported as fully established.
- `usable_partial`: some high-confidence entries exist and the protocol is healthy; may be reported as a usable partial seed index.
- `incomplete`: pending/needs-more-evidence work remains; report honestly.
- `failed`: protocol/tool failure, no tagged entries, or unusable state.

Entry counts are diagnostics/reference targets, not failure thresholds. Never lower evidence standards to increase counts.

## Candidate policy

- hard-ignore only high-confidence dependency/system/build dirs from policy;
- cache/tmp/log/backup-like names are soft downrank only, not exclusion;
- Office/PDF/text documents are valid evidence sources even when few in number or in generic-named folders;
- default queries and marker names are candidate-discovery signals only;
- they must not become route tags automatically.

## Do not

- do not write case-specific rules;
- do not auto-generate route tags from path names;
- do not write if/elif classifiers over paths, file counts, or extensions;
- do not bulk apply file-type tags;
- do not skip because of `children_count < 3`, `Generic directory`, `unsupported extension`, or Office/document-heavy content;
- do not use raw SQL or import internal store functions;
- do not call a small partial index complete.
