# file_index_sop v27 — runtime SOP

This is the single root SOP entry for local file semantic indexing. Use it for ordinary local-file tasks. If the user asks to build/rebuild an index, read `file_index_sop/cold_start_sop.md`.

## Import

Always use:

```python
from file_index_sop import *
```

Do not import internal modules such as `file_index_sop.store`. Do not use raw SQL for normal inspection.

## Runtime flow

Use low-friction wrappers so you do not need to remember internal return fields:

```python
hits = recall_hits(user_query, limit=20)
# if insufficient:
rows = search_files_rows(user_query, scope=optional_scope, limit=50)   # list[dict]
paths = search_files_paths(user_query, scope=optional_scope, limit=50) # list[str]
```

For one-call query + task ledger:

```python
res = run_file_query(user_query, scope=optional_scope, limit=20)
# Agent decides which paths are useful from res["all_hits"]
```

`search_files_rows/paths` are thin Everything/es.exe wrappers. They do not expand semantics, infer tags, or rerank. Use `search_files_detailed(...)` only when search behavior is suspicious; it returns argv/scope/encoding/stderr/hit_count diagnostics.

## Finish / after-effect

Before final answer, if the task used local paths, call the low-friction finalizer:

```python
finish_local_file_task(
    query=user_query,
    used=[...],      # paths actually used/read/summarized
    found=[...],     # useful paths found by fallback
    rejected=[...],  # wrong candidates for this query
    fallback_used=None,  # auto: True only if found/used includes external paths
    mode="draft",
)
```

`task_id` is optional; the helper binds only to a recent open task for the same query, otherwise it creates a new task. It never binds to an arbitrary previous task. Behavior:
- indexed used paths get hit_count/last_used and are warmed/rebalanced;
- external found/used paths create a draft update plan;
- rejected paths create immediate query-level negative evidence;
- active/warm/max_nodes caps are enforced opportunistically.

## Corrections

User correction is first-class evidence:

```python
record_correction(query, wrong_paths=[...], missed_paths=[...], note="user correction: ...")
mark_not_relevant(path, query, reason="...")
update_entry_tags(path, add=[...], remove=[...], evidence_note="...")  # weak labels become facets unless force_route=True
```

Do not just fix the answer; write correction evidence so the same mistake is less likely next time.

## Inspection and audit

Use wrappers only:

```python
index_summary()
list_entries(limit=50)
list_nodes(role="entry", tier="warm", limit=50)
list_leaf(entry_path)
top_tags()
search_index("machine learning", tags_any=["machine-learning", "ml-agents"], limit=50)
nodes_by_tag("machine-learning")
audit_index()      # structural + runtime + weak-tag audit
audit_runtime()    # task binding, recall consumption, fallback finalization, correction effects
```

## Route tag / facet rule

Agent writes route tags; helper never infers them. Route tags must be evidence-backed semantic search routes for this entry. Weak type labels such as `python-project`, `document-archive`, `pdf-documents`, `markdown-docs`, `web-development` are facets/signals, not sufficient route tags by themselves.

## Tier rule

- active: small hot set from real use;
- warm: stable semantic entry layer;
- cold: support leaves and low-frequency candidates.

`maintenance_tick()` / `rebalance_tiers()` enforces max_active/max_warm/max_nodes. Do not manually set many nodes to active.
