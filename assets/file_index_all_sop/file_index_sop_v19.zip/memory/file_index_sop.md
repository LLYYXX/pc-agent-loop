# file_index_sop v19-lite — Agent 操作协议

定位：file_index 是 Agent 的 L5 文件语义索引层。Everything/es.exe 负责事实检索；Agent 负责语义判断；SQLite 负责记录和复用。

禁止：不要把索引内容写进 L1/L2；不要在 helper 中自动生成 route tag；不要为了历史 case 写特判；不要把冷启动当成自动理解全盘。

## 模式 A：本地文件任务

1. 先调用 `recall(query)` 或 `locate(query)`。
2. 若语义命中不足，再调用 `search_files(query, scope=...)` 或 `search_files_detailed(...)`。
3. 正常执行文件读取、目录遍历、总结、移动、重命名等任务。
4. 最终回答前调用：

```python
finalize_file_task(task_id=task_id, query=query, used_paths=[...], found_paths=[...], rejected_paths=[...], fallback_used=..., mode="draft")
```

规则：命中已有索引并实际使用时会升温；fallback 找到索引外路径时生成 draft update plan。默认不直接污染主库。

## 模式 B：Agent 主导冷启动

冷启动不是自动 builder。按以下流程做：

1. `ensure_search_ready(start=True, patch=True)`。
2. `init_db()`。
3. `explore_scope(scope)` 获取顶层目录和 recent 事实。
4. 用 `search_files` / `search_to_evidence` / `path_evidence` 探索候选。
5. Agent 自己选择能缩小搜索范围的目录作为 entry。
6. 对每个 entry 读取 `path_evidence(entry_path)`。
7. Agent 根据 evidence 写 `brief`、`route_tags`、`evidence_note`。
8. 调用 `apply_index_plan(plan)` 或 `annotate_entry(...)`。
9. 对代表文件调用 `attach_leaf(entry_path, leaf_path)`；不要把大量文档直接刷成主索引。
10. 用 `stats()` / `audit_index()` 检查一致性。

冷启动允许只建立几百个高质量 entry/leaf。不要为了凑 1000 节点降低判断质量。

## route tag 规则

不是少打 tag，而是打一条对一条。

route tag 必须：
- 描述当前 entry 的主要搜索用途。
- 可作为 recall 入口。
- 有 evidence_note 支撑。
- 不能来自邻居项目、外部引用、模板示例、依赖或局部弱证据的无条件冒泡。
- 不能复读路径或使用泛词（file/folder/project/document/general 等）。

不确定时先取更多 evidence，或暂不写 tag。

## Evidence 使用规则

`path_evidence(path)` 只返回事实，不给语义结论。Agent 必须自行判断。

README/head 中要区分：当前项目自我描述、外部关联项目、引用/致谢/链接、模板/示例、依赖/工具。route tag 只能来自当前节点自身主语义。

## 配置和 memory 分层

- L1：只保留 file_index_sop 触发词。
- L2：只放 LOCAL_TOOLS/es.exe 等环境事实。
- L3：本目录放 SOP、代码、极简 policy。
- L5：SQLite 存 nodes/tags/aliases/update plans/hit_count。

policy 只放结构参数、采样限制和 ignore dirs，不放语义规则库、项目名、研究词或历史 case。
