# file_index v19-lite design

v19-lite 是一次减法版本。它不再试图自动构建完整 F 盘语义索引，而是把 file_index 恢复成 Agent 的 L5 语义笔记层。

保留：
- Everything/es.exe 薄封装；
- SQLite overlay；
- Agent-authored entry/leaf/tag/brief；
- path evidence helper；
- recall/query alias；
- runtime finalize：命中升温、未命中 draft update。

移除/废弃：
- 自动 cold-start builder；
- auto_apply_index_plan；
- 复杂 entry aggregation；
- 复杂 finish_cold_start；
- 复杂 virtual tree；
- 大规模 tag/facet 常量。

核心边界：helper 负责事实、证据、状态和校验；语义判断由 Agent 完成。
