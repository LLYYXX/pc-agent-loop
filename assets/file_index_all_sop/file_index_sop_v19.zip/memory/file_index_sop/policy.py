"""Small policy loader for file_index_sop v19-lite.

Policy contains structural limits and evidence sampling options only. It must not
contain semantic routing rules, user project names, or task-specific terms.
"""
from __future__ import annotations

import json
import os
from copy import deepcopy
from typing import Any, Dict

_THIS = os.path.dirname(os.path.abspath(__file__))
_CONFIG = os.path.join(_THIS, "config")
_DEFAULT = os.path.join(_CONFIG, "default_policy.json")
_LOCAL = os.path.join(_CONFIG, "local_policy.json")


def _read_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except FileNotFoundError:
        return {}
    except Exception:
        return {}


def _deep_merge(base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
    out = deepcopy(base)
    for k, v in patch.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)  # type: ignore[arg-type]
        else:
            out[k] = deepcopy(v)
    return out


def load_index_policy() -> Dict[str, Any]:
    base = _read_json(_DEFAULT)
    local = _read_json(_LOCAL)
    overrides = local.get("overrides", {}) if isinstance(local.get("overrides"), dict) else {}
    return _deep_merge(base, overrides)


def policy_paths() -> Dict[str, str]:
    return {"default_policy": _DEFAULT, "local_policy": _LOCAL, "config_dir": _CONFIG}


def _set_dotted(d: Dict[str, Any], key: str, value: Any) -> None:
    cur = d
    parts = key.split(".")
    for p in parts[:-1]:
        nxt = cur.get(p)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[p] = nxt
        cur = nxt
    cur[parts[-1]] = value


def update_local_policy_patch(patch: Dict[str, Any]) -> Dict[str, Any]:
    """Patch local_policy.json overrides only. Dotted keys are supported."""
    os.makedirs(_CONFIG, exist_ok=True)
    local = _read_json(_LOCAL) or {"version": 1, "inherits": "default_policy.json", "overrides": {}}
    overrides = local.get("overrides")
    if not isinstance(overrides, dict):
        overrides = {}
        local["overrides"] = overrides
    for k, v in patch.items():
        if "." in k:
            _set_dotted(overrides, k, v)
        else:
            overrides[k] = v
    with open(_LOCAL, "w", encoding="utf-8", newline="\n") as f:
        json.dump(local, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return {"ok": True, "local_policy": _LOCAL, "policy": load_index_policy()}


def audit_policy() -> Dict[str, Any]:
    p = load_index_policy()
    warnings = []
    target = int(p.get("target_nodes", 1000) or 1000)
    if int(p.get("max_active", 80) or 0) > target:
        warnings.append("max_active exceeds target_nodes")
    if int(p.get("max_warm", 420) or 0) > target:
        warnings.append("max_warm exceeds target_nodes")
    if int(p.get("leaf_cap_per_entry", 8) or 0) > 100:
        warnings.append("leaf_cap_per_entry is unusually high")
    # Keep audit structural. Do not embed historical case names or user-specific
    # literals here; source audits for such strings should be done outside the
    # runtime package when packaging a release.
    return {"ok": not warnings, "warnings": warnings, "policy": p, "paths": policy_paths()}
