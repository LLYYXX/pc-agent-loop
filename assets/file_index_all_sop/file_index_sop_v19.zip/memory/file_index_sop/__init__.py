"""file_index_sop v19-lite.

Agent-led L5 file semantic overlay. The package intentionally does not perform
automatic semantic tagging or cold-start building. Use the helper API.
"""
from .helper import *  # noqa: F401,F403
