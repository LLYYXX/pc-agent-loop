"""Agent-facing entry points for file_index_sop v11.

No GenericAgent imports. The Agent calls these functions via code_run.
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import builder, ensure_es, everything, store

_PATH_OVERRIDE: Optional[str] = None
_CONN: Optional[sqlite3.Connection] = None
_FTS_OK = False


def _db_path_used() -> str:
    return _PATH_OVERRIDE if _PATH_OVERRIDE else store.default_db_path()


def _ensure_conn() -> Tuple[sqlite3.Connection, bool, str]:
    global _CONN, _FTS_OK
    if _CONN is None:
        _CONN = store.connect(_PATH_OVERRIDE)
        _FTS_OK = store.init_schema(_CONN)
    return _CONN, _FTS_OK, _db_path_used()


def _close_conn() -> None:
    global _CONN
    if _CONN is not None:
        _CONN.close(); _CONN = None


def init_db(db_path: Optional[str] = None) -> Dict[str, Any]:
    global _PATH_OVERRIDE
    _PATH_OVERRIDE = os.path.abspath(db_path) if db_path else None
    _close_conn(); _, fts, p = _ensure_conn()
    return {"ok": True, "db_path": p, "fts_enabled": fts, "ignore_rules": store.IGNORE_RULES_PATH, "events": store.EVENTS_PATH}


def ensure_search_ready(*, start: bool = True, patch: bool = True, dry_run: bool = False) -> Dict[str, Any]:
    return ensure_es.ensure_ready(start=start, patch=patch, dry_run=dry_run)


# Runtime search -------------------------------------------------------------

def search_files(query: str, *, limit: int = 50, scope: Optional[str] = None, sort_mtime_desc: bool = False, **kwargs: Any) -> List[Dict[str, Any]]:
    # Compatibility for earlier Agent mistakes: name_pattern="*foo*" becomes query="foo".
    if not query and kwargs.get("name_pattern"):
        query = str(kwargs["name_pattern"]).strip("*")
    return everything.search(query, limit=limit, scope=scope, sort_mtime_desc=sort_mtime_desc)


def recent_files(*, limit: int = 500, scope: Optional[str] = None, query: str = "*") -> List[Dict[str, Any]]:
    return everything.recent(limit=limit, scope=scope, query=query)


def _infer_intent(query: str) -> str:
    q = (query or "").lower()
    if any(x in q for x in ["报销", "发票", "收据", "账单", "invoice", "receipt", "bill"]): return "billing"
    if any(x in q for x in ["zotero", "paper", "论文", "文献", "aios"]): return "paper"
    if any(x in q for x in ["毕设", "毕业设计", "终稿", "定稿", "thesis", "final"]): return "thesis"
    if any(x in q for x in ["skill", "local tools", "工具", "配置", "memory", "sop"]): return "config"
    if any(x in q for x in ["项目", "project", "代码", "repo", "agent", "mcp", "llm"]): return "project"
    return "general"


def _query_variants(query: str, intent: str = "") -> List[str]:
    q = (query or "").strip()
    intent = intent or _infer_intent(q)
    variants = [q]
    ql = q.lower()
    def add(*xs: str) -> None:
        for x in xs:
            if x and x not in variants:
                variants.append(x)
    if intent == "billing":
        if "cursor" in ql: add("cursor invoice", "cursor receipt", "cursor bill", "cursor 发票", "cursor 收据", "cursor 账单")
        add("invoice", "receipt", "bill", "发票", "收据", "账单", "报销")
    elif intent == "paper":
        if "zotero" in ql: add("zotero pdf", "zotero paper", "AIOS", "AI system", "agent system", "semantic file system")
        add("paper pdf", "research paper", "论文 pdf", "文献")
    elif intent == "thesis":
        add("毕业设计", "毕设", "终稿", "定稿", "final", "thesis")
    elif intent == "config":
        add("skill list", "local tools", "global_mem", "runtime environment", "SOP", "配置", "工具")
    return variants[:12]


def _is_noise_path(path: str, intent: str = "") -> bool:
    p = (path or "").lower().replace("/", "\\")
    common = ["$recycle.bin", "\\node_modules\\", "\\.git\\", "__pycache__", "\\cache\\", "\\tmp\\", "\\temp\\"]
    if any(x in p for x in common): return True
    if intent in {"billing", "paper", "thesis", "general"}:
        if "\\appdata\\" in p and ("\\logs\\" in p or "\\cache\\" in p): return True
        if "cursor\\logs" in p or "\\roaming\\cursor\\logs" in p: return True
    return False


def _dedupe_rank_files(rows: List[Dict[str, Any]], intent: str = "", limit: int = 20) -> List[Dict[str, Any]]:
    out = []
    seen = set()
    for r in rows:
        p = r.get("path", "")
        if not p or p in seen:
            continue
        rr = dict(r)
        rr["noise_downranked"] = _is_noise_path(p, intent)
        out.append(rr); seen.add(p)
    out.sort(key=lambda x: (x.get("noise_downranked", False), -float(x.get("score", 0) or 0), str(x.get("path", ""))))
    return out[:limit]


def recall(query: str, *, limit: int = 10, include_dormant: bool = False,
           node_types: Optional[Sequence[str]] = None, verbose: bool = False) -> List[Dict[str, Any]]:
    conn, fts, _ = _ensure_conn()
    return store.recall(conn, query, limit=limit, include_dormant=include_dormant,
                        node_types=node_types, fts_ok=fts, verbose=verbose)


def locate(query: str, *, limit: int = 10, scope: Optional[str] = None, include_cold: bool = False) -> Dict[str, Any]:
    """Stable runtime locator.

    v11 uses query aliases first, then active/warm semantic recall, then scoped
    Everything variants with intent-sensitive noise downrank. It remains non-invasive:
    it only searches, never reads or edits files.
    """
    conn, fts, _ = _ensure_conn()
    intent = _infer_intent(query)
    aliases = store.query_alias_hits(conn, query, limit=limit)
    alias_hits: List[Dict[str, Any]] = []
    for a in aliases:
        for key in ("path", "entry_path"):
            p = a.get(key)
            if p and os.path.exists(p):
                alias_hits.append({"path": p, "source": "query_alias", "query_text": a.get("query_text"), "success_count": a.get("success_count"), "intent": a.get("intent")})
    sem = recall(query, limit=max(limit, 12), include_dormant=include_cold, verbose=False)
    # Anchor-aware filtering: if a strong anchor exists, prefer semantic hits containing it unless aliases already hit.
    ql = (query or "").lower()
    anchors = [a for a in ["zotero", "cursor", "wechat", "微信", "毕业", "毕设", "invoice", "receipt", "账单", "发票", "收据"] if a in ql]
    if anchors and not alias_hits:
        anchored = [h for h in sem if any(a.lower() in (h.get("path", "") + " " + h.get("brief", "") + " " + " ".join(h.get("tags", []))).lower() for a in anchors)]
        if anchored:
            sem = anchored + [h for h in sem if h not in anchored]
    variants = _query_variants(query, intent=intent)
    scoped: List[Dict[str, Any]] = []
    # Use explicit scope, alias entry scopes, then top semantic dir scopes.
    scopes: List[str] = []
    if scope: scopes.append(scope)
    for h in alias_hits:
        p = h.get("path")
        if p and os.path.isdir(p): scopes.append(p)
        elif p: scopes.append(os.path.dirname(p))
    for hit in sem[:4]:
        if hit.get("node_type") == "dir": scopes.append(hit["path"])
    seen_scopes = []
    for sc in scopes:
        if sc and sc not in seen_scopes and os.path.exists(sc):
            seen_scopes.append(sc)
    for sc in seen_scopes[:4]:
        for v in variants[:8]:
            try:
                scoped.extend(search_files(v, scope=sc, limit=max(3, limit // 2)))
            except Exception as e:
                scoped.append({"error": str(e), "scope": sc, "query": v})
    fallback: List[Dict[str, Any]] = []
    if not scoped or len([x for x in scoped if not x.get("error") and not _is_noise_path(x.get("path", ""), intent)]) < max(2, limit // 4):
        for v in variants[:8]:
            try:
                fallback.extend(search_files(v, limit=limit, scope=scope))
            except Exception as e:
                fallback.append({"error": str(e), "query": v})
    scoped_ranked = _dedupe_rank_files([x for x in scoped if not x.get("error")], intent=intent, limit=limit)
    fallback_ranked = _dedupe_rank_files([x for x in fallback if not x.get("error")], intent=intent, limit=limit)
    store.append_event("locate", reason=query, source="helper", extra={"intent": intent, "variants": variants, "semantic_hits": len(sem), "scoped_hits": len(scoped_ranked), "fallback_hits": len(fallback_ranked)})
    return {"query": query, "intent": intent, "query_alias_hits": alias_hits[:limit], "semantic_hits": sem[:limit], "scoped_filesystem_hits": scoped_ranked, "fallback_filesystem_hits": fallback_ranked, "variants": variants, "next": "Read/verify top hits; before final answer, call commit_file_task(...) with used/found/rejected paths so the index learns."}


# Index update ---------------------------------------------------------------

def annotate_node(path: str, tags: Sequence[str] | str = (), *, brief: str = "", node_type: Optional[str] = None,
                  tier: str = "warm", state: Optional[str] = None, source: str = "agent", confidence: str = "verified",
                  seed_score: float = 0.0, evidence: Optional[Any] = None, relation: Optional[Any] = None,
                  enforce_tag_gate: bool = True) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn()
    return store.annotate_node(conn, path, tags, brief=brief, node_type=node_type, tier=tier, state=state, source=source,
                               confidence=confidence, seed_score=seed_score, evidence=evidence, relation=relation,
                               enforce_tag_gate=enforce_tag_gate, fts_ok=fts)


def annotate(path: str, tags: Sequence[str] | str = (), *, brief: str = "", source: str = "agent", tier: str = "warm", state: Optional[str] = None) -> Dict[str, Any]:
    return annotate_node(path, tags, brief=brief, source=source, tier=state or tier, confidence="verified")


def mark_used(path: str, *, matched_tags: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.mark_used(conn, path, matched_tags=matched_tags, fts_ok=fts)


def promote(path: str, *, target_tier: str = "active", target_state: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.set_tier(conn, path, target_state or target_tier, fts_ok=fts)


def demote(path: str, *, target_tier: str = "cold", target_state: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.set_tier(conn, path, target_state or target_tier, fts_ok=fts)


def decay(*, active_days: float = 14, warm_days: float = 180) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.decay(conn, active_days=active_days, warm_days=warm_days, fts_ok=fts)


def rebalance(*, max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts)


def report_file_deleted(path: str, *, reason: str = "") -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.report_file_deleted(conn, path, reason=reason, fts_ok=fts)


def report_file_changed(path: str, *, note: str = "") -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return store.report_file_changed(conn, path, note=note)


def report_file_moved(old_path: str, new_path: str) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.report_file_moved(conn, old_path, new_path, fts_ok=fts)


def report_file_created(path: str, *, brief: str, tags: Sequence[str] | str, tier: str = "warm") -> Dict[str, Any]:
    return annotate_node(path, tags, brief=brief, tier=tier, source="agent-file-created", confidence="verified")


# Cold start / miss recovery -------------------------------------------------

def begin_cold_start(*, target_nodes: int = 1000, max_active: int = 80, scope: Optional[str] = None,
                     agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", purpose: Optional[str] = None,
                     recent_limit: int = 3000, limit_per_query: int = 180, parent_levels: int = 2,
                     auto_prepare_search: bool = True) -> Dict[str, Any]:
    if auto_prepare_search:
        prep = ensure_search_ready(start=True, patch=True)
        if not prep.get("ok"):
            return {"ok": False, "stage": "ensure_search_ready", "prepare_result": prep}
    conn, _, _ = _ensure_conn()
    return builder.prepare_cold_start(conn, target_nodes=target_nodes, max_active=max_active, scope=scope,
                                      agent_queries=agent_queries, memory_text=memory_text, purpose=purpose,
                                      recent_limit=recent_limit, limit_per_query=limit_per_query,
                                      parent_levels=parent_levels)


def collect_cold_start_entries(session_id: str, *, max_queries: int = 4, recent_limit: int = 800,
                               limit_per_query: int = 80, max_entries: int = 80,
                               time_budget_sec: float = 25.0, include_recent: bool = True) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn()
    return builder.collect_cold_start_entries(conn, session_id, max_queries=max_queries,
                                              recent_limit=recent_limit, limit_per_query=limit_per_query,
                                              max_entries=max_entries, time_budget_sec=time_budget_sec,
                                              include_recent=include_recent)


def cold_start_batch(session_id: str, *, batch_size: int = 50) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.cold_start_batch(conn, session_id, batch_size=batch_size)


def propose_index_plan(session_id: str, *, batch_size: int = 30, min_confidence: float = 0.45, include_deferred: bool = False) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.propose_index_plan(conn, session_id, batch_size=batch_size, min_confidence=min_confidence, include_deferred=include_deferred)


def auto_apply_index_plan(session_id: str, *, batch_size: int = 30, min_confidence: float = 0.45) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.auto_apply_index_plan(conn, session_id, batch_size=batch_size, min_confidence=min_confidence, fts_ok=fts)


def apply_index_plan(plan: Sequence[Dict[str, Any]], *, default_tier: str = "warm", default_state: Optional[str] = None,
                     default_source: str = "agent-builder", enforce_tag_gate: bool = True,
                     session_id: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn()
    return builder.apply_index_plan(conn, plan, default_tier=default_tier, default_state=default_state,
                                    default_source=default_source, enforce_tag_gate=enforce_tag_gate,
                                    fts_ok=fts, session_id=session_id)


def cold_start_status(session_id: str) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.cold_start_status(conn, session_id)


def finish_cold_start(session_id: str, *, max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.finish_cold_start(conn, session_id, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts)


def label_worklist(*, limit: int = 80, node_types: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return builder.label_worklist(conn, limit=limit, node_types=node_types)


def miss_recovery_batch(query: str, *, memory_text: str = "", scope: Optional[str] = None, limit: int = 80) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.miss_recovery_batch(conn, query, memory_text=memory_text, scope=scope, limit=limit)


def probe_node(path: str) -> Dict[str, Any]:
    return builder.probe_node(path)


# Task-level after-hit learning ---------------------------------------------

def begin_file_task(query: str, *, intent: str = "", scope: Optional[str] = None, meta: Optional[Any] = None) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn()
    return builder.begin_file_task(conn, query, intent=intent, scope=scope, meta=meta)


def commit_file_task(*, task_id: Optional[str] = None, query: str = "", outcome: str = "success",
                     found_paths: Optional[Sequence[str]] = None, used_paths: Optional[Sequence[str]] = None,
                     created_paths: Optional[Sequence[str]] = None, modified_paths: Optional[Sequence[str]] = None,
                     moved_paths: Optional[Sequence[Sequence[str]]] = None, deleted_paths: Optional[Sequence[str]] = None,
                     rejected_paths: Optional[Sequence[str]] = None, fallback_used: bool = False,
                     intent: str = "", note: str = "", max_nodes: int = 1000, max_active: int = 80,
                     max_warm: int = 420) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn()
    return builder.commit_file_task(conn, task_id=task_id, query=query, outcome=outcome,
                                    found_paths=found_paths, used_paths=used_paths,
                                    created_paths=created_paths, modified_paths=modified_paths,
                                    moved_paths=moved_paths, deleted_paths=deleted_paths,
                                    rejected_paths=rejected_paths, fallback_used=fallback_used,
                                    intent=intent, note=note, max_nodes=max_nodes,
                                    max_active=max_active, max_warm=max_warm, fts_ok=fts)


def query_aliases(query: str, *, limit: int = 10) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn()
    return store.query_alias_hits(conn, query, limit=limit)


def virtual_tree(*, limit_per_group: int = 12) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn()
    return store.virtual_tree(conn, limit_per_group=limit_per_group)


def list_virtual_roots() -> List[str]:
    return store.list_virtual_roots()


def list_entries_by_facet(facet: str, *, include_cold: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn()
    return store.list_entries_by_facet(conn, facet, include_cold=include_cold, limit=limit)


# Config/log/audit -----------------------------------------------------------

def add_ignore_rule(rule: str) -> Dict[str, Any]:
    return store.add_ignore_rule(rule)


def ignore_rules() -> List[str]:
    return store.load_ignore_rules()


def recent_events(limit: int = 50, op: Optional[str] = None) -> List[Dict[str, Any]]:
    return store.recent_events(limit=limit, op=op)


def audit_index(*, fix: bool = False) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.audit_index(conn, fix=fix, fts_ok=fts)


# Inspection/export ----------------------------------------------------------

def stats() -> Dict[str, Any]:
    conn, fts, path = _ensure_conn(); return store.stats(conn, fts_ok=fts, db_path=path, es_ok=everything.resolve_es_exe() is not None)


def facets(*, limit: int = 30) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return store.facets(conn, limit=limit)


def list_candidates(*, tier: Optional[str] = None, state: Optional[str] = None, node_type: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_candidates(conn, tier=tier, state=state, node_type=node_type, limit=limit)


def list_by_tag(tag: str, *, include_dormant: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_by_tag(conn, tag, include_dormant=include_dormant, limit=limit)


def list_under_parent(parent: str, *, include_dormant: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_under_parent(conn, parent, include_dormant=include_dormant, limit=limit)


def export_jsonl(output_path: Optional[str] = None) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn()
    if output_path:
        with open(output_path, "w", encoding="utf-8") as fh: n = store.export_jsonl(conn, fh)
        return {"ok": True, "path": os.path.abspath(output_path), "lines": n}
    n = store.export_jsonl(conn, sys.stdout); return {"ok": True, "path": "-", "lines": n}


def print_json(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))
