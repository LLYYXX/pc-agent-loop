"""Agent-facing helper API for file_index_sop v17.

Keep this file as an execution protocol, not a design essay. Helper functions do
not infer domain semantics or create route tags automatically.
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import builder, ensure_es, everything, store

_PATH_OVERRIDE: Optional[str] = None
_CONN: Optional[sqlite3.Connection] = None
_FTS_OK = False


def _db_path_used() -> str:
    return _PATH_OVERRIDE if _PATH_OVERRIDE else store.default_db_path()


def _ensure_conn() -> Tuple[sqlite3.Connection, bool, str]:
    global _CONN, _FTS_OK
    if _CONN is None:
        _CONN = store.connect(_PATH_OVERRIDE)
        _FTS_OK = store.init_schema(_CONN)
    return _CONN, _FTS_OK, _db_path_used()


def _close_conn() -> None:
    global _CONN
    if _CONN is not None:
        _CONN.close(); _CONN = None


def print_json(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))


def init_db(db_path: Optional[str] = None) -> Dict[str, Any]:
    global _PATH_OVERRIDE
    _PATH_OVERRIDE = os.path.abspath(db_path) if db_path else None
    _close_conn(); _, fts, p = _ensure_conn()
    return {"ok": True, "db_path": p, "fts_enabled": fts, "ignore_rules": store.IGNORE_RULES_PATH, "events": store.EVENTS_PATH}


def ensure_search_ready(*, start: bool = True, patch: bool = True, dry_run: bool = False) -> Dict[str, Any]:
    return ensure_es.ensure_ready(start=start, patch=patch, dry_run=dry_run)


def search_files(query: str, *, limit: int = 50, scope: Optional[str] = None, sort_mtime_desc: bool = False, **kwargs: Any) -> List[Dict[str, Any]]:
    if not query and kwargs.get("name_pattern"):
        query = str(kwargs["name_pattern"]).strip("*")
    return everything.search(query, limit=limit, scope=scope, sort_mtime_desc=sort_mtime_desc)


def search_files_detailed(query: str, *, limit: int = 50, scope: Optional[str] = None, sort_mtime_desc: bool = False, **kwargs: Any) -> Dict[str, Any]:
    return everything.search_detailed(query, limit=limit, scope=scope, sort_mtime_desc=sort_mtime_desc)


def last_search_diagnostic() -> Dict[str, Any]:
    return everything.last_search_diagnostic()


def recent_files(*, limit: int = 500, scope: Optional[str] = None, query: str = "*") -> List[Dict[str, Any]]:
    return everything.recent(limit=limit, scope=scope, query=query)


def recall(query: str, *, limit: int = 10, include_dormant: bool = False, node_types: Optional[Sequence[str]] = None, verbose: bool = False) -> List[Dict[str, Any]]:
    conn, fts, _ = _ensure_conn()
    return store.recall(conn, query, limit=limit, include_dormant=include_dormant, node_types=node_types, fts_ok=fts, verbose=verbose)


def _dedupe_rank_files(rows: List[Dict[str, Any]], limit: int = 20) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for r in rows:
        p = r.get("path", "")
        if p and p not in seen:
            out.append(dict(r)); seen.add(p)
    return out[:limit]


def _light_intent(query: str) -> str:
    q = (query or "").lower()
    if any(x in q for x in ["找", "路径", "文件", "目录", "file", "folder"]): return "file-task"
    if any(x in q for x in ["总结", "整理", "summary"]): return "summary-task"
    return "general"


def locate(query: str, *, limit: int = 10, scope: Optional[str] = None, include_cold: bool = False, task_id: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn()
    intent = _light_intent(query)
    if not task_id:
        task = builder.begin_file_task(conn, query, intent=intent, scope=scope, meta={"source": "locate-v17"})
        task_id = task.get("task_id")
    aliases = store.query_alias_hits(conn, query, limit=limit)
    alias_hits: List[Dict[str, Any]] = []
    for a in aliases:
        for key in ("path", "entry_path"):
            p = a.get(key)
            if p and os.path.exists(p):
                alias_hits.append({"path": p, "source": "query_alias", "query_text": a.get("query_text"), "success_count": a.get("success_count"), "intent": a.get("intent")})
    sem = recall(query, limit=max(limit, 12), include_dormant=include_cold, verbose=False)
    scoped: List[Dict[str, Any]] = []
    scopes: List[str] = []
    if scope: scopes.append(scope)
    for h in alias_hits:
        p = h.get("path")
        if p and os.path.isdir(p): scopes.append(p)
        elif p: scopes.append(os.path.dirname(p))
    for hit in sem[:4]:
        if hit.get("node_type") == "dir": scopes.append(hit["path"])
    seen_scopes: List[str] = []
    for sc in scopes:
        if sc and sc not in seen_scopes and os.path.exists(sc):
            seen_scopes.append(sc)
    for sc in seen_scopes[:4]:
        try:
            scoped.extend(search_files(query, scope=sc, limit=max(3, limit // 2)))
        except Exception as e:
            scoped.append({"error": str(e), "diagnostic": last_search_diagnostic(), "scope": sc, "query": query})
    fallback: List[Dict[str, Any]] = []
    fallback_used = False
    if not [x for x in scoped if not x.get("error")]:
        fallback_used = True
        try:
            fallback.extend(search_files(query, limit=limit, scope=scope))
        except Exception as e:
            fallback.append({"error": str(e), "diagnostic": last_search_diagnostic(), "query": query})
    scoped_ranked = _dedupe_rank_files([x for x in scoped if not x.get("error")], limit=limit)
    fallback_ranked = _dedupe_rank_files([x for x in fallback if not x.get("error")], limit=limit)
    finalize_required = bool(fallback_used or fallback_ranked)
    store.append_event("locate", reason=query, source="helper-v17", extra={"task_id": task_id, "intent": intent, "semantic_hits": len(sem), "scoped_hits": len(scoped_ranked), "fallback_hits": len(fallback_ranked), "fallback_used": fallback_used})
    return {"query": query, "task_id": task_id, "intent": intent, "query_alias_hits": alias_hits[:limit], "semantic_hits": sem[:limit], "scoped_filesystem_hits": scoped_ranked, "fallback_filesystem_hits": fallback_ranked, "variants": [query], "finalize_required": finalize_required, "next": "Before final answer, call finalize_file_task(task_id, used_paths=[...]). Existing indexed hits warm up; unindexed/fallback paths draft an update plan."}


# Direct index operations ----------------------------------------------------

def annotate_node(path: str, tags: Sequence[str] | str = (), *, brief: str = "", node_type: Optional[str] = None, tier: str = "warm", state: Optional[str] = None, source: str = "agent", confidence: str = "verified", seed_score: float = 0.0, evidence: Optional[Any] = None, relation: Optional[Any] = None, enforce_tag_gate: bool = True) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn()
    return store.annotate_node(conn, path, tags, brief=brief, node_type=node_type, tier=tier, state=state, source=source, confidence=confidence, seed_score=seed_score, evidence=evidence, relation=relation, enforce_tag_gate=enforce_tag_gate, fts_ok=fts)


def mark_used(path: str, *, matched_tags: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.mark_used(conn, path, matched_tags=matched_tags, fts_ok=fts)


def promote(path: str, *, target_tier: str = "active", target_state: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.set_tier(conn, path, target_state or target_tier, fts_ok=fts)


def demote(path: str, *, target_tier: str = "cold", target_state: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.set_tier(conn, path, target_state or target_tier, fts_ok=fts)


def rebalance(*, max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts)


# Cold start -----------------------------------------------------------------

def begin_cold_start(*, target_nodes: int = 1000, max_active: int = 80, scope: Optional[str] = None, agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", purpose: Optional[str] = None, recent_limit: int = 3000, limit_per_query: int = 180, parent_levels: int = 3, auto_prepare_search: bool = True) -> Dict[str, Any]:
    if auto_prepare_search:
        prep = ensure_search_ready(start=True, patch=True)
        if not prep.get("ok"):
            return {"ok": False, "stage": "ensure_search_ready", "prepare_result": prep}
    conn, _, _ = _ensure_conn()
    return builder.prepare_cold_start(conn, target_nodes=target_nodes, max_active=max_active, scope=scope, agent_queries=agent_queries, memory_text=memory_text, purpose=purpose, recent_limit=recent_limit, limit_per_query=limit_per_query, parent_levels=parent_levels)


def collect_cold_start_entries(session_id: str, *, max_queries: int = 4, recent_limit: int = 800, limit_per_query: int = 80, max_entries: int = 80, time_budget_sec: float = 25.0, include_recent: bool = True) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn()
    return builder.collect_cold_start_entries(conn, session_id, max_queries=max_queries, recent_limit=recent_limit, limit_per_query=limit_per_query, max_entries=max_entries, time_budget_sec=time_budget_sec, include_recent=include_recent)


def cold_start_status(session_id: str) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.cold_start_status(conn, session_id)


def cold_start_batch(session_id: str, *, batch_size: int = 50) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.cold_start_batch(conn, session_id, batch_size=batch_size)


def cold_start_evidence_batch(session_id: str, *, batch_size: int = 10) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.cold_start_evidence_batch(conn, session_id, batch_size=batch_size)


def propose_index_plan(session_id: str, *, batch_size: int = 10, min_confidence: float = 0.45, include_deferred: bool = False) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.propose_index_plan(conn, session_id, batch_size=batch_size, min_confidence=min_confidence, include_deferred=include_deferred)


def auto_apply_index_plan(session_id: str, *, batch_size: int = 10, min_confidence: float = 0.45) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.auto_apply_index_plan(conn, session_id, batch_size=batch_size, min_confidence=min_confidence, fts_ok=fts)


def apply_index_plan(plan: Sequence[Dict[str, Any]], *, session_id: Optional[str] = None, default_tier: str = "warm", default_source: str = "agent-plan") -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.apply_index_plan(conn, plan, session_id=session_id, default_tier=default_tier, default_source=default_source, fts_ok=fts)


def finish_cold_start(session_id: str, *, max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.finish_cold_start(conn, session_id, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts)


def probe_node(path: str) -> Dict[str, Any]:
    return builder.probe_node(path)


def miss_recovery_batch(query: str, *, memory_text: str = "", scope: Optional[str] = None, limit: int = 80) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.miss_recovery_batch(conn, query, memory_text=memory_text, scope=scope, limit=limit)


# Task-level update ----------------------------------------------------------

def begin_file_task(query: str, *, intent: str = "", scope: Optional[str] = None, meta: Optional[Any] = None) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.begin_file_task(conn, query, intent=intent, scope=scope, meta=meta)


def draft_update_plan(*, query: str = "", task_id: Optional[str] = None, outcome: str = "success", found_paths: Optional[Sequence[str]] = None, used_paths: Optional[Sequence[str]] = None, created_paths: Optional[Sequence[str]] = None, modified_paths: Optional[Sequence[str]] = None, moved_paths: Optional[Sequence[Sequence[str]]] = None, deleted_paths: Optional[Sequence[str]] = None, rejected_paths: Optional[Sequence[str]] = None, fallback_used: bool = False, intent: str = "", note: str = "") -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.draft_update_plan(conn, query=query, task_id=task_id, outcome=outcome, found_paths=found_paths, used_paths=used_paths, created_paths=created_paths, modified_paths=modified_paths, moved_paths=moved_paths, deleted_paths=deleted_paths, rejected_paths=rejected_paths, fallback_used=fallback_used, intent=intent, note=note)


def apply_update_plan(plan_id: Optional[str] = None, *, plan: Optional[Dict[str, Any]] = None, max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.apply_update_plan(conn, plan_id=plan_id, plan=plan, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts)


def list_pending_update_plans(*, limit: int = 20) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return builder.list_pending_update_plans(conn, limit=limit)


def commit_file_task(*, task_id: Optional[str] = None, query: str = "", outcome: str = "success", found_paths: Optional[Sequence[str]] = None, used_paths: Optional[Sequence[str]] = None, created_paths: Optional[Sequence[str]] = None, modified_paths: Optional[Sequence[str]] = None, moved_paths: Optional[Sequence[Sequence[str]]] = None, deleted_paths: Optional[Sequence[str]] = None, rejected_paths: Optional[Sequence[str]] = None, fallback_used: bool = False, intent: str = "", note: str = "", mode: str = "draft", max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.commit_file_task(conn, task_id=task_id, query=query, outcome=outcome, found_paths=found_paths, used_paths=used_paths, created_paths=created_paths, modified_paths=modified_paths, moved_paths=moved_paths, deleted_paths=deleted_paths, rejected_paths=rejected_paths, fallback_used=fallback_used, intent=intent, note=note, mode=mode, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts)


def finalize_file_task(task_id: Optional[str] = None, *, query: str = "", used_paths: Optional[Sequence[str]] = None, found_paths: Optional[Sequence[str]] = None, rejected_paths: Optional[Sequence[str]] = None, fallback_used: bool = False, intent: str = "", mode: str = "draft", max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.finalize_file_task(conn, task_id=task_id, query=query, used_paths=used_paths, found_paths=found_paths, rejected_paths=rejected_paths, fallback_used=fallback_used, intent=intent, mode=mode, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts)


# Inspection/audit -----------------------------------------------------------

def query_aliases(query: str, *, limit: int = 10) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.query_alias_hits(conn, query, limit=limit)


def virtual_tree(*, limit_per_group: int = 12) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return store.virtual_tree(conn, limit_per_group=limit_per_group)


def list_virtual_roots() -> List[str]:
    return store.list_virtual_roots()


def list_entries_by_facet(facet: str, *, include_cold: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_entries_by_facet(conn, facet, include_cold=include_cold, limit=limit)


def list_by_tag(tag: str, *, include_dormant: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_by_tag(conn, tag, include_dormant=include_dormant, limit=limit)


def list_candidates(*, tier: Optional[str] = None, state: Optional[str] = None, node_type: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_candidates(conn, tier=tier, state=state, node_type=node_type, limit=limit)


def audit_index(*, fix: bool = False) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.audit_index(conn, fix=fix, fts_ok=fts)


def stats() -> Dict[str, Any]:
    conn, fts, path = _ensure_conn(); return store.stats(conn, fts_ok=fts, db_path=path, es_ok=everything.resolve_es_exe() is not None)


def facets(*, limit: int = 30) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return store.facets(conn, limit=limit)


def recent_events(limit: int = 50, op: Optional[str] = None) -> List[Dict[str, Any]]:
    return store.recent_events(limit=limit, op=op)


def ignore_rules() -> List[str]:
    return store.load_ignore_rules()


def add_ignore_rule(rule: str) -> Dict[str, Any]:
    return store.add_ignore_rule(rule)


def report_file_deleted(path: str, *, reason: str = "") -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.report_file_deleted(conn, path, reason=reason, fts_ok=fts)


def report_file_changed(path: str, *, note: str = "") -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return store.report_file_changed(conn, path, note=note)


def report_file_moved(old_path: str, new_path: str) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.report_file_moved(conn, old_path, new_path, fts_ok=fts)


def export_jsonl(output_path: Optional[str] = None) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn()
    if output_path:
        with open(output_path, "w", encoding="utf-8") as fh: n = store.export_jsonl(conn, fh)
        return {"ok": True, "path": os.path.abspath(output_path), "lines": n}
    n = store.export_jsonl(conn, sys.stdout); return {"ok": True, "path": "-", "lines": n}
