"""file_index_sop v17: Agent-driven evidence-packet semantic file index."""
__version__ = "v17"

try:
    from .helper import *  # noqa: F401,F403
except Exception:
    pass
