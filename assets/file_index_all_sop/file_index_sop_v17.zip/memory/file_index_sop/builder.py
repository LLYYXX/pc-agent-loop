"""v17 entry-first builder for the Agent-driven file semantic index.

This module deliberately does **not** infer route tags from domain keywords.
It only discovers candidates, packages local evidence, records file-task state,
validates Agent-supplied annotations, and applies confirmed index updates.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import time
import uuid
from collections import defaultdict
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import everything, store

TEXT_EXTS = {".md", ".txt", ".rst", ".py", ".js", ".ts", ".tsx", ".jsx", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".env", ".csv", ".tex"}
DOC_EXTS = {".pdf", ".md", ".txt", ".rst", ".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx", ".tex", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf"}
CONFIG_LIKE_NAMES = {"readme", "license", "makefile", "dockerfile", "requirements", "pyproject", "package", "pom", "settings", "config", "global_mem", "local_tools"}
VALID_PLAN_REF_PREFIXES = (
    "path", "basename", "file_name", "visible_terms", "probe", "document_heads", "document_seeds", "evidence_files",
    "representative_children", "leaf_candidates", "file_type_mix", "task", "user", "content_head"
)
INVALID_PLAN_REF_PARTS = ("sibling", "neighbor", "parent-only", "adjacent")

ENTRY_TARGET_FRACTION = 0.12
ENTRY_MIN_FRACTION = 0.50
TAGGED_ENTRY_MIN_FRACTION = 0.35
MIN_ENTRY_FLOOR = 20
MAX_ENTRY_TARGET = 160
DEFAULT_PARENT_LEVELS = 3
MAX_LEAF_CANDIDATES_PER_ENTRY = 24
MAX_SEED_DOCS_PER_ENTRY = 10
HASHLIKE_DIR_RE = re.compile(r"^[A-Z0-9]{6,12}$", re.I)


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path)))


def _loads(s: Any, default: Any) -> Any:
    if isinstance(s, (dict, list)):
        return s
    try:
        return json.loads(s or "")
    except Exception:
        return default


def _json(x: Any) -> str:
    return json.dumps(x, ensure_ascii=False, default=str)


def _ext(path: str) -> str:
    return os.path.splitext(os.path.basename(path))[1].lower()


def _basename_stem(path: str) -> str:
    return os.path.splitext(os.path.basename(path))[0].lower()


def _is_document_file(path: str) -> bool:
    if not os.path.isfile(path):
        return False
    ext = _ext(path)
    if ext in DOC_EXTS:
        return True
    stem = _basename_stem(path)
    return (not ext) and stem in CONFIG_LIKE_NAMES


def _is_textish(path: str) -> bool:
    if not os.path.isfile(path):
        return False
    ext = _ext(path)
    if ext in TEXT_EXTS:
        return True
    stem = _basename_stem(path)
    return (not ext) and stem in CONFIG_LIKE_NAMES


def _safe_stat(path: str) -> Dict[str, Any]:
    row: Dict[str, Any] = {"path": _norm(path), "exists": os.path.exists(path), "is_dir": os.path.isdir(path), "is_file": os.path.isfile(path)}
    try:
        st = os.stat(path, follow_symlinks=False)
        row.update({"size": int(st.st_size), "mtime_ns": int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9))), "mtime": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(st.st_mtime))})
    except OSError:
        pass
    return row


def _read_head(path: str, *, max_chars: int = 1600, max_bytes: int = 8192) -> str:
    if not _is_textish(path):
        return ""
    try:
        with open(path, "rb") as fh:
            raw = fh.read(max_bytes)
        return raw.decode("utf-8", errors="replace")[:max_chars]
    except Exception:
        return ""


def _visible_terms(path: str, limit: int = 24) -> List[str]:
    text = os.path.basename(path)
    toks = re.split(r"[^A-Za-z0-9\u4e00-\u9fff]+", text)
    out: List[str] = []
    for t in toks:
        if not t:
            continue
        if t.lower() in {"the", "and", "for", "with", "from", "file", "project", "folder"}:
            continue
        if t not in out:
            out.append(t)
        if len(out) >= limit:
            break
    return out


def _node_type(path: str) -> Optional[str]:
    if os.path.isdir(path):
        return "dir"
    if os.path.isfile(path):
        return "file"
    return None


def _type_bucket(path: str) -> str:
    if os.path.isdir(path):
        return "dir"
    ext = _ext(path).lstrip(".") or "noext"
    if _is_document_file(path):
        return "document"
    if ext in {"py", "js", "ts", "tsx", "jsx", "java", "go", "rs", "cpp", "c", "cs"}:
        return "code"
    if ext in {"json", "yaml", "yml", "toml", "ini", "cfg", "conf", "env"}:
        return "config"
    if ext in {"png", "jpg", "jpeg", "webp", "mp4", "wav", "mp3"}:
        return "media"
    return ext


def _candidate_score(path: str, *, source: str = "") -> Tuple[float, List[str]]:
    p = _norm(path)
    score = 0.0
    reasons: List[str] = []
    if not os.path.exists(p) or store.match_ignore_rules(p):
        return -9999.0, ["ignored-or-missing"]
    try:
        st = os.stat(p, follow_symlinks=False)
        age = (time.time() - st.st_mtime) / 86400
        if age < 3:
            score += 28; reasons.append("recent-3d")
        elif age < 14:
            score += 18; reasons.append("recent-14d")
        elif age < 60:
            score += 10; reasons.append("recent-60d")
    except OSError:
        pass
    if os.path.isdir(p):
        score += 12; reasons.append("directory-scope")
    if _is_document_file(p):
        score += 30; reasons.append("document-seed")
    if _is_textish(p):
        score += 8; reasons.append("text-head-readable")
    base = os.path.basename(p).lower()
    if _basename_stem(p) in CONFIG_LIKE_NAMES or base in {"readme.md", "requirements.txt", "pyproject.toml", "package.json", "pom.xml"}:
        score += 12; reasons.append("entry-evidence-file")
    if source:
        reasons.append("source:" + source)
    return score, reasons


def _dedupe_preserve(rows: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for r in rows:
        p = _norm(str(r.get("path") or ""))
        if not p or p in seen or not os.path.exists(p) or store.match_ignore_rules(p):
            continue
        rr = dict(r)
        rr["path"] = p
        out.append(rr); seen.add(p)
    return out


def _generic_discovery_jobs(scope: Optional[str], agent_queries: Sequence[str]) -> List[Dict[str, Any]]:
    jobs: List[Dict[str, Any]] = []
    # File-type/document seeds: first-class document candidates, not root detectors.
    for pat in ("*.pdf", "*.md", "*.txt", "*.docx", "*.pptx", "*.xlsx", "*.tex", "*.json", "*.yaml", "*.yml", "*.toml", "*.ini", "*.cfg", "*.conf"):
        jobs.append({"query": pat, "scope": scope, "source": "document-file-seed"})
    # Generic evidence files that often explain a directory. These do not create route tags by themselves.
    for pat in ("README.md", "readme.md", "requirements.txt", "pyproject.toml", "package.json", "pom.xml", "Dockerfile", "Makefile"):
        jobs.append({"query": pat, "scope": scope, "source": "evidence-file-seed"})
    for q in agent_queries:
        q = str(q).strip()
        if q:
            jobs.append({"query": q, "scope": scope, "source": "user-query"})
    return jobs


def prepare_cold_start(conn: sqlite3.Connection, *, target_nodes: int = 1000, max_active: int = 80, scope: Optional[str] = None,
                       agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", purpose: Optional[str] = None,
                       recent_limit: int = 3000, limit_per_query: int = 180, parent_levels: int = DEFAULT_PARENT_LEVELS) -> Dict[str, Any]:
    sid = "cs_" + uuid.uuid4().hex[:12]
    jobs = _generic_discovery_jobs(scope, list(agent_queries or []))
    meta = {
        "mode": "v17-entry-first-evidence-only",
        "scope": scope,
        "memory_text": memory_text[:2000],
        "purpose": purpose or "",
        "jobs": jobs,
        "query_cursor": 0,
        "recent_done": False,
        "collection_done": False,
        "candidate_count": 0,
        "target_entries": max(40, min(MAX_ENTRY_TARGET, int(target_nodes * ENTRY_TARGET_FRACTION))),
        "doc_seed_budget": max(80, min(260, int(target_nodes * 0.22))),
        "per_parent_leaf_cap": 8,
        "parent_levels": max(1, int(parent_levels or DEFAULT_PARENT_LEVELS)),
        "recent_limit": recent_limit,
        "limit_per_query": limit_per_query,
    }
    now = time.time()
    conn.execute("INSERT INTO build_sessions(session_id,status,target_nodes,max_active,created_at,updated_at,meta) VALUES(?,?,?,?,?,?,?)", (sid, "open", int(target_nodes), int(max_active), now, now, _json(meta)))
    conn.commit()
    store.append_event("cold_start_begin", source="builder-v17", reason=sid, extra={"scope": scope, "jobs_total": len(jobs), "mode": meta["mode"]})
    return {"ok": True, "session_id": sid, "mode": meta["mode"], "target_nodes": target_nodes, "max_active": max_active, "queries_total": len(jobs), "jobs_total": len(jobs), "query_cursor": 0, "recent_done": False, "collection_done": False, "target_entries": meta["target_entries"], "next_action": "collect_cold_start_entries(session_id)"}


def _session(conn: sqlite3.Connection, session_id: str) -> Tuple[sqlite3.Row, Dict[str, Any]]:
    row = conn.execute("SELECT * FROM build_sessions WHERE session_id=?", (session_id,)).fetchone()
    if not row:
        raise ValueError("unknown build session: " + session_id)
    return row, _loads(row["meta"], {})


def _append_unique_dicts(dst: List[Dict[str, Any]], src: Sequence[Dict[str, Any]], *, key: str = "path", limit: int = 24) -> List[Dict[str, Any]]:
    seen = {str(x.get(key) or "") for x in dst}
    for item in src:
        k = str(item.get(key) or "")
        if k and k not in seen:
            dst.append(dict(item)); seen.add(k)
        if len(dst) >= limit:
            break
    return dst


def _merge_build_item(conn: sqlite3.Connection, session_id: str, item: Dict[str, Any]) -> bool:
    """Insert or merge one entry candidate.

    v17: repeated file/document seeds under the same parent strengthen that
    parent entry packet instead of creating isolated file packets.
    """
    now = time.time()
    path = item["path"]
    old = conn.execute("SELECT * FROM build_items WHERE session_id=? AND path=?", (session_id, path)).fetchone()
    if not old:
        conn.execute("""INSERT INTO build_items(session_id,path,node_type,suggested_tier,seed_score,evidence,relation,visible_terms,status,batch_no,created_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (session_id, path, item["node_type"], item.get("suggested_tier", "warm"), float(item.get("seed_score") or 0), _json(item.get("evidence", [])), _json(item.get("relation", {})), _json(item.get("visible_terms", [])), "pending", 0, now, now))
        return True
    if old["status"] != "pending":
        return False
    rel = _loads(old["relation"], {})
    new_rel = item.get("relation") or {}
    ev = list(dict.fromkeys((_loads(old["evidence"], []) or []) + (item.get("evidence") or [])))
    terms = list(dict.fromkeys((_loads(old["visible_terms"], []) or []) + (item.get("visible_terms") or [])))[:48]
    for key in ("source_seed_paths", "document_seeds", "evidence_files"):
        rel[key] = _append_unique_dicts(list(rel.get(key) or []), list(new_rel.get(key) or []), limit=MAX_SEED_DOCS_PER_ENTRY if key != "source_seed_paths" else 40)
    rel["leaf_candidates"] = _append_unique_dicts(list(rel.get("leaf_candidates") or []), list(new_rel.get("leaf_candidates") or []), limit=MAX_LEAF_CANDIDATES_PER_ENTRY)
    rel["facets"] = list(dict.fromkeys(list(rel.get("facets") or []) + list(new_rel.get("facets") or [])))
    rel["signals"] = list(dict.fromkeys(list(rel.get("signals") or []) + list(new_rel.get("signals") or [])))[:40]
    rel["aggregation"] = rel.get("aggregation") or {}
    rel["aggregation"]["seed_count"] = len(rel.get("source_seed_paths") or []) + len(rel.get("leaf_candidates") or [])
    if not rel.get("probe") and new_rel.get("probe"):
        rel["probe"] = new_rel["probe"]
    seed = max(float(old["seed_score"] or 0), float(item.get("seed_score") or 0)) + min(18.0, 1.8 * len(rel.get("leaf_candidates") or []))
    tier = "warm" if seed >= 30 else "cold"
    conn.execute("""UPDATE build_items SET suggested_tier=?, seed_score=?, evidence=?, relation=?, visible_terms=?, updated_at=?
                    WHERE session_id=? AND path=?""",
                 (tier, seed, _json(ev), _json(rel), _json(terms), now, session_id, path))
    return False


def _looks_hashlike_dir(path: str) -> bool:
    name = os.path.basename(os.path.normpath(path))
    return bool(HASHLIKE_DIR_RE.fullmatch(name))


def _within_scope(path: str, scope: Optional[str]) -> bool:
    if not scope:
        return True
    try:
        return _norm(path).lower().startswith(_norm(scope).lower())
    except Exception:
        return True


def _ancestor_dirs_for_file(path: str, *, scope: Optional[str], parent_levels: int = DEFAULT_PARENT_LEVELS) -> List[str]:
    """Return structural directory entry candidates for a file seed.

    Files provide evidence to parent scopes. Helper does not infer semantics.
    """
    p = _norm(path)
    cur = os.path.dirname(p)
    out: List[str] = []
    levels = max(1, int(parent_levels or DEFAULT_PARENT_LEVELS))
    while cur and cur != os.path.dirname(cur) and len(out) < levels:
        if not _within_scope(cur, scope):
            break
        if os.path.isdir(cur) and not store.match_ignore_rules(cur):
            out.append(cur)
        cur = os.path.dirname(cur)
    if out and _looks_hashlike_dir(out[0]):
        up = os.path.dirname(out[0])
        if up and up != out[0] and _within_scope(up, scope) and os.path.isdir(up) and up not in out and not store.match_ignore_rules(up):
            out.append(up)
    return out


def _leaf_fact(path: str, *, source: str, score: float, reasons: Sequence[str]) -> Dict[str, Any]:
    return {"path": _norm(path), "node_type": _node_type(path), "basename": os.path.basename(path), "score": round(float(score), 3), "source": source, "reasons": list(reasons)[:8], "file_type": _type_bucket(path)}


def _document_seed_fact(path: str, *, source: str, score: float, reasons: Sequence[str]) -> Dict[str, Any]:
    fact = _leaf_fact(path, source=source, score=score, reasons=reasons)
    if _is_textish(path):
        head = _read_head(path, max_chars=900, max_bytes=4096)
        if head:
            fact["head"] = head
            fact["head_warning"] = "Head text may include references, examples, badges, or related projects. Agent must identify the candidate's own purpose before assigning route tags."
    return fact


def _facets_for_entry_candidate(path: str, reasons: Sequence[str]) -> List[str]:
    facets = ["role:entry", "candidate-scope", "entry-candidate"]
    if any("document-seed" in r for r in reasons):
        facets.append("has-document-seeds")
    if any("evidence-file" in r for r in reasons):
        facets.append("has-evidence-files")
    if any(r.startswith("source:recent") for r in reasons):
        facets.append("recently-modified")
    return list(dict.fromkeys(facets))


def _entry_item_for_seed(entry_path: str, *, seed_path: str, source: str, scope: Optional[str], parent_levels: int, ancestor_rank: int = 0) -> Optional[Dict[str, Any]]:
    ep = _norm(entry_path)
    sp = _norm(seed_path)
    if not os.path.isdir(ep) or store.match_ignore_rules(ep):
        return None
    seed_score, seed_reasons = _candidate_score(sp, source=source)
    if seed_score < 0:
        return None
    score = max(8.0, seed_score * (1.0 - min(ancestor_rank, 4) * 0.12)) + 14.0
    reasons = ["entry-from-seed", f"ancestor-rank:{ancestor_rank}"] + seed_reasons
    probe = probe_node(ep)
    rel = {
        "role": "entry",
        "entry_kind": "aggregated-entry-candidate",
        "source_seed_paths": [{"path": sp, "source": source, "ancestor_rank": ancestor_rank}],
        "document_seeds": [],
        "evidence_files": [],
        "leaf_candidates": [],
        "signals": reasons,
        "facets": _facets_for_entry_candidate(ep, reasons),
        "probe": probe,
        "aggregation": {"mode": "file/document seeds -> parent entry", "seed_count": 1},
    }
    lf = _leaf_fact(sp, source=source, score=seed_score, reasons=seed_reasons)
    rel["leaf_candidates"].append(lf)
    if _is_document_file(sp):
        rel["document_seeds"].append(_document_seed_fact(sp, source=source, score=seed_score, reasons=seed_reasons))
    else:
        rel["evidence_files"].append(lf)
    return {"path": ep, "node_type": "dir", "suggested_tier": "warm" if score >= 30 else "cold", "seed_score": round(score, 3), "evidence": [source] + reasons, "relation": rel, "visible_terms": _visible_terms(ep) + _visible_terms(sp)}


def _directory_item(path: str, *, source: str) -> Optional[Dict[str, Any]]:
    p = _norm(path)
    if not os.path.isdir(p) or store.match_ignore_rules(p):
        return None
    score, reasons = _candidate_score(p, source=source)
    if score < 0:
        return None
    rel = probe_node(p)
    rel["role"] = "entry"
    rel["entry_kind"] = "directory-seed-candidate"
    rel["signals"] = reasons
    rel["facets"] = _facets_for_entry_candidate(p, reasons)
    rel["aggregation"] = {"mode": "directory seed", "seed_count": 0}
    return {"path": p, "node_type": "dir", "suggested_tier": "warm" if score >= 26 else "cold", "seed_score": round(score + 10, 3), "evidence": [source] + reasons, "relation": rel, "visible_terms": _visible_terms(p)}


def _candidate_to_build_items(path: str, *, source: str, scope: Optional[str], parent_levels: int) -> List[Dict[str, Any]]:
    p = _norm(path)
    if not os.path.exists(p) or store.match_ignore_rules(p):
        return []
    if os.path.isdir(p):
        item = _directory_item(p, source=source)
        return [item] if item else []
    if os.path.isfile(p):
        items: List[Dict[str, Any]] = []
        for rank, entry in enumerate(_ancestor_dirs_for_file(p, scope=scope, parent_levels=parent_levels)):
            it = _entry_item_for_seed(entry, seed_path=p, source=source, scope=scope, parent_levels=parent_levels, ancestor_rank=rank)
            if it:
                items.append(it)
        return items
    return []


def _legacy_candidate_to_build_item(path: str, *, source: str, scope: Optional[str], parent_levels: int) -> Optional[Dict[str, Any]]:
    items = _candidate_to_build_items(path, source=source, scope=scope, parent_levels=parent_levels)
    return items[0] if items else None

def collect_cold_start_entries(conn: sqlite3.Connection, session_id: str, *, max_queries: int = 4, recent_limit: int = 800,
                               limit_per_query: int = 80, max_entries: int = 80, time_budget_sec: float = 25.0,
                               include_recent: bool = True) -> Dict[str, Any]:
    row, meta = _session(conn, session_id)
    scope = meta.get("scope")
    jobs = list(meta.get("jobs") or [])
    cursor = int(meta.get("query_cursor") or 0)
    parent_levels = int(meta.get("parent_levels") or 1)
    start = time.time()
    candidates: List[Tuple[str, str]] = []
    query_errors: List[str] = []
    recent_attempted = False
    if include_recent and not meta.get("recent_done"):
        recent_attempted = True
        try:
            for r in everything.recent(limit=recent_limit, scope=scope, query="*"):
                candidates.append((r["path"], "recent"))
        except Exception as e:
            query_errors.append("recent:" + str(e))
        meta["recent_done"] = True
    processed = 0
    while cursor < len(jobs) and processed < max_queries and (time.time() - start) < time_budget_sec:
        job = jobs[cursor]
        try:
            rows = everything.search(job["query"], scope=job.get("scope"), limit=limit_per_query)
            for r in rows:
                candidates.append((r["path"], job.get("source", "query")))
        except Exception as e:
            query_errors.append(f"{job.get('query')}: {e}")
        cursor += 1; processed += 1
    meta["query_cursor"] = cursor
    meta["collection_done"] = bool(cursor >= len(jobs) and meta.get("recent_done"))
    # v17 entry-first aggregation: candidate files become evidence for parent
    # directory entry packets. Files are not staged as primary build items.
    staged_paths: set[str] = set()
    merged_new = 0
    considered_items = 0
    seed_rows: List[Tuple[float, str, str]] = []
    for p, src in candidates:
        sc, _rs = _candidate_score(p, source=src)
        if sc > 0:
            seed_rows.append((sc, p, src))
    for _sc, p, src in sorted(seed_rows, key=lambda x: x[0], reverse=True):
        if len(staged_paths) >= max_entries:
            break
        for item in _candidate_to_build_items(p, source=src, scope=scope, parent_levels=parent_levels):
            considered_items += 1
            if item["path"] not in staged_paths and len(staged_paths) >= max_entries:
                break
            was_new = _merge_build_item(conn, session_id, item)
            if was_new:
                merged_new += 1
            staged_paths.add(item["path"])
    meta["candidate_count"] = int(meta.get("candidate_count") or 0) + len(candidates)
    conn.execute("UPDATE build_sessions SET meta=?,updated_at=? WHERE session_id=?", (_json(meta), time.time(), session_id))
    conn.commit()
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    return {"ok": True, "session_id": session_id, "mode": meta.get("mode"), "processed_queries": processed, "query_cursor": cursor, "queries_total": len(jobs), "recent_attempted": recent_attempted, "recent_done": bool(meta.get("recent_done")), "collection_done": bool(meta.get("collection_done")), "candidate_count_this_round": len(candidates), "staged_new": merged_new, "entry_items_considered": considered_items, "pending": pending, "elapsed_sec": round(time.time() - start, 3), "query_errors": query_errors, "next_action": "cold_start_evidence_batch" if pending else "collect_cold_start_entries"}


def cold_start_status(conn: sqlite3.Connection, session_id: str) -> Dict[str, Any]:
    row, meta = _session(conn, session_id)
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    applied = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    skipped = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='skipped'", (session_id,)).fetchone()[0]
    nodes = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
    entries = conn.execute("SELECT COUNT(*) FROM nodes WHERE json_extract(relation,'$.role')='entry'").fetchone()[0]
    target_nodes = int(row["target_nodes"])
    target_entries = int(meta.get("target_entries") or 120)
    return {"ok": True, "session_id": session_id, "status": row["status"], "mode": meta.get("mode"), "pending": pending, "applied_entries": applied, "skipped": skipped, "target_entries": target_entries, "remaining_entries": max(0, target_entries - entries), "nodes_total": nodes, "entry_nodes": entries, "target_nodes": target_nodes, "remaining_nodes": max(0, target_nodes - nodes), "max_active": int(row["max_active"]), "collection_done": bool(meta.get("collection_done")), "recent_done": bool(meta.get("recent_done")), "query_cursor": int(meta.get("query_cursor") or 0), "queries_total": len(meta.get("jobs") or []), "candidate_count_seen": int(meta.get("candidate_count") or 0), "next_action": "finish_cold_start" if pending == 0 else "cold_start_evidence_batch + apply_index_plan"}


def cold_start_batch(conn: sqlite3.Connection, session_id: str, *, batch_size: int = 50) -> Dict[str, Any]:
    rows = conn.execute("SELECT * FROM build_items WHERE session_id=? AND status='pending' ORDER BY node_type='dir' DESC, seed_score DESC, path LIMIT ?", (session_id, max(1, int(batch_size)))).fetchall()
    items = []
    for r in rows:
        items.append({"path": r["path"], "node_type": r["node_type"], "suggested_tier": r["suggested_tier"], "seed_score": r["seed_score"], "evidence": _loads(r["evidence"], []), "relation": _loads(r["relation"], {}), "visible_terms": _loads(r["visible_terms"], [])})
    return {"ok": True, "session_id": session_id, "items": items, "batch_size": len(items), "next_action": "Agent annotates evidence packets; then apply_index_plan"}


def _compact_probe_for_agent(probe: Dict[str, Any]) -> Dict[str, Any]:
    out = {k: probe.get(k) for k in ("path", "node_type", "stat", "basename", "visible_terms") if k in probe}
    if probe.get("head"):
        out["content_head"] = probe["head"][:1200]
        out["content_head_warning"] = "Head text may mention external projects, citations, badges, or examples. Route tags must describe this candidate itself, not referenced items."
    if probe.get("children"):
        out["representative_children"] = probe["children"][:30]
    if probe.get("document_heads"):
        out["document_heads"] = probe["document_heads"][:3]
        out["document_head_warning"] = "Document heads are local evidence, but Agent must decide their scope. Do not promote a child/template/reference topic to parent route tag unless it is the parent scope's main purpose."
    if probe.get("file_type_mix"):
        out["file_type_mix"] = probe["file_type_mix"]
    return out


def cold_start_evidence_batch(conn: sqlite3.Connection, session_id: str, *, batch_size: int = 10) -> Dict[str, Any]:
    batch = cold_start_batch(conn, session_id, batch_size=batch_size)
    packets = []
    for item in batch.get("items", []):
        rel = item.get("relation") or {}
        probe = rel.get("probe") or rel or {}
        packets.append({
            "path": item["path"],
            "node_type": item["node_type"],
            "suggested_tier": item.get("suggested_tier"),
            "seed_score": item.get("seed_score"),
            "visible_terms": item.get("visible_terms", []),
            "facets": rel.get("facets", []),
            "evidence": item.get("evidence", []),
            "probe": _compact_probe_for_agent(probe),
            "entry_aggregation": rel.get("aggregation", {}),
            "source_seed_paths": (rel.get("source_seed_paths") or [])[:12],
            "document_seeds": (rel.get("document_seeds") or [])[:6],
            "evidence_files": (rel.get("evidence_files") or [])[:6],
            "leaf_candidates": (rel.get("leaf_candidates") or [])[:12],
            "annotation_contract": {
                "agent_must_decide_semantics": True,
                "route_tag_rules": [
                    "打一条，对一条；数量不限，但每条必须准确。",
                    "route tag 只能描述该节点作为搜索范围或文件本体的主语义。",
                    "不能把邻居项目、父目录泛语义、引用链接、模板示例、依赖/配置文件的局部语义冒泡成父级 route tag。",
                    "每个 route tag 必须在 relation.route_tag_evidence 中引用本 packet 的证据字段。",
                    "允许 evidence refs: path, basename, file_name, visible_terms, probe.*, document_heads[*], representative_children[*], leaf_candidates[*], file_type_mix, content_head, task, user。",
                ],
                "output_plan_schema": {"path": item["path"], "action": "apply|skip", "tier": "warm|cold", "brief": "...", "tags": ["route-tag"], "relation": {"role": rel.get("role", "entry"), "route_tag_evidence": {"route-tag": ["probe.content_head"]}, "facets": rel.get("facets", [])}},
            },
        })
    return {"ok": True, "session_id": session_id, "mode": "v17-entry-first-evidence-packet", "packets": packets, "items": packets, "batch_size": len(packets), "plan": [], "next_action": "Agent/LLM annotates packets, then apply_index_plan(plan, session_id=session_id). Do not call auto_apply_index_plan."}


def propose_index_plan(conn: sqlite3.Connection, session_id: str, *, batch_size: int = 10, min_confidence: float = 0.45, include_deferred: bool = False) -> Dict[str, Any]:
    return cold_start_evidence_batch(conn, session_id, batch_size=batch_size)


def auto_apply_index_plan(conn: sqlite3.Connection, session_id: str, *, batch_size: int = 10, min_confidence: float = 0.45, fts_ok: bool = False) -> Dict[str, Any]:
    return {"ok": False, "error": "auto_apply_index_plan disabled in v17: helper does not generate semantic tags. Use cold_start_evidence_batch/propose_index_plan, let Agent annotate, then apply_index_plan.", "evidence_batch": cold_start_evidence_batch(conn, session_id, batch_size=batch_size)}


def _tag_evidence_map(item: Dict[str, Any]) -> Dict[str, Any]:
    rel = item.get("relation") or {}
    if not isinstance(rel, dict):
        rel = {}
    ev = item.get("route_tag_evidence") or item.get("evidence_refs") or rel.get("route_tag_evidence") or rel.get("evidence_refs") or {}
    return ev if isinstance(ev, dict) else {}


def _validate_evidence_refs(tag: str, refs: Any) -> Optional[str]:
    if isinstance(refs, str):
        refs = [refs]
    if not isinstance(refs, list) or not refs:
        return f"route tag '{tag}' missing evidence_ref"
    for raw in refs:
        ref = str(raw).strip()
        if not ref:
            continue
        low = ref.lower()
        if any(x in low for x in INVALID_PLAN_REF_PARTS):
            return f"route tag '{tag}' uses invalid cross-candidate evidence_ref: {ref}"
        if any(low.startswith(pfx) for pfx in VALID_PLAN_REF_PREFIXES):
            return None
    return f"route tag '{tag}' evidence_ref must cite packet evidence, not unsupported context"


def _validate_plan_item(item: Dict[str, Any]) -> Optional[str]:
    if item.get("action") == "skip":
        return None
    rel = item.get("relation") or {}
    if not isinstance(rel, dict):
        rel = {}
    role = rel.get("role") or ("leaf" if item.get("node_type") == "file" else "entry")
    tier = item.get("tier") or item.get("state") or "warm"
    raw_tags = item.get("tags") or []
    tags = [raw_tags] if isinstance(raw_tags, str) else list(raw_tags)
    tags = [str(x).strip() for x in tags if str(x).strip()]
    if tier in {"active", "warm"} and role != "leaf" and not tags:
        return "active/warm entry requires Agent-supplied route tags; use tier='cold' or action='skip' if semantics are not established"
    evmap = _tag_evidence_map(item)
    for tag in tags:
        n = store.normalize_tags([tag])
        key = tag if tag in evmap else (n[0] if n and n[0] in evmap else None)
        if not key:
            return f"route tag '{tag}' missing evidence_ref"
        err = _validate_evidence_refs(tag, evmap.get(key))
        if err:
            return err
    return None


def _materialize_leaf(conn: sqlite3.Connection, entry_path: str, leaf: Dict[str, Any], *, fts_ok: bool = False) -> Dict[str, Any]:
    p = _norm(str(leaf.get("path") or ""))
    if not p or not os.path.exists(p) or store.match_ignore_rules(p):
        return {"ok": False, "path": p, "error": "missing_or_ignored_leaf"}
    rel = {"role": "leaf", "entry": entry_path, "facets": ["support-leaf"], "source_leaf_reason": leaf.get("reasons", [])}
    brief = f"Support file under {os.path.basename(entry_path) or entry_path}: {os.path.basename(p)}"
    return store.annotate_node(conn, p, [], brief=brief, node_type=_node_type(p), tier="cold", source="agent-plan-leaf", confidence="support", seed_score=float(leaf.get("score") or 0), evidence=["materialized-from-entry", entry_path], relation=rel, fts_ok=fts_ok)


def apply_index_plan(conn: sqlite3.Connection, plan: Sequence[Dict[str, Any]], *, session_id: Optional[str] = None, default_tier: str = "warm", default_state: Optional[str] = None, default_source: str = "agent-plan", enforce_tag_gate: bool = True, fts_ok: bool = False) -> Dict[str, Any]:
    applied = skipped = materialized = 0
    errors: List[Dict[str, Any]] = []
    rejected_tags: List[Any] = []
    for item in plan or []:
        p = _norm(str(item.get("path") or ""))
        if not p:
            errors.append({"path": "", "error": "missing path"}); continue
        if item.get("action") == "skip":
            skipped += 1
            if session_id:
                conn.execute("UPDATE build_items SET status='skipped',updated_at=? WHERE session_id=? AND path=?", (time.time(), session_id, p))
            continue
        err = _validate_plan_item(item)
        if err:
            errors.append({"path": p, "error": err}); continue
        rel = item.get("relation") or {}
        if not isinstance(rel, dict):
            rel = {}
        if not rel.get("role"):
            rel["role"] = "leaf" if (item.get("node_type") == "file" or os.path.isfile(p)) else "entry"
        # Merge original build-item evidence so Agent can submit a compact plan
        # without copying all leaf_candidates back from the packet.
        if session_id:
            src_row = conn.execute("SELECT relation,evidence,seed_score FROM build_items WHERE session_id=? AND path=?", (session_id, p)).fetchone()
            if src_row:
                src_rel = _loads(src_row["relation"], {})
                if src_rel:
                    for key in ("leaf_candidates", "document_seeds", "evidence_files", "source_seed_paths"):
                        if key not in rel or not rel.get(key):
                            rel[key] = src_rel.get(key) or []
                    if "aggregation" not in rel and src_rel.get("aggregation"):
                        rel["aggregation"] = src_rel.get("aggregation")
        # preserve refs at top relation level
        evmap = _tag_evidence_map(item)
        if evmap:
            rel["route_tag_evidence"] = evmap
        tier = item.get("tier") or item.get("state") or default_state or default_tier
        res = store.annotate_node(conn, p, item.get("tags") or [], brief=item.get("brief") or "", node_type=item.get("node_type") or _node_type(p), tier=tier, source=item.get("source") or default_source, confidence=item.get("confidence") or "agent-verified", seed_score=float(item.get("seed_score") or 0), evidence=item.get("evidence") or [], relation=rel, enforce_tag_gate=enforce_tag_gate, fts_ok=fts_ok)
        if not res.get("ok"):
            errors.append({"path": p, "error": res.get("error"), "details": res}); continue
        applied += 1
        if res.get("rejected_tags"):
            rejected_tags.append({"path": p, "tags": res.get("rejected_tags")})
        # Only materialize leaf candidates from Agent-approved entry; do not infer extra semantics.
        if rel.get("role") == "entry":
            for leaf in (rel.get("leaf_candidates") or [])[:8]:
                lr = _materialize_leaf(conn, p, leaf, fts_ok=fts_ok)
                if lr.get("ok"):
                    materialized += 1
        if session_id:
            conn.execute("UPDATE build_items SET status='applied',updated_at=? WHERE session_id=? AND path=?", (time.time(), session_id, p))
    conn.commit()
    return {"applied_entries": applied, "applied": applied, "materialized_leaf_nodes": materialized, "skipped": skipped, "errors": errors, "rejected_tags": rejected_tags}


def _structural_requirements(conn: sqlite3.Connection, *, max_nodes: int, target_entries: int) -> Dict[str, Any]:
    entry_nodes = conn.execute("SELECT COUNT(*) FROM nodes WHERE json_extract(relation,'$.role')='entry'").fetchone()[0]
    dir_entry_nodes = conn.execute("SELECT COUNT(*) FROM nodes WHERE node_type='dir' AND json_extract(relation,'$.role')='entry'").fetchone()[0]
    leaf_nodes = conn.execute("SELECT COUNT(*) FROM nodes WHERE json_extract(relation,'$.role')='leaf'").fetchone()[0]
    tagged_entry_nodes = conn.execute("""SELECT COUNT(DISTINCT n.path) FROM nodes n JOIN node_tags t ON n.path=t.path
                                          WHERE json_extract(n.relation,'$.role')='entry'""").fetchone()[0]
    nodes_total = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
    entry_min = max(MIN_ENTRY_FLOOR, int(min(target_entries, max_nodes * ENTRY_TARGET_FRACTION) * ENTRY_MIN_FRACTION))
    tagged_min = max(10, int(entry_min * TAGGED_ENTRY_MIN_FRACTION))
    nodes_min = int(max_nodes * 0.50) if max_nodes >= 500 else max(50, int(max_nodes * 0.4))
    leaf_parent_missing = 0
    for (rel_s,) in conn.execute("SELECT relation FROM nodes WHERE json_extract(relation,'$.role')='leaf'"):
        rel = _loads(rel_s, {})
        ep = rel.get("entry")
        if ep and not conn.execute("SELECT 1 FROM nodes WHERE path=?", (_norm(ep),)).fetchone():
            leaf_parent_missing += 1
    return {"nodes_total": nodes_total, "entry_nodes": entry_nodes, "dir_entry_nodes": dir_entry_nodes, "leaf_nodes": leaf_nodes, "tagged_entry_nodes": tagged_entry_nodes, "entry_min": entry_min, "tagged_entry_min": tagged_min, "nodes_min": nodes_min, "leaf_parent_missing": leaf_parent_missing}


def finish_cold_start(conn: sqlite3.Connection, session_id: str, *, max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420, fts_ok: bool = False) -> Dict[str, Any]:
    st = cold_start_status(conn, session_id)
    row, meta = _session(conn, session_id)
    target_entries = int(meta.get("target_entries") or max(40, min(MAX_ENTRY_TARGET, int(max_nodes * ENTRY_TARGET_FRACTION))))
    if st["pending"] > 0:
        return {**st, "ok": False, "status": "partial", "error": "pending build items remain", "next_action": "process entry evidence_batch or skip pending items"}
    if st["remaining_entries"] > 0 and not st["collection_done"]:
        return {**st, "ok": False, "status": "partial", "error": "not enough accepted semantic entries", "next_action": "continue collect_cold_start_entries + entry evidence_batch + apply_index_plan"}
    rb = store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts_ok)
    req = _structural_requirements(conn, max_nodes=max_nodes, target_entries=target_entries)
    errors: List[str] = []
    if req["entry_nodes"] < req["entry_min"]:
        errors.append(f"entry layer too small: {req['entry_nodes']} < {req['entry_min']}")
    if req["dir_entry_nodes"] < req["entry_min"]:
        errors.append(f"directory entry layer too small: {req['dir_entry_nodes']} < {req['entry_min']}")
    if req["tagged_entry_nodes"] < req["tagged_entry_min"]:
        errors.append(f"tagged entry coverage too low: {req['tagged_entry_nodes']} < {req['tagged_entry_min']}")
    if req["nodes_total"] < req["nodes_min"]:
        errors.append(f"node count too low for target: {req['nodes_total']} < {req['nodes_min']}")
    if req["leaf_parent_missing"]:
        errors.append(f"leaf nodes without indexed parent entry: {req['leaf_parent_missing']}")
    if errors:
        conn.execute("UPDATE build_sessions SET status='partial',updated_at=? WHERE session_id=?", (time.time(), session_id))
        conn.commit()
        out = cold_start_status(conn, session_id)
        return {**out, "ok": False, "status": "partial", "error": "; ".join(errors), "structural_requirements": req, "rebalance": rb, "next_action": "Do not report completion. Continue entry aggregation/Agent annotation or explicitly lower target constraints."}
    conn.execute("UPDATE build_sessions SET status='complete',updated_at=? WHERE session_id=?", (time.time(), session_id))
    conn.commit()
    out = cold_start_status(conn, session_id)
    return {**out, "ok": True, "status": "complete", "structural_requirements": req, "rebalance": rb, "next_action": "audit_index(fix=False); stats(); virtual_tree()"}

def label_worklist(conn: sqlite3.Connection, *, limit: int = 80, node_types: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
    cond = ["tier='cold'"]
    params: List[Any] = []
    if node_types:
        ph = ",".join("?" for _ in node_types)
        cond.append(f"node_type IN ({ph})"); params.extend(node_types)
    rows = conn.execute(f"SELECT path,node_type,brief,tier,relation,evidence FROM nodes WHERE {' AND '.join(cond)} ORDER BY seed_score DESC LIMIT ?", (*params, int(limit))).fetchall()
    return [dict(r) for r in rows]


def miss_recovery_batch(conn: sqlite3.Connection, query: str, *, memory_text: str = "", scope: Optional[str] = None, limit: int = 80) -> Dict[str, Any]:
    rows = everything.search(query, scope=scope, limit=limit)
    packets = []
    for r in rows[:limit]:
        p = r["path"]
        packets.append({"path": p, "node_type": _node_type(p), "probe": _compact_probe_for_agent(probe_node(p)), "note": "Miss recovery evidence only; Agent must decide whether to draft/apply update."})
    return {"ok": True, "query": query, "scope": scope, "items": packets, "next_action": "Use draft_update_plan/finalize_file_task if these paths are actually used."}


def probe_node(path: str) -> Dict[str, Any]:
    p = _norm(path)
    nt = _node_type(p)
    out: Dict[str, Any] = {"path": p, "node_type": nt, "basename": os.path.basename(p), "stat": _safe_stat(p), "visible_terms": _visible_terms(p)}
    if nt == "file":
        head = _read_head(p)
        if head:
            out["head"] = head
        out["file_type"] = _type_bucket(p)
        return out
    if nt == "dir":
        children: List[str] = []
        type_mix: Dict[str, int] = defaultdict(int)
        doc_heads: List[Dict[str, Any]] = []
        leaf_candidates: List[Dict[str, Any]] = []
        try:
            with os.scandir(p) as it:
                entries = []
                for ent in it:
                    try:
                        if store.match_ignore_rules(ent.path):
                            continue
                        entries.append(ent)
                    except OSError:
                        continue
                entries = sorted(entries, key=lambda e: e.name.lower())[:120]
                for ent in entries:
                    children.append(ent.name)
                    typ = _type_bucket(ent.path)
                    type_mix[typ] += 1
                    if ent.is_file(follow_symlinks=False) and _is_document_file(ent.path):
                        sc, rs = _candidate_score(ent.path, source="dir-child")
                        leaf_candidates.append({"path": _norm(ent.path), "node_type": "file", "score": round(sc, 3), "basename": ent.name, "reasons": rs})
                # Sample only top few readable doc heads; avoid cost explosion.
                for leaf in sorted(leaf_candidates, key=lambda x: x.get("score", 0), reverse=True)[:3]:
                    hp = leaf["path"]
                    h = _read_head(hp, max_chars=900, max_bytes=4096)
                    if h:
                        doc_heads.append({"path": hp, "basename": os.path.basename(hp), "head": h})
        except OSError as e:
            out["error"] = str(e)
        out["children"] = children[:80]
        out["file_type_mix"] = dict(type_mix)
        out["document_heads"] = doc_heads
        out["leaf_candidates"] = sorted(leaf_candidates, key=lambda x: x.get("score", 0), reverse=True)[:12]
    return out


# -------------------------- task/update plan -------------------------------

def begin_file_task(conn: sqlite3.Connection, query: str, *, intent: str = "", scope: Optional[str] = None, meta: Optional[Any] = None) -> Dict[str, Any]:
    return store.begin_task_session(conn, query, intent=intent, scope=scope, meta=meta)


def _ensure_update_plan_table(conn: sqlite3.Connection) -> None:
    conn.execute("""CREATE TABLE IF NOT EXISTS update_plans (
      plan_id TEXT PRIMARY KEY,
      status TEXT DEFAULT 'draft',
      query_text TEXT DEFAULT '',
      intent TEXT DEFAULT '',
      mode TEXT DEFAULT 'draft',
      operations_json TEXT NOT NULL DEFAULT '[]',
      evidence_json TEXT NOT NULL DEFAULT '{}',
      created_at REAL NOT NULL,
      updated_at REAL NOT NULL
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_update_plans_status ON update_plans(status, updated_at)")
    conn.commit()


def _best_existing_entry_ancestor(conn: sqlite3.Connection, path: str) -> Optional[str]:
    p = _norm(path)
    cur = p if os.path.isdir(p) else os.path.dirname(p)
    while cur and cur != os.path.dirname(cur):
        row = conn.execute("SELECT path FROM nodes WHERE path=? AND json_extract(relation,'$.role')='entry'", (cur,)).fetchone()
        if row:
            return row[0]
        cur = os.path.dirname(cur)
    return None


def _infer_entry_for_path(path: str) -> str:
    p = _norm(path)
    if os.path.isdir(p):
        return p
    return os.path.dirname(p) or p


def _task_brief(entry: str, query: str, paths: Sequence[str]) -> str:
    base = os.path.basename(entry) or entry
    return f"Task-derived scope for query '{query[:80]}' centered on {base}; pending Agent route-tag review"


def draft_update_plan(conn: sqlite3.Connection, *, query: str = "", task_id: Optional[str] = None, outcome: str = "success",
                      found_paths: Optional[Sequence[str]] = None, used_paths: Optional[Sequence[str]] = None,
                      created_paths: Optional[Sequence[str]] = None, modified_paths: Optional[Sequence[str]] = None,
                      moved_paths: Optional[Sequence[Sequence[str]]] = None, deleted_paths: Optional[Sequence[str]] = None,
                      rejected_paths: Optional[Sequence[str]] = None, fallback_used: bool = False,
                      intent: str = "", note: str = "") -> Dict[str, Any]:
    _ensure_update_plan_table(conn)
    used = [_norm(x) for x in (used_paths or []) if str(x).strip()]
    found = [_norm(x) for x in (found_paths or []) if str(x).strip()]
    created = [_norm(x) for x in (created_paths or []) if str(x).strip()]
    modified = [_norm(x) for x in (modified_paths or []) if str(x).strip()]
    all_paths = list(dict.fromkeys(used + created + modified + found))
    ops: List[Dict[str, Any]] = []
    by_entry: Dict[str, List[str]] = defaultdict(list)
    for p in all_paths:
        if not os.path.exists(p) or store.match_ignore_rules(p):
            continue
        ep = _best_existing_entry_ancestor(conn, p) or _infer_entry_for_path(p)
        by_entry[ep].append(p)
    for ep, ps in by_entry.items():
        if not os.path.exists(ep) or store.match_ignore_rules(ep):
            continue
        rel = {"role": "entry", "entry_kind": "task-derived-entry", "facets": ["task-derived", "needs-agent-tag-review"], "source_query": query, "route_tag_evidence": {}, "leaf_candidates": [{"path": x, "reasons": ["task-evidence"]} for x in ps[:20]]}
        ops.append({"op": "upsert_entry", "path": ep, "node_type": _node_type(ep), "tier": "cold", "brief": _task_brief(ep, query, ps), "tags": [], "relation": rel, "evidence": ["task-evidence", query, intent]})
        for p in ps:
            used_flag = p in used or p in created or p in modified
            ops.append({"op": "upsert_leaf", "path": p, "entry_path": ep, "used": used_flag, "query": query})
            ops.append({"op": "record_alias", "query": query, "entry_path": ep, "path": p, "intent": intent, "evidence": {"used": used_flag, "fallback_used": fallback_used}})
        ops.append({"op": "record_alias", "query": query, "entry_path": ep, "intent": intent, "evidence": {"paths": ps[:10], "fallback_used": fallback_used}})
    for pair in moved_paths or []:
        if len(pair) >= 2:
            ops.append({"op": "move", "old_path": pair[0], "new_path": pair[1]})
    for p in deleted_paths or []:
        ops.append({"op": "delete", "path": p})
    for p in rejected_paths or []:
        ops.append({"op": "negative", "query": query, "path": p, "intent": intent, "reason": "task_rejected_path"})
    pid = "up_" + uuid.uuid4().hex[:12]
    now = time.time()
    evidence = {"task_id": task_id, "outcome": outcome, "fallback_used": fallback_used, "note": note, "found_paths": list(found_paths or [])[:20], "used_paths": list(used_paths or [])[:20], "semantic_mode": "no-auto-route-tags"}
    conn.execute("INSERT INTO update_plans(plan_id,status,query_text,intent,mode,operations_json,evidence_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)", (pid, "draft", query or "", intent or "", "draft", _json(ops), _json(evidence), now, now))
    conn.commit()
    store.append_event("update_plan_drafted", reason=query, source="task-v17", extra={"plan_id": pid, "ops": len(ops), "intent": intent, "semantic_mode": "no-auto-route-tags"})
    return {"ok": True, "plan_id": pid, "status": "draft", "query": query, "intent": intent, "operations": ops, "operation_count": len(ops), "next_action": "Review operations. Add route tags separately only after Agent evidence review; otherwise apply for aliases/warmup only."}


def list_pending_update_plans(conn: sqlite3.Connection, *, limit: int = 20) -> List[Dict[str, Any]]:
    _ensure_update_plan_table(conn)
    out = []
    for r in conn.execute("SELECT * FROM update_plans WHERE status='draft' ORDER BY updated_at DESC LIMIT ?", (max(1, int(limit)),)):
        d = dict(r)
        d["operations"] = _loads(d.pop("operations_json"), [])
        d["evidence"] = _loads(d.pop("evidence_json"), {})
        out.append(d)
    return out


def apply_update_plan(conn: sqlite3.Connection, plan_id: Optional[str] = None, *, plan: Optional[Dict[str, Any]] = None,
                      max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420, fts_ok: bool = False) -> Dict[str, Any]:
    _ensure_update_plan_table(conn)
    if plan is None:
        if not plan_id:
            return {"ok": False, "error": "plan_id or plan required"}
        row = conn.execute("SELECT * FROM update_plans WHERE plan_id=?", (plan_id,)).fetchone()
        if not row:
            return {"ok": False, "error": "update plan not found", "plan_id": plan_id}
        plan = {"plan_id": row["plan_id"], "query": row["query_text"], "intent": row["intent"], "operations": _loads(row["operations_json"], [])}
    ops = list(plan.get("operations") or [])
    applied = {"entries": 0, "leaves": 0, "aliases": 0, "negative": 0, "moves": 0, "deletes": 0, "errors": []}
    for op in ops:
        typ = op.get("op")
        try:
            if typ == "upsert_entry":
                # If this is already an indexed entry and the update plan has no
                # Agent-reviewed route tags, preserve the existing semantic node.
                # Query aliases can still point to it; tag updates require a
                # separate evidence-reviewed apply_index_plan call.
                existing = conn.execute("SELECT path FROM nodes WHERE path=?", (_norm(op["path"]),)).fetchone()
                if existing and not (op.get("tags") or []):
                    store.upsert_facets(conn, op["path"], ["task-derived", "needs-agent-tag-review"], source="update-plan")
                    applied["entries"] += 1
                    continue
                rel = op.get("relation") or {"role": "entry", "facets": ["task-derived", "needs-agent-tag-review"]}
                res = store.annotate_node(conn, op["path"], op.get("tags") or [], brief=op.get("brief") or _task_brief(op["path"], plan.get("query", ""), []), node_type=op.get("node_type") or _node_type(op["path"]), tier=op.get("tier") or "cold", source="update-plan", confidence="task-derived", evidence=op.get("evidence") or [], relation=rel, fts_ok=fts_ok)
                if res.get("ok"): applied["entries"] += 1
                else: applied["errors"].append({"op": op, "error": res.get("error")})
            elif typ == "upsert_leaf":
                p = _norm(op["path"]); ep = _norm(op.get("entry_path") or os.path.dirname(p))
                rel = {"role": "leaf", "entry": ep, "facets": ["support-leaf", "task-used" if op.get("used") else "task-found"]}
                brief = f"Task {'used' if op.get('used') else 'found'} file for query '{str(op.get('query') or '')[:80]}': {os.path.basename(p)}"
                res = store.annotate_node(conn, p, [], brief=brief, node_type=_node_type(p), tier="active" if op.get("used") else "cold", source="update-plan", confidence="task-derived", evidence=["task-evidence", op.get("query")], relation=rel, fts_ok=fts_ok)
                if res.get("ok"):
                    applied["leaves"] += 1
                    if op.get("used"):
                        store.mark_used(conn, p, fts_ok=fts_ok)
                else:
                    applied["errors"].append({"op": op, "error": res.get("error")})
            elif typ == "record_alias":
                store.record_query_alias(conn, op.get("query") or plan.get("query", ""), entry_path=op.get("entry_path"), path=op.get("path"), intent=op.get("intent") or plan.get("intent", ""), source="update-plan", evidence=op.get("evidence"))
                applied["aliases"] += 1
            elif typ == "negative":
                store.record_negative_evidence(conn, op.get("query") or plan.get("query", ""), op["path"], intent=op.get("intent") or plan.get("intent", ""), reason=op.get("reason") or "task_rejected_path", source="update-plan")
                applied["negative"] += 1
            elif typ == "move":
                store.report_file_moved(conn, op["old_path"], op["new_path"], fts_ok=fts_ok); applied["moves"] += 1
            elif typ == "delete":
                store.report_file_deleted(conn, op["path"], reason="update-plan", fts_ok=fts_ok); applied["deletes"] += 1
        except Exception as e:
            applied["errors"].append({"op": op, "error": str(e)})
    if plan_id:
        conn.execute("UPDATE update_plans SET status='applied',updated_at=? WHERE plan_id=?", (time.time(), plan_id))
    rb = store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts_ok)
    conn.commit()
    return {"ok": not applied["errors"], "plan_id": plan_id or plan.get("plan_id"), "applied": applied, "rebalance": rb}


def commit_file_task(conn: sqlite3.Connection, *, task_id: Optional[str] = None, query: str = "", outcome: str = "success",
                     found_paths: Optional[Sequence[str]] = None, used_paths: Optional[Sequence[str]] = None,
                     created_paths: Optional[Sequence[str]] = None, modified_paths: Optional[Sequence[str]] = None,
                     moved_paths: Optional[Sequence[Sequence[str]]] = None, deleted_paths: Optional[Sequence[str]] = None,
                     rejected_paths: Optional[Sequence[str]] = None, fallback_used: bool = False,
                     intent: str = "", note: str = "", mode: str = "draft", max_nodes: int = 1000,
                     max_active: int = 80, max_warm: int = 420, fts_ok: bool = False) -> Dict[str, Any]:
    if mode == "apply":
        plan = draft_update_plan(conn, query=query, task_id=task_id, outcome=outcome, found_paths=found_paths, used_paths=used_paths, created_paths=created_paths, modified_paths=modified_paths, moved_paths=moved_paths, deleted_paths=deleted_paths, rejected_paths=rejected_paths, fallback_used=fallback_used, intent=intent, note=note)
        applied = apply_update_plan(conn, plan_id=plan.get("plan_id"), max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts_ok)
        return {"ok": applied.get("ok"), "draft": plan, "apply": applied}
    return {"ok": True, "draft": draft_update_plan(conn, query=query, task_id=task_id, outcome=outcome, found_paths=found_paths, used_paths=used_paths, created_paths=created_paths, modified_paths=modified_paths, moved_paths=moved_paths, deleted_paths=deleted_paths, rejected_paths=rejected_paths, fallback_used=fallback_used, intent=intent, note=note)}


def finalize_file_task(conn: sqlite3.Connection, task_id: Optional[str] = None, *, query: str = "", used_paths: Optional[Sequence[str]] = None, found_paths: Optional[Sequence[str]] = None, rejected_paths: Optional[Sequence[str]] = None, fallback_used: bool = False, intent: str = "", mode: str = "draft", max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420, fts_ok: bool = False) -> Dict[str, Any]:
    used = [_norm(x) for x in (used_paths or []) if str(x).strip()]
    found = [_norm(x) for x in (found_paths or []) if str(x).strip()]
    existing_used: List[str] = []
    unknown_used: List[str] = []
    for p in used:
        row = conn.execute("SELECT path FROM nodes WHERE path=?", (p,)).fetchone()
        if row:
            existing_used.append(p)
        else:
            unknown_used.append(p)
    warmed = []
    for p in existing_used:
        res = store.mark_used(conn, p, fts_ok=fts_ok)
        if res.get("ok"):
            warmed.append(p)
    unknown_found = [p for p in found if not conn.execute("SELECT path FROM nodes WHERE path=?", (p,)).fetchone()]
    dirty = bool(unknown_used or unknown_found or rejected_paths or fallback_used)
    draft = None
    applied = None
    if dirty:
        draft = draft_update_plan(conn, query=query, task_id=task_id, found_paths=unknown_found + [p for p in found if p not in unknown_found], used_paths=unknown_used, rejected_paths=rejected_paths, fallback_used=fallback_used, intent=intent)
        if mode == "apply":
            applied = apply_update_plan(conn, plan_id=draft.get("plan_id"), max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts_ok)
    rb = store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, max_warm=max_warm, fts_ok=fts_ok) if warmed else {"ok": True, "changed": {}}
    conn.commit()
    return {"ok": True, "task_id": task_id, "warmed_paths": warmed, "dirty": dirty, "draft": draft, "apply": applied, "rebalance": rb, "next_action": "apply_update_plan(draft['plan_id']) after result confirmation" if draft and not applied else "done"}


def audit_index(conn: sqlite3.Connection, *, fix: bool = False, fts_ok: bool = False) -> Dict[str, Any]:
    out = {"nodes_total": 0, "entry_nodes": 0, "leaf_nodes": 0, "unknown_role_nodes": 0, "missing_paths": 0, "ignored_rule_violations": 0, "bad_node_types": 0, "bad_tag_count": 0, "generic_brief_count": 0, "active_warm_without_tags": 0, "route_tags_missing_evidence": 0, "tagged_entry_nodes": 0, "dir_entry_nodes": 0, "leaf_parent_missing": 0, "structural_warnings": [], "samples": {"missing": [], "ignored": [], "bad_tags": [], "bad_briefs": [], "active_without_tags": [], "missing_evidence": [], "leaf_parent_missing": []}}
    for r in conn.execute("SELECT path,node_type,brief,tier,relation FROM nodes"):
        out["nodes_total"] += 1
        p = r["path"]
        rel = _loads(r["relation"], {})
        role = rel.get("role")
        if role == "entry":
            out["entry_nodes"] += 1
            if r["node_type"] == "dir":
                out["dir_entry_nodes"] += 1
        elif role == "leaf":
            out["leaf_nodes"] += 1
            ep = rel.get("entry")
            if ep and not conn.execute("SELECT 1 FROM nodes WHERE path=?", (_norm(ep),)).fetchone():
                out["leaf_parent_missing"] += 1
                if len(out["samples"]["leaf_parent_missing"]) < 5:
                    out["samples"]["leaf_parent_missing"].append({"path": p, "entry": ep})
        else:
            out["unknown_role_nodes"] += 1
        if not os.path.exists(p):
            out["missing_paths"] += 1
            if len(out["samples"]["missing"]) < 5: out["samples"]["missing"].append(p)
        if store.match_ignore_rules(p):
            out["ignored_rule_violations"] += 1
            if len(out["samples"]["ignored"]) < 5: out["samples"]["ignored"].append(p)
        if _node_type(p) != r["node_type"]:
            out["bad_node_types"] += 1
        if r["tier"] in {"active", "warm"} and store.bad_brief_reason(r["brief"], p):
            out["generic_brief_count"] += 1
            if len(out["samples"]["bad_briefs"]) < 5: out["samples"]["bad_briefs"].append(p)
        tags = [x[0] for x in conn.execute("SELECT tag FROM node_tags WHERE path=?", (p,))]
        if role == "entry" and tags:
            out["tagged_entry_nodes"] += 1
        if r["tier"] in {"active", "warm"} and role != "leaf" and not tags:
            out["active_warm_without_tags"] += 1
            if len(out["samples"]["active_without_tags"]) < 5: out["samples"]["active_without_tags"].append(p)
        evmap = rel.get("route_tag_evidence") or {}
        for tag in tags:
            n = store.normalize_tags([tag])
            key = tag if tag in evmap else (n[0] if n and n[0] in evmap else tag)
            err = _validate_evidence_refs(tag, evmap.get(key))
            if err:
                out["route_tags_missing_evidence"] += 1
                if len(out["samples"]["missing_evidence"]) < 5: out["samples"]["missing_evidence"].append({"path": p, "tag": tag, "error": err})
    if out["entry_nodes"] < 20:
        out["structural_warnings"].append("entry layer is very small; index may be a file sample rather than semantic map")
    if out["tagged_entry_nodes"] < 10:
        out["structural_warnings"].append("too few tagged entries for recall")
    if out["leaf_nodes"] > max(1, out["entry_nodes"]) * 20:
        out["structural_warnings"].append("leaf/entry ratio too high; document seeds may not be aggregated")
    if out["leaf_parent_missing"]:
        out["structural_warnings"].append("some leaf nodes point to non-indexed parent entries")
    out["ok"] = not (out["missing_paths"] or out["ignored_rule_violations"] or out["bad_node_types"] or out["bad_tag_count"] or out["generic_brief_count"] or out["route_tags_missing_evidence"] or out["leaf_parent_missing"])
    return out
