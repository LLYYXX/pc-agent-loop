# 文件语义索引 v17 设计说明

v17 的修正目标：解决 v16 冷启动退化为“文件采样库”的问题。

核心结论：

1. 文档文件是一等候选，但不等于大量文件直接入库。
2. 文档 / 配置 / 最近文件 seed 应先聚合成父级目录 entry candidate。
3. Agent 主要标注 entry packet；leaf 只作为支撑材料挂在已确认 entry 下。
4. helper 不生成 route tag；只负责候选发现、证据打包、正确搜索、状态记录和校验入库。
5. finish/audit 必须做结构验收：目录 entry 数、tagged entry 数、leaf 是否有 indexed parent。
6. collection_done 只表示当前 discovery jobs 结束，不表示没有更多高价值文件。
7. 错误 tag 比没有 tag 更不可接受；打一条必须对一条，并回指 packet evidence。

v17 不引入 case detector，不对任何具体应用、项目、工作区或历史测试样本做专门规则。结构性 hash/random 父目录上跳只用于父级聚合，不产生语义。
