# v26 smoke test notes

Validated on a temporary synthetic scope:

- `from file_index_sop import *` imports successfully.
- `collect_cold_start_entries` discovers a candidate.
- Rough `apply_index_plan(..., session_id=sid)` is rejected before `expand_candidate`.
- After `expand_candidate`, type-only classifier submissions such as `python-project` with file-count evidence are rejected.
- `commit_candidate(..., evidence_refs=[...])` succeeds for an evidence-backed route tag and stores weak type labels as facets.
- `recall_hits(query)` returns a plain list of hits while recording task ledger state.
- `run_file_query(query)` returns `{task_id, recall_hits, search_hits, all_hits}`.
- `finish_local_file_task(query, used=[...])` warms used paths and triggers rebalance without requiring the Agent to maintain `task_id`.
- `record_correction` creates correction evidence and a draft update plan.
- `audit_index()` includes runtime audit and can flag recall hits without finalize.
