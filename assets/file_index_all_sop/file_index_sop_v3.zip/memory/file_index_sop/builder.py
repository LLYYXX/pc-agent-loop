"""
Agent-driven cold-start builder for file_index_sop v3.

Goal: when the user asks the Agent to build the index or triggers a cold-start
command, the Agent can call cold_start_index(...) and produce a governed SQLite
pool of ~1000 high-value/common file and directory nodes.

The module remains deterministic and framework-neutral. It does not call an LLM
API. The Agent supplies memory-informed discovery queries when available; the
code executes es.exe searches, filters/grades candidates, enforces capacity, and
writes nodes. Later the Agent can refine tags/briefs through apply_index_plan.
"""
from __future__ import annotations

import os
import re
import time
from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import everything, store

HARD_EXCLUDE_SEGMENTS = {
    ".git", ".svn", ".hg", "node_modules", "__pycache__", ".venv", "venv", "env",
    "dist", "build", "target", ".cache", "cache", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".idea", ".vscode", ".vs", "logs", "log", "tmp", "temp",
    "coverage", "site-packages", "library", "obj", "bin", "debug", "release",
    "deriveddata", "appdata", "local settings", "$recycle.bin", "system volume information",
    "wandb", "tensorboard", "checkpoints", ".ipynb_checkpoints",
}

HARD_EXCLUDE_EXTS = {
    ".pyc", ".pyo", ".class", ".o", ".obj", ".dll", ".exe", ".so", ".dylib",
    ".tmp", ".temp", ".cache", ".lock", ".log", ".bak", ".swp", ".swo",
}
MEDIA_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".mp4", ".mov", ".avi", ".mkv"}
ARCHIVE_EXTS = {".zip", ".7z", ".rar", ".tar", ".gz", ".bz2"}
TEXTISH_EXTS = {
    ".md", ".txt", ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cs", ".go", ".rs",
    ".json", ".yaml", ".yml", ".toml", ".ini", ".csv", ".tsv", ".tex", ".ipynb",
    ".sql", ".pdf", ".docx", ".xlsx", ".xls", ".pptx", ".html", ".vue",
}
ENTRY_BASENAMES = {
    "readme.md", "readme.txt", "package.json", "pyproject.toml", "requirements.txt",
    "dockerfile", "docker-compose.yml", "docker-compose.yaml", "pom.xml", "cargo.toml",
    "go.mod", "manifest.json", "main.py", "app.py", "index.js", "index.ts", "setup.py",
    "makefile", "cmakelists.txt", "environment.yml", "conda.yml",
}
PROJECT_MARKERS = {
    ".git", "package.json", "pyproject.toml", "requirements.txt", "pom.xml", "cargo.toml",
    "go.mod", "projectsettings", "assets", ".sln", "docker-compose.yml", "dockerfile",
}
DEFAULT_DISCOVERY_QUERIES = [
    "README.md", "pyproject.toml", "package.json", "requirements.txt", "docker-compose", "Dockerfile",
    "论文", "paper", "thesis", "实验", "experiment", "result", "results",
    "报销", "发票", "账单", "invoice", "receipt",
]


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _segments(path: str) -> List[str]:
    p = _norm(path)
    parts: List[str] = []
    while True:
        head, tail = os.path.split(p)
        if tail:
            parts.append(tail.lower())
            p = head
        else:
            if head:
                parts.append(head.lower())
            break
        if head == p:
            break
    return list(reversed(parts))


def _path_l(path: str) -> str:
    return _norm(path).lower().replace("\\", "/")


def memory_queries(memory_text: str = "", *, max_queries: int = 24) -> List[str]:
    """Derive short es probes from Agent Memory text. Agent may pass better queries explicitly."""
    text = memory_text or ""
    # Keep named/technical chunks and Chinese terms. This is intentionally simple.
    latin = re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", text)
    chinese = re.findall(r"[\u4e00-\u9fff]{2,10}", text)
    stop = {
        "the", "and", "with", "from", "that", "this", "agent", "model", "user", "project",
        "系统", "用户", "当前", "研究", "项目", "实现", "文件", "方向", "需要", "相关", "设计",
    }
    counts = Counter()
    for t in latin + chinese:
        key = t.strip().strip("-_ ")
        if not key or key.lower() in stop or key in stop:
            continue
        if len(key) > 40:
            continue
        counts[key] += 1
    # Prefer repeated / domain-looking terms, not generic prose fragments.
    ranked = [k for k, _ in counts.most_common(max_queries * 2)]
    out: List[str] = []
    seen = set()
    for q in ranked:
        qn = q.lower()
        if qn in seen:
            continue
        seen.add(qn)
        out.append(q)
        if len(out) >= max_queries:
            break
    return out


def merge_queries(agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", *, max_queries: int = 40) -> List[str]:
    out: List[str] = []
    seen = set()
    for q in list(agent_queries or []) + memory_queries(memory_text, max_queries=24) + DEFAULT_DISCOVERY_QUERIES:
        qs = str(q).strip()
        if not qs:
            continue
        key = qs.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(qs)
        if len(out) >= max_queries:
            break
    return out


def purpose_allows_media(purpose: Optional[str]) -> bool:
    p = (purpose or "").lower()
    return any(x in p for x in ["image", "screenshot", "素材", "图片", "截图", "报销", "invoice", "receipt", "发票", "账单"])


def classify_candidate(row: Dict[str, Any], *, purpose: Optional[str] = None, memory_terms: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    path = _norm(row.get("path", ""))
    base = os.path.basename(path)
    base_l = base.lower()
    ext = os.path.splitext(base_l)[1]
    segs = _segments(path)
    p_l = _path_l(path)
    reasons: List[str] = []
    hard = False
    score = 0.0

    bad_segments = [s for s in segs if s in HARD_EXCLUDE_SEGMENTS]
    if bad_segments:
        hard = True
        reasons.append("generated-segment:" + "/".join(bad_segments[:3]))
    if any(x in p_l for x in ["/appdata/", "/localappdata/"]) and any(x in p_l for x in ["/cache/", "/logs/", "/temp/"]):
        hard = True; reasons.append("appdata-generated")
    if re.match(r"^(~\$|\.?#|thumbs\.db$|desktop\.ini$)", base_l):
        hard = True; reasons.append("auto-filename")
    if ext in HARD_EXCLUDE_EXTS:
        hard = True; reasons.append("generated-ext:" + ext)

    if ext in TEXTISH_EXTS:
        score += 5.0; reasons.append("textish")
    if base_l in ENTRY_BASENAMES:
        score += 12.0; reasons.append("entry-file")
    if ext in MEDIA_EXTS:
        if purpose_allows_media(purpose):
            score += 1.0; reasons.append("media-allowed")
        else:
            score -= 12.0; reasons.append("media-downrank")
    if ext in ARCHIVE_EXTS:
        score += 1.0 if purpose_allows_media(purpose) else -4.0
        reasons.append("archive")

    # Domain/path signals. They are scoring signals, not tags.
    high_value_terms = [
        "论文", "paper", "thesis", "实验", "experiment", "result", "results", "eval",
        "报销", "发票", "账单", "invoice", "receipt", "resume", "简历", "课程", "课题组",
        "mcp", "agent", "trajectory", "memory", "simulation", "benchmark",
    ]
    for t in high_value_terms:
        if t.lower() in p_l:
            score += 3.0; reasons.append("path-signal:" + t)
            break
    for t in memory_terms or []:
        tl = t.lower()
        if len(tl) >= 3 and tl in p_l:
            score += 4.0; reasons.append("memory-signal:" + t[:24])
            break

    mtime_ns = row.get("mtime_ns")
    if isinstance(mtime_ns, int) and mtime_ns > 0:
        age_days = max(0.0, (time.time() - (mtime_ns / 1e9)) / 86400.0)
        if age_days < 7:
            score += 8.0; reasons.append("recent-7d")
        elif age_days < 30:
            score += 6.0; reasons.append("recent-30d")
        elif age_days < 180:
            score += 3.0; reasons.append("recent-180d")
        elif age_days < 730:
            score += 1.0; reasons.append("recent-2y")
    if row.get("is_dir"):
        score += 1.0; reasons.append("dir")
    return {"path": path, "basename": base, "parent": os.path.dirname(path), "ext": ext, "hard_exclude": hard, "score": round(score, 4), "reasons": reasons}


def filter_candidates(rows: Sequence[Dict[str, Any]], *, purpose: Optional[str] = None,
                      memory_terms: Optional[Sequence[str]] = None, keep_excluded: bool = False) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for r in rows:
        if str(r.get("path", "")).startswith("ERROR:"):
            continue
        c = classify_candidate(r, purpose=purpose, memory_terms=memory_terms)
        p = c["path"]
        if not p or p in seen:
            continue
        seen.add(p)
        if c["hard_exclude"] and not keep_excluded:
            continue
        merged = dict(r); merged.update(c)
        out.append(merged)
    out.sort(key=lambda x: (-float(x.get("score") or 0.0), x.get("path", "")))
    return out


def _is_ignored(path: str, ignored: Sequence[Dict[str, Any]]) -> bool:
    p = _norm(path)
    for r in ignored:
        rp = _norm(r.get("path", ""))
        typ = (r.get("path_type") or "prefix").lower()
        if typ == "exact" and p == rp:
            return True
        if typ == "prefix" and (p == rp or p.startswith(rp + os.sep)):
            return True
    return False


def collect_candidates(agent_queries: Optional[Sequence[str]] = None, *, memory_text: str = "", scope: Optional[str] = None,
                       limit_per_query: int = 120, include_recent: bool = True, recent_limit: int = 2000,
                       purpose: Optional[str] = None, ignored: Optional[Sequence[Dict[str, Any]]] = None,
                       keep_excluded: bool = False) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    queries = merge_queries(agent_queries, memory_text, max_queries=40)
    if include_recent:
        try:
            rows.extend(everything.recent(limit=recent_limit, scope=scope, query="*"))
        except Exception as e:
            errors.append({"path": "ERROR:recent", "error": str(e)})
    for q in queries:
        try:
            rows.extend(everything.search(q, limit=limit_per_query, scope=scope, files=True))
        except Exception as e:
            errors.append({"path": f"ERROR:{q}", "error": str(e)})
    mem_terms = memory_queries(memory_text, max_queries=32)
    filtered = filter_candidates(rows, purpose=purpose, memory_terms=mem_terms, keep_excluded=keep_excluded)
    if ignored and not keep_excluded:
        filtered = [c for c in filtered if not _is_ignored(c["path"], ignored)]
    return filtered + errors


def _parent(path: str) -> str:
    return os.path.dirname(_norm(path))


def parent_chain(path: str, *, levels: int = 2) -> List[str]:
    out: List[str] = []
    cur = _parent(path)
    for _ in range(max(0, levels)):
        if not cur or cur == os.path.dirname(cur):
            break
        out.append(cur)
        cur = os.path.dirname(cur)
    return out


def diversify_by_parent(candidates: Sequence[Dict[str, Any]], *, target: int, initial_cap_per_parent: int = 18) -> List[Dict[str, Any]]:
    """Select high-scoring candidates while preventing one directory from consuming the pool."""
    clean = [c for c in candidates if not str(c.get("path", "")).startswith("ERROR:")]
    clean.sort(key=lambda x: (-float(x.get("score") or 0.0), x.get("path", "")))
    selected: List[Dict[str, Any]] = []
    selected_paths = set()
    cap = max(1, initial_cap_per_parent)
    while len(selected) < target and cap <= 200:
        counts: Dict[str, int] = defaultdict(int)
        new_selected: List[Dict[str, Any]] = []
        new_paths = set()
        for c in clean:
            p = c["path"]
            par = c.get("parent") or _parent(p)
            if counts[par] >= cap:
                continue
            if p in new_paths:
                continue
            counts[par] += 1
            new_selected.append(c)
            new_paths.add(p)
            if len(new_selected) >= target:
                break
        selected, selected_paths = new_selected, new_paths
        if len(selected) >= target or len(selected) == len(clean):
            break
        cap *= 2
    return selected[:target]


def cluster_by_parent(candidates: Sequence[Dict[str, Any]], *, max_samples_per_cluster: int = 8, max_clusters: int = 60) -> List[Dict[str, Any]]:
    groups: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for c in candidates:
        if str(c.get("path", "")).startswith("ERROR:"):
            continue
        groups[c.get("parent") or _parent(c.get("path", ""))].append(c)
    clusters: List[Dict[str, Any]] = []
    for parent, items in groups.items():
        items_sorted = sorted(items, key=lambda x: (-float(x.get("score") or 0.0), x.get("basename", "")))
        exts = Counter((x.get("ext") or os.path.splitext(str(x.get("basename", "")))[1].lower() or "[no_ext]") for x in items)
        score_sum = sum(float(x.get("score") or 0.0) for x in items)
        clusters.append({
            "parent": parent,
            "hit_count": len(items),
            "score_sum": round(score_sum, 4),
            "extensions": dict(exts.most_common(10)),
            "top_reasons": [k for k, _ in Counter(r for x in items for r in x.get("reasons", [])).most_common(8)],
            "samples": [
                {"path": x.get("path"), "basename": x.get("basename"), "score": x.get("score"), "reasons": x.get("reasons", [])[:5]}
                for x in items_sorted[:max_samples_per_cluster]
            ],
        })
    clusters.sort(key=lambda c: (-float(c["score_sum"]), -int(c["hit_count"]), c["parent"]))
    return clusters[:max_clusters]


def brief_from_path(path: str, *, node_type: str, evidence_count: int = 0) -> str:
    """Deterministic, intentionally weak brief. Agent should refine high-value nodes later."""
    base = os.path.basename(_norm(path)) or _norm(path)
    if node_type == "dir":
        if evidence_count:
            return f"候选文件聚合目录，当前索引池中有 {evidence_count} 个相关子项。"
        return "候选目录节点，等待 Agent 基于实际任务补充语义说明。"
    return f"候选文件：{base}。等待 Agent 在实际任务中补充语义说明。"


def build_parent_nodes(files: Sequence[Dict[str, Any]], *, levels: int = 2, max_dirs: int = 220) -> List[Dict[str, Any]]:
    children: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for f in files:
        p = f.get("path")
        if not p:
            continue
        for par in parent_chain(p, levels=levels):
            children[par].append(f)
    nodes: List[Dict[str, Any]] = []
    for par, ch in children.items():
        if not ch:
            continue
        score = min(80.0, sum(float(c.get("score") or 0.0) for c in ch) * 0.18 + len(ch) * 3.5)
        state = "active" if len(ch) >= 8 and score >= 35 else ("warm" if len(ch) >= 2 else "cold")
        rel_children = [c["path"] for c in sorted(ch, key=lambda x: -float(x.get("score") or 0.0))[:80]]
        evidence = [os.path.basename(x) for x in rel_children[:12]]
        nodes.append({
            "path": par,
            "node_type": "dir",
            "tags": [],
            "brief": brief_from_path(par, node_type="dir", evidence_count=len(ch)),
            "state": state,
            "confidence": "candidate",
            "source": "cold-start-parent",
            "seed_score": round(score, 4),
            "evidence": evidence,
            "relation": {"children_in_pool": rel_children, "child_count": len(ch)},
        })
    nodes.sort(key=lambda n: (-float(n["seed_score"]), n["path"]))
    return nodes[:max_dirs]


def file_plan_from_candidates(candidates: Sequence[Dict[str, Any]], *, max_file_nodes: int, max_active_files: int) -> List[Dict[str, Any]]:
    chosen = diversify_by_parent(candidates, target=max_file_nodes, initial_cap_per_parent=18)
    plan: List[Dict[str, Any]] = []
    for i, c in enumerate(chosen):
        score = float(c.get("score") or 0.0)
        state = "active" if i < max_active_files and score >= 8 else ("warm" if score >= 4 else "cold")
        plan.append({
            "path": c["path"],
            "node_type": "file",
            "tags": [],
            "brief": brief_from_path(c["path"], node_type="file"),
            "state": state,
            "confidence": "candidate",
            "source": "cold-start-file",
            "seed_score": score,
            "evidence": c.get("reasons", [])[:8],
            "relation": {"parent": c.get("parent"), "ext": c.get("ext")},
        })
    return plan


def apply_index_plan(conn: Any, plan: Sequence[Dict[str, Any]], *, default_state: str = "warm", default_source: str = "agent-builder",
                     enforce_tag_gate: bool = True, fts_ok: bool) -> Dict[str, Any]:
    written: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    for item in plan:
        try:
            if not item.get("path"):
                raise ValueError("plan item missing path")
            res = store.annotate_node(
                conn,
                item["path"],
                item.get("tags") or [],
                brief=item.get("brief") or "",
                node_type=item.get("node_type"),
                source=item.get("source") or default_source,
                state=item.get("state") or default_state,
                confidence=item.get("confidence") or "candidate",
                seed_score=float(item.get("seed_score") or 0.0),
                evidence=item.get("evidence"),
                relation=item.get("relation"),
                enforce_tag_gate=enforce_tag_gate,
                fts_ok=fts_ok,
            )
            written.append(res)
        except Exception as e:
            errors.append({"item": item, "error": str(e)})
    return {"ok": not errors, "written_count": len(written), "written_sample": written[:10], "errors": errors}


def make_discovery_summary(candidates: Sequence[Dict[str, Any]], *, max_files: int = 60, max_clusters: int = 40) -> Dict[str, Any]:
    clean = [c for c in candidates if not str(c.get("path", "")).startswith("ERROR:")]
    errors = [c for c in candidates if str(c.get("path", "")).startswith("ERROR:")]
    return {
        "files_sample": [{"path": c.get("path"), "score": c.get("score"), "reasons": c.get("reasons", [])[:5]} for c in clean[:max_files]],
        "clusters": cluster_by_parent(clean, max_clusters=max_clusters),
        "errors": errors,
        "agent_instruction": (
            "This is a compressed observation for the Agent. If cold-start is requested, do not ask the user to choose. "
            "Use this summary to refine tags/briefs only for high-value residual semantic nodes. "
            "Tags must not repeat path/file/type facts that es.exe can search."
        ),
    }


def cold_start_index(conn: Any, *, fts_ok: bool, target_rows: int = 1000, max_active: int = 220,
                     scope: Optional[str] = None, agent_queries: Optional[Sequence[str]] = None,
                     memory_text: str = "", purpose: Optional[str] = None, recent_limit: int = 2200,
                     limit_per_query: int = 140, parent_levels: int = 2, include_dirs: bool = True,
                     ignored: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """
    One-call cold start. Produces approximately target_rows nodes using es-backed
    candidate discovery and deterministic scoring. It does not invent semantic tags.

    In SOP usage, the Agent should pass memory_text and/or agent_queries. After
    this function writes the initial pool, the Agent may call label_worklist()
    and apply_index_plan() to enrich a small subset with high-information tags.
    """
    target_rows = max(100, min(int(target_rows), 5000))
    max_active = max(20, min(int(max_active), target_rows))
    dir_budget = int(target_rows * 0.18) if include_dirs else 0
    file_budget = max(1, target_rows - dir_budget)
    active_file_budget = int(max_active * 0.70)

    cands = collect_candidates(
        agent_queries,
        memory_text=memory_text,
        scope=scope,
        limit_per_query=limit_per_query,
        include_recent=True,
        recent_limit=recent_limit,
        purpose=purpose,
        ignored=ignored,
    )
    clean = [c for c in cands if not str(c.get("path", "")).startswith("ERROR:")]
    file_plan = file_plan_from_candidates(clean, max_file_nodes=file_budget, max_active_files=active_file_budget)
    dir_plan: List[Dict[str, Any]] = []
    if include_dirs:
        selected_files = [{"path": p["path"], "score": p.get("seed_score", 0)} for p in file_plan]
        dir_plan = build_parent_nodes(selected_files, levels=parent_levels, max_dirs=dir_budget)
        # Cap active dirs so the default recall layer remains sane.
        active_dirs = max_active - sum(1 for p in file_plan if p["state"] == "active")
        seen_active = 0
        for d in dir_plan:
            if d["state"] == "active":
                seen_active += 1
                if seen_active > active_dirs:
                    d["state"] = "warm"
    plan = file_plan + dir_plan
    # If candidate volume is low, do not create fake rows.
    plan = plan[:target_rows]
    res = apply_index_plan(conn, plan, default_state="warm", default_source="cold-start", enforce_tag_gate=True, fts_ok=fts_ok)
    rb = store.rebalance(conn, max_nodes=target_rows, max_active=max_active, fts_ok=fts_ok)
    summary = make_discovery_summary(clean, max_files=40, max_clusters=25)
    return {
        "ok": res["ok"],
        "target_rows": target_rows,
        "candidate_count": len(clean),
        "planned_rows": len(plan),
        "written_count": res["written_count"],
        "errors": res["errors"][:20],
        "rebalance": rb,
        "queries_used": merge_queries(agent_queries, memory_text, max_queries=40),
        "summary": summary,
    }


def label_worklist(conn: Any, *, limit: int = 80, node_types: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
    """Return high-priority nodes that need Agent-generated brief/tags refinement."""
    allowed = {x.lower() for x in node_types} if node_types else None
    rows = conn.execute("SELECT path,node_type,brief,state,seed_score,hit_count,evidence_json,relation_json FROM nodes WHERE state!='retired' ORDER BY seed_score DESC, hit_count DESC LIMIT ?", (max(1, int(limit) * 3),)).fetchall()
    out: List[Dict[str, Any]] = []
    for r in rows:
        if allowed and r["node_type"] not in allowed:
            continue
        # Prioritize nodes with deterministic placeholder briefs or no tags.
        tag_count = conn.execute("SELECT COUNT(*) FROM node_tags WHERE path=? AND state!='retired'", (r["path"],)).fetchone()[0]
        if tag_count > 0 and r["brief"] and not str(r["brief"]).startswith("候选"):
            continue
        out.append({
            "path": r["path"],
            "node_type": r["node_type"],
            "current_brief": r["brief"] or "",
            "seed_score": r["seed_score"],
            "state": r["state"],
            "evidence": store._json_loads(r["evidence_json"], []),  # internal helper, stable enough here
            "relation": store._json_loads(r["relation_json"], {}),
            "agent_instruction": "Generate one-line brief and sparse residual tags only if they add semantic information beyond path/file/type facts.",
        })
        if len(out) >= limit:
            break
    return out
