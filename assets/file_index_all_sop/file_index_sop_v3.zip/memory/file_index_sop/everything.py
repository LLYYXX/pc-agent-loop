"""
Thin voidtools Everything CLI (es.exe) wrapper for file_index_sop v3.

This module is deliberately small and deterministic. It gives the Agent a stable
filesystem substrate API and structured results, but does not build semantic
state, patch memory, or fall back to os.walk.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from typing import Any, Dict, List, Optional

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_GLOBAL_MEM = os.path.join(_REPO_ROOT, "memory", "global_mem.txt")


def _stdout_encoding_default() -> str:
    return "mbcs" if os.name == "nt" else "utf-8"


def resolve_es_exe() -> Optional[str]:
    """Configured es.exe only: env -> L2 LOCAL_TOOLS es.exe=. No probing here."""
    for key in ("EVERYTHING_ES_EXE", "GA_ES_EXE"):
        v = (os.environ.get(key) or "").strip().strip('"').strip("'")
        if v and os.path.isfile(v):
            return os.path.normpath(os.path.abspath(v))
    if not os.path.isfile(_GLOBAL_MEM):
        return None
    try:
        raw = open(_GLOBAL_MEM, encoding="utf-8", errors="replace").read()
    except OSError:
        return None
    in_lt = False
    for line in raw.splitlines():
        st = line.strip()
        if st.upper() == "## [LOCAL_TOOLS]":
            in_lt = True
            continue
        if in_lt and st.startswith("## [") and st.endswith("]"):
            break
        if in_lt:
            m = re.match(r"^\s*es\.exe\s*=\s*(.+)$", line, re.I)
            if m:
                cand = m.group(1).strip().strip('"').strip("'")
                if cand and os.path.isfile(cand):
                    return os.path.normpath(os.path.abspath(cand))
    return None


def es_path_arg(scope_abs: str) -> str:
    s = os.path.normpath(os.path.abspath(scope_abs))
    if len(s) == 2 and s[1] == ":":
        return s + "\\"
    return s


def _stat_row(path: str) -> Dict[str, Any]:
    p = os.path.normpath(path)
    row: Dict[str, Any] = {"path": p, "basename": os.path.basename(p), "parent": os.path.dirname(p)}
    try:
        st = os.stat(p, follow_symlinks=False)
        row["is_dir"] = os.path.isdir(p)
        row["size"] = st.st_size if os.path.isfile(p) else None
        row["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
        row["ctime_ns"] = int(getattr(st, "st_ctime_ns", int(st.st_ctime * 1e9)))
    except OSError:
        pass
    return row


def search(query: str, limit: int = 50, scope: Optional[str] = None, *, sort: Optional[str] = None,
           descending: bool = True, folders: Optional[bool] = None, files: Optional[bool] = None,
           subprocess_timeout: float = 120.0) -> List[Dict[str, Any]]:
    """
    Run es.exe and return structured rows.

    Args:
        query: Raw Everything query. The wrapper intentionally does not invent
            query syntax; Agent/SOP can pass exact Everything expressions.
        limit: result cap, hard-limited to 50k.
        scope: optional path scope, passed as -path.
        sort: optional Everything sort name such as "Date Modified".
        descending: add -sort-descending when sort is set.
        folders/files: append folder: or file: to the query.
    """
    exe = resolve_es_exe()
    if not exe:
        raise FileNotFoundError("es.exe not configured. Run: python memory/file_index_sop/ensure_es.py")
    q = (query or "").strip()
    flags: List[str] = []
    if folders is True:
        flags.append("folder:")
    if files is True:
        flags.append("file:")
    if flags:
        q = " ".join(flags + ([q] if q else []))
    if not q:
        raise ValueError("search query is empty")
    limit = max(1, min(int(limit), 50000))
    enc = (os.environ.get("FILE_INDEX_ES_STDOUT_ENCODING") or os.environ.get("GRADED_ES_STDOUT_ENCODING") or "").strip() or _stdout_encoding_default()
    argv = [exe, "-n", str(limit)]
    if sort:
        argv.extend(["-sort", str(sort)])
        argv.append("-sort-descending" if descending else "-sort-ascending")
    if scope:
        argv.extend(["-path", es_path_arg(scope)])
    argv.append(q)
    kwargs: Dict[str, Any] = {
        "args": argv,
        "capture_output": True,
        "text": True,
        "encoding": enc,
        "errors": "replace",
        "timeout": float(subprocess_timeout),
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    r = subprocess.run(**kwargs)
    if r.returncode != 0 and not (r.stdout or "").strip():
        err = (r.stderr or "").strip() or f"exit {r.returncode}"
        hint = ""
        if "ipc" in err.lower():
            hint = " — 请先启动 voidtools Everything（托盘程序需常驻），以便 es.exe 通过 IPC 查询索引。"
        raise RuntimeError(f"es.exe failed: {err}{hint}")
    out: List[Dict[str, Any]] = []
    seen = set()
    for line in (r.stdout or "").splitlines():
        p = line.strip()
        if not p:
            continue
        p = os.path.normpath(p)
        if p in seen:
            continue
        seen.add(p)
        out.append(_stat_row(p))
    return out


def recent(limit: int = 500, scope: Optional[str] = None, query: str = "*") -> List[Dict[str, Any]]:
    return search(query or "*", limit=limit, scope=scope, sort="Date Modified", descending=True, files=True)


def search_error_json(err: BaseException) -> str:
    return json.dumps({"ok": False, "error": str(err), "hint": "python memory/file_index_sop/ensure_es.py"}, ensure_ascii=False)
