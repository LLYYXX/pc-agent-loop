"""
Persistence for file_index_sop v3.

Framework-neutral SQLite store for an Agent-driven file semantic coverage layer.
No GenericAgent imports, no background watcher, no vector store, no internal LLM API.

Core shape:
- nodes: file / dir cards in a governed pool of high-value candidate files and parents
- node_tags: sparse residual semantic tags, intentionally not path/extension/type words
- events: audit trail for promotion/decay/stale/build actions
- ignored_paths: reusable negative filters discovered by the Agent/builder
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_VALID_STATES = {"active", "warm", "cold", "stale", "retired"}
_VALID_NODE_TYPES = {"file", "dir", "unknown"}

# Conservative: these are usually metadata/type words that es.exe already handles.
_GENERIC_BAD_TAGS = {
    "file", "files", "folder", "directory", "dir", "document", "doc", "data", "dataset",
    "result", "results", "config", "configuration", "script", "source", "code", "src",
    "python", "py", "javascript", "typescript", "java", "csharp", "cs", "markdown", "md",
    "json", "yaml", "yml", "csv", "pdf", "docx", "xlsx", "pptx", "txt", "tex",
    "readme", "test", "tests", "experiment", "experiments", "project", "repo", "repository",
    "image", "images", "log", "logs", "cache", "tmp", "temp", "output", "outputs",
}

_INIT_SQL = """
CREATE TABLE IF NOT EXISTS nodes (
  path TEXT PRIMARY KEY,
  node_type TEXT DEFAULT 'unknown',
  brief TEXT DEFAULT '',
  size INTEGER,
  mtime_ns INTEGER,
  state TEXT DEFAULT 'warm',
  source TEXT DEFAULT 'manual',
  confidence TEXT DEFAULT 'candidate',
  seed_score REAL DEFAULT 0,
  hit_count INTEGER DEFAULT 0,
  last_access REAL,
  last_seen REAL,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  evidence_json TEXT DEFAULT '[]',
  relation_json TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS node_tags (
  path TEXT NOT NULL,
  tag TEXT NOT NULL,
  state TEXT DEFAULT 'warm',
  confidence REAL DEFAULT 1.0,
  hit_count INTEGER DEFAULT 0,
  last_hit REAL,
  source TEXT DEFAULT 'manual',
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  PRIMARY KEY(path, tag)
);

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL,
  op TEXT NOT NULL,
  path TEXT,
  tag TEXT,
  old_state TEXT,
  new_state TEXT,
  note TEXT
);

CREATE TABLE IF NOT EXISTS ignored_paths (
  path TEXT PRIMARY KEY,
  path_type TEXT DEFAULT 'prefix',
  reason TEXT DEFAULT '',
  source TEXT DEFAULT 'manual',
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL
);
"""


def default_db_path() -> str:
    env = (os.environ.get("GA_FILE_INDEX_DB") or os.environ.get("FILE_INDEX_DB") or "").strip()
    return os.path.abspath(env) if env else os.path.join(_THIS_DIR, "file_index.sqlite")


def connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    p = db_path or default_db_path()
    d = os.path.dirname(p)
    if d:
        os.makedirs(d, exist_ok=True)
    conn = sqlite3.Connection(p, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    return bool(conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone())


def valid_state(state: Optional[str], default: str = "warm") -> str:
    s = (state or "").strip().lower()
    return s if s in _VALID_STATES else default


def valid_node_type(node_type: Optional[str], default: str = "unknown") -> str:
    s = (node_type or "").strip().lower()
    return s if s in _VALID_NODE_TYPES else default


def normalize_path(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def infer_node_type(path: str) -> str:
    p = normalize_path(path)
    if os.path.isdir(p):
        return "dir"
    if os.path.isfile(p):
        return "file"
    return "unknown"


def _basename_parent(path: str) -> Tuple[str, str]:
    return os.path.basename(path), os.path.dirname(path)


def _json_dumps(obj: Any) -> str:
    return json.dumps(obj if obj is not None else {}, ensure_ascii=False, sort_keys=True)


def _json_loads(raw: Optional[str], default: Any) -> Any:
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


def _tokenize_visible(s: str) -> List[str]:
    # Enough for redundancy filtering; not intended as a tokenizer for semantic search.
    out = re.findall(r"[a-zA-Z0-9]+|[\u4e00-\u9fff]{2,}", s.lower())
    return [x for x in out if x]


def observable_terms(path: str, *, parent_depth: int = 3) -> Set[str]:
    p = normalize_path(path)
    base = os.path.basename(p)
    stem, ext = os.path.splitext(base)
    terms: Set[str] = set(_tokenize_visible(stem))
    if ext:
        terms.update(_tokenize_visible(ext.lstrip(".")))
    par = os.path.dirname(p)
    for _ in range(parent_depth):
        if not par or par == os.path.dirname(par):
            break
        terms.update(_tokenize_visible(os.path.basename(par)))
        par = os.path.dirname(par)
    return {t for t in terms if t}


def normalize_tags(tags: Sequence[str] | str) -> List[str]:
    if isinstance(tags, str):
        parts = re.split(r"[,;\n]+", tags)
    else:
        parts = [str(x) for x in tags]
    out: List[str] = []
    seen: Set[str] = set()
    for t in parts:
        t = " ".join(t.strip().lower().split()).replace(" ", "-").replace("_", "-")
        t = t.strip("-_/\\.,;:|[]{}()<>\"'")
        if not t or t in seen:
            continue
        seen.add(t)
        out.append(t)
    return out


def is_redundant_tag(tag: str, path: str) -> bool:
    tg = tag.strip().lower().replace("_", "-")
    if not tg:
        return True
    if tg in _GENERIC_BAD_TAGS:
        return True
    obs = observable_terms(path)
    chunks = [c for c in re.split(r"[-_/]+", tg) if c]
    if not chunks:
        return True
    if tg in obs:
        return True
    # Reject pure path/type combinations such as file-index-sop, python-script, result-csv.
    return all((c in obs or c in _GENERIC_BAD_TAGS) for c in chunks)


def filter_high_info_tags(tags: Sequence[str] | str, path: str) -> Tuple[List[str], List[str]]:
    kept: List[str] = []
    rejected: List[str] = []
    for tg in normalize_tags(tags):
        if is_redundant_tag(tg, path):
            rejected.append(tg)
        else:
            kept.append(tg)
    return kept, rejected


def _migrate_v1_if_present(conn: sqlite3.Connection) -> None:
    """Copy old files/file_tags rows into nodes/node_tags if a v1 DB is reused."""
    now = time.time()
    if _table_exists(conn, "files"):
        try:
            for r in conn.execute("SELECT path, brief, size, mtime_ns, state, hit_count, last_access, created_at, updated_at FROM files"):
                p = normalize_path(r["path"])
                conn.execute(
                    """INSERT OR IGNORE INTO nodes(path,node_type,brief,size,mtime_ns,state,source,confidence,seed_score,hit_count,last_access,last_seen,created_at,updated_at,evidence_json,relation_json)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (p, infer_node_type(p), r["brief"] or "", r["size"], r["mtime_ns"], valid_state(r["state"], "warm"),
                     "migrated-v1", "candidate", 0.0, r["hit_count"] or 0, r["last_access"], now,
                     r["created_at"] or now, r["updated_at"] or now, "[]", "{}"),
                )
        except sqlite3.OperationalError:
            pass
    if _table_exists(conn, "file_tags"):
        try:
            for r in conn.execute("SELECT path, tag, state, confidence, hit_count, last_hit, source, created_at, updated_at FROM file_tags"):
                p = normalize_path(r["path"])
                conn.execute(
                    """INSERT OR IGNORE INTO node_tags(path,tag,state,confidence,hit_count,last_hit,source,created_at,updated_at)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (p, r["tag"], valid_state(r["state"], "warm"), r["confidence"] if r["confidence"] is not None else 1.0,
                     r["hit_count"] or 0, r["last_hit"], r["source"] or "migrated-v1", r["created_at"] or now, r["updated_at"] or now),
                )
        except sqlite3.OperationalError:
            pass


def try_create_fts(conn: sqlite3.Connection) -> bool:
    try:
        conn.execute(
            """CREATE VIRTUAL TABLE IF NOT EXISTS node_fts
               USING fts5(path UNINDEXED, basename, parent, tags_text, brief,
                         tokenize = 'unicode61 remove_diacritics 2');"""
        )
        conn.commit()
        return True
    except sqlite3.OperationalError:
        conn.rollback()
        try:
            conn.execute("DROP TABLE IF EXISTS node_fts")
            conn.commit()
        except sqlite3.OperationalError:
            conn.rollback()
        return False


def init_schema(conn: sqlite3.Connection) -> bool:
    conn.executescript(_INIT_SQL)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_state ON nodes(state)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(node_type)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_last_access ON nodes(last_access)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_seed_score ON nodes(seed_score)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_source ON nodes(source)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_node_tags_tag ON node_tags(tag)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_node_tags_state ON node_tags(state)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_node_tags_last_hit ON node_tags(last_hit)")
    _migrate_v1_if_present(conn)
    conn.commit()
    ok = try_create_fts(conn)
    fts_rebuild_all(conn, fts_ok=ok)
    return ok


def log_event(conn: sqlite3.Connection, op: str, *, path: Optional[str] = None, tag: Optional[str] = None,
              old_state: Optional[str] = None, new_state: Optional[str] = None, note: Optional[str] = None) -> None:
    conn.execute(
        "INSERT INTO events(ts,op,path,tag,old_state,new_state,note) VALUES (?,?,?,?,?,?,?)",
        (time.time(), op, path, tag, old_state, new_state, note),
    )


def _tags_text(conn: sqlite3.Connection, path: str) -> str:
    rows = conn.execute("SELECT tag FROM node_tags WHERE path=? AND state!='retired' ORDER BY tag", (path,)).fetchall()
    return " ".join(r[0] for r in rows)


def fts_sync_row(conn: sqlite3.Connection, path: str, *, fts_ok: bool) -> None:
    if not fts_ok:
        return
    p = normalize_path(path)
    conn.execute("DELETE FROM node_fts WHERE path=?", (p,))
    row = conn.execute("SELECT brief,state FROM nodes WHERE path=?", (p,)).fetchone()
    if not row or row["state"] == "retired":
        return
    base, parent = _basename_parent(p)
    conn.execute(
        "INSERT INTO node_fts(path,basename,parent,tags_text,brief) VALUES (?,?,?,?,?)",
        (p, base, parent, _tags_text(conn, p), row["brief"] or ""),
    )


def fts_rebuild_all(conn: sqlite3.Connection, *, fts_ok: bool) -> None:
    if not fts_ok:
        return
    conn.execute("DELETE FROM node_fts")
    for r in conn.execute("SELECT path FROM nodes WHERE state!='retired'"):
        fts_sync_row(conn, r[0], fts_ok=True)
    conn.commit()


def allowed_states(include_dormant: bool, include_retired: bool) -> Set[str]:
    if include_retired:
        return {"active", "warm", "cold", "stale", "retired"}
    if include_dormant:
        return {"active", "warm", "cold", "stale"}
    return {"active", "warm"}


def _state_weight(st: str) -> float:
    return {"active": 8.0, "warm": 6.2, "cold": 3.2, "stale": 1.4, "retired": -1e6}.get(st, 0.0)


def _recent_weight(ts: Optional[float]) -> float:
    if ts is None or ts <= 0:
        return 0.0
    age_days = (time.time() - ts) / 86400.0
    return max(0.0, 2.0 - min(age_days / 45.0, 2.0))


def _fts_match_expr(tokens: List[str]) -> Optional[str]:
    parts = []
    for t in tokens:
        clean = t.replace('"', '').strip()
        if clean:
            parts.append(f'"{clean}"')
    return " AND ".join(parts) if parts else None


def annotate_node(conn: sqlite3.Connection, path: str, tags: Sequence[str] | str = (), *, brief: str = "",
                  node_type: Optional[str] = None, source: str = "manual", state: str = "active",
                  confidence: str = "verified", seed_score: float = 0.0,
                  evidence: Optional[Sequence[Any]] = None, relation: Optional[Dict[str, Any]] = None,
                  enforce_tag_gate: bool = True, fts_ok: bool) -> Dict[str, Any]:
    p = normalize_path(path)
    now = time.time()
    nt = valid_node_type(node_type, infer_node_type(p))
    st = valid_state(state, "warm")
    brief_in = (brief or "").strip()
    sz: Optional[int] = None
    mt_ns: Optional[int] = None
    if os.path.isfile(p):
        try:
            s = os.stat(p, follow_symlinks=False)
            sz = int(s.st_size)
            mt_ns = int(getattr(s, "st_mtime_ns", int(s.st_mtime * 1e9)))
        except OSError:
            pass
    elif os.path.isdir(p):
        try:
            s = os.stat(p, follow_symlinks=False)
            mt_ns = int(getattr(s, "st_mtime_ns", int(s.st_mtime * 1e9)))
        except OSError:
            pass

    prev = conn.execute("SELECT brief,created_at,hit_count,last_access,evidence_json,relation_json,source FROM nodes WHERE path=?", (p,)).fetchone()
    merged_brief = brief_in if brief_in else ((prev["brief"] or "").strip() if prev else "")
    created = prev["created_at"] if prev else now
    hc = prev["hit_count"] if prev else 0
    lac = prev["last_access"] if prev else None

    old_evidence = _json_loads(prev["evidence_json"], []) if prev else []
    ev = list(evidence) if evidence is not None else old_evidence
    old_relation = _json_loads(prev["relation_json"], {}) if prev else {}
    rel = dict(old_relation)
    if relation:
        rel.update(relation)

    conn.execute(
        """INSERT INTO nodes(path,node_type,brief,size,mtime_ns,state,source,confidence,seed_score,hit_count,last_access,last_seen,created_at,updated_at,evidence_json,relation_json)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
           ON CONFLICT(path) DO UPDATE SET
             node_type=excluded.node_type,
             brief=CASE WHEN excluded.brief!='' THEN excluded.brief ELSE nodes.brief END,
             size=COALESCE(excluded.size,nodes.size),
             mtime_ns=COALESCE(excluded.mtime_ns,nodes.mtime_ns),
             state=excluded.state,
             source=excluded.source,
             confidence=excluded.confidence,
             seed_score=MAX(nodes.seed_score, excluded.seed_score),
             last_seen=excluded.last_seen,
             updated_at=excluded.updated_at,
             evidence_json=excluded.evidence_json,
             relation_json=excluded.relation_json""",
        (p, nt, merged_brief, sz, mt_ns, st, source, confidence, float(seed_score or 0.0),
         hc if prev else 0, lac, now, created, now, _json_dumps(ev), _json_dumps(rel)),
    )

    kept, rejected = filter_high_info_tags(tags, p) if enforce_tag_gate else (normalize_tags(tags), [])
    log_event(conn, "annotate_node", path=p, new_state=st, note=_json_dumps({"tags": kept, "rejected_tags": rejected, "source": source}))
    for tg in kept:
        conn.execute(
            """INSERT INTO node_tags(path,tag,state,confidence,hit_count,last_hit,source,created_at,updated_at)
               VALUES (?,?,?,?,?,?,?,?,?)
               ON CONFLICT(path,tag) DO UPDATE SET
                 state=excluded.state,
                 source=excluded.source,
                 confidence=MAX(node_tags.confidence, excluded.confidence),
                 updated_at=excluded.updated_at""",
            (p, tg, st, 1.0, 0, None, source, now, now),
        )
        log_event(conn, "tag_upsert", path=p, tag=tg, new_state=st)
    fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return {"ok": True, "path": p, "node_type": nt, "state": st, "tags": kept, "rejected_tags": rejected, "brief": merged_brief}


def recall(conn: sqlite3.Connection, query: str, *, limit: int = 10, include_dormant: bool = False,
           include_retired: bool = False, node_types: Optional[Sequence[str]] = None,
           fts_ok: bool, verbose: bool = False) -> List[Dict[str, Any]]:
    tokens = [t for t in re.split(r"\s+", (query or "").strip().lower()) if t]
    if not tokens:
        return []
    states = sorted(allowed_states(include_dormant, include_retired))
    ph = ",".join("?" * len(states))
    allow = tuple(states)
    type_filter = {valid_node_type(t) for t in node_types} if node_types else None

    candidates: Set[str] = set()
    expr = _fts_match_expr(tokens)
    if fts_ok and expr:
        try:
            sql = f"SELECT f.path FROM node_fts fts JOIN nodes f ON f.path=fts.path WHERE fts MATCH ? AND f.state IN ({ph})"
            for r in conn.execute(sql, (expr, *allow)):
                candidates.add(r[0])
        except sqlite3.OperationalError:
            pass

    for tok in tokens:
        li = f"%{tok}%"
        for r in conn.execute(f"SELECT path FROM nodes WHERE state IN ({ph}) AND (LOWER(path) LIKE ? OR LOWER(IFNULL(brief,'')) LIKE ?)", (*allow, li, li)):
            candidates.add(r[0])
        for r in conn.execute(f"SELECT DISTINCT path FROM node_tags WHERE state IN ({ph}) AND LOWER(tag) LIKE ?", (*allow, li)):
            candidates.add(r[0])

    out: List[Dict[str, Any]] = []
    for p in candidates:
        n = conn.execute("SELECT * FROM nodes WHERE path=?", (p,)).fetchone()
        if not n or n["state"] not in allow:
            continue
        if type_filter and n["node_type"] not in type_filter:
            continue
        path = n["path"]
        brief = n["brief"] or ""
        base, parent = _basename_parent(path)
        tag_rows = [r for r in conn.execute("SELECT tag,state,hit_count,last_hit FROM node_tags WHERE path=?", (path,)) if r["state"] in allow]
        score = _state_weight(n["state"]) + min((n["hit_count"] or 0) * 0.06, 2.0) + _recent_weight(n["last_access"])
        reasons: List[str] = []
        for tr in tag_rows:
            score += _state_weight(tr["state"]) * 0.25 + min((tr["hit_count"] or 0) * 0.04, 1.0) + _recent_weight(tr["last_hit"]) * 0.4
        for tok in tokens:
            tag_hit = False
            for tr in tag_rows:
                tg = (tr["tag"] or "").lower()
                if tok == tg:
                    score += 46.0; reasons.append("tag-exact"); tag_hit = True; break
                if len(tok) >= 2 and tok in tg:
                    score += 27.0; reasons.append("tag-partial"); tag_hit = True; break
            if brief and tok in brief.lower():
                score += 15.0 + (4.0 if not tag_hit else 0.0); reasons.append("brief")
            # Weak fallback only. Everything remains the real metadata substrate.
            if tok in base.lower():
                score += 5.0; reasons.append("basename")
            if tok in path.lower():
                score += 2.3; reasons.append("path")
            if tok in parent.lower():
                score += 1.0; reasons.append("parent")
        if n["state"] == "stale":
            score -= 8.0; reasons.append("stale")
        row: Dict[str, Any] = {
            "path": path,
            "node_type": n["node_type"],
            "tags": [r["tag"] for r in tag_rows],
            "brief": brief,
            "state": n["state"],
            "score": round(score, 4),
            "reason": ";".join(sorted(set(reasons))) if reasons else "ranked",
        }
        if verbose:
            row.update({
                "parent": parent,
                "basename": base,
                "hit_count": n["hit_count"],
                "last_access": n["last_access"],
                "seed_score": n["seed_score"],
                "confidence": n["confidence"],
                "evidence": _json_loads(n["evidence_json"], []),
                "relation": _json_loads(n["relation_json"], {}),
            })
        out.append(row)
    out.sort(key=lambda x: (-x["score"], x["path"]))
    return out[: max(1, int(limit))]


def mark_used(conn: sqlite3.Connection, path: str, *, matched_tags: Optional[Sequence[str]] = None, fts_ok: bool) -> Dict[str, Any]:
    p = normalize_path(path)
    row = conn.execute("SELECT state FROM nodes WHERE path=?", (p,)).fetchone()
    if not row:
        return {"ok": False, "error": "path not indexed", "path": p}
    old = row["state"]
    new = "warm" if old in {"cold", "stale"} else ("active" if old == "warm" else old)
    now = time.time()
    conn.execute("UPDATE nodes SET hit_count=hit_count+1,last_access=?,state=?,updated_at=? WHERE path=?", (now, new, now, p))
    if new != old:
        log_event(conn, "promote_node", path=p, old_state=old, new_state=new)
    if matched_tags is not None:
        wanted = set(normalize_tags(list(matched_tags)))
        for tr in conn.execute("SELECT tag,state FROM node_tags WHERE path=?", (p,)):
            if tr["tag"] not in wanted or tr["state"] == "retired":
                continue
            t_old = tr["state"]
            t_new = "warm" if t_old in {"cold", "stale"} else ("active" if t_old == "warm" else t_old)
            conn.execute("UPDATE node_tags SET hit_count=hit_count+1,last_hit=?,state=?,updated_at=? WHERE path=? AND tag=?", (now, t_new, now, p, tr["tag"]))
            if t_new != t_old:
                log_event(conn, "promote_tag", path=p, tag=tr["tag"], old_state=t_old, new_state=t_new)
    fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return {"ok": True, "path": p, "old_state": old, "new_state": new}


def set_state(conn: sqlite3.Connection, path: str, state: str, *, tag: Optional[str] = None, fts_ok: bool) -> Dict[str, Any]:
    p = normalize_path(path)
    st = valid_state(state, "warm")
    now = time.time()
    if tag:
        tg = normalize_tags([tag])[0]
        old = conn.execute("SELECT state FROM node_tags WHERE path=? AND tag=?", (p, tg)).fetchone()
        conn.execute("UPDATE node_tags SET state=?,updated_at=? WHERE path=? AND tag=?", (st, now, p, tg))
        log_event(conn, "set_tag_state", path=p, tag=tg, old_state=old[0] if old else None, new_state=st)
    else:
        old = conn.execute("SELECT state FROM nodes WHERE path=?", (p,)).fetchone()
        conn.execute("UPDATE nodes SET state=?,updated_at=? WHERE path=?", (st, now, p))
        conn.execute("UPDATE node_tags SET state=?,updated_at=? WHERE path=? AND state!='retired'", (st, now, p))
        log_event(conn, "set_node_state", path=p, old_state=old[0] if old else None, new_state=st)
    fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return {"ok": True, "path": p, "state": st, "tag": tag}


def decay(conn: sqlite3.Connection, *, active_days: float = 30.0, warm_days: float = 90.0, fts_ok: bool) -> Dict[str, int]:
    now = time.time()
    out = {"active_to_warm": 0, "warm_to_cold": 0}
    for r in conn.execute("SELECT path,state,last_access FROM nodes WHERE state IN ('active','warm')"):
        p, st, la = r["path"], r["state"], r["last_access"]
        age = None if la is None else (now - la) / 86400.0
        new = st
        if st == "active" and (age is None or age > active_days):
            new = "warm"; out["active_to_warm"] += 1
        elif st == "warm" and (age is None or age > warm_days):
            new = "cold"; out["warm_to_cold"] += 1
        if new != st:
            conn.execute("UPDATE nodes SET state=?,updated_at=? WHERE path=?", (new, now, p))
            conn.execute("UPDATE node_tags SET state=?,updated_at=? WHERE path=? AND state!='retired'", (new, now, p))
            log_event(conn, "decay_node", path=p, old_state=st, new_state=new)
            fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return out


def check_stale(conn: sqlite3.Connection, path: Optional[str] = None, *, fts_ok: bool) -> Dict[str, int]:
    now = time.time()
    stale = retired = 0
    paths = [normalize_path(path)] if path else [r[0] for r in conn.execute("SELECT path FROM nodes")]
    for p in paths:
        rec = conn.execute("SELECT mtime_ns,state,node_type FROM nodes WHERE path=?", (p,)).fetchone()
        if not rec:
            continue
        if not os.path.exists(p):
            conn.execute("UPDATE nodes SET state='retired',updated_at=? WHERE path=?", (now, p))
            conn.execute("UPDATE node_tags SET state='retired',updated_at=? WHERE path=?", (now, p))
            log_event(conn, "path_missing", path=p, old_state=rec["state"], new_state="retired")
            retired += 1; fts_sync_row(conn, p, fts_ok=fts_ok); continue
        try:
            s = os.stat(p, follow_symlinks=False)
            cur = int(getattr(s, "st_mtime_ns", int(s.st_mtime * 1e9)))
        except OSError:
            continue
        if rec["mtime_ns"] is None or cur != rec["mtime_ns"]:
            conn.execute("UPDATE nodes SET state='stale',mtime_ns=?,updated_at=? WHERE path=?", (cur, now, p))
            conn.execute("UPDATE node_tags SET state='stale',updated_at=? WHERE path=? AND state!='retired'", (now, p))
            log_event(conn, "mtime_stale", path=p, note=f"stored={rec['mtime_ns']};current={cur}")
            stale += 1; fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return {"marked_stale": stale, "marked_retired": retired}


def rebalance(conn: sqlite3.Connection, *, max_nodes: int = 1000, max_active: int = 220, fts_ok: bool) -> Dict[str, Any]:
    """Deterministically keep the cold-start pool bounded and states sane."""
    rows = conn.execute("SELECT path,state,node_type,seed_score,hit_count,last_access,brief FROM nodes WHERE state!='retired'").fetchall()
    now = time.time()
    scored: List[Tuple[float, str, str]] = []
    for r in rows:
        score = float(r["seed_score"] or 0.0) + min((r["hit_count"] or 0) * 8.0, 80.0)
        score += _recent_weight(r["last_access"]) * 4.0
        if r["brief"]:
            score += 2.0
        if r["node_type"] == "dir":
            score += 2.5
        if r["state"] == "stale":
            score -= 30.0
        scored.append((score, r["path"], r["state"]))
    scored.sort(key=lambda x: (-x[0], x[1]))
    keep_paths = {p for _, p, _ in scored[:max_nodes]}
    active_paths = {p for _, p, _ in scored[:max_active]}
    warm_paths = {p for _, p, _ in scored[max_active:max_nodes]}
    changed = {"to_active": 0, "to_warm": 0, "to_cold": 0, "retired_overflow": 0}
    for _, p, old in scored:
        if p not in keep_paths:
            new = "retired"; changed["retired_overflow"] += 1
        elif p in active_paths and old != "stale":
            new = "active"; changed["to_active"] += int(old != new)
        elif p in warm_paths and old != "stale":
            new = "warm"; changed["to_warm"] += int(old != new)
        else:
            new = "cold"; changed["to_cold"] += int(old != new)
        if new != old:
            conn.execute("UPDATE nodes SET state=?,updated_at=? WHERE path=?", (new, now, p))
            conn.execute("UPDATE node_tags SET state=?,updated_at=? WHERE path=? AND state!='retired'", (new, now, p))
            log_event(conn, "rebalance", path=p, old_state=old, new_state=new)
            fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return {"ok": True, "max_nodes": max_nodes, "max_active": max_active, **changed}


def add_ignored_path(conn: sqlite3.Connection, path: str, *, reason: str = "", path_type: str = "prefix", source: str = "manual") -> Dict[str, Any]:
    p = normalize_path(path)
    now = time.time()
    conn.execute(
        """INSERT INTO ignored_paths(path,path_type,reason,source,created_at,updated_at) VALUES (?,?,?,?,?,?)
           ON CONFLICT(path) DO UPDATE SET path_type=excluded.path_type,reason=excluded.reason,source=excluded.source,updated_at=excluded.updated_at""",
        (p, path_type, reason, source, now, now),
    )
    conn.commit()
    return {"ok": True, "path": p, "path_type": path_type, "reason": reason}


def ignored_paths(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    return [dict(r) for r in conn.execute("SELECT path,path_type,reason,source,created_at,updated_at FROM ignored_paths ORDER BY path")]


def facets(conn: sqlite3.Connection, *, limit: int = 30) -> Dict[str, Any]:
    lim = max(5, int(limit))
    state_counts = dict(conn.execute("SELECT state,COUNT(*) FROM nodes GROUP BY state"))
    type_counts = dict(conn.execute("SELECT node_type,COUNT(*) FROM nodes GROUP BY node_type"))
    tags_top = [dict(r) for r in conn.execute("SELECT tag,state,COUNT(*) AS n FROM node_tags GROUP BY tag,state ORDER BY n DESC LIMIT ?", (lim,))]
    recent = [dict(r) for r in conn.execute("SELECT path,node_type,brief,state,hit_count,last_access,seed_score FROM nodes ORDER BY COALESCE(last_access,0) DESC, seed_score DESC LIMIT ?", (lim,))]
    parents: Dict[str, int] = {}
    for (p,) in conn.execute("SELECT path FROM nodes WHERE node_type='file'"):
        par = os.path.dirname(p)
        for _ in range(3):
            if not par or par == os.path.dirname(par):
                break
            parents[par] = parents.get(par, 0) + 1
            par = os.path.dirname(par)
    top_parents = [{"parent": p, "n": n} for p, n in sorted(parents.items(), key=lambda x: -x[1])[:lim]]
    return {"nodes_by_state": state_counts, "nodes_by_type": type_counts, "tags_top": tags_top, "recent_used": recent, "top_parents": top_parents}


def stats(conn: sqlite3.Connection, *, fts_ok: bool, db_path: str, es_ok: Optional[bool]) -> Dict[str, Any]:
    return {
        "db_path": db_path,
        "fts_enabled": fts_ok,
        "es_exe_configured": bool(es_ok),
        "nodes_total": conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0],
        "node_tags_total": conn.execute("SELECT COUNT(*) FROM node_tags").fetchone()[0],
        "nodes_by_state": dict(conn.execute("SELECT state,COUNT(*) FROM nodes GROUP BY state")),
        "nodes_by_type": dict(conn.execute("SELECT node_type,COUNT(*) FROM nodes GROUP BY node_type")),
        "ignored_paths": conn.execute("SELECT COUNT(*) FROM ignored_paths").fetchone()[0],
    }


def list_candidates(conn: sqlite3.Connection, *, state: Optional[str] = None, node_type: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    wh: List[str] = []
    args: List[Any] = []
    if state:
        wh.append("state=?"); args.append(valid_state(state))
    if node_type:
        wh.append("node_type=?"); args.append(valid_node_type(node_type))
    sql = "SELECT path,node_type,brief,state,source,confidence,seed_score,hit_count,last_access FROM nodes"
    if wh:
        sql += " WHERE " + " AND ".join(wh)
    sql += " ORDER BY seed_score DESC, hit_count DESC, path LIMIT ?"
    args.append(max(1, int(limit)))
    return [dict(r) for r in conn.execute(sql, tuple(args))]


def list_by_tag(conn: sqlite3.Connection, tag: str, *, include_dormant: bool = False, include_retired: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    t = normalize_tags([tag])[0] if normalize_tags([tag]) else tag.strip().lower()
    states = sorted(allowed_states(include_dormant, include_retired))
    ph = ",".join("?" * len(states))
    rows = conn.execute(
        f"""SELECT n.path,n.node_type,n.brief,n.state AS node_state,t.state AS tag_state,t.tag
             FROM nodes n JOIN node_tags t ON n.path=t.path
             WHERE t.tag=? AND n.state IN ({ph}) AND t.state IN ({ph})
             ORDER BY t.last_hit IS NULL, t.last_hit DESC, n.seed_score DESC LIMIT ?""",
        (t, *states, *states, max(1, int(limit))),
    ).fetchall()
    return [dict(r) for r in rows]


def list_under_parent(conn: sqlite3.Connection, parent: str, *, include_dormant: bool = False, include_retired: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    par = normalize_path(parent).rstrip("/\\")
    pfx = par + os.sep
    states = allowed_states(include_dormant, include_retired)
    out: List[Dict[str, Any]] = []
    for r in conn.execute("SELECT path,node_type,brief,state,seed_score FROM nodes ORDER BY seed_score DESC,path"):
        p = normalize_path(r["path"])
        if r["state"] in states and (p == par or p.startswith(pfx)):
            out.append(dict(r))
            if len(out) >= limit:
                break
    return out


def export_jsonl(conn: sqlite3.Connection, fh: Any) -> int:
    n = 0
    for r in conn.execute("SELECT * FROM nodes"):
        fh.write(json.dumps({"type": "node", **dict(r)}, ensure_ascii=False) + "\n"); n += 1
    for r in conn.execute("SELECT * FROM node_tags"):
        fh.write(json.dumps({"type": "tag", **dict(r)}, ensure_ascii=False) + "\n"); n += 1
    for r in conn.execute("SELECT * FROM ignored_paths"):
        fh.write(json.dumps({"type": "ignored_path", **dict(r)}, ensure_ascii=False) + "\n"); n += 1
    return n
