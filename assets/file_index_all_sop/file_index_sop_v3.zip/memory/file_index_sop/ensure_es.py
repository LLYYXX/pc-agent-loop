#!/usr/bin/env python3
"""
Discover es.exe and patch only ``## [LOCAL_TOOLS]`` in memory/global_mem.txt with ``es.exe=``.
Does not run automatically from search_files. Use explicitly or when configuring a machine.

Usage:
  python memory/file_index_sop/ensure_es.py [--dry-run]
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import sys

_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
_GLOBAL_MEM = os.path.join(_REPO_ROOT, "memory", "global_mem.txt")
_SECTION = "LOCAL_TOOLS"


def _parse_es_from_local_tools(content: str) -> str | None:
    in_lt = False
    _re_head = re.compile(r"^##\s*\[([^\]]+)\]\s*$", re.I)
    for line in content.splitlines():
        st = line.strip()
        hm = _re_head.match(st)
        if hm:
            if hm.group(1).strip().upper() == _SECTION:
                in_lt = True
            elif in_lt:
                break
            continue
        if not in_lt:
            continue
        m = re.match(r"^\s*es\.exe\s*=\s*(.+)$", line, re.I)
        if m:
            cand = m.group(1).strip().strip('"').strip("'")
            if cand:
                return cand
    return None


def _discover_es_exe() -> str | None:
    for key in ("EVERYTHING_ES_EXE", "GA_ES_EXE"):
        v = (os.environ.get(key) or "").strip().strip('"').strip("'")
        if v and os.path.isfile(v):
            return os.path.normpath(os.path.abspath(v))
    w = shutil.which("es.exe")
    if w and os.path.isfile(w):
        return os.path.normpath(os.path.abspath(w))
    if sys.platform == "win32":
        try:
            import winreg

            for hive_name, sub in (
                ("HKLM", r"SOFTWARE\voidtools\Everything"),
                ("HKCU", r"SOFTWARE\voidtools\Everything"),
            ):
                try:
                    root = winreg.HKEY_LOCAL_MACHINE if hive_name == "HKLM" else winreg.HKEY_CURRENT_USER
                    with winreg.OpenKey(root, sub) as k:
                        base, _ = winreg.QueryValueEx(k, "InstallLocation")
                    if isinstance(base, str) and base.strip():
                        es = os.path.join(base.rstrip("\\/"), "es.exe")
                        if os.path.isfile(es):
                            return os.path.normpath(es)
                except OSError:
                    continue
        except Exception:
            pass
    pf = (os.environ.get("ProgramFiles") or "").strip()
    pfx86 = (os.environ.get("ProgramFiles(x86)") or "").strip()
    lad = (os.environ.get("LocalAppData") or "").strip()
    for base in (
        os.path.join(pf, "Everything") if pf else None,
        os.path.join(pfx86, "Everything") if pfx86 else None,
        os.path.join(lad, "Everything") if lad else None,
    ):
        if not base:
            continue
        es = os.path.join(base, "es.exe")
        if os.path.isfile(es):
            return os.path.normpath(es)
    return None


def _patch_global_mem(es_path: str, raw: str) -> list[str]:
    norm = os.path.normpath(es_path)
    lines = raw.splitlines(keepends=True)
    if not lines:
        lines = ["# Global memory L2 — see memory_management_sop.md\n"]
    _re_head = re.compile(r"^##\s*\[([^\]]+)\]\s*$", re.I)
    out: list[str] = []
    i = 0
    in_lt = False
    lt_header_idx = -1
    replaced_in_lt = False
    found_lt = False
    while i < len(lines):
        line = lines[i]
        st = line.strip()
        hm = _re_head.match(st)
        if hm and hm.group(1).strip().upper() == _SECTION:
            found_lt = True
            in_lt = True
            lt_header_idx = len(out)
            out.append(line)
            i += 1
            continue
        if in_lt:
            if hm and hm.group(1).strip().upper() != _SECTION:
                if not replaced_in_lt:
                    out.insert(lt_header_idx + 1, f"es.exe={norm}\n")
                    replaced_in_lt = True
                in_lt = False
                out.append(line)
                i += 1
                continue
            if re.match(r"^\s*es\.exe\s*=", line, re.I):
                out.append(f"es.exe={norm}\n")
                replaced_in_lt = True
            else:
                out.append(line)
            i += 1
            continue
        out.append(line)
        i += 1
    if in_lt and not replaced_in_lt:
        out.insert(lt_header_idx + 1, f"es.exe={norm}\n")
        replaced_in_lt = True
    if not found_lt:
        text = "".join(out).rstrip()
        sec = f"## [{_SECTION}]"
        block = f"\n\n{sec}\n" + f"es.exe={norm}\n"
        out = [text + block if text else f"{sec}\n" + f"es.exe={norm}\n"]
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="Configure es.exe under ## [LOCAL_TOOLS] in global_mem.txt")
    ap.add_argument("--dry-run", action="store_true", help="print actions only; do not write global_mem.txt")
    args = ap.parse_args()

    cand = _discover_es_exe()
    if not cand:
        print("ERROR: could not locate es.exe. Install voidtools Everything or set EVERYTHING_ES_EXE.", file=sys.stderr)
        return 2
    if not os.path.isfile(cand):
        print(f"ERROR: path not a file: {cand}", file=sys.stderr)
        return 2

    try:
        raw = open(_GLOBAL_MEM, encoding="utf-8", errors="replace").read()
    except FileNotFoundError:
        raw = ""
    existing = _parse_es_from_local_tools(raw)
    if existing and os.path.normpath(existing) == os.path.normpath(cand):
        print(f"OK: es.exe already set to valid path:\n  {cand}")
        print(f"global_mem: {_GLOBAL_MEM}")
        return 0

    new_lines = _patch_global_mem(cand, raw)
    if args.dry_run:
        print(f"DRY-RUN: would write es.exe={cand}\ninto section ## [{_SECTION}] of:\n  {_GLOBAL_MEM}")
        print("Preview last few lines after patch:")
        tail = "".join(new_lines[-8:])
        print(tail)
        return 0

    os.makedirs(os.path.dirname(_GLOBAL_MEM), exist_ok=True)
    with open(_GLOBAL_MEM, "w", encoding="utf-8", newline="\n") as f:
        f.writelines(new_lines)
    print(f"OK: wrote es.exe=\n  {cand}\nto {_GLOBAL_MEM}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
