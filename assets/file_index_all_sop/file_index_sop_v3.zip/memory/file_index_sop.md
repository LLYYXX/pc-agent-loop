# 文件语义索引 Skill v3（纯 Agent 驱动）

这是供 Agent 调用的轻量本地文件语义索引 SOP / Skill 原型。GA 只是首个载体；本目录下的 Python helper 不依赖 GenericAgent 内部类、不注册工具、不 hook `file_read`、不后台运行。

## 核心目标

- **Everything / es.exe**：负责文件事实检索，包括文件名、路径、扩展名、时间排序、scope 限定。
- **file_index_sop**：负责 es.exe 之上的正交语义覆盖，包括高价值文件池、父目录/祖父目录节点、稀疏高信息 tag、一行 brief、冷热升降级。
- **Agent**：负责根据任务和 Memory 主动决定何时用索引、何时补建索引、何时治理索引。用户不应手动筛选文件或维护 tag。

最终冷启动效果：当用户要求“建索引”或触发冷启动时，Agent 应调用 `cold_start_index()`，生成约 1000 条 `nodes` 数据；这些数据是最可能高价值/常用的一批文件和父级目录节点。之后 Agent 可在任务中继续补 tag、补 brief、升降级。

## import

通常 `code_run` cwd 在 `./temp`，用：

```python
import sys, os
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop.helper import *
```

可选环境变量：`FILE_INDEX_DB` 或 `GA_FILE_INDEX_DB` 覆盖默认数据库路径：

```text
memory/file_index_sop/file_index.sqlite
```

## es.exe 配置

如果 `stats()` 显示 `es_exe_configured=False`：

```powershell
python memory/file_index_sop/ensure_es.py --dry-run
python memory/file_index_sop/ensure_es.py
```

`ensure_es.py` 只 patch L2 `## [LOCAL_TOOLS]` 小节里的 `es.exe=`，不整文件覆盖全局记忆。

## 用户触发冷启动时，Agent 必须这样做

不要问用户选哪些文件。Agent 自己执行：

```python
from file_index_sop.helper import init_db, cold_start_index, stats, label_worklist, print_json

print_json(init_db())

# memory_text 可放 Agent 当前能读取到的长期记忆摘要；agent_queries 由 Agent 根据任务/Memory 生成。
res = cold_start_index(
    target_rows=1000,
    max_active=220,
    memory_text="""这里放 Agent Memory 中与用户长期项目/课程/研究/工作相关的摘要。""",
    agent_queries=["mcp", "trajectory", "元应用", "论文", "实验", "报销", "invoice"],
)
print_json(res)
print_json(stats())
```

`cold_start_index()` 会：

1. 用 es.exe 采样 recent 文件和 Memory/query-guided 候选。
2. 过滤明显软件生成物、缓存、日志、构建产物、依赖目录。
3. 给候选文件打分并做父目录多样性限制，避免一个目录吃掉全部 1000 条。
4. 写入约 1000 条 `nodes`：多数是 file nodes，少量是 parent / grandparent dir nodes。
5. 默认不发明语义 tag；tag 应由 Agent 后续对少量高价值节点基于上下文补充。
6. 根据分数和容量设置 active/warm/cold，并调用 `rebalance()` 控制默认召回规模。

## 冷启动后，Agent 应主动补语义

冷启动只建立高价值候选池，不等于完整语义理解。Agent 应立即查看需要补充的节点：

```python
work = label_worklist(limit=60)
print_json(work)
```

Agent 阅读 worklist 后，自主生成 plan，不问用户：

```python
plan = [
  {
    "path": r"F:\...\某个高价值目录或文件",
    "node_type": "dir",
    "state": "active",
    "brief": "一行短说明：这个目录/文件为什么未来值得找。",
    "tags": ["高信息语义tag"],
    "source": "agent-refine",
    "confidence": "agent-judged"
  }
]
print_json(apply_index_plan(plan))
```

## 日常文件任务流程

1. 当前上下文已有文件内容：直接用，不查索引。
2. 否则先：

```python
cands = recall("用户语义需求", limit=8)
```

3. 如果命中 dir node，把它当 scope，用 es 展开：

```python
search_files("更具体的文件事实词", scope="命中的目录")
```

4. 如果 recall 不足：

```python
search_files("文件名/路径/时间/扩展名事实词", limit=50)
```

5. 如果任务中发现新高价值路径：

```python
annotate_node(path, node_type="file"或"dir", tags=[...], brief="一行说明", state="active")
```

6. 如果是索引命中的节点并实际使用：

```python
mark_used(path, matched_tags=["实际命中的tag"])
```

## tag 规则：高信息语义残差

tag 不是分类标签，不复制 es.exe 能搜到的信息。只有当 tag 提供路径、文件名、扩展名、父目录看不出的任务语义时才写。

避免：

```text
python, json, csv, markdown, readme, config, result, experiment, project, folder, file
```

提倡：

```text
mcp-service-statistics
trajectory-reuse
golden-trace
unity-ml-agents
paper-evidence-table
deployment-entry
```

如果想不到高信息 tag，`tags=[]` 是正确结果。brief 可以更宽松，但必须是一行短说明，不写长摘要。

## 状态

| state | 含义 |
|---|---|
| active | 默认召回。真实任务使用过，或冷启动中分数最高的少量节点。 |
| warm | 已进入 1000 池，候选价值较高，但未验证。 |
| cold | 低置信候选或长期未命中，默认 recall 不返回；`include_dormant=True` 可查。 |
| stale | mtime 改变，语义待复核。 |
| retired | 路径消失或容量淘汰墓碑。 |

维护：

```python
decay(active_days=30, warm_days=90)
check_stale()
rebalance(max_nodes=1000, max_active=220)
```

## 关键 API

### 使用层

```python
recall(query, limit=10, include_dormant=False, node_types=None, verbose=False)
locate(query, limit=10, scope=None)
search_files(query, limit=50, scope=None, sort=None, files=None, folders=None)
annotate_node(...)
mark_used(path, matched_tags=None)
promote(path), demote(path)
decay(), check_stale(), rebalance()
```

### 构建层

```python
cold_start_index(target_rows=1000, max_active=220, memory_text="", agent_queries=[...])
discovery_summary(agent_queries=[...], memory_text="...")
collect_candidates(...)
label_worklist(limit=80)
apply_index_plan(plan)
add_ignored_path(path, reason="...", path_type="prefix")
```

## 不要做

- 不要让用户手工维护日常索引。
- 不要全盘 LLM 标注。
- 不要后台 watcher。
- 不要向量库。
- 不要在 helper 内部绑定具体 LLM API。
- 不要用 os.walk 替代 es.exe。
- 不要把 tag 写成文件类型/扩展名/路径词。

## 验证目标

冷启动后应满足：

```python
s = stats()
s["nodes_total"] 约等于 1000
s["nodes_by_type"] 同时包含 file 和 dir
s["nodes_by_state"] 包含 active/warm/cold
```

并能完成：

```python
recall("某个语义需求", include_dormant=True)
list_candidates(state="active", limit=20)
label_worklist(limit=20)
```
