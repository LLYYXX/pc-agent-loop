# 文件语义索引 Skill（v16）

本文件只写给 Agent 执行。目标：Everything 负责全量事实检索；本 Skill 维护约 1000 条高价值语义节点。语义判断由 Agent/LLM 基于证据完成；helper 只做候选发现、证据打包、正确搜索、状态记录、校验入库。

## 0. 边界

- 不后台 watcher，不 hook `file_read` / `file_write`，不接管文件操作。
- 不引入向量库。
- `search_files()` 是正确性优先的薄封装，只调用 es.exe，不做语义扩展。
- route tag 不由 helper 自动生成；必须由 Agent 根据 evidence packet 标注。
- 错误 tag 比没有 tag 更不可接受。能确认多少就打多少；每条 route tag 必须准确并带 evidence ref。
- 文档文件是一等候选，但有预算和同父目录上限，不能让大型文档集合刷屏。

## 1. 初始化

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop import *

print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

## 2. 冷启动建库模式

用户要求“给某盘建索引”时执行。

### 2.1 创建 session

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=80,
    scope=r"F:\\",
    memory_text="本轮用户明确提供的简短上下文；没有就留空",
    agent_queries=[],
)
print_json(res)
session_id = res["session_id"]
```

### 2.2 分批收集候选

```python
while True:
    status = cold_start_status(session_id)
    if status.get("pending", 0) >= 40 or status.get("collection_done"):
        break
    print_json(collect_cold_start_entries(
        session_id,
        max_queries=6,
        limit_per_query=100,
        recent_limit=1000,
        max_entries=100,
        time_budget_sec=30,
    ))
```

候选流包括 recent、文档文件种子、通用 evidence 文件、用户显式 query。文档文件是候选本体，不要求父目录先命中。

### 2.3 证据包标注

禁止手写路径 if/elif，也禁止让 helper 自动打语义 tag。取 evidence packet 后由 Agent 标注：

```python
batch = cold_start_evidence_batch(session_id, batch_size=8)
print_json(batch)
```

Agent 对每个 packet 判断：

- `action="apply"`：证据足够，写入 brief / route tags / facets。
- `action="skip"`：没有足够证据或不值得入库。
- `tier="warm"`：稳定语义节点。
- `tier="cold"`：支撑/候选节点。

每个 route tag 必须在 `relation.route_tag_evidence` 中引用本 packet 的证据字段，例如：

```python
plan = [
    {
        "path": packet["path"],
        "action": "apply",
        "node_type": packet["node_type"],
        "tier": "warm",
        "brief": "...",
        "tags": ["..."],
        "relation": {
            "role": "entry",
            "facets": packet.get("facets", []),
            "route_tag_evidence": {
                "some-route-tag": ["probe.content_head", "representative_children[0]"]
            },
        },
        "evidence": ["agent-annotated-from-evidence-packet"],
    }
]
print_json(apply_index_plan(plan, session_id=session_id))
```

有效 evidence ref 前缀包括：`path`、`basename`、`file_name`、`visible_terms`、`probe.*`、`document_heads[*]`、`representative_children[*]`、`leaf_candidates[*]`、`file_type_mix`、`content_head`、`task`、`user`。不能引用邻居项目、父目录泛语义或外部案例作为 route tag 证据。

继续循环：

```python
while True:
    status = cold_start_status(session_id)
    if status.get("pending", 0) <= 0:
        if status.get("remaining_nodes", 1) <= 0 or status.get("collection_done"):
            break
        print_json(collect_cold_start_entries(session_id, max_queries=6, limit_per_query=100, recent_limit=1000, max_entries=100, time_budget_sec=30))
        continue
    batch = cold_start_evidence_batch(session_id, batch_size=8)
    print_json(batch)
    # Agent 标注 batch -> plan
    # print_json(apply_index_plan(plan, session_id=session_id))
```

### 2.4 完成与验收

```python
result = finish_cold_start(session_id, max_nodes=1000, max_active=80, max_warm=420)
print_json(result)
if not result.get("ok") or result.get("status") != "complete":
    # 不得向用户报告“索引已完成”；继续收集/标注/跳过。
    print_json(result)
else:
    print_json(audit_index(fix=False))
    print_json(stats())
    print_json(virtual_tree(limit_per_group=10))
```

合格要求：

- 总节点接近且不超过 `max_nodes`。
- active 小；warm 是稳定语义层；cold 是支撑层。
- active/warm entry 有高信息 route tags 和 brief。
- route tag 不能是路径复读、分类词或局部 evidence 的错误冒泡。
- audit 中 missing、ignored、bad tag、generic brief、missing evidence 接近 0。

## 3. 运行时文件任务模式

### 3.1 定位

```python
res = locate("用户原始语义问题", limit=10)
print_json(res)
task_id = res.get("task_id")
```

`locate()` 会：

- 创建轻量 task ledger。
- 查 query alias。
- 查 active/warm semantic recall。
- 用 Agent 给出的原始 query 在命中 scope 内做薄 `search_files()`。
- 如果 scope 内无结果，再 fallback 到 Everything。

`locate()` 不做 case-specific query expansion。需要变体时，Agent 自己调用：

```python
print_json(search_files("事实查询词", scope="已知目录", limit=20))
print_json(search_files_detailed("事实查询词", scope="已知目录", limit=20))
```

`search_files_detailed()` 返回 argv、scope、encoding、stderr、hit_count 等诊断信息。

### 3.2 正常文件操作

Agent 正常使用文件工具读取、列目录、移动、重命名、写文件。本 Skill 不接管这些操作。

### 3.3 任务结束前 finalize

若本轮使用了本地路径，最终回答前调用：

```python
print_json(finalize_file_task(
    task_id=task_id,
    query="用户原始问题",
    used_paths=[...],
    found_paths=[...],
    rejected_paths=[...],
    fallback_used=bool(res.get("fallback_filesystem_hits")),
    mode="draft",
))
```

行为：

- 已在索引内且被使用的路径：升温 / 更新 hit_count / last_used。
- 索引外但被找到或使用的路径：生成 draft update plan。
- 无变化：no-op。

确认结果后再应用：

```python
print_json(apply_update_plan(plan_id))
```

## 4. 未命中更新计划

未命中但 fallback 找到结果时，默认只 draft，不直接生成 route tag：

```python
plan = draft_update_plan(
    query="用户原始问题",
    task_id=task_id,
    found_paths=[...],
    used_paths=[...],
    rejected_paths=[...],
    fallback_used=True,
)
print_json(plan)
```

`draft_update_plan()` 只记录 entry/leaf、query alias、negative evidence。新 route tag 仍需 Agent 基于 evidence packet 另行标注。

## 5. route tag 与 facet

- `node_tags`：route tags，参与 recall，必须准确、有 evidence ref。
- `node_facets`：组织信息，用于虚拟树、过滤和解释。
- `tier` / `role` 也是组织 facet。

如果只能确认“这是文档集合 / 项目根 / 配置文件 / 支撑 leaf”，但不能确认可路由语义，写 facet 或 cold，不要写 route tag。

## 6. 低层搜索原则

`search_files()` 是 es.exe 薄封装：

```text
scope is not None -> es.exe -n <limit> -path <scope> <query>
scope is None     -> es.exe -n <limit> <query>
```

不得在低层改写 query。失败时使用 `search_files_detailed()` 或 `last_search_diagnostic()` 查看 raw argv/stderr。
