"""file_index_sop v16: Agent-driven evidence-packet semantic file index."""
__version__ = "v16"

try:
    from .helper import *  # noqa: F401,F403
except Exception:
    pass
