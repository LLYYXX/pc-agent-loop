"""Robust voidtools Everything substrate layer.

This module is intentionally thin: it resolves/sniffs es.exe, optionally starts
Everything.exe, builds argv lists without shell splitting, handles Windows stdout
encoding, and returns structured diagnostics. It does not infer semantic tags.
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import sys
import time
from typing import Any, Dict, List, Optional, Sequence, Tuple

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
_GLOBAL_MEM = os.path.join(_REPO_ROOT, "memory", "global_mem.txt")
_SECTION = "LOCAL_TOOLS"
_L2_HEAD_RE = re.compile(r"^##\s*\[([^\]]+)\]\s*$", re.I)
_resolved_es_cache: Optional[str] = None
_autostart_attempted = False


def _norm(p: str) -> str:
    return os.path.normpath(os.path.abspath(str(p).strip().strip('"').strip("'")))


def read_global_mem() -> str:
    try:
        return open(_GLOBAL_MEM, encoding="utf-8", errors="replace").read()
    except FileNotFoundError:
        return ""
    except OSError:
        return ""


def parse_local_tools(content: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    in_lt = False
    for line in content.splitlines():
        st = line.strip()
        hm = _L2_HEAD_RE.match(st)
        if hm:
            if hm.group(1).strip().upper() == _SECTION:
                in_lt = True
            elif in_lt:
                break
            continue
        if in_lt:
            m = re.match(r"^\s*([^=]+?)\s*=\s*(.+)$", line)
            if m:
                out[m.group(1).strip()] = m.group(2).strip().strip('"').strip("'")
    return out


def patch_local_tools(es_path: str, everything_path: Optional[str] = None, raw: Optional[str] = None) -> str:
    """Patch only ## [LOCAL_TOOLS], preserving all other memory sections."""
    es_path = os.path.normpath(es_path)
    if raw is None:
        raw = read_global_mem()
    lines = raw.splitlines(keepends=True)
    if not lines:
        lines = ["# Global memory L2\n"]
    out: List[str] = []
    in_lt = False
    found = False
    wrote_es = False
    wrote_ev = False
    insert_at = -1
    for line in lines:
        m = _L2_HEAD_RE.match(line.strip())
        if m and m.group(1).strip().upper() == _SECTION:
            found = True; in_lt = True; insert_at = len(out) + 1; out.append(line); continue
        if in_lt and m and m.group(1).strip().upper() != _SECTION:
            if not wrote_es:
                out.insert(insert_at, f"es.exe={es_path}\n"); insert_at += 1
            if everything_path and not wrote_ev:
                out.insert(insert_at, f"Everything.exe={os.path.normpath(everything_path)}\n"); insert_at += 1
            in_lt = False; out.append(line); continue
        if in_lt:
            if re.match(r"^\s*es\.exe\s*=", line, re.I):
                out.append(f"es.exe={es_path}\n"); wrote_es = True
            elif re.match(r"^\s*Everything\.exe\s*=", line, re.I):
                if everything_path:
                    out.append(f"Everything.exe={os.path.normpath(everything_path)}\n"); wrote_ev = True
                else:
                    out.append(line)
            else:
                out.append(line)
        else:
            out.append(line)
    if in_lt:
        if not wrote_es:
            out.insert(insert_at, f"es.exe={es_path}\n"); insert_at += 1
        if everything_path and not wrote_ev:
            out.insert(insert_at, f"Everything.exe={os.path.normpath(everything_path)}\n")
    if not found:
        text = "".join(out).rstrip()
        block = f"\n\n## [{_SECTION}]\nes.exe={es_path}\n"
        if everything_path:
            block += f"Everything.exe={os.path.normpath(everything_path)}\n"
        return (text + block).lstrip("\n")
    return "".join(out)


def write_local_tools(es_path: str, everything_path: Optional[str] = None) -> bool:
    raw = read_global_mem()
    text = patch_local_tools(es_path, everything_path, raw)
    os.makedirs(os.path.dirname(_GLOBAL_MEM), exist_ok=True)
    try:
        with open(_GLOBAL_MEM, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        return True
    except OSError:
        return False


def _everything_for_es(es_path: str) -> Optional[str]:
    d = os.path.dirname(os.path.abspath(es_path))
    for name in ("Everything.exe", "Everything64.exe", "Everything32.exe", "everything.exe"):
        p = os.path.join(d, name)
        if os.path.isfile(p):
            return os.path.normpath(p)
    return None


def discover_es_and_everything() -> Tuple[Optional[str], Optional[str], str]:
    raw = read_global_mem(); lt = parse_local_tools(raw)
    for key in ("EVERYTHING_ES_EXE", "GA_ES_EXE", "FILE_INDEX_ES_EXE"):
        v = (os.environ.get(key) or "").strip()
        if v and os.path.isfile(_norm(v)):
            es = _norm(v); return es, _everything_for_es(es), f"env:{key}"
    if lt.get("es.exe") and os.path.isfile(_norm(lt["es.exe"])):
        es = _norm(lt["es.exe"]); ev = lt.get("Everything.exe")
        evn = _norm(ev) if ev and os.path.isfile(_norm(ev)) else _everything_for_es(es)
        return es, evn, "LOCAL_TOOLS:es.exe"
    w = shutil.which("es.exe")
    if w and os.path.isfile(w):
        es = _norm(w); return es, _everything_for_es(es), "PATH"
    if sys.platform == "win32":
        try:
            import winreg  # type: ignore
            for hive_name, root in (("HKLM", winreg.HKEY_LOCAL_MACHINE), ("HKCU", winreg.HKEY_CURRENT_USER)):
                for sub in (r"SOFTWARE\voidtools\Everything", r"SOFTWARE\WOW6432Node\voidtools\Everything"):
                    try:
                        with winreg.OpenKey(root, sub) as k:
                            base, _ = winreg.QueryValueEx(k, "InstallLocation")
                        if isinstance(base, str) and base.strip():
                            es = os.path.join(base, "es.exe"); ev = os.path.join(base, "Everything.exe")
                            if os.path.isfile(es):
                                return _norm(es), _norm(ev) if os.path.isfile(ev) else None, f"registry:{hive_name}:{sub}"
                    except OSError:
                        continue
        except Exception:
            pass
    for key in ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData"):
        base = os.environ.get(key) or ""
        for sub in ("Everything", os.path.join("voidtools", "Everything")):
            d = os.path.join(base, sub) if base else ""
            es = os.path.join(d, "es.exe"); ev = os.path.join(d, "Everything.exe")
            if os.path.isfile(es):
                return _norm(es), _norm(ev) if os.path.isfile(ev) else None, "common-path"
    return None, None, "not-found"


def resolve_es_exe() -> Optional[str]:
    global _resolved_es_cache
    if _resolved_es_cache and os.path.isfile(_resolved_es_cache):
        return _resolved_es_cache
    es, _ev, _src = discover_es_and_everything()
    if es:
        _resolved_es_cache = es
    return es


def es_path_scope_arg(scope_abs: str) -> str:
    s = os.path.normpath(os.path.abspath(scope_abs))
    if len(s) == 2 and s[1] == ":":
        return s + "\\"
    return s


def stdout_encoding() -> str:
    v = (os.environ.get("FILE_INDEX_ES_STDOUT_ENCODING") or os.environ.get("ES_STDOUT_ENCODING") or "").strip()
    if v:
        return v
    return "mbcs" if sys.platform == "win32" else "utf-8"


def run_es_subprocess(es_exe: str, argv: Sequence[str], *, timeout: float = 120.0) -> subprocess.CompletedProcess[str]:
    kwargs: Dict[str, Any] = {
        "args": [es_exe] + list(argv),
        "capture_output": True,
        "text": True,
        "encoding": stdout_encoding(),
        "errors": "replace",
        "timeout": float(max(5.0, min(timeout, 7200.0))),
    }
    if sys.platform == "win32":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return subprocess.run(**kwargs)


def _windows_everything_process_running() -> bool:
    if sys.platform != "win32":
        return False
    try:
        kw: Dict[str, Any] = {"args": ["tasklist", "/FI", "IMAGENAME eq Everything.exe", "/FO", "CSV", "/NH"], "capture_output": True, "text": True, "timeout": 8}
        kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        r = subprocess.run(**kw)
        return "Everything.exe" in ((r.stdout or "") + (r.stderr or ""))
    except Exception:
        return False


def _run_probe(es_path: str, timeout: float = 8.0) -> Tuple[bool, str]:
    try:
        r = run_es_subprocess(es_path, ["-n", "1", "*"], timeout=timeout)
        if r.returncode == 0 or (r.stdout or "").strip():
            return True, "es.exe query OK"
        return False, (r.stderr or "").strip() or f"exit {r.returncode}"
    except Exception as e:
        return False, str(e)


def start_everything(everything_path: Optional[str], es_path: Optional[str], wait_seconds: float = 10.0) -> Tuple[bool, str]:
    ev = everything_path or (_everything_for_es(es_path) if es_path else None)
    if not ev or not os.path.isfile(ev):
        return False, "Everything.exe not found; configure it or start Everything manually"
    try:
        kwargs: Dict[str, Any] = {"args": [ev, "-startup", "-minimized"], "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
        if sys.platform == "win32":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        subprocess.Popen(**kwargs)
    except Exception as e:
        return False, f"failed to start Everything: {e}"
    if es_path:
        deadline = time.time() + wait_seconds; last = ""
        while time.time() < deadline:
            ok, msg = _run_probe(es_path, timeout=3.0)
            if ok:
                return True, "Everything started and es.exe IPC is ready"
            last = msg; time.sleep(0.7)
        return False, "Everything start attempted but es.exe IPC not ready: " + last
    return True, "Everything start attempted"


def ensure_ready(*, start: bool = True, patch: bool = True, dry_run: bool = False) -> Dict[str, Any]:
    es, ev, source = discover_es_and_everything()
    if not es:
        return {"ok": False, "error": "could not locate es.exe", "source": source, "hint": "Install voidtools Everything or set EVERYTHING_ES_EXE."}
    configured = parse_local_tools(read_global_mem()).get("es.exe") == es
    would_write = patch and not configured
    wrote = False
    if would_write and not dry_run:
        wrote = write_local_tools(es, ev)
    ok, probe = _run_probe(es, timeout=6.0)
    start_message = ""
    started = False
    if not ok and start:
        started, start_message = start_everything(ev, es)
        ok, probe = _run_probe(es, timeout=6.0)
    return {"ok": bool(ok), "es_exe": es, "everything_exe": ev, "source": source, "configured": configured or wrote, "would_write": bool(would_write), "wrote": wrote, "started": started, "start_message": start_message, "probe": probe, "encoding": stdout_encoding(), "global_mem": _GLOBAL_MEM}


def build_argv(query: str, *, limit: int = 50, scope: Optional[str] = None, extra_args: Optional[Sequence[str]] = None) -> List[str]:
    q = (query or "").strip()
    if not q:
        raise ValueError("Everything query is empty")
    limit = max(1, min(int(limit), 50000))
    argv: List[str] = ["-n", str(limit)]
    if scope:
        argv.extend(["-path", es_path_scope_arg(scope)])
    if extra_args:
        argv.extend([str(x) for x in extra_args if str(x).strip()])
    argv.append(q)
    return argv


def query_es(query: str, *, limit: int = 50, scope: Optional[str] = None, extra_args: Optional[Sequence[str]] = None, timeout: float = 120.0, start: bool = False) -> Dict[str, Any]:
    es = resolve_es_exe()
    if not es:
        return {"ok": False, "error": "es.exe not configured", "hint": "call ensure_search_ready(start=True, patch=True)"}
    if start:
        ensure_ready(start=True, patch=False)
    try:
        argv = build_argv(query, limit=limit, scope=scope, extra_args=extra_args)
        r = run_es_subprocess(es, argv, timeout=timeout)
        lines = [os.path.normpath(x.strip()) for x in (r.stdout or "").splitlines() if x.strip()]
        return {"ok": r.returncode == 0 or bool(lines), "query": query, "scope": scope, "argv": argv, "es_exe": es, "encoding": stdout_encoding(), "returncode": r.returncode, "stderr": r.stderr or "", "hit_count": len(lines), "paths": lines}
    except Exception as e:
        return {"ok": False, "query": query, "scope": scope, "argv": (build_argv(query, limit=limit, scope=scope, extra_args=extra_args) if query else []), "es_exe": es, "encoding": stdout_encoding(), "error": str(e)}
