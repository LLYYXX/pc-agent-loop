"""SQLite store for the file semantic index.

v11 model boundary:
- Main index stores only current usable semantic nodes.
- Node tier is exactly active / warm / cold; cold start mostly builds warm/cold, real task use promotes active.
- Node type is exactly file / dir.
- Ignore rules live in ignore_rules.json.
- Trace/debug events live in events.jsonl.
"""
from __future__ import annotations

import fnmatch
import json
import os
import re
import sqlite3
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
IGNORE_RULES_PATH = os.path.join(_THIS_DIR, "ignore_rules.json")
EVENTS_PATH = os.path.join(_THIS_DIR, "events.jsonl")
_VALID_TIERS = {"active", "warm", "cold"}
_VALID_NODE_TYPES = {"file", "dir"}

_BAD_TAGS = {
    "file", "files", "folder", "directory", "dir", "document", "doc", "data", "dataset",
    "result", "results", "config", "configuration", "script", "source", "code", "src",
    "python", "py", "javascript", "typescript", "java", "markdown", "md", "json", "yaml", "yml",
    "csv", "pdf", "docx", "xlsx", "pptx", "readme", "test", "tests", "experiment", "experiments",
    "project", "projects", "image", "images", "log", "logs", "cache", "temp", "tmp", "note", "notes",
    "paper", "papers", "uncategorized", "general", "misc", "other", "unknown", "tbd",
    "academic", "coursework", "reading-material", "workspace-project", "fdu-related",
    "web-interface", "api-service", "testing-suite", "containerization", "frontend-dev", "backend-dev",
    "tool", "tools", "development", "dev", "library", "libraries", "资料", "材料", "项目", "文档",
    "文件", "目录", "学习", "课程", "论文", "实验", "通用", "其他", "归档",
}

# Route tags are stricter than internal candidate signals. These labels may be
# useful while scoring or explaining candidates, but they should not enter
# node_tags because they do not provide an orthogonal semantic route.
_BAD_ROUTE_TAGS = {
    "archive", "archives", "materials", "material", "general-materials", "reference-materials",
    "active-project", "workspace-project", "development-workspace", "python-project", "unity-project",
    "project-root", "software-project-root", "code-repository", "semantic-scope", "course-materials", "study-materials", "reading-materials",
    "game-dev", "development", "dev-workspace", "资料目录", "学习材料", "课程材料", "阅读材料",
}
_BAD_ROUTE_COMPONENTS = {
    "archive", "archives", "material", "materials", "general", "workspace", "project", "projects",
    "development", "dev", "coursework", "study", "reading", "root", "scope", "folder", "directory",
}

_BAD_BRIEF_PATTERNS = [
    r"^\s*$",
    r"^(file|dir|folder|document|project|node)\s*[:：]?\s*.*$",
    r"^.+节点$",
    r"^项目说明$",
    r"^课程资料$",
    r"^系统或依赖缓存$",
    r"^依赖或缓存目录$",
    r"^文件[:：]",
    r"^目录[:：]",
]

_SCHEMA = """
CREATE TABLE IF NOT EXISTS nodes (
  path TEXT PRIMARY KEY,
  node_type TEXT NOT NULL CHECK(node_type IN ('file','dir')),
  brief TEXT NOT NULL DEFAULT '',
  tier TEXT NOT NULL DEFAULT 'warm' CHECK(tier IN ('active','warm','cold')),
  source TEXT DEFAULT 'agent',
  confidence TEXT DEFAULT 'candidate',
  seed_score REAL DEFAULT 0,
  hit_count INTEGER DEFAULT 0,
  last_access REAL,
  size INTEGER,
  mtime_ns INTEGER,
  evidence TEXT DEFAULT '[]',
  relation TEXT DEFAULT '{}',
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS node_tags (
  path TEXT NOT NULL,
  tag TEXT NOT NULL,
  confidence REAL DEFAULT 1.0,
  source TEXT DEFAULT 'agent',
  hit_count INTEGER DEFAULT 0,
  last_hit REAL,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  PRIMARY KEY(path, tag),
  FOREIGN KEY(path) REFERENCES nodes(path) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS build_sessions (
  session_id TEXT PRIMARY KEY,
  status TEXT DEFAULT 'open',
  target_nodes INTEGER DEFAULT 1000,
  max_active INTEGER DEFAULT 220,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  meta TEXT DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS build_items (
  session_id TEXT NOT NULL,
  path TEXT NOT NULL,
  node_type TEXT NOT NULL CHECK(node_type IN ('file','dir')),
  suggested_tier TEXT DEFAULT 'warm' CHECK(suggested_tier IN ('active','warm','cold')),
  seed_score REAL DEFAULT 0,
  evidence TEXT DEFAULT '[]',
  relation TEXT DEFAULT '{}',
  visible_terms TEXT DEFAULT '[]',
  status TEXT DEFAULT 'pending',
  batch_no INTEGER DEFAULT 0,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  PRIMARY KEY(session_id, path)
);
CREATE TABLE IF NOT EXISTS node_facets (
  path TEXT NOT NULL,
  facet TEXT NOT NULL,
  source TEXT DEFAULT 'system',
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  PRIMARY KEY(path, facet),
  FOREIGN KEY(path) REFERENCES nodes(path) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS task_sessions (
  task_id TEXT PRIMARY KEY,
  query_text TEXT DEFAULT '',
  intent TEXT DEFAULT '',
  scope TEXT,
  status TEXT DEFAULT 'open',
  started_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  meta TEXT DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS query_aliases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  query_text TEXT NOT NULL,
  normalized_query TEXT NOT NULL,
  intent TEXT DEFAULT '',
  entry_path TEXT DEFAULT '',
  path TEXT DEFAULT '',
  success_count INTEGER DEFAULT 1,
  last_success REAL NOT NULL,
  source TEXT DEFAULT 'task-commit',
  evidence_json TEXT DEFAULT '{}',
  UNIQUE(normalized_query, entry_path, path)
);
CREATE TABLE IF NOT EXISTS negative_evidence (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  query_text TEXT DEFAULT '',
  normalized_query TEXT DEFAULT '',
  intent TEXT DEFAULT '',
  path TEXT NOT NULL,
  reason TEXT DEFAULT '',
  count INTEGER DEFAULT 1,
  last_seen REAL NOT NULL,
  source TEXT DEFAULT 'task-commit',
  UNIQUE(normalized_query, intent, path)
);
"""

_DEFAULT_IGNORE_RULES = [
    ".git", ".svn", ".hg", "node_modules", "bower_components", "__pycache__", ".venv", "venv", "env",
    "site-packages", "$RECYCLE.BIN", "System Volume Information", "xwechat_files", "WeChat Files",
    ".cache", "cache", "caches", "logs", "log", "tmp", "temp", "build", "dist", "target", "out",
    ".pytest_cache", ".mypy_cache", ".ruff_cache", ".ipynb_checkpoints", "wandb", "tensorboard", "checkpoints",
    "*.pyc", "*.pyo", "*.class", "*.o", "*.obj", "*.dll", "*.exe", "*.so", "*.tmp", "*.cache", "*.lock", "*.log", "*.bak", "*.swp", "*.swo",
    "*/wandb/*", "*/tensorboard/*", "*/checkpoints/*", "*/.ipynb_checkpoints/*",
]


def default_db_path() -> str:
    env = (os.environ.get("GA_FILE_INDEX_DB") or os.environ.get("FILE_INDEX_DB") or "").strip()
    return os.path.abspath(env) if env else os.path.join(_THIS_DIR, "file_index.sqlite")


def connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    p = db_path or default_db_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    conn = sqlite3.connect(p, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def try_create_fts(conn: sqlite3.Connection) -> bool:
    try:
        conn.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS node_fts USING fts5(
            path UNINDEXED, node_type UNINDEXED, tags_text, brief,
            tokenize='unicode61 remove_diacritics 2'
        )""")
        conn.commit()
        return True
    except sqlite3.OperationalError:
        conn.rollback()
        return False


def init_schema(conn: sqlite3.Connection) -> bool:
    conn.executescript(_SCHEMA)
    _migrate_from_v6_if_needed(conn)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_tier ON nodes(tier)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(node_type)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_score ON nodes(seed_score)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tags_tag ON node_tags(tag)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_build_items_status ON build_items(session_id,status)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_facets_facet ON node_facets(facet)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_query_aliases_query ON query_aliases(normalized_query)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_negative_evidence_query ON negative_evidence(normalized_query,intent)")
    conn.commit()
    ensure_default_files()
    ok = try_create_fts(conn)
    fts_rebuild_all(conn, fts_ok=ok)
    return ok


def _table_columns(conn: sqlite3.Connection, table: str) -> Set[str]:
    try:
        return {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}
    except sqlite3.Error:
        return set()


def _migrate_from_v6_if_needed(conn: sqlite3.Connection) -> None:
    cols = _table_columns(conn, "nodes")
    if cols:
        # v6 used state, unknown/stale/retired. Add tier if needed and map usable rows.
        if "tier" not in cols:
            try:
                conn.execute("ALTER TABLE nodes ADD COLUMN tier TEXT DEFAULT 'warm'")
            except sqlite3.OperationalError:
                pass
        if "state" in cols:
            conn.execute("UPDATE nodes SET tier=CASE WHEN state IN ('active','warm','cold') THEN state ELSE 'cold' END WHERE tier IS NULL OR tier NOT IN ('active','warm','cold')")
        # Remove unusable historical rows instead of carrying tombstones in the main index.
        conn.execute("DELETE FROM node_tags WHERE path IN (SELECT path FROM nodes WHERE node_type NOT IN ('file','dir'))")
        conn.execute("DELETE FROM nodes WHERE node_type NOT IN ('file','dir')")

    bcols = _table_columns(conn, "build_items")
    if bcols and "suggested_tier" not in bcols:
        try:
            conn.execute("ALTER TABLE build_items ADD COLUMN suggested_tier TEXT DEFAULT 'warm'")
        except sqlite3.OperationalError:
            pass
        if "suggested_state" in bcols:
            conn.execute("UPDATE build_items SET suggested_tier=CASE WHEN suggested_state IN ('active','warm','cold') THEN suggested_state ELSE 'warm' END WHERE suggested_tier IS NULL OR suggested_tier NOT IN ('active','warm','cold')")
    conn.commit()


def ensure_default_files() -> None:
    if not os.path.exists(IGNORE_RULES_PATH):
        with open(IGNORE_RULES_PATH, "w", encoding="utf-8") as fh:
            json.dump(_DEFAULT_IGNORE_RULES, fh, ensure_ascii=False, indent=2)
    os.makedirs(os.path.dirname(EVENTS_PATH), exist_ok=True)
    if not os.path.exists(EVENTS_PATH):
        open(EVENTS_PATH, "a", encoding="utf-8").close()


# JSON policy/log files ------------------------------------------------------

def load_ignore_rules() -> List[str]:
    ensure_default_files()
    try:
        data = json.load(open(IGNORE_RULES_PATH, encoding="utf-8"))
        if isinstance(data, list):
            return [str(x) for x in data if str(x).strip()]
    except Exception:
        pass
    return list(_DEFAULT_IGNORE_RULES)


def save_ignore_rules(rules: Sequence[str]) -> None:
    clean: List[str] = []
    seen: Set[str] = set()
    for r in rules:
        s = str(r).strip()
        if s and s not in seen:
            clean.append(s); seen.add(s)
    with open(IGNORE_RULES_PATH, "w", encoding="utf-8") as fh:
        json.dump(clean, fh, ensure_ascii=False, indent=2)


def add_ignore_rule(rule: str) -> Dict[str, Any]:
    rules = load_ignore_rules()
    if rule not in rules:
        rules.append(rule)
        save_ignore_rules(rules)
        append_event("ignore_rule_added", reason=rule, source="agent")
    return {"ok": True, "rule": rule, "rules_total": len(rules)}


def _split_parts(path: str) -> List[str]:
    # Robust across Windows paths even when tests run on non-Windows hosts.
    p = os.path.normpath(str(path)).replace("\\", "/")
    return [x.lower() for x in p.split("/") if x]


def match_ignore_rules(path: str, rules: Optional[Sequence[str]] = None) -> List[str]:
    rules = list(rules) if rules is not None else load_ignore_rules()
    p_norm = os.path.normpath(os.path.abspath(str(path)))
    p_slash = p_norm.replace("\\", "/")
    parts = set(_split_parts(p_norm))
    base = os.path.basename(p_norm)
    matched: List[str] = []
    for rule in rules:
        r = str(rule).strip()
        if not r:
            continue
        rl = r.lower()
        if "*" in r:
            if fnmatch.fnmatch(p_slash.lower(), r.replace("\\", "/").lower()) or fnmatch.fnmatch(base.lower(), rl):
                matched.append(r)
        elif rl.startswith(".") and rl.count(".") == 1 and os.path.splitext(base.lower())[1] == rl:
            matched.append(r)
        elif rl in parts:
            matched.append(r)
    return matched


def append_event(op: str, *, path: Optional[str] = None, tag: Optional[str] = None,
                 reason: str = "", source: str = "system", extra: Optional[Dict[str, Any]] = None) -> None:
    ensure_default_files()
    row = {"ts": time.time(), "op": op, "path": path, "tag": tag, "reason": reason, "source": source, "extra": extra or {}}
    with open(EVENTS_PATH, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(row, ensure_ascii=False) + "\n")


def recent_events(limit: int = 50, op: Optional[str] = None) -> List[Dict[str, Any]]:
    ensure_default_files()
    rows: List[Dict[str, Any]] = []
    try:
        with open(EVENTS_PATH, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                    if op is None or r.get("op") == op:
                        rows.append(r)
                except Exception:
                    continue
    except OSError:
        pass
    return rows[-max(1, int(limit)):]


# Basic helpers --------------------------------------------------------------

def infer_node_type(path: str) -> Optional[str]:
    try:
        p = os.path.normpath(os.path.abspath(path))
        if os.path.isfile(p):
            return "file"
        if os.path.isdir(p):
            return "dir"
    except OSError:
        return None
    return None


def stat_info(path: str) -> Tuple[Optional[int], Optional[int]]:
    try:
        st = os.stat(path, follow_symlinks=False)
        return int(st.st_size), int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
    except OSError:
        return None, None


def _json(x: Any, fallback: str) -> str:
    if x is None:
        return fallback
    if isinstance(x, str):
        return x
    return json.dumps(x, ensure_ascii=False)


def _loads(s: Any, default: Any) -> Any:
    try:
        return json.loads(s) if s else default
    except Exception:
        return default


def normalize_tags(tags: Sequence[str] | str) -> List[str]:
    parts = re.split(r"[,;\n]+", tags) if isinstance(tags, str) else [str(t) for t in tags]
    out: List[str] = []; seen: Set[str] = set()
    for raw in parts:
        t = raw.strip().lower()
        t = re.sub(r"\s+", "-", t)
        t = re.sub(r"[^a-z0-9\-_\u4e00-\u9fff]+", "-", t)
        t = re.sub(r"-+", "-", t).strip("-_")
        if t and t not in seen:
            seen.add(t); out.append(t)
    return out


def visible_terms(path: str) -> Set[str]:
    p = os.path.normpath(str(path)).lower().replace("\\", "/")
    parts = re.split(r"[/_\-.\s]+", p)
    terms = {x for x in parts if len(x) >= 2 and not re.fullmatch(r"\d+", x)}
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    if ext:
        terms.add(ext)
    return terms


def filter_high_info_tags(tags: Sequence[str] | str, path: str, *, extra_visible: Optional[Iterable[str]] = None) -> Tuple[List[str], List[str]]:
    norm = normalize_tags(tags)
    vis = visible_terms(path)
    if extra_visible:
        vis |= {str(x).lower().strip() for x in extra_visible if str(x).strip()}
    kept: List[str] = []; rejected: List[str] = []
    for tag in norm:
        pieces = {p for p in re.split(r"[-_]+", tag) if p}
        if tag in _BAD_TAGS or (pieces and pieces.issubset(_BAD_TAGS)):
            rejected.append(tag + ":generic")
            continue
        if tag in vis or (pieces and pieces.issubset(vis)) or (pieces and pieces.issubset(vis | _BAD_TAGS)):
            rejected.append(tag + ":visible")
            continue
        if len(tag) < 3:
            rejected.append(tag + ":short")
            continue
        kept.append(tag)
    return kept, rejected



def filter_route_tags(tags: Sequence[str] | str, path: str, *, extra_visible: Optional[Iterable[str]] = None) -> Tuple[List[str], List[str]]:
    """Strict but flexible route-tag gate for entry nodes.

    Route tags are not category labels. They are query aliases that should route
    a future user intent to a useful scope. The gate rejects exact path repeats
    and generic labels, but it still allows new domain terms and cross-language
    aliases without requiring a fixed ontology.
    """
    norm = normalize_tags(tags)
    vis = visible_terms(path)
    if extra_visible:
        vis |= {str(x).lower().strip() for x in extra_visible if str(x).strip()}
    base = os.path.basename(os.path.normpath(path)).lower()
    base_norms = set(normalize_tags([base, re.sub(r"[_\s]+", "-", base)]))
    kept: List[str] = []
    rejected: List[str] = []
    for tag in norm:
        pieces = {p for p in re.split(r"[-_]+", tag) if p}
        cjk_only = bool(re.fullmatch(r"[\u4e00-\u9fff]{2,}", tag))
        if tag in _BAD_ROUTE_TAGS or tag in _BAD_TAGS or (pieces and pieces.issubset(_BAD_TAGS | _BAD_ROUTE_COMPONENTS)):
            rejected.append(tag + ":generic-route")
            continue
        if (not cjk_only) and len(tag) < 3:
            rejected.append(tag + ":short")
            continue
        # Reject exact basename repetition and pure visible one-piece terms. Multi-piece
        # aliases are allowed only when they contain at least one non-visible semantic
        if tag in base_norms or (len(pieces) <= 1 and tag in vis):
            rejected.append(tag + ":path-repeat")
            continue
        if pieces and pieces.issubset(vis | _BAD_ROUTE_COMPONENTS | _BAD_TAGS):
            rejected.append(tag + ":path-or-category")
            continue
        kept.append(tag)
    return kept, rejected

def bad_brief_reason(brief: str, path: str = "") -> Optional[str]:
    b = (brief or "").strip()
    if len(b) < 6:
        return "too-short"
    if os.path.basename(path) and b.lower() == os.path.basename(path).lower():
        return "basename-only"
    for pat in _BAD_BRIEF_PATTERNS:
        if re.match(pat, b, re.I):
            return "generic"
    return None


def _tags_text(conn: sqlite3.Connection, path: str) -> str:
    return " ".join(r[0] for r in conn.execute("SELECT tag FROM node_tags WHERE path=?", (path,)))


def fts_sync_row(conn: sqlite3.Connection, path: str, *, fts_ok: bool) -> None:
    if not fts_ok:
        return
    p = os.path.normpath(os.path.abspath(path))
    conn.execute("DELETE FROM node_fts WHERE path=?", (p,))
    r = conn.execute("SELECT node_type, brief FROM nodes WHERE path=?", (p,)).fetchone()
    if not r:
        return
    conn.execute("INSERT INTO node_fts(path,node_type,tags_text,brief) VALUES(?,?,?,?)", (p, r["node_type"], _tags_text(conn, p), r["brief"] or ""))


def fts_rebuild_all(conn: sqlite3.Connection, *, fts_ok: bool) -> None:
    if not fts_ok:
        return
    try:
        conn.execute("DELETE FROM node_fts")
        for (p,) in conn.execute("SELECT path FROM nodes"):
            fts_sync_row(conn, p, fts_ok=True)
        conn.commit()
    except sqlite3.OperationalError:
        conn.rollback()


# Facets / task learning ------------------------------------------------------

def normalize_query_text(q: str) -> str:
    toks = normalize_tags(q or "")
    return " ".join(toks[:24])


def normalize_facet(f: str) -> str:
    f = str(f or "").strip().lower().replace("_", "-")
    f = re.sub(r"\s+", "-", f)
    f = re.sub(r"[^a-z0-9\-:\u4e00-\u9fff]+", "-", f).strip("-")
    return f


def upsert_facets(conn: sqlite3.Connection, path: str, facets: Sequence[str] | str, *, source: str = "system") -> List[str]:
    p = os.path.normpath(os.path.abspath(path))
    vals = [facets] if isinstance(facets, str) else list(facets or [])
    now = time.time()
    clean: List[str] = []
    seen: Set[str] = set()
    for f in vals:
        nf = normalize_facet(f)
        if nf and nf not in seen:
            clean.append(nf); seen.add(nf)
    for f in clean:
        conn.execute("""INSERT INTO node_facets(path,facet,source,created_at,updated_at)
                        VALUES(?,?,?,?,?)
                        ON CONFLICT(path,facet) DO UPDATE SET updated_at=excluded.updated_at, source=excluded.source""",
                     (p, f, source, now, now))
    return clean


def facets_for_path(conn: sqlite3.Connection, path: str) -> List[str]:
    p = os.path.normpath(os.path.abspath(path))
    return [r[0] for r in conn.execute("SELECT facet FROM node_facets WHERE path=? ORDER BY facet", (p,))]


def begin_task_session(conn: sqlite3.Connection, query: str, *, intent: str = "", scope: Optional[str] = None, meta: Optional[Any] = None) -> Dict[str, Any]:
    import uuid
    now = time.time()
    tid = "ft_" + uuid.uuid4().hex[:12]
    conn.execute("""INSERT INTO task_sessions(task_id,query_text,intent,scope,status,started_at,updated_at,meta)
                    VALUES(?,?,?,?,?,?,?,?)""",
                 (tid, query or "", intent or "", scope, "open", now, now, _json(meta, "{}")))
    append_event("file_task_started", reason=query, source="task", extra={"task_id": tid, "intent": intent, "scope": scope})
    conn.commit()
    return {"ok": True, "task_id": tid, "query": query, "intent": intent, "scope": scope}


def append_task_event(conn: sqlite3.Connection, task_id: Optional[str], op: str, *, query: str = "", path: Optional[str] = None, extra: Optional[Any] = None) -> None:
    append_event("task_" + op, path=path, source="task", reason=query, extra={"task_id": task_id, **(extra or {})})


def record_query_alias(conn: sqlite3.Connection, query: str, *, entry_path: Optional[str] = None, path: Optional[str] = None, intent: str = "", source: str = "task-commit", evidence: Optional[Any] = None) -> None:
    nq = normalize_query_text(query)
    if not nq or (not entry_path and not path):
        return
    now = time.time()
    ep = os.path.normpath(os.path.abspath(entry_path)) if entry_path else ""
    pp = os.path.normpath(os.path.abspath(path)) if path else ""
    conn.execute("""INSERT INTO query_aliases(query_text,normalized_query,intent,entry_path,path,success_count,last_success,source,evidence_json)
                    VALUES(?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(normalized_query, entry_path, path) DO UPDATE SET
                      success_count=success_count+1, last_success=excluded.last_success, query_text=excluded.query_text,
                      intent=COALESCE(NULLIF(excluded.intent,''), query_aliases.intent), evidence_json=excluded.evidence_json""",
                 (query, nq, intent or "", ep, pp, 1, now, source, _json(evidence, "{}")))


def query_alias_hits(conn: sqlite3.Connection, query: str, *, limit: int = 10) -> List[Dict[str, Any]]:
    nq = normalize_query_text(query)
    if not nq:
        return []
    toks = nq.split()[:8]
    clauses = []
    params: List[Any] = []
    for tok in toks:
        clauses.append("normalized_query LIKE ?")
        params.append(f"%{tok}%")
    if not clauses:
        return []
    sql = f"""SELECT * FROM query_aliases WHERE {' OR '.join(clauses)}
              ORDER BY success_count DESC,last_success DESC LIMIT ?"""
    out = []
    for r in conn.execute(sql, (*params, max(1, limit))):
        d = dict(r); d["evidence"] = _loads(d.pop("evidence_json", "{}"), {})
        out.append(d)
    return out


def record_negative_evidence(conn: sqlite3.Connection, query: str, path: str, *, intent: str = "", reason: str = "", source: str = "task-commit") -> None:
    p = os.path.normpath(os.path.abspath(path))
    nq = normalize_query_text(query)
    now = time.time()
    conn.execute("""INSERT INTO negative_evidence(query_text,normalized_query,intent,path,reason,count,last_seen,source)
                    VALUES(?,?,?,?,?,?,?,?)
                    ON CONFLICT(normalized_query, intent, path) DO UPDATE SET
                       count=count+1, last_seen=excluded.last_seen, reason=excluded.reason, query_text=excluded.query_text""",
                 (query or "", nq, intent or "", p, reason or "", 1, now, source))


def negative_paths_for_query(conn: sqlite3.Connection, query: str, *, intent: str = "", limit: int = 100) -> Set[str]:
    nq = normalize_query_text(query)
    toks = nq.split()[:8]
    if not toks:
        return set()
    clauses = []
    params: List[Any] = []
    for tok in toks:
        clauses.append("normalized_query LIKE ?")
        params.append(f"%{tok}%")
    sql = f"""SELECT path FROM negative_evidence WHERE ({' OR '.join(clauses)})
              {'AND (intent=? OR intent='')' if intent else ''}
              ORDER BY count DESC,last_seen DESC LIMIT ?"""
    if intent:
        params.append(intent)
    params.append(limit)
    return {r[0] for r in conn.execute(sql, params)}


# Main index operations ------------------------------------------------------

def annotate_node(conn: sqlite3.Connection, path: str, tags: Sequence[str] | str = (), *, brief: str = "",
                  node_type: Optional[str] = None, tier: str = "warm", state: Optional[str] = None,
                  source: str = "agent", confidence: str = "verified", seed_score: float = 0.0,
                  evidence: Optional[Any] = None, relation: Optional[Any] = None,
                  enforce_tag_gate: bool = True, fts_ok: bool = False) -> Dict[str, Any]:
    p = os.path.normpath(os.path.abspath(path))
    if match_ignore_rules(p):
        append_event("node_rejected_ignore_rule", path=p, source=source, reason=",".join(match_ignore_rules(p)))
        return {"ok": False, "error": "path matches ignore_rules", "path": p}
    inferred = infer_node_type(p)
    if inferred is None:
        append_event("node_rejected_unresolved_type", path=p, source=source)
        return {"ok": False, "error": "path is missing/inaccessible or type unresolved", "path": p}
    nt = node_type or inferred
    if nt != inferred or nt not in _VALID_NODE_TYPES:
        append_event("node_rejected_bad_type", path=p, source=source, reason=f"provided={node_type}, inferred={inferred}")
        return {"ok": False, "error": f"invalid node_type; inferred {inferred}", "path": p}
    tr = state or tier
    if tr not in _VALID_TIERS:
        return {"ok": False, "error": "tier must be active/warm/cold", "path": p}
    br = (brief or "").strip()
    rel_for_policy = relation if isinstance(relation, dict) else _loads(_json(relation, "{}"), {})
    role_for_policy = rel_for_policy.get("role")
    task_verified = bool(rel_for_policy.get("task_verified") or rel_for_policy.get("used_by_task") or rel_for_policy.get("content_read"))
    if tr in {"active", "warm"} and bad_brief_reason(br, p):
        return {"ok": False, "error": f"bad brief: {bad_brief_reason(br, p)}", "path": p}
    kept, rejected = filter_high_info_tags(tags, p) if enforce_tag_gate else (normalize_tags(tags), [])
    tag_required = tr in {"active", "warm"} and role_for_policy != "leaf"
    if tag_required and not kept:
        return {"ok": False, "error": "active/warm entry requires at least one valid high-info tag", "path": p, "rejected_tags": rejected}
    size, mtime_ns = stat_info(p)
    now = time.time()
    conn.execute("""INSERT INTO nodes(path,node_type,brief,tier,source,confidence,seed_score,hit_count,last_access,size,mtime_ns,evidence,relation,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(path) DO UPDATE SET node_type=excluded.node_type, brief=excluded.brief, tier=excluded.tier,
                      source=excluded.source, confidence=excluded.confidence, seed_score=MAX(nodes.seed_score, excluded.seed_score),
                      size=excluded.size, mtime_ns=excluded.mtime_ns, evidence=excluded.evidence, relation=excluded.relation, updated_at=excluded.updated_at""",
                 (p, nt, br, tr, source, confidence, float(seed_score or 0), 0, None, size, mtime_ns,
                  _json(evidence, "[]"), _json(relation, "{}"), now, now))
    conn.execute("DELETE FROM node_tags WHERE path=?", (p,))
    for tag in kept:
        conn.execute("""INSERT OR REPLACE INTO node_tags(path,tag,confidence,source,hit_count,last_hit,created_at,updated_at)
                        VALUES(?,?,?,?,0,NULL,?,?)""", (p, tag, 1.0, source, now, now))
    for tag in rejected:
        append_event("tag_rejected", path=p, tag=tag.split(":", 1)[0], source=source, reason=tag.split(":", 1)[-1])
    facets = []
    if isinstance(rel_for_policy, dict):
        for k in ("facets", "signals"):
            vals = rel_for_policy.get(k) or []
            if isinstance(vals, str): vals = [vals]
            facets.extend([str(x) for x in vals if str(x).strip()])
        if role_for_policy: facets.append(f"role:{role_for_policy}")
    facets.append(f"tier:{tr}")
    conn.execute("DELETE FROM node_facets WHERE path=?", (p,))
    upsert_facets(conn, p, facets, source=source)
    append_event("node_upserted", path=p, source=source, reason=tr, extra={"tags": kept, "node_type": nt, "facets": facets})
    fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return {"ok": True, "path": p, "node_type": nt, "tier": tr, "tags": kept, "rejected_tags": rejected}


def _allowed(include_dormant: bool) -> Set[str]:
    return {"active", "warm", "cold"} if include_dormant else {"active", "warm"}


def _tier_weight(tier: str) -> float:
    return {"active": 10.0, "warm": 6.5, "cold": 2.0}.get(tier, 0.0)


def recall(conn: sqlite3.Connection, query: str, *, limit: int = 10, include_dormant: bool = False,
           node_types: Optional[Sequence[str]] = None, fts_ok: bool = False, verbose: bool = False) -> List[Dict[str, Any]]:
    q = (query or "").strip()
    if not q:
        return []
    allow = sorted(_allowed(include_dormant)); ph = ",".join("?" * len(allow))
    params: List[Any] = list(allow)
    type_sql = ""
    if node_types:
        nts = [x for x in node_types if x in _VALID_NODE_TYPES]
        if nts:
            type_sql = " AND n.node_type IN (%s)" % ",".join("?" * len(nts)); params += nts
    candidates: Dict[str, Dict[str, Any]] = {}
    tokens = normalize_tags(q) + [x.lower() for x in re.findall(r"[A-Za-z0-9_\-\u4e00-\u9fff]{2,}", q)]
    like_clauses = []
    like_params: List[Any] = []
    for tok in tokens[:8]:
        like_clauses.append("(n.brief LIKE ? OR n.path LIKE ? OR t.tag LIKE ?)")
        like_params += [f"%{tok}%", f"%{tok}%", f"%{tok}%"]
    if like_clauses:
        sql = f"""SELECT n.path,n.node_type,n.brief,n.tier,n.seed_score,n.hit_count,n.last_access,GROUP_CONCAT(t.tag,' ') tags
                  FROM nodes n LEFT JOIN node_tags t ON n.path=t.path
                  WHERE n.tier IN ({ph}){type_sql} AND ({' OR '.join(like_clauses)})
                  GROUP BY n.path LIMIT ?"""
        for r in conn.execute(sql, (*params, *like_params, max(limit * 8, 50))):
            candidates[r["path"]] = dict(r)
    if fts_ok:
        try:
            # FTS query can fail on punctuation; use normalized tokens.
            fts_q = " OR ".join(tokens[:8]) or q
            sql = f"""SELECT n.path,n.node_type,n.brief,n.tier,n.seed_score,n.hit_count,n.last_access,GROUP_CONCAT(t.tag,' ') tags
                      FROM node_fts f JOIN nodes n ON f.path=n.path LEFT JOIN node_tags t ON n.path=t.path
                      WHERE node_fts MATCH ? AND n.tier IN ({ph}){type_sql}
                      GROUP BY n.path LIMIT ?"""
            for r in conn.execute(sql, (fts_q, *params, max(limit * 8, 50))):
                candidates[r["path"]] = dict(r)
        except sqlite3.OperationalError:
            pass
    out: List[Dict[str, Any]] = []
    ql = q.lower()
    for r in candidates.values():
        tags = (r.get("tags") or "")
        text = f"{r['path']} {r.get('brief') or ''} {tags}".lower()
        score = _tier_weight(r["tier"]) + float(r.get("seed_score") or 0) * 0.02 + min((r.get("hit_count") or 0) * 2, 20)
        # Prefer semantic entry/scope nodes for recall; leaf nodes are mainly
        # surfaced after scope search or include_dormant expansion.
        try:
            rel = _loads(conn.execute("SELECT relation FROM nodes WHERE path=?", (r["path"],)).fetchone()[0], {})
        except Exception:
            rel = {}
        role = rel.get("role")
        if role == "entry":
            score += 12
        elif role == "leaf":
            score -= 6
        if ql in text:
            score += 20
        for tok in tokens:
            if tok and tok in tags:
                score += 18
            elif tok and tok in text:
                score += 6
        item = {"path": r["path"], "node_type": r["node_type"], "brief": r["brief"], "tier": r["tier"], "score": round(score, 3), "tags": tags.split() if tags else [], "role": role}
        if verbose:
            item.update({"hit_count": r.get("hit_count"), "last_access": r.get("last_access"), "seed_score": r.get("seed_score")})
        out.append(item)
    out.sort(key=lambda x: x["score"], reverse=True)
    return out[:max(1, int(limit))]


def mark_used(conn: sqlite3.Connection, path: str, *, matched_tags: Optional[Sequence[str]] = None, fts_ok: bool = False) -> Dict[str, Any]:
    p = os.path.normpath(os.path.abspath(path)); now = time.time()
    r = conn.execute("SELECT tier FROM nodes WHERE path=?", (p,)).fetchone()
    if not r:
        return {"ok": False, "error": "path not indexed", "path": p}
    new = {"cold": "warm", "warm": "active"}.get(r["tier"], r["tier"])
    conn.execute("UPDATE nodes SET hit_count=hit_count+1,last_access=?,tier=?,updated_at=? WHERE path=?", (now, new, now, p))
    conn.execute("DELETE FROM node_facets WHERE path=? AND facet LIKE 'tier:%'", (p,))
    upsert_facets(conn, p, [f"tier:{new}", "recently-used"], source="mark_used")
    for tag in normalize_tags(matched_tags or []):
        conn.execute("UPDATE node_tags SET hit_count=hit_count+1,last_hit=?,updated_at=? WHERE path=? AND tag=?", (now, now, p, tag))
    append_event("mark_used", path=p, reason=f"{r['tier']}->{new}", source="agent")
    fts_sync_row(conn, p, fts_ok=fts_ok); conn.commit()
    return {"ok": True, "path": p, "old_tier": r["tier"], "tier": new}


def set_tier(conn: sqlite3.Connection, path: str, tier: str, *, fts_ok: bool = False) -> Dict[str, Any]:
    if tier not in _VALID_TIERS:
        return {"ok": False, "error": "tier must be active/warm/cold"}
    p = os.path.normpath(os.path.abspath(path)); now = time.time()
    old = conn.execute("SELECT tier FROM nodes WHERE path=?", (p,)).fetchone()
    conn.execute("UPDATE nodes SET tier=?,updated_at=? WHERE path=?", (tier, now, p))
    conn.execute("DELETE FROM node_facets WHERE path=? AND facet LIKE 'tier:%'", (p,))
    upsert_facets(conn, p, [f"tier:{tier}"], source="set_tier")
    append_event("set_tier", path=p, reason=f"{old['tier'] if old else None}->{tier}", source="agent")
    fts_sync_row(conn, p, fts_ok=fts_ok); conn.commit()
    return {"ok": True, "path": p, "tier": tier}


def delete_node(conn: sqlite3.Connection, path: str, *, reason: str = "", source: str = "agent", fts_ok: bool = False) -> Dict[str, Any]:
    p = os.path.normpath(os.path.abspath(path))
    existed = conn.execute("SELECT 1 FROM nodes WHERE path=?", (p,)).fetchone() is not None
    conn.execute("DELETE FROM node_tags WHERE path=?", (p,))
    conn.execute("DELETE FROM nodes WHERE path=?", (p,))
    if fts_ok:
        conn.execute("DELETE FROM node_fts WHERE path=?", (p,))
    append_event("node_deleted", path=p, reason=reason, source=source)
    conn.commit()
    return {"ok": True, "path": p, "existed": existed}


def report_file_deleted(conn: sqlite3.Connection, path: str, *, reason: str = "", fts_ok: bool = False) -> Dict[str, Any]:
    return delete_node(conn, path, reason=reason or "file operation reported deletion/missing", source="agent", fts_ok=fts_ok)


def report_file_changed(conn: sqlite3.Connection, path: str, *, note: str = "") -> Dict[str, Any]:
    p = os.path.normpath(os.path.abspath(path))
    size, mtime = stat_info(p)
    conn.execute("UPDATE nodes SET size=?,mtime_ns=?,updated_at=? WHERE path=?", (size, mtime, time.time(), p))
    append_event("file_changed", path=p, reason=note, source="agent")
    conn.commit()
    return {"ok": True, "path": p, "size": size, "mtime_ns": mtime}


def report_file_moved(conn: sqlite3.Connection, old_path: str, new_path: str, *, fts_ok: bool = False) -> Dict[str, Any]:
    old = os.path.normpath(os.path.abspath(old_path)); new = os.path.normpath(os.path.abspath(new_path))
    nt = infer_node_type(new)
    if nt is None:
        return {"ok": False, "error": "new_path missing/inaccessible", "new_path": new}
    if match_ignore_rules(new):
        return {"ok": False, "error": "new_path matches ignore_rules", "new_path": new}
    size, mtime = stat_info(new)
    conn.execute("UPDATE nodes SET path=?,node_type=?,size=?,mtime_ns=?,updated_at=? WHERE path=?", (new, nt, size, mtime, time.time(), old))
    conn.execute("UPDATE node_tags SET path=? WHERE path=?", (new, old))
    if fts_ok:
        conn.execute("DELETE FROM node_fts WHERE path=?", (old,)); fts_sync_row(conn, new, fts_ok=True)
    append_event("file_moved", path=old, reason=new, source="agent")
    conn.commit()
    return {"ok": True, "old_path": old, "new_path": new}


def _mtime_recency_bonus(mtime_ns: Optional[int], now: Optional[float] = None) -> float:
    if not mtime_ns:
        return 0.0
    now = now or time.time()
    try:
        age = (now - (mtime_ns / 1_000_000_000)) / 86400
    except Exception:
        return 0.0
    if age < 3: return 28.0
    if age < 7: return 22.0
    if age < 30: return 14.0
    if age < 90: return 6.0
    return 0.0


def rebalance(conn: sqlite3.Connection, *, max_nodes: int = 1000, max_active: int = 80, max_warm: int = 420, fts_ok: bool = False) -> Dict[str, Any]:
    """Normalize tiers under v11 semantics.

    - cold start should mainly yield warm entries/docs + cold support leaves.
    - active is a small hot set: recent true-use or most recent high-quality warm nodes.
    - warm is the base semantic map under a bounded budget.
    - cold is support/reserve and is trimmed last by total max_nodes.
    """
    rows = list(conn.execute("SELECT path,tier,seed_score,hit_count,last_access,node_type,brief,size,mtime_ns,evidence,relation FROM nodes"))
    now = time.time()
    scored = []
    changed = {"active": 0, "warm": 0, "cold": 0, "deleted": 0}
    for r in rows:
        p = r["path"]
        tag_n = conn.execute("SELECT COUNT(*) FROM node_tags WHERE path=?", (p,)).fetchone()[0]
        exists = os.path.exists(p)
        brief_ok = bad_brief_reason(r["brief"] or "", p) is None
        rel = _loads(r["relation"], {})
        role = rel.get("role")
        facets = set(facets_for_path(conn, p))
        usage = int(r["hit_count"] or 0)
        has_alias = conn.execute("SELECT 1 FROM query_aliases WHERE path=? OR entry_path=? LIMIT 1", (p, p)).fetchone() is not None
        recent_access = 0.0
        if r["last_access"]:
            age = (now - r["last_access"]) / 86400
            if age < 1: recent_access = 45
            elif age < 7: recent_access = 32
            elif age < 30: recent_access = 18
            elif age < 90: recent_access = 6
        recency = _mtime_recency_bonus(r["mtime_ns"], now)
        semantic = (26 if tag_n else 0) + (8 if brief_ok else 0)
        scope = 0
        if role == "entry": scope += 28
        if r["node_type"] == "dir": scope += 8
        if any(f in facets for f in ["project-root", "document-collection", "billing-records", "zotero-library", "config-root", "course-materials", "research-library"]): scope += 8
        leaf_penalty = -8 if role == "leaf" and usage == 0 and not has_alias else 0
        base = float(r["seed_score"] or 0) * 0.03 + semantic + scope + min(usage * 10, 60) + recent_access + recency + (20 if has_alias else 0) + leaf_penalty
        if not exists:
            base -= 5000
        # v16: active/warm entries need route tags. Query aliases can point to
        # cold task-derived entries, but they must not silently become warm/active
        # semantic entries without Agent-reviewed tags. Leaf/document nodes may warm
        # from actual use without route tags.
        if role == "entry":
            active_eligible = bool(exists and brief_ok and tag_n > 0 and (usage > 0 or has_alias or recency > 0))
            warm_eligible = bool(exists and brief_ok and tag_n > 0)
        else:
            active_eligible = bool(exists and brief_ok and (usage > 0 or has_alias or ("high-value-document" in facets and tag_n > 0 and recency > 0)))
            warm_eligible = bool(exists and brief_ok and (tag_n > 0 or usage > 0 or has_alias or "high-value-document" in facets or "config-like" in facets))
        scored.append({"score": base, "path": p, "old": r["tier"], "active_ok": active_eligible, "warm_ok": warm_eligible, "role": role, "usage": usage})
    scored.sort(key=lambda x: x["score"], reverse=True)
    keep = {x["path"] for x in scored[:max_nodes]}
    active = {x["path"] for x in [y for y in scored if y["path"] in keep and y["active_ok"]][:max_active]}
    warm = set()
    for x in scored:
        if x["path"] not in keep or x["path"] in active:
            continue
        if x["warm_ok"] and len(warm) < max_warm:
            warm.add(x["path"])
    for x in scored:
        p = x["path"]; old = x["old"]
        if p not in keep or not os.path.exists(p):
            delete_node(conn, p, reason="rebalance_drop_or_missing", source="rebalance", fts_ok=fts_ok)
            changed["deleted"] += 1
            continue
        if p in active:
            new = "active"
        elif p in warm:
            new = "warm"
        else:
            new = "cold"
        if new != old:
            conn.execute("UPDATE nodes SET tier=?,updated_at=? WHERE path=?", (new, now, p))
            append_event("rebalance", path=p, reason=f"{old}->{new}", source="rebalance")
            changed[new] += 1
            # keep tier facet fresh
            conn.execute("DELETE FROM node_facets WHERE path=? AND facet LIKE 'tier:%'", (p,))
            upsert_facets(conn, p, [f"tier:{new}"], source="rebalance")
            fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return {"ok": True, "changed": changed, "max_nodes": max_nodes, "max_active": max_active, "max_warm": max_warm,
            "tiers_after": dict(conn.execute("SELECT tier,COUNT(*) FROM nodes GROUP BY tier"))}

def decay(conn: sqlite3.Connection, *, active_days: float = 30, warm_days: float = 90, fts_ok: bool = False) -> Dict[str, int]:
    now = time.time(); out = {"active_to_warm": 0, "warm_to_cold": 0}
    for r in conn.execute("SELECT path,tier,last_access FROM nodes WHERE tier IN ('active','warm')"):
        age = None if not r["last_access"] else (now - r["last_access"]) / 86400
        new = None
        if r["tier"] == "active" and (age is None or age > active_days):
            new = "warm"; out["active_to_warm"] += 1
        elif r["tier"] == "warm" and (age is None or age > warm_days):
            new = "cold"; out["warm_to_cold"] += 1
        if new:
            set_tier(conn, r["path"], new, fts_ok=fts_ok)
    return out


def list_candidates(conn: sqlite3.Connection, *, tier: Optional[str] = None, state: Optional[str] = None, node_type: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    cond = []; params: List[Any] = []
    tr = tier or state
    if tr: cond.append("tier=?"); params.append(tr)
    if node_type: cond.append("node_type=?"); params.append(node_type)
    where = " WHERE " + " AND ".join(cond) if cond else ""
    rows = conn.execute(f"SELECT path,node_type,brief,tier,seed_score,hit_count,evidence,relation FROM nodes{where} ORDER BY tier='active' DESC, seed_score DESC LIMIT ?", (*params, max(1, limit))).fetchall()
    return [{"path": r["path"], "node_type": r["node_type"], "brief": r["brief"], "tier": r["tier"], "state": r["tier"], "seed_score": r["seed_score"], "hit_count": r["hit_count"], "evidence": _loads(r["evidence"], []), "relation": _loads(r["relation"], {})} for r in rows]


def facets(conn: sqlite3.Connection, *, limit: int = 30) -> Dict[str, Any]:
    role_counts = {r[0] or "unknown": r[1] for r in conn.execute("SELECT json_extract(relation,'$.role'),COUNT(*) FROM nodes GROUP BY json_extract(relation,'$.role')")}
    return {
        "nodes_by_tier": dict(conn.execute("SELECT tier,COUNT(*) FROM nodes GROUP BY tier")),
        "nodes_by_state": dict(conn.execute("SELECT tier,COUNT(*) FROM nodes GROUP BY tier")),
        "nodes_by_type": dict(conn.execute("SELECT node_type,COUNT(*) FROM nodes GROUP BY node_type")),
        "nodes_by_role": role_counts,
        "top_tags": [dict(r) for r in conn.execute("SELECT tag,COUNT(*) n FROM node_tags GROUP BY tag ORDER BY n DESC LIMIT ?", (limit,))],
        "top_dirs": _top_dirs(conn, limit),
        "recent_used": [dict(r) for r in conn.execute("SELECT path,node_type,brief,tier,hit_count,last_access FROM nodes ORDER BY COALESCE(last_access,0) DESC LIMIT ?", (limit,))],
    }


def _top_dirs(conn: sqlite3.Connection, limit: int) -> List[Dict[str, Any]]:
    c: Dict[str, int] = {}
    for (p,) in conn.execute("SELECT path FROM nodes WHERE node_type='file'"):
        par = os.path.dirname(p)
        if par:
            c[par] = c.get(par, 0) + 1
    return [{"parent": k, "n": v} for k, v in sorted(c.items(), key=lambda kv: -kv[1])[:limit]]


def stats(conn: sqlite3.Connection, *, fts_ok: bool, db_path: str, es_ok: bool) -> Dict[str, Any]:
    role_counts = {r[0] or "unknown": r[1] for r in conn.execute("SELECT json_extract(relation,'$.role'),COUNT(*) FROM nodes GROUP BY json_extract(relation,'$.role')")}
    return {
        "db_path": db_path, "fts_enabled": fts_ok, "es_exe_configured": es_ok,
        "nodes_total": conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0],
        "tags_total": conn.execute("SELECT COUNT(*) FROM node_tags").fetchone()[0],
        "nodes_by_tier": dict(conn.execute("SELECT tier,COUNT(*) FROM nodes GROUP BY tier")),
        "nodes_by_state": dict(conn.execute("SELECT tier,COUNT(*) FROM nodes GROUP BY tier")),
        "nodes_by_type": dict(conn.execute("SELECT node_type,COUNT(*) FROM nodes GROUP BY node_type")),
        "nodes_by_role": role_counts,
        "open_build_sessions": conn.execute("SELECT COUNT(*) FROM build_sessions WHERE status='open'").fetchone()[0],
        "query_aliases_total": conn.execute("SELECT COUNT(*) FROM query_aliases").fetchone()[0],
        "negative_evidence_total": conn.execute("SELECT COUNT(*) FROM negative_evidence").fetchone()[0],
        "facets_total": conn.execute("SELECT COUNT(*) FROM node_facets").fetchone()[0],
        "ignore_rules_count": len(load_ignore_rules()),
    }


def list_by_tag(conn: sqlite3.Connection, tag: str, *, include_dormant: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    norm = normalize_tags([tag])
    if not norm:
        return []
    t = norm[0]; allow = sorted(_allowed(include_dormant)); ph = ",".join("?" * len(allow))
    rows = conn.execute(f"SELECT n.path,n.node_type,n.brief,n.tier,t.tag FROM nodes n JOIN node_tags t ON n.path=t.path WHERE t.tag=? AND n.tier IN ({ph}) ORDER BY n.tier='active' DESC,n.seed_score DESC LIMIT ?", (t, *allow, limit)).fetchall()
    return [dict(r) for r in rows]


def list_under_parent(conn: sqlite3.Connection, parent: str, *, include_dormant: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    par = os.path.normpath(os.path.abspath(parent)).rstrip("/\\"); pfx = par + os.sep; allow = _allowed(include_dormant)
    out = []
    for r in conn.execute("SELECT path,node_type,brief,tier FROM nodes ORDER BY path"):
        p = os.path.normpath(os.path.abspath(r["path"]))
        if r["tier"] in allow and (p == par or p.startswith(pfx)):
            out.append(dict(r))
            if len(out) >= limit: break
    return out


def export_jsonl(conn: sqlite3.Connection, fh: Any) -> int:
    n = 0
    for r in conn.execute("SELECT * FROM nodes"):
        fh.write(json.dumps({"type": "node", **dict(r)}, ensure_ascii=False) + "\n"); n += 1
    for r in conn.execute("SELECT * FROM node_tags"):
        fh.write(json.dumps({"type": "tag", **dict(r)}, ensure_ascii=False) + "\n"); n += 1
    return n

# Virtual tree / tag-facet organization --------------------------------------

def list_entries_by_facet(conn: sqlite3.Connection, facet: str, *, include_cold: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    nf = normalize_facet(facet)
    tiers = {"active", "warm", "cold"} if include_cold else {"active", "warm"}
    ph = ",".join("?" * len(tiers))
    rows = conn.execute(f"""SELECT n.path,n.node_type,n.brief,n.tier,n.seed_score,n.hit_count,n.relation\n                            FROM nodes n JOIN node_facets f ON n.path=f.path\n                            WHERE f.facet=? AND n.tier IN ({ph})\n                            ORDER BY n.tier='active' DESC,n.hit_count DESC,n.seed_score DESC LIMIT ?""", (nf, *sorted(tiers), limit)).fetchall()
    return [{"path": r["path"], "node_type": r["node_type"], "brief": r["brief"], "tier": r["tier"], "role": _loads(r["relation"], {}).get("role"), "facets": facets_for_path(conn, r["path"])} for r in rows]


def list_virtual_roots() -> List[str]:
    return ["hot", "semantic-map", "research", "projects", "documents", "config", "cold-support"]


def virtual_tree(conn: sqlite3.Connection, *, limit_per_group: int = 12) -> Dict[str, Any]:
    groups = {
        "hot": {"description": "recent active working set", "facets": ["tier:active", "recently-used", "task-derived"]},
        "semantic-map": {"description": "warm base semantic index", "facets": ["tier:warm", "role:entry", "document-collection"]},
        "research": {"description": "research/paper/agent literature routes", "tags": ["aios-literature", "agent-system-papers", "llm-agent-research", "mcp-service-integration", "research-literature"]},
        "projects": {"description": "project and tool scopes", "tags": ["llm-agent-runtime", "local-file-semantic-index", "gui-automation-agent", "ocr-recognition", "image-generation", "llm-finetuning"]},
        "documents": {"description": "billing, thesis, course, and document collections", "tags": ["reimbursement-records", "software-subscription-billing", "thesis-final-materials", "course-learning-materials", "business-documents"]},
        "config": {"description": "agent/runtime configuration and skill/tool records", "tags": ["skill-registry", "local-tools-config", "runtime-environment", "user-preferences", "agent-memory-system"]},
        "cold-support": {"description": "support leaves and reserve candidates", "facets": ["tier:cold", "support-leaf"]},
    }
    out: Dict[str, Any] = {}
    for name, spec in groups.items():
        entries: List[Dict[str, Any]] = []
        for t in spec.get("tags", []):
            entries.extend(list_by_tag(conn, t, include_dormant=name == "cold-support", limit=max(3, limit_per_group // 2)))
        for f in spec.get("facets", []):
            entries.extend(list_entries_by_facet(conn, f, include_cold=name == "cold-support", limit=max(3, limit_per_group // 2)))
        seen = set(); uniq = []
        for e in entries:
            p = e.get("path")
            if p and p not in seen:
                uniq.append(e); seen.add(p)
            if len(uniq) >= limit_per_group:
                break
        out[name] = {"description": spec["description"], "count": len(uniq), "items": uniq}
    return {"ok": True, "roots": list(groups.keys()), "groups": out}

# ---------------------------------------------------------------------------
# v16 dynamic virtual tree override: no domain/case-specific tag roots.
# ---------------------------------------------------------------------------

def list_virtual_roots() -> List[str]:  # type: ignore[override]
    return ["hot", "semantic-map", "documents", "cold-support", "top-route-tags", "top-facets"]


def _node_summary(conn: sqlite3.Connection, path: str) -> Dict[str, Any]:
    r = conn.execute("SELECT path,node_type,brief,tier,relation,seed_score,hit_count FROM nodes WHERE path=?", (path,)).fetchone()
    if not r:
        return {"path": path}
    tags = [x[0] for x in conn.execute("SELECT tag FROM node_tags WHERE path=? ORDER BY tag", (path,))]
    return {"path": r["path"], "node_type": r["node_type"], "brief": r["brief"], "tier": r["tier"], "role": _loads(r["relation"], {}).get("role"), "seed_score": r["seed_score"], "hit_count": r["hit_count"], "tags": tags, "facets": facets_for_path(conn, path)}


def virtual_tree(conn: sqlite3.Connection, *, limit_per_group: int = 12) -> Dict[str, Any]:  # type: ignore[override]
    lim = max(1, int(limit_per_group))
    groups: Dict[str, Any] = {}
    hot = [r[0] for r in conn.execute("SELECT path FROM nodes WHERE tier='active' ORDER BY COALESCE(last_access,0) DESC, hit_count DESC, seed_score DESC LIMIT ?", (lim,))]
    warm_entries = [r[0] for r in conn.execute("SELECT path FROM nodes WHERE tier='warm' AND json_extract(relation,'$.role')='entry' ORDER BY hit_count DESC, seed_score DESC LIMIT ?", (lim,))]
    docs = [r[0] for r in conn.execute("""SELECT n.path FROM nodes n JOIN node_facets f ON n.path=f.path
                                      WHERE f.facet IN ('high-value-document','document-seed','text-head-readable')
                                      ORDER BY n.tier='active' DESC,n.tier='warm' DESC,n.seed_score DESC LIMIT ?""", (lim,))]
    cold = [r[0] for r in conn.execute("SELECT path FROM nodes WHERE tier='cold' ORDER BY seed_score DESC LIMIT ?", (lim,))]
    groups["hot"] = {"description": "recent active working set", "count": len(hot), "items": [_node_summary(conn, p) for p in hot]}
    groups["semantic-map"] = {"description": "warm semantic entries", "count": len(warm_entries), "items": [_node_summary(conn, p) for p in warm_entries]}
    groups["documents"] = {"description": "document/config seeds and text-head-readable files", "count": len(docs), "items": [_node_summary(conn, p) for p in docs]}
    groups["cold-support"] = {"description": "cold support leaves and candidates", "count": len(cold), "items": [_node_summary(conn, p) for p in cold]}
    top_tags = []
    for r in conn.execute("SELECT tag,COUNT(*) n FROM node_tags GROUP BY tag ORDER BY n DESC, tag LIMIT ?", (lim,)):
        sample = [x[0] for x in conn.execute("SELECT path FROM node_tags WHERE tag=? LIMIT 5", (r["tag"],))]
        top_tags.append({"tag": r["tag"], "count": r["n"], "sample_paths": sample})
    top_facets = []
    for r in conn.execute("SELECT facet,COUNT(*) n FROM node_facets GROUP BY facet ORDER BY n DESC, facet LIMIT ?", (lim,)):
        sample = [x[0] for x in conn.execute("SELECT path FROM node_facets WHERE facet=? LIMIT 5", (r["facet"],))]
        top_facets.append({"facet": r["facet"], "count": r["n"], "sample_paths": sample})
    groups["top-route-tags"] = {"description": "dynamic top route tags", "count": len(top_tags), "items": top_tags}
    groups["top-facets"] = {"description": "dynamic top facets", "count": len(top_facets), "items": top_facets}
    return {"ok": True, "roots": list_virtual_roots(), "groups": groups}
