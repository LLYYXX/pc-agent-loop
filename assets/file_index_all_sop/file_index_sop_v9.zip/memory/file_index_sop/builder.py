"""v9 builder: incremental entry-first semantic file index construction.

The cold start process does NOT ask the Agent to label 1000 raw paths.
It collects high-value file candidates, normalizes them into parent/grandparent
semantic scopes (entries), lets the Agent label those entries, and then
materializes representative leaf nodes under accepted entries.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import everything, store

TEXTISH_EXTS = {
    ".md", ".txt", ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cs", ".go", ".rs",
    ".json", ".yaml", ".yml", ".toml", ".ini", ".csv", ".tsv", ".tex", ".ipynb",
    ".sql", ".pdf", ".docx", ".xlsx", ".xls", ".pptx", ".html", ".vue", ".xml",
}
MEDIA_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".mp4", ".mov", ".avi", ".mkv"}
ARCHIVE_EXTS = {".zip", ".7z", ".rar", ".tar", ".gz", ".bz2"}
ENTRY_BASENAMES = {
    "readme.md", "readme.txt", "package.json", "pyproject.toml", "requirements.txt", "requirements-dev.txt",
    "dockerfile", "docker-compose.yml", "docker-compose.yaml", "pom.xml", "cargo.toml", "go.mod",
    "main.py", "app.py", "index.js", "index.ts", "setup.py", "makefile", "cmakelists.txt",
    "environment.yml", "conda.yml", "manifest.json", "packages.json",
}
PROJECT_MARKERS = {
    ".git", "package.json", "pyproject.toml", "requirements.txt", "setup.py", "pom.xml", "cargo.toml",
    "go.mod", "docker-compose.yml", "docker-compose.yaml", "assets", "projectsettings", "packages",
}
COLLECTION_MARKERS = {
    "invoice", "receipt", "发票", "收据", "账单", "论文", "papers", "paper", "notes", "materials", "材料",
    "实验", "results", "figures", "data", "简历", "毕设", "毕业", "课程", "作业",
}
GENERIC_CONTAINER_NAMES = {
    "workspace", "workspaces", "pythonproject", "unityproject", "document", "documents", "books", "fdu",
    "sunglink", "zhongduo", "from thinkpad", "temp", "tmp", "download", "downloads", "repositories",
}
DEFAULT_DISCOVERY_QUERIES = [
    "README.md", "pyproject.toml", "package.json", "requirements.txt", "docker-compose", "Dockerfile",
    "论文", "paper", "thesis", "实验", "experiment", "results", "报销", "发票", "账单", "invoice", "receipt",
    "mcp", "agent", "trajectory", "memory", "ml-agents", "llm", "llama", "paddle", "ocr", "nlp", "diffusion", "zotero",
    "课程", "简历", "毕业", "毕设", "GenericAgent", "Micro-Agent", "元应用", "仿真", "轨迹",
]
LOW_VALUE_SEGMENTS = {"node_modules", ".git", "$recycle.bin", "__pycache__", ".venv", "venv", "site-packages", "cache", "logs", "tmp", "temp", "build", "dist", "target"}


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _path_l(path: str) -> str:
    return _norm(path).lower().replace("\\", "/")


def _split_path_parts(path: str) -> List[str]:
    # Split on both slash types so this also behaves predictably in non-Windows tests.
    p = str(path).replace("\\", "/").lower()
    return [x for x in p.split("/") if x]


def _node_type(path: str) -> Optional[str]:
    return store.infer_node_type(path)


def _direct_names(path: str, limit: int = 600) -> set[str]:
    try:
        return {x.lower() for x in os.listdir(path)[:limit]}
    except OSError:
        return set()


def _is_ignored(path: str) -> bool:
    return bool(store.match_ignore_rules(path)) or any(p in LOW_VALUE_SEGMENTS for p in _split_path_parts(path))


def _inside_scope(path: str, scope: Optional[str]) -> bool:
    if not scope:
        return True
    return _path_l(path).startswith(_path_l(scope))


def _is_generic_container_dir(path: str) -> bool:
    return os.path.basename(_norm(path)).lower() in GENERIC_CONTAINER_NAMES


def _purpose_allows_media(purpose: Optional[str]) -> bool:
    p = (purpose or "").lower()
    return any(x in p for x in ["image", "screenshot", "素材", "图片", "截图", "报销", "invoice", "receipt", "发票", "账单"])


def memory_queries(memory_text: str = "", *, max_queries: int = 30) -> List[str]:
    text = memory_text or ""
    latin = re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", text)
    chinese = re.findall(r"[\u4e00-\u9fff]{2,10}", text)
    stop = {"the", "and", "with", "from", "that", "this", "agent", "model", "user", "project", "file", "系统", "用户", "当前", "研究", "项目", "实现", "文件", "方向", "需要", "相关", "设计"}
    cnt: Counter[str] = Counter()
    for x in latin + chinese:
        if len(x) <= 42 and x.lower() not in stop and x not in stop:
            cnt[x] += 1
    return [k for k, _ in cnt.most_common(max_queries)]


def merge_queries(agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", *, max_queries: int = 70) -> List[str]:
    out: List[str] = []
    seen = set()
    for q in list(agent_queries or []) + memory_queries(memory_text) + DEFAULT_DISCOVERY_QUERIES:
        qs = str(q).strip()
        if qs and qs.lower() not in seen:
            out.append(qs); seen.add(qs.lower())
        if len(out) >= max_queries:
            break
    return out


def _project_marker_score(path: str) -> Tuple[float, List[str]]:
    p = _norm(path)
    if not os.path.isdir(p) or _is_ignored(p):
        return 0.0, []
    names = _direct_names(p)
    score = 0.0; reasons: List[str] = []
    if ".git" in names:
        score += 30; reasons.append("project-root:git")
    if "assets" in names and "projectsettings" in names:
        score += 35; reasons.append("project-root:unity")
    for marker in ["package.json", "pyproject.toml", "requirements.txt", "setup.py", "pom.xml", "cargo.toml", "go.mod", "docker-compose.yml", "docker-compose.yaml"]:
        if marker in names:
            score += 20; reasons.append("project-marker:" + marker); break
    if names & {x.lower() for x in COLLECTION_MARKERS}:
        score += 12; reasons.append("collection-marker")
    return score, reasons


def _collection_root(path: str, *, scope: Optional[str] = None, max_levels: int = 4) -> Optional[Tuple[str, float, List[str]]]:
    cur = _norm(path)
    if os.path.isfile(cur):
        cur = os.path.dirname(cur)
    stop = _norm(scope) if scope else None
    for _ in range(max_levels):
        if not cur or cur == os.path.dirname(cur):
            break
        if stop and not _inside_scope(cur, stop):
            break
        if _is_ignored(cur):
            return None
        base = os.path.basename(cur).lower()
        names = _direct_names(cur, limit=250)
        score = 0.0; reasons: List[str] = []
        if any(m.lower() in base for m in COLLECTION_MARKERS):
            score += 20; reasons.append("collection-name")
        if names & {x.lower() for x in COLLECTION_MARKERS}:
            score += 18; reasons.append("collection-children")
        if score > 0 and not _is_generic_container_dir(cur):
            return cur, score, reasons
        nxt = os.path.dirname(cur)
        if nxt == cur: break
        cur = nxt
    return None


def _find_project_root(path: str, *, scope: Optional[str] = None, max_levels: int = 8) -> Optional[Tuple[str, float, List[str]]]:
    cur = _norm(path)
    if os.path.isfile(cur):
        cur = os.path.dirname(cur)
    stop = _norm(scope) if scope else None
    best: Optional[Tuple[str, float, List[str]]] = None
    for _ in range(max_levels):
        if not cur or cur == os.path.dirname(cur):
            break
        if stop and not _inside_scope(cur, stop):
            break
        if _is_ignored(cur):
            return None
        score, reasons = _project_marker_score(cur)
        if score > 0 and not _is_generic_container_dir(cur):
            best = (cur, score, reasons)
        nxt = os.path.dirname(cur)
        if nxt == cur:
            break
        cur = nxt
    return best


def _candidate_score(path: str, row: Optional[Dict[str, Any]], *, purpose: Optional[str], memory_terms: Sequence[str]) -> Tuple[float, List[str]]:
    p = _norm(path)
    nt = _node_type(p)
    if nt is None or _is_ignored(p):
        return -9999, ["ignored-or-missing"]
    reasons: List[str] = []
    score = 0.0
    base = os.path.basename(p); bl = base.lower(); ext = os.path.splitext(bl)[1]
    if nt == "file":
        if ext in TEXTISH_EXTS or bl in ENTRY_BASENAMES or (not ext and bl in {"dockerfile", "makefile", "license"}):
            score += 10; reasons.append("textish-or-entry")
        if bl in ENTRY_BASENAMES:
            score += 16; reasons.append("entry-file")
        if ext in MEDIA_EXTS and not _purpose_allows_media(purpose):
            score -= 12; reasons.append("media-downrank")
        if ext in ARCHIVE_EXTS and not _purpose_allows_media(purpose):
            score -= 5; reasons.append("archive-downrank")
    else:
        ms, mr = _project_marker_score(p)
        score += ms; reasons.extend(mr)
        if _is_generic_container_dir(p):
            score -= 20; reasons.append("generic-container")
    pl = _path_l(p)
    for sig in ["mcp", "agent", "trajectory", "轨迹", "元应用", "simulation", "仿真", "paper", "论文", "experiment", "实验", "benchmark", "zotero", "invoice", "receipt", "发票", "账单", "llm", "llama", "paddle", "ocr", "nlp", "diffusion", "ml-agents"]:
        if sig.lower() in pl:
            score += 5; reasons.append("path-signal:" + sig)
    for term in memory_terms:
        t = str(term).lower().strip()
        if t and len(t) >= 3 and t in pl:
            score += 5; reasons.append("memory-signal:" + str(term)[:30])
    try:
        mt = int((row or {}).get("mtime_ns") or os.stat(p, follow_symlinks=False).st_mtime_ns)
        age_days = max(0, (time.time() - mt / 1e9) / 86400)
        if age_days < 7: score += 14; reasons.append("recent-7d")
        elif age_days < 30: score += 9; reasons.append("recent-30d")
        elif age_days < 180: score += 4; reasons.append("recent-180d")
        elif age_days < 730: score += 1
    except OSError:
        pass
    return score, reasons


def _rows_to_candidates(rows: Dict[str, Dict[str, Any]], *, memory_text: str = "", purpose: Optional[str] = None) -> List[Dict[str, Any]]:
    """Convert raw Everything rows into scored file/dir candidates.

    This is intentionally deterministic and reusable by both the one-shot
    helper and the v9 incremental collector.
    """
    terms = memory_queries(memory_text, max_queries=60)
    cands: Dict[str, Dict[str, Any]] = {}
    for p, r in rows.items():
        nt = _node_type(p)
        if nt is None or _is_ignored(p):
            continue
        score, reasons = _candidate_score(p, r, purpose=purpose, memory_terms=terms)
        if score < -100:
            continue
        c = {"path": p, "node_type": nt, "score": score, "reasons": reasons, "row": r}
        old = cands.get(p)
        if old is None or score > old.get("score", 0):
            cands[p] = c
    return sorted(cands.values(), key=lambda x: float(x.get("score") or 0), reverse=True)


def collect_candidates(agent_queries: Optional[Sequence[str]] = None, *, memory_text: str = "", scope: Optional[str] = None,
                       limit_per_query: int = 120, include_recent: bool = True, recent_limit: int = 1800,
                       purpose: Optional[str] = None) -> List[Dict[str, Any]]:
    """One-shot candidate collection, retained for miss recovery and small scopes.

    For full-drive cold start, v9 uses collect_cold_start_entries() instead so
    this expensive work is split across multiple recoverable calls.
    """
    queries = merge_queries(agent_queries, memory_text)
    rows: Dict[str, Dict[str, Any]] = {}
    if include_recent:
        try:
            for r in everything.recent(limit=recent_limit, scope=scope):
                p = _norm(r["path"])
                if not _is_ignored(p): rows[p] = r
        except Exception as e:
            store.append_event("recent_search_failed", reason=str(e), source="builder")
    for q in queries:
        try:
            for r in everything.search(q, limit=limit_per_query, scope=scope):
                p = _norm(r["path"])
                if not _is_ignored(p): rows[p] = r
        except Exception as e:
            store.append_event("query_search_failed", reason=f"{q}: {e}", source="builder")
    return _rows_to_candidates(rows, memory_text=memory_text, purpose=purpose)


def collect_candidates_incremental(queries: Sequence[str], *, memory_text: str = "", scope: Optional[str] = None,
                                   limit_per_query: int = 80, include_recent: bool = False, recent_limit: int = 800,
                                   purpose: Optional[str] = None, time_budget_sec: float = 20.0) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Collect a bounded batch of candidates.

    This function is the core v9 fix: it performs the same search/filter/score
    logic as collect_candidates(), but bounded by query count and wall-clock
    budget. Repeated calls over the stored query list preserve coverage without
    making begin_cold_start() or any single step scan the entire drive.
    """
    started = time.time()
    rows: Dict[str, Dict[str, Any]] = {}
    processed_queries = 0
    recent_attempted = False
    recent_failed = None
    if include_recent and time.time() - started < time_budget_sec:
        recent_attempted = True
        try:
            for r in everything.recent(limit=recent_limit, scope=scope):
                p = _norm(r["path"])
                if not _is_ignored(p): rows[p] = r
                if time.time() - started >= time_budget_sec:
                    break
        except Exception as e:
            recent_failed = str(e)
            store.append_event("recent_search_failed", reason=str(e), source="builder")
    query_errors: List[Dict[str, str]] = []
    for q in list(queries):
        if time.time() - started >= time_budget_sec:
            break
        try:
            for r in everything.search(q, limit=limit_per_query, scope=scope):
                p = _norm(r["path"])
                if not _is_ignored(p): rows[p] = r
                if time.time() - started >= time_budget_sec:
                    break
        except Exception as e:
            query_errors.append({"query": str(q), "error": str(e)})
            store.append_event("query_search_failed", reason=f"{q}: {e}", source="builder")
        processed_queries += 1
    cands = _rows_to_candidates(rows, memory_text=memory_text, purpose=purpose)
    stats = {
        "raw_rows": len(rows),
        "candidate_count": len(cands),
        "processed_queries": processed_queries,
        "recent_attempted": recent_attempted,
        "recent_failed": recent_failed,
        "query_errors": query_errors[:8],
        "elapsed_sec": round(time.time() - started, 3),
    }
    return cands, stats

def _pick_entry_for_candidate(path: str, *, scope: Optional[str]) -> Optional[Tuple[str, float, List[str]]]:
    # Prefer project/material roots. Fall back to parent/grandparent only if it is not generic.
    for fn in (_find_project_root, _collection_root):
        root = fn(path, scope=scope)
        if root:
            return root
    cur = _norm(path)
    if os.path.isfile(cur):
        par = os.path.dirname(cur)
    else:
        par = cur
    if _is_ignored(par):
        return None
    # Generic parent is often too broad. Try grandparent only when parent is a meaningful non-container.
    if not _is_generic_container_dir(par):
        return par, 8.0, ["parent-scope"]
    gp = os.path.dirname(par)
    if gp and not _is_generic_container_dir(gp) and not _is_ignored(gp):
        return gp, 6.0, ["grandparent-scope"]
    return None


def _entry_kind(path: str, reasons: Sequence[str]) -> str:
    pl = _path_l(path)
    rs = " ".join(reasons).lower()
    if "project-root:unity" in rs or ("assets" in _direct_names(path) and "projectsettings" in _direct_names(path)):
        return "unity-project"
    if "project-root" in rs or "project-marker" in rs:
        return "project-root"
    if any(x in pl for x in ["invoice", "receipt", "账单", "发票", "报销"]):
        return "billing-materials"
    if any(x in pl for x in ["paper", "论文", "thesis", "zotero"]):
        return "paper-materials"
    if any(x in pl for x in ["课程", "作业", "大一", "大二", "大三", "大四"]):
        return "course-materials"
    return "semantic-scope"


def probe_node(path: str, *, max_children: int = 24) -> Dict[str, Any]:
    p = _norm(path)
    nt = _node_type(p)
    probe: Dict[str, Any] = {"path": p, "node_type": nt, "exists": nt is not None}
    if nt == "dir":
        try:
            names = os.listdir(p)[:max_children]
        except OSError:
            names = []
        probe["children"] = names
        probe["markers"] = [x for x in names if x.lower() in ENTRY_BASENAMES or x.lower() in PROJECT_MARKERS]
        for readme in ["README.md", "readme.md", "README.txt", "readme.txt"]:
            rp = os.path.join(p, readme)
            if os.path.isfile(rp):
                try:
                    with open(rp, encoding="utf-8", errors="replace") as fh:
                        probe["readme_excerpt"] = " ".join(fh.read(1200).split())[:800]
                except OSError:
                    pass
                break
        # Lightweight config/requirements summaries.
        for fn in ["package.json", "pyproject.toml", "requirements.txt", "Packages/manifest.json"]:
            fp = os.path.join(p, *fn.split("/"))
            if os.path.isfile(fp):
                try:
                    with open(fp, encoding="utf-8", errors="replace") as fh:
                        probe.setdefault("config_excerpt", {})[fn] = " ".join(fh.read(1600).split())[:900]
                except OSError:
                    pass
    elif nt == "file":
        probe["basename"] = os.path.basename(p)
        if os.path.splitext(p)[1].lower() in {".md", ".txt", ".py", ".json", ".toml", ".yml", ".yaml"} or os.path.basename(p).lower() in {"dockerfile", "makefile"}:
            try:
                with open(p, encoding="utf-8", errors="replace") as fh:
                    probe["excerpt"] = " ".join(fh.read(1200).split())[:800]
            except OSError:
                pass
    return probe


def build_entry_items(cands: Sequence[Dict[str, Any]], *, target_entries: int = 220, scope: Optional[str] = None,
                      leaf_per_entry: int = 10) -> List[Dict[str, Any]]:
    entries: Dict[str, Dict[str, Any]] = {}
    for c in cands:
        ep = _pick_entry_for_candidate(c["path"], scope=scope)
        if not ep:
            continue
        entry_path, bonus, entry_reasons = ep
        if _is_ignored(entry_path) or _node_type(entry_path) != "dir":
            continue
        e = entries.setdefault(entry_path, {
            "path": entry_path, "node_type": "dir", "score": 0.0, "reasons": [], "leaf_candidates": [], "leaf_seen": set(),
        })
        cscore = max(float(c.get("score") or 0), 0)
        e["score"] += min(cscore * 0.25, 10.0) + bonus
        e["reasons"].extend(c.get("reasons", [])[:6] + entry_reasons)
        lp = c["path"]
        if lp != entry_path and lp not in e["leaf_seen"] and len(e["leaf_candidates"]) < leaf_per_entry * 2:
            e["leaf_candidates"].append({
                "path": lp, "node_type": c.get("node_type"), "score": cscore,
                "basename": os.path.basename(lp), "reasons": c.get("reasons", [])[:6],
            })
            e["leaf_seen"].add(lp)
    items: List[Dict[str, Any]] = []
    for e in entries.values():
        # Penalize entries with no representative leaf unless they are clear roots.
        leaf_n = len(e["leaf_candidates"])
        reason_text = " ".join(e["reasons"]).lower()
        marker_bonus = 30 if ("project-root" in reason_text or "project-marker" in reason_text or "collection" in reason_text) else 0
        score = float(e["score"]) + marker_bonus + min(leaf_n, 12) * 2
        if score < 12:
            continue
        # Deduplicate reasons while preserving order.
        seen = set(); reasons = []
        for r in e["reasons"]:
            if r not in seen:
                reasons.append(r); seen.add(r)
        suggested = "active" if score >= 55 else "warm" if score >= 25 else "cold"
        probe = probe_node(e["path"])
        relation = {
            "role": "entry", "entry_kind": _entry_kind(e["path"], reasons),
            "leaf_candidates": e["leaf_candidates"][:leaf_per_entry],
            "leaf_count": leaf_n,
            "probe": probe,
        }
        items.append({
            "path": e["path"], "node_type": "dir", "suggested_tier": suggested,
            "seed_score": round(score, 3), "evidence": [f"leaf_candidates={leaf_n}"] + reasons[:16],
            "relation": relation, "visible_terms": sorted(store.visible_terms(e["path"]))[:30],
        })
    items.sort(key=lambda x: (x["suggested_tier"] == "active", x["suggested_tier"] == "warm", x["seed_score"]), reverse=True)
    return items[:target_entries]


def _session_meta(row: Any) -> Dict[str, Any]:
    try:
        meta = json.loads(row["meta"] or "{}")
        return meta if isinstance(meta, dict) else {}
    except Exception:
        return {}


def _update_session_meta(conn, session_id: str, meta: Dict[str, Any]) -> None:
    conn.execute("UPDATE build_sessions SET meta=?,updated_at=? WHERE session_id=?",
                 (json.dumps(meta, ensure_ascii=False), time.time(), session_id))


def _insert_build_items(conn, session_id: str, items: Sequence[Dict[str, Any]], *, batch_no: int = 0) -> int:
    now = time.time()
    inserted = 0
    for n in items:
        if _is_ignored(n["path"]) or _node_type(n["path"]) != n.get("node_type"):
            store.append_event("candidate_ignored", path=n.get("path"), reason="ignore_or_type_after_entry_build", source="builder")
            continue
        cur = conn.execute("""INSERT OR IGNORE INTO build_items(session_id,path,node_type,suggested_tier,seed_score,evidence,relation,visible_terms,status,batch_no,created_at,updated_at)
                              VALUES(?,?,?,?,?,?,?,?, 'pending',?,?,?)""",
                           (session_id, n["path"], n["node_type"], n["suggested_tier"], float(n.get("seed_score") or 0),
                            json.dumps(n.get("evidence", []), ensure_ascii=False), json.dumps(n.get("relation", {}), ensure_ascii=False),
                            json.dumps(n.get("visible_terms", []), ensure_ascii=False), batch_no, now, now))
        if cur.rowcount:
            inserted += 1
    return inserted


def prepare_cold_start(conn, *, target_nodes: int = 1000, max_active: int = 220, scope: Optional[str] = None,
                       agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", purpose: Optional[str] = None,
                       recent_limit: int = 1800, limit_per_query: int = 120, parent_levels: int = 2) -> Dict[str, Any]:
    """Start a v9 cold-start session quickly, without scanning the drive.

    v8 still did candidate collection/probing inside begin_cold_start(), which
    can time out on a large F: drive. v9 deliberately makes begin_cold_start()
    a lightweight session creation step. The same coverage is obtained through
    repeated collect_cold_start_entries() calls, each with explicit budgets.
    """
    target = max(20, int(target_nodes))
    target_entries = max(60, min(260, int(target * 0.22)))
    queries = merge_queries(agent_queries, memory_text)
    sid = "cs_" + hashlib.sha1((str(time.time()) + str(scope) + str(len(queries))).encode()).hexdigest()[:12]
    now = time.time()
    meta = {
        "scope": scope,
        "purpose": purpose,
        "memory_text": (memory_text or "")[:16000],
        "queries": queries,
        "query_cursor": 0,
        "recent_done": False,
        "collect_done": False,
        "candidate_count": 0,
        "staged_entries": 0,
        "target_entries": target_entries,
        "collection_rounds": 0,
        "mode": "v9-incremental-entry-first",
        "default_recent_limit": recent_limit,
        "default_limit_per_query": limit_per_query,
    }
    conn.execute("INSERT INTO build_sessions(session_id,status,target_nodes,max_active,created_at,updated_at,meta) VALUES(?,?,?,?,?,?,?)",
                 (sid, "open", target, max_active, now, now, json.dumps(meta, ensure_ascii=False)))
    store.append_event("cold_start_started", reason=sid, source="builder", extra={"target_nodes": target, "target_entries": target_entries, "scope": scope, "mode": meta["mode"], "queries_total": len(queries)})
    conn.commit()
    return {
        "ok": True,
        "session_id": sid,
        "mode": meta["mode"],
        "message": "session created; call collect_cold_start_entries() in bounded rounds before cold_start_batch()",
        "queries_total": len(queries),
        "query_cursor": 0,
        "recent_done": False,
        "collection_done": False,
        "staged_entries": 0,
        "target_nodes": target,
        "target_entries": target_entries,
        "max_active": max_active,
        "remaining_entries": target_entries,
        "next_action": "collect_cold_start_entries(session_id, max_queries=..., time_budget_sec=...)"
    }


def collect_cold_start_entries(conn, session_id: str, *, max_queries: int = 4, recent_limit: int = 800,
                               limit_per_query: int = 80, max_entries: int = 80, time_budget_sec: float = 25.0,
                               include_recent: bool = True) -> Dict[str, Any]:
    """Incrementally collect/probe/stage semantic entry candidates.

    This preserves v8 quality and coverage because it uses the same candidate
    scoring, scope aggregation, probe, and entry builder. The only change is
    execution granularity: a full-drive cold start becomes many small commits
    rather than one timeout-prone begin_cold_start() call.
    """
    sess = conn.execute("SELECT * FROM build_sessions WHERE session_id=?", (session_id,)).fetchone()
    if not sess:
        return {"ok": False, "error": "session not found", "session_id": session_id}
    meta = _session_meta(sess)
    if meta.get("mode") not in {"v9-incremental-entry-first", "v8-entry-first"}:
        # Allow older sessions, but normalize metadata.
        meta["mode"] = "v9-incremental-entry-first"
    scope = meta.get("scope")
    purpose = meta.get("purpose")
    memory_text = meta.get("memory_text") or ""
    queries = list(meta.get("queries") or [])
    if not queries:
        queries = merge_queries([], memory_text)
        meta["queries"] = queries
    cursor = int(meta.get("query_cursor") or 0)
    recent_done = bool(meta.get("recent_done"))
    max_queries = max(0, int(max_queries))
    max_entries = max(1, int(max_entries))
    target_nodes = int(sess["target_nodes"] or 1000)
    target_entries = int(meta.get("target_entries") or max(60, min(260, target_nodes * 0.22)))
    leaf_per_entry = max(6, min(14, target_nodes // max(target_entries, 1)))

    chunk = queries[cursor: cursor + max_queries]
    include_recent_now = bool(include_recent and not recent_done)
    if not chunk and not include_recent_now:
        meta["collect_done"] = True
        _update_session_meta(conn, session_id, meta)
        conn.commit()
        return {"ok": True, "session_id": session_id, "collection_done": True, "staged_new": 0, "message": "all discovery queries have been processed"}

    cands, cstats = collect_candidates_incremental(chunk, memory_text=memory_text, scope=scope,
                                                   limit_per_query=limit_per_query, include_recent=include_recent_now,
                                                   recent_limit=recent_limit, purpose=purpose,
                                                   time_budget_sec=float(time_budget_sec))
    processed = int(cstats.get("processed_queries") or 0)
    # Even if recent search failed, it has been attempted; don't retry every round by default.
    if include_recent_now:
        meta["recent_done"] = True
    meta["query_cursor"] = min(len(queries), cursor + processed)
    meta["candidate_count"] = int(meta.get("candidate_count") or 0) + int(cstats.get("candidate_count") or 0)
    meta["collection_rounds"] = int(meta.get("collection_rounds") or 0) + 1

    items = build_entry_items(cands, target_entries=max_entries, scope=scope, leaf_per_entry=leaf_per_entry)
    batch_no = int(meta.get("collection_rounds") or 0)
    inserted = _insert_build_items(conn, session_id, items, batch_no=batch_no)
    staged_total = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=?", (session_id,)).fetchone()[0]
    meta["staged_entries"] = staged_total
    if meta["query_cursor"] >= len(queries) and meta.get("recent_done"):
        meta["collect_done"] = True
    _update_session_meta(conn, session_id, meta)
    conn.commit()
    store.append_event("cold_start_collected", reason=session_id, source="builder", extra={"processed_queries": processed, "staged_new": inserted, "staged_total": staged_total, "candidate_count": cstats.get("candidate_count"), "elapsed_sec": cstats.get("elapsed_sec")})
    return {
        "ok": True,
        "session_id": session_id,
        "mode": meta.get("mode"),
        "processed_queries": processed,
        "query_cursor": meta["query_cursor"],
        "queries_total": len(queries),
        "recent_attempted": cstats.get("recent_attempted"),
        "recent_done": meta.get("recent_done"),
        "collection_done": bool(meta.get("collect_done")),
        "candidate_count_this_round": cstats.get("candidate_count"),
        "staged_new": inserted,
        "staged_entries": staged_total,
        "pending": conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0],
        "elapsed_sec": cstats.get("elapsed_sec"),
        "next_action": "cold_start_batch() if pending > 0; otherwise call collect_cold_start_entries() again" if not meta.get("collect_done") else "cold_start_batch() or finish_cold_start() when enough entries are applied",
        "query_errors": cstats.get("query_errors", []),
    }

def cold_start_batch(conn, session_id: str, *, batch_size: int = 50) -> Dict[str, Any]:
    rows = conn.execute("SELECT * FROM build_items WHERE session_id=? AND status='pending' ORDER BY seed_score DESC LIMIT ?", (session_id, max(1, int(batch_size)))).fetchall()
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    applied = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    rejected = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='rejected'", (session_id,)).fetchone()[0]
    items = []
    for r in rows:
        relation = json.loads(r["relation"] or "{}")
        probe = relation.get("probe", {})
        items.append({
            "path": r["path"], "node_type": r["node_type"], "suggested_tier": r["suggested_tier"], "seed_score": r["seed_score"],
            "visible_terms": json.loads(r["visible_terms"] or "[]"), "evidence": json.loads(r["evidence"] or "[]"),
            "relation": relation, "probe": probe,
            "required_output": {
                "brief": "one-line scope value statement: what this directory lets the Agent find/do",
                "tags": "2-4 route tags: query aliases or task semantics, not path repetition",
                "note": "Label the scope/entry, not every leaf. Accepted entries will auto-materialize representative leaves."
            },
        })
    sess = conn.execute("SELECT meta FROM build_sessions WHERE session_id=?", (session_id,)).fetchone()
    meta = _session_meta(sess) if sess else {}
    return {"ok": True, "session_id": session_id, "pending": pending, "applied_entries": applied, "rejected": rejected,
            "collection_done": bool(meta.get("collect_done")), "staged_entries": int(meta.get("staged_entries") or 0),
            "query_cursor": int(meta.get("query_cursor") or 0), "queries_total": len(meta.get("queries") or []),
            "items": items,
            "next_action": "label returned items" if items else ("collect_cold_start_entries" if not meta.get("collect_done") else "finish or collect more candidates if remaining_entries > 0")}


def _staged_map(conn, session_id: str) -> Dict[str, Dict[str, Any]]:
    return {r["path"]: dict(r) for r in conn.execute("SELECT * FROM build_items WHERE session_id=?", (session_id,))}


def _materialize_leaf_nodes(conn, entry_path: str, entry_brief: str, entry_tags: Sequence[str], relation: Dict[str, Any], *, source: str, fts_ok: bool, max_leaves: int = 10) -> int:
    leaves = relation.get("leaf_candidates") or []
    count = 0
    for leaf in leaves[:max_leaves]:
        lp = _norm(leaf.get("path", ""))
        if not lp or lp == entry_path or _is_ignored(lp) or not os.path.exists(lp):
            continue
        nt = _node_type(lp)
        if nt not in {"file", "dir"}:
            continue
        base = os.path.basename(lp)
        # Leaf brief is deliberately lightweight; route semantics live on entry.
        br = f"Representative item under {os.path.basename(entry_path)}: {base}"
        if store.bad_brief_reason(br, lp):
            br = f"Supports indexed scope {os.path.basename(entry_path)} via {base}"
        rel = {"role": "leaf", "entry": entry_path, "entry_tags": list(entry_tags), "leaf_reasons": leaf.get("reasons", [])}
        # Leaf nodes do not need independent tags; they are found through the entry scope.
        res = store.annotate_node(conn, lp, [], brief=br, node_type=nt, tier="cold", source=source + ":leaf", confidence="entry-derived", seed_score=float(leaf.get("score") or 0), evidence=leaf.get("reasons", []), relation=rel, enforce_tag_gate=False, fts_ok=fts_ok)
        if res.get("ok"):
            count += 1
    return count


def apply_index_plan(conn, plan: Sequence[Dict[str, Any]], *, default_tier: str = "warm", default_state: Optional[str] = None, default_source: str = "agent-builder", enforce_tag_gate: bool = True, fts_ok: bool = False, session_id: Optional[str] = None) -> Dict[str, Any]:
    staged = _staged_map(conn, session_id) if session_id else {}
    applied = 0; skipped = 0; materialized = 0; errors: List[Dict[str, Any]] = []; rejected_tags: List[Dict[str, str]] = []
    now = time.time()
    for item in plan:
        p = _norm(item.get("path", ""))
        if not p:
            errors.append({"item": item, "error": "missing path"}); continue
        if item.get("action") == "skip":
            if session_id and p in staged:
                conn.execute("UPDATE build_items SET status='skipped',updated_at=? WHERE session_id=? AND path=?", (now, session_id, p))
            store.append_event("cold_start_skipped", path=p, reason=str(item.get("reason") or "agent skip"), source=item.get("source") or default_source)
            skipped += 1; continue
        if session_id and p not in staged:
            errors.append({"item": item, "error": "path not in cold-start staged entries; do not invent paths"})
            store.append_event("session_path_rejected", path=p, reason="not_in_build_items", source="builder")
            continue
        if not os.path.exists(p):
            errors.append({"item": item, "error": "path does not exist"}); continue
        if _is_ignored(p):
            errors.append({"item": item, "error": "path matches ignore_rules"}); continue
        inferred = store.infer_node_type(p)
        nt = item.get("node_type") or (staged.get(p) or {}).get("node_type") or inferred
        if inferred is None or nt != inferred or nt not in {"file", "dir"}:
            errors.append({"item": item, "error": f"invalid node_type; inferred {inferred}"}); continue
        tier = item.get("tier") or item.get("state") or default_state or default_tier
        if tier not in {"active", "warm", "cold"}:
            errors.append({"item": item, "error": "tier must be active/warm/cold"}); continue
        # In v9 cold-start build_items are entries, so active/warm are expected.
        brief = (item.get("brief") or "").strip()
        if store.bad_brief_reason(brief, p):
            errors.append({"item": item, "error": f"bad brief: {store.bad_brief_reason(brief, p)}"})
            if session_id and p in staged:
                conn.execute("UPDATE build_items SET status='rejected',updated_at=? WHERE session_id=? AND path=?", (now, session_id, p))
            continue
        extra_visible = []
        staged_relation: Dict[str, Any] = {}
        if session_id and p in staged:
            try: extra_visible = json.loads(staged[p].get("visible_terms") or "[]")
            except Exception: extra_visible = []
            try: staged_relation = json.loads(staged[p].get("relation") or "{}")
            except Exception: staged_relation = {}
        tags = item.get("tags") or []
        # v9 route tags may include query aliases that overlap path terms, so use relaxed gate.
        kept, rejected = store.filter_route_tags(tags, p, extra_visible=extra_visible) if hasattr(store, "filter_route_tags") else store.filter_high_info_tags(tags, p, extra_visible=extra_visible)
        if tier in {"active", "warm"} and len(kept) < 1:
            errors.append({"item": item, "error": "active/warm entry requires route tags", "rejected_tags": rejected})
            if session_id and p in staged:
                conn.execute("UPDATE build_items SET status='rejected',updated_at=? WHERE session_id=? AND path=?", (now, session_id, p))
            continue
        evidence = item.get("evidence") if "evidence" in item else (json.loads(staged[p]["evidence"]) if session_id and p in staged else [])
        relation = item.get("relation") if "relation" in item else staged_relation
        if not isinstance(relation, dict):
            relation = {}
        relation = {**relation, "role": relation.get("role") or "entry"}
        res = store.annotate_node(conn, p, kept, brief=brief, node_type=nt, tier=tier, source=item.get("source") or default_source, confidence=item.get("confidence") or "agent-entry", seed_score=float(item.get("seed_score") if "seed_score" in item else (staged.get(p, {}).get("seed_score") or 0)), evidence=evidence, relation=relation, enforce_tag_gate=False, fts_ok=fts_ok)
        if not res.get("ok"):
            errors.append({"item": item, "error": res.get("error")}); continue
        for r in rejected:
            rejected_tags.append({p: r})
        if session_id:
            conn.execute("UPDATE build_items SET status='applied',updated_at=? WHERE session_id=? AND path=?", (now, session_id, p))
        applied += 1
        materialized += _materialize_leaf_nodes(conn, p, brief, kept, relation, source=item.get("source") or default_source, fts_ok=fts_ok, max_leaves=int(item.get("max_leaves") or 10))
    conn.commit()
    return {"applied_entries": applied, "applied": applied, "materialized_leaf_nodes": materialized, "skipped": skipped, "errors": errors, "rejected_tags": rejected_tags}


def cold_start_status(conn, session_id: str) -> Dict[str, Any]:
    sess = conn.execute("SELECT * FROM build_sessions WHERE session_id=?", (session_id,)).fetchone()
    if not sess:
        return {"ok": False, "error": "session not found", "session_id": session_id}
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    applied_entries = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    skipped = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='skipped'", (session_id,)).fetchone()[0]
    rejected = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='rejected'", (session_id,)).fetchone()[0]
    meta = _session_meta(sess)
    target_nodes = int(sess["target_nodes"])
    target_entries = int(meta.get("target_entries") or max(60, min(260, target_nodes * 0.22)))
    total_nodes = conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
    entry_nodes = conn.execute("SELECT COUNT(*) FROM nodes WHERE json_extract(relation,'$.role')='entry'").fetchone()[0]
    queries_total = len(meta.get("queries") or [])
    query_cursor = int(meta.get("query_cursor") or 0)
    collect_done = bool(meta.get("collect_done"))
    remaining_entries = max(0, target_entries - applied_entries)
    if remaining_entries <= 0:
        next_action = "finish_cold_start"
    elif pending > 0:
        next_action = "cold_start_batch + apply_index_plan"
    elif not collect_done:
        next_action = "collect_cold_start_entries"
    else:
        next_action = "collection exhausted; lower target_entries or broaden queries/scope"
    return {"ok": True, "session_id": session_id, "status": sess["status"], "mode": meta.get("mode", "v9-incremental-entry-first"),
            "pending": pending, "applied_entries": applied_entries, "skipped": skipped, "rejected": rejected,
            "target_entries": target_entries, "remaining_entries": remaining_entries,
            "nodes_total": total_nodes, "entry_nodes": entry_nodes, "target_nodes": target_nodes,
            "remaining_nodes": max(0, target_nodes - total_nodes), "max_active": sess["max_active"],
            "collection_done": collect_done, "recent_done": bool(meta.get("recent_done")),
            "query_cursor": query_cursor, "queries_total": queries_total,
            "staged_entries": int(meta.get("staged_entries") or 0),
            "collection_rounds": int(meta.get("collection_rounds") or 0),
            "candidate_count_seen": int(meta.get("candidate_count") or 0),
            "next_action": next_action}

def finish_cold_start(conn, session_id: str, *, max_nodes: int = 1000, max_active: int = 220, fts_ok: bool = False) -> Dict[str, Any]:
    st = cold_start_status(conn, session_id)
    if not st.get("ok"):
        return st
    # Completion is based on semantic entries, not raw path count only.
    if st["remaining_entries"] > 0:
        return {"ok": False, "status": "partial", "error": "not enough accepted semantic entries", **st, "next_action": "continue cold_start_batch + apply_index_plan, or collect more candidates"}
    rb = store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, fts_ok=fts_ok)
    audit = audit_index(conn, fix=False, fts_ok=fts_ok)
    if audit.get("ignored_rule_violations") or audit.get("missing_paths") or audit.get("bad_node_types"):
        return {"ok": False, "status": "audit_failed", "rebalance": rb, "audit": audit}
    conn.execute("UPDATE build_sessions SET status='complete',updated_at=? WHERE session_id=?", (time.time(), session_id))
    conn.commit()
    store.append_event("cold_start_finished", reason=session_id, source="builder", extra={"rebalance": rb, "audit": audit})
    return {"ok": True, "status": "complete", "session_id": session_id, "rebalance": rb, "audit": audit, **cold_start_status(conn, session_id)}


def label_worklist(conn, *, limit: int = 80, node_types: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
    # Prefer existing entries with weak/no route tags, then high-score warm/cold nodes.
    sql = """SELECT n.path,n.node_type,n.brief,n.tier,n.seed_score,n.evidence,n.relation,COUNT(t.tag) tag_n
             FROM nodes n LEFT JOIN node_tags t ON n.path=t.path
             GROUP BY n.path
             ORDER BY (json_extract(n.relation,'$.role')='entry') DESC, tag_n ASC, n.seed_score DESC LIMIT ?"""
    out = []
    for r in conn.execute(sql, (max(1, int(limit)),)):
        out.append({"path": r["path"], "node_type": r["node_type"], "tier": r["tier"], "brief": r["brief"], "seed_score": r["seed_score"], "tag_count": r["tag_n"], "evidence": json.loads(r["evidence"] or "[]"), "relation": json.loads(r["relation"] or "{}"), "probe": (json.loads(r["relation"] or "{}").get("probe") if r["relation"] else None)})
    return out


def miss_recovery_batch(conn, query: str, *, memory_text: str = "", scope: Optional[str] = None, limit: int = 80) -> Dict[str, Any]:
    cands = collect_candidates([query], memory_text=memory_text, scope=scope, limit_per_query=max(40, limit), include_recent=False, recent_limit=0, purpose=query)
    entries = build_entry_items(cands, target_entries=max(10, min(limit, 80)), scope=scope, leaf_per_entry=8)
    return {"ok": True, "query": query, "entries": entries[:limit], "note": "Label promising entries with apply_index_plan; accepted entries can materialize representative leaves."}


def audit_index(conn, *, fix: bool = False, fts_ok: bool = False) -> Dict[str, Any]:
    missing: List[str] = []; ignored: List[str] = []; bad_tags: List[Dict[str, str]] = []; bad_briefs: List[str] = []; bad_types: List[str] = []; active_without_tags: List[str] = []
    role_counts: Counter[str] = Counter()
    for r in conn.execute("SELECT path,node_type,tier,brief,relation FROM nodes"):
        p = r["path"]
        rel = {}
        try: rel = json.loads(r["relation"] or "{}")
        except Exception: rel = {}
        role_counts[rel.get("role", "unknown")] += 1
        if r["node_type"] not in {"file", "dir"}: bad_types.append(p)
        if not os.path.exists(p): missing.append(p)
        if store.match_ignore_rules(p): ignored.append(p)
        if r["tier"] in {"active", "warm"}:
            if store.bad_brief_reason(r["brief"] or "", p): bad_briefs.append(p)
            tag_n = conn.execute("SELECT COUNT(*) FROM node_tags WHERE path=?", (p,)).fetchone()[0]
            if tag_n == 0: active_without_tags.append(p)
    for r in conn.execute("SELECT path,tag FROM node_tags"):
        kept, rejected = store.filter_route_tags([r["tag"]], r["path"]) if hasattr(store, "filter_route_tags") else store.filter_high_info_tags([r["tag"]], r["path"])
        if rejected: bad_tags.append({r["path"]: r["tag"]})
    if fix:
        for p in set(missing + ignored + bad_types):
            store.delete_node(conn, p, reason="audit_fix_remove_unusable", source="audit", fts_ok=fts_ok)
        for bt in bad_tags:
            for p, tag in bt.items():
                conn.execute("DELETE FROM node_tags WHERE path=? AND tag=?", (p, tag))
        conn.commit()
    return {
        "nodes_total": conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0],
        "entry_nodes": role_counts.get("entry", 0), "leaf_nodes": role_counts.get("leaf", 0), "unknown_role_nodes": role_counts.get("unknown", 0),
        "missing_paths": len(missing), "ignored_rule_violations": len(ignored), "bad_node_types": len(bad_types),
        "bad_tag_count": len(bad_tags), "generic_brief_count": len(bad_briefs), "active_warm_without_tags": len(active_without_tags),
        "samples": {"missing": missing[:10], "ignored": ignored[:10], "bad_tags": bad_tags[:10], "bad_briefs": bad_briefs[:10], "active_without_tags": active_without_tags[:10]},
    }
