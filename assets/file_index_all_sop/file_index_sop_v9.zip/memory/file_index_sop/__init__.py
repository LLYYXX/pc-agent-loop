"""file_index_sop v9: incremental entry-first semantic coverage over Everything/es.exe."""
__version__ = "v9"
