# file_index_sop v25 — runtime SOP

This is the single root SOP entry for local file semantic indexing. Use it for ordinary local-file tasks. If the user asks to build/rebuild an index, read `file_index_sop/cold_start_sop.md`.

## Import

Always use the package already stored in memory:

```python
from file_index_sop import *
```

Do not import internal modules such as `file_index_sop.store` during normal use. Do not use raw SQL for normal inspection.

## Runtime flow

1. Try semantic recall/locate first:

```python
res = recall(user_query)      # fixed dict: {ok, task_id, query, hits, finalize_required}
# or
res = locate(user_query)
```

2. If recall is insufficient, use factual search:

```python
hits = search_files(user_query, scope=optional_scope, limit=50)
```

`search_files` is a thin Everything/es.exe wrapper. It does not expand semantics, infer tags, or rerank. Use `search_files_detailed` only when search behavior is suspicious; it exposes argv/scope/encoding/stderr/hit_count.

3. For database inspection, use wrappers only:

```python
index_summary()
list_entries(limit=50)
list_nodes(role="entry", tier="warm", limit=50)
list_leaf(entry_path)
top_tags()
search_index("machine learning", tags_any=["machine-learning", "ml-agents", "ai-audio"], limit=50)
nodes_by_tag("machine-learning")
get_node(path)
audit_index()
```

4. Use normal Agent tools to read/list/summarize files after locating paths.

5. Before final answer, if the task used local paths, call:

```python
finalize_file_task(
    task_id=res.get("task_id"),
    query=user_query,
    used_paths=[...],
    found_paths=[...],
    rejected_paths=[...],
    fallback_used=bool(res.get("fallback_used")),
    mode="draft",
)
```

Behavior:
- used indexed paths are promoted/warmed and then rebalanced;
- active/warm/max_nodes caps are enforced opportunistically;
- external paths generate a draft update plan;
- draft plans do not invent route tags.

## Route tag rule

Agent writes route tags. Helper never infers them.

A route tag must describe the current entry's main search use, not a neighboring project, dependency, external reference, or generic category. Every tagged entry must include an evidence note grounded in expanded evidence.

## Tier rule

- active: small hot set from real use;
- warm: stable semantic entry layer;
- cold: support leaves and low-frequency candidates.

`maintenance_tick()` / `rebalance_tiers()` enforces max_active/max_warm/max_nodes. Do not manually set many nodes to active.
