# file_index_sop v25 — cold start SOP

Use this only when the user asks to build or rebuild an initial index for a scope such as `F:\`.

Cold start is Agent-led and transaction-oriented. Helper provides candidates, rough evidence, expanded evidence, session status, and storage. It does not generate semantic route tags.

## Import and start

```python
from file_index_sop import *
ensure_search_ready(start=True, patch=True)
init_db()
res = begin_cold_start(scope="F:\\", target_nodes=1000)
sid = res["session_id"]
```

`target_nodes` is a budget/cap hint, not a required number of committed entries.

## Candidate loop

```python
collect_cold_start_entries(sid)
batch = cold_start_batch(sid, batch_size=6)
items = batch["items"]
```

`cold_start_batch` is rough triage only. Do not apply route tags from rough evidence alone. Do not write path/extension/children_count if-elif classifiers over the batch.

For any item to apply:

```python
expanded = expand_candidate(sid, item["path"])
# read expanded["item"]["evidence"], especially representative_document_files and document_heads/content_head if present
```

Then choose exactly one:

```python
# apply only when expanded evidence supports the brief/tags
apply_index_plan([
  {
    "path": path,
    "role": "entry",
    "tier": "warm",
    "brief": "Agent-written one-line scope description",
    "tags": ["accurate-route-tag"],
    "evidence_note": "Based on expanded evidence: ...",
    "leaf_candidates": [ ... optional representative paths ... ]
  }
], session_id=sid)

# skip only for specific confirmed reasons such as duplicate/already-indexed, out-of-scope,
# system/dependency/build, confirmed-noise, user-excluded, or not-useful-after-expanded-evidence
skip_candidate(sid, path, reason="duplicate: already indexed by parent entry")

# defer when evidence is insufficient, generic-looking, small, Office-heavy, or otherwise unknown
defer_candidate(sid, path, reason="needs expanded/manual evidence; do not skip unknown document candidate")
```

Rejected apply results are not progress. If `apply_index_plan` says expanded evidence is required, call `expand_candidate` and retry or defer. If skip is rejected, use defer/need_more_evidence unless the reason is one of the explicit skip categories.

## Finish

```python
finish = finish_cold_start(sid)
audit = audit_index()
summary = index_summary()
```

Finish status semantics:
- `complete`: broad verified coverage; may be reported as fully established.
- `usable_partial`: some high-confidence entries exist and the protocol is healthy; may be reported as a usable partial seed index.
- `incomplete`: pending/needs-more-evidence work remains; report honestly.
- `failed`: protocol/tool failure, no tagged entries, or unusable state.

Entry counts are diagnostics/reference targets, not failure thresholds. Never lower evidence standards to increase counts.

## Candidate policy

- hard-ignore only high-confidence dependency/system/build dirs from policy;
- cache/tmp/log/backup-like names are soft downrank only, not exclusion;
- Office/PDF/text documents are valid evidence sources even when few in number or in generic-named folders;
- default queries and marker names are candidate-discovery signals only;
- they must not become route tags automatically.

## Do not

- do not write case-specific rules;
- do not auto-generate route tags from path names;
- do not write if/elif classifiers over paths, file counts, or extensions;
- do not skip because of `children_count < 3`, `Generic directory`, `unsupported extension`, or Office/document-heavy content;
- do not use raw SQL or import internal store functions;
- do not call a small partial index complete.
