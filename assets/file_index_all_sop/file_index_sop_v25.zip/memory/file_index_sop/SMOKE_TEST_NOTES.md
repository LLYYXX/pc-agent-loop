# file_index_sop v25 smoke-test notes

Implemented and smoke-tested against a synthetic scope with:

- a code project with README/pyproject;
- a small Office-document directory with `.docx`/`.pptx`;
- a Markdown notes directory with readable content head;
- a tmp/video directory.

Checks run:

1. `python -m py_compile memory/file_index_sop/*.py`
2. `from file_index_sop import *` imports successfully.
3. `begin_cold_start / collect_cold_start_entries / cold_start_batch` run.
4. Candidate source classes include `document_parent`; document seeds are not starved by top/recent sources.
5. Rough batch item cannot be applied before `expand_candidate`; it is marked `needs_more_evidence`.
6. `expand_candidate` returns `document_heads` for text evidence.
7. Expanded evidence-backed apply succeeds.
8. `skip_candidate(..., "Generic directory")` and `skip_candidate(..., "Too few items")` are rejected and move candidate to `needs_more_evidence`.
9. `finish_cold_start` does not fail merely because committed entries are below 60/120; counts are diagnostics/reference targets, not hard failure thresholds.
10. `recall` returns a fixed dict and `search_index` works through public wrappers.

Known boundary: no semantic tag correctness is guaranteed by helper. The helper enforces transaction/evidence protocol and blocks common degenerative execution patterns; Agent/Verifier still owns semantic judgment.
