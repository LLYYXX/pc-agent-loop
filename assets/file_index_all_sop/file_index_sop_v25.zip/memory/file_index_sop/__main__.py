from .helper import print_json, index_summary

if __name__ == "__main__":
    print_json(index_summary())
