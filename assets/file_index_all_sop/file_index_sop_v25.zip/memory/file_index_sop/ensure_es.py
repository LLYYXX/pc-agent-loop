#!/usr/bin/env python3
"""Prepare Everything/es.exe for file_index_sop.

Discovery, optional LOCAL_TOOLS patching, and optional Everything startup live here.
Search wrappers remain thin and do not patch memory.
"""
from __future__ import annotations

import argparse
import json
try:
    from . import everything_core as core
except Exception:  # direct script execution
    import os, sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import everything_core as core


def ensure_ready(*, start: bool = True, patch: bool = True, dry_run: bool = False):
    return core.ensure_ready(start=start, patch=patch, dry_run=dry_run)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-start", action="store_true")
    ap.add_argument("--no-patch", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ns = ap.parse_args()
    print(json.dumps(ensure_ready(start=not ns.no_start, patch=not ns.no_patch, dry_run=ns.dry_run), ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
