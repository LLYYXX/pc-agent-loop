# file_index_sop v23 design note

file_index is Agent L5 memory: a lightweight SQLite semantic overlay over Everything/es.exe.

- L1 triggers `file_index_sop.md`.
- L2 stores environment facts such as `LOCAL_TOOLS/es.exe`.
- L3 stores `file_index_sop.md` and the `file_index_sop/` package.
- L5 stores nodes/tags/aliases/update plans/usage.

The project intentionally does less in Python: the Agent judges semantics from expanded evidence, while helper code handles search, evidence packaging, storage, candidate state, status, and opportunistic tier rebalance.

Runtime and cold start are split:

- runtime SOP: `memory/file_index_sop.md`
- cold-start SOP: `memory/file_index_sop/cold_start_sop.md`

The only normal import is:

```python
from file_index_sop import *
```
