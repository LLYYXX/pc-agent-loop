# 文件语义索引 Skill（Agent 冷启动建库版 v6）

本 Skill 是 Everything / `es.exe` 之上的**正交语义覆盖层**。目标不是生成候选池，而是让 Agent 在用户触发“建索引 / 冷启动”后，针对一个磁盘或目录建立一份**可直接用于文件检索任务的高价值语义索引**。

最终冷启动产物应当接近：

- 约 1000 条真实存在的节点；
- 节点必须来自 es.exe / 文件系统验证，不允许 Agent 发明路径；
- active / warm 节点必须有具体 brief 和高信息 tag；
- cold 节点是已验证的保留候选，必须有 brief，tag 可选；
- `.git`、`node_modules`、缓存、日志、构建产物、回收站、依赖目录不应进入索引；
- tag 用于快速缩小搜索范围，命中目录后再用 `search_files(..., scope=dir)` 展开。

## 核心边界

- `es.exe` 负责文件事实检索：文件名、路径、扩展名、时间、scope。
- 本索引负责语义覆盖：路径看不出来的用途、任务关系、材料归属、项目语义。
- LLM 能力在 Agent 层；Python helper 只做确定性执行：嗅探/启动、es 查询、候选压缩、写库、召回、升降级、质量门禁。
- 不改 GenericAgent 主流程，不注册工具，不 hook `file_read`，不后台 watcher，不向量库。

## import

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop.helper import *
```

## 使用索引前：先确保 Everything 可用

Agent 在首次使用索引或冷启动前，必须显式执行：

```python
print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

`ensure_search_ready()` 负责：

1. 嗅探 `es.exe`；
2. 嗅探 `Everything.exe`；
3. patch `memory/global_mem.txt` 的 `## [LOCAL_TOOLS]`；
4. 如果 es IPC 不可用，则尝试启动 Everything；
5. 再 probe `es.exe` 是否可查。

`everything.py` 只执行已配置的 `es.exe` 查询，不嗅探、不启动、不写 memory。

## 冷启动：针对磁盘建立高价值索引

用户说“帮我针对 F 盘建一个初步索引”时，Agent 不得只生成候选池后停止。完整冷启动是一个多轮 Agent 流程。

### 1. 开始 cold-start session

Agent 先根据 Memory / 用户长期任务生成 `agent_queries`。例如 MCP、trajectory、元应用、论文、实验、报销、invoice、ML、Unity、Paddle 等。然后：

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=220,
    scope=r"F:\",
    memory_text="这里填可用的 Agent Memory 摘要",
    agent_queries=["mcp", "trajectory", "轨迹", "元应用", "论文", "实验", "报销", "invoice", "receipt", "ml-agents", "llm", "paddle"],
)
print_json(res)
session_id = res["session_id"]
```

v6 会 staged 多于 1000 的真实候选，允许 Agent 跳过低价值项，但最终 finish 前必须应用足够的高质量节点。

### 2. Agent 分批标注并入库

循环执行，直到 `cold_start_status(session_id)["remaining_to_target"] == 0`：

```python
batch = cold_start_batch(session_id, batch_size=40)
print_json(batch)
```

Agent 阅读 `batch["items"]` 后生成 plan。只能使用 batch 中的原始 path，禁止发明路径。

每个 plan item：

```python
{
  "path": r"F:\...\某真实路径",       # 必须来自 staged batch
  "node_type": "file" or "dir",
  "state": "active" or "warm" or "cold",
  "brief": "一行说明这个节点未来为什么值得找。",
  "tags": ["high-info-routing-tag"],
  "source": "agent-cold-start"
}
```

质量规则：

- `active`: 必须是真正重要的默认召回节点，必须有具体 brief + 至少一个通过 gate 的高信息 tag。
- `warm`: 必须是高价值、未来可能复用的节点，必须有具体 brief + 至少一个通过 gate 的高信息 tag；如果写不出高信息 tag，应降为 `cold`。
- `cold`: 已验证保留候选，必须有具体 brief，tag 可选。
- 如果候选是系统目录、依赖、缓存、日志、构建产物、低价值样本，使用 `{"action": "skip"}`。
- 不要用 `uncategorized/general/academic/coursework/reading-material/project/file/folder/python/json/csv/config/result` 这类占位或泛化 tag。
- tag 必须是 Everything 不能直接表达的语义残差。
- brief 不能是“dir节点”“项目说明”“课程资料”“文件: xxx”等泛泛说明。

写入：

```python
print_json(apply_index_plan(plan, session_id=session_id))
```

若返回 errors，Agent 必须修正当前 batch，不要跳过错误。

### 3. 完成冷启动

当 `remaining_to_target == 0`：

```python
print_json(cold_start_status(session_id))
print_json(finish_cold_start(session_id, max_nodes=1000, max_active=220))
print_json(audit_index(fix=False))
print_json(stats())
print_json(facets(limit=30))
```

`finish_cold_start()` 会自动 audit + rebalance。若 applied 未达到目标，会返回错误，Agent 必须继续 `cold_start_batch()` + `apply_index_plan()`。

## 运行时检索流程

遇到文件相关任务时，Agent 必须先用语义索引缩小范围：

```python
hits = recall("用户语义意图", limit=8)
```

如果命中 `dir` 节点：

```python
search_files("文件事实词，如 result csv config invoice", scope=hits[0]["path"], limit=20)
```

如果语义索引没有命中或命中很差：

```python
summary = miss_recovery_batch("用户查询", memory_text="可用的 Agent Memory 摘要", limit=80)
```

Agent 根据 `summary` 自行生成 `index_plan`，必须包含 `brief` 和必要的高信息 `tags`，然后：

```python
apply_index_plan(plan)
rebalance(max_nodes=1000, max_active=220)
```

任务完成后：

```python
mark_used(path, matched_tags=["实际命中的tag"])
```

## tag 规则

Tag 是高信息路由键，不是分类标签。

只写：

- 路径 / 文件名 / 扩展名 / 父目录看不出来；
- 未来 Agent 可能用这个语义来找；
- 能显著缩小搜索范围。

避免：

- `readme`, `markdown`, `python`, `json`, `csv`, `config`, `test`, `result`, `project`, `folder`, `file`；
- `uncategorized`, `general`, `academic`, `coursework`, `reading-material`；
- 路径词的同义重复；
- 扩展名和普通文件类型。

推荐：

- `trajectory-reuse-evaluation`
- `unity-ml-agents-training`
- `mcp-service-statistics`
- `generic-agent-runtime`
- `paper-evidence-table`
- `cursor-reimbursement-billing`

## 状态

- `active`: 默认强召回；必须有 brief + 高信息 tag。
- `warm`: 默认召回但弱于 active；必须有 brief + 高信息 tag。
- `cold`: 保留候选，默认不召回；必须有 brief，tag 可选。
- `stale`: mtime 改变，需要复核。
- `retired`: 路径消失或确认不用。

维护：

```python
check_stale()
decay(active_days=30, warm_days=90)
rebalance(max_nodes=1000, max_active=220)
audit_index(fix=True)
```

## 验证目标

冷启动完成后应满足：

- `stats()["nodes_total"]` 约 1000；
- `audit_index(fix=False)` 中 nonexistent/generated/bad_tag/bad_brief 计数应接近 0；
- active/warm 节点都有具体 brief 和有效 tag；
- `facets()` 不应出现 `uncategorized` 等占位 tag；
- `.git`、`node_modules`、`$RECYCLE.BIN` 不应出现在 active/warm；
- `recall("机器学习")`、`recall("Agent开发")`、`recall("OCR识别")` 等应能命中合理文件或目录；
- 命中目录节点后，Agent 能用 `search_files(..., scope=dir)` 快速展开。
