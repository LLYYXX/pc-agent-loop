"""SQLite store for Agent-driven file semantic coverage."""
from __future__ import annotations

import json
import os
import re
import sqlite3
import time
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_VALID_STATES = {"active", "warm", "cold", "stale", "retired"}
_VALID_NODE_TYPES = {"file", "dir", "unknown"}
_GENERIC_BAD_TAGS = {
    "file","files","folder","directory","dir","document","doc","data","dataset","result","results",
    "config","configuration","script","source","code","src","python","py","javascript","typescript",
    "java","csharp","cs","markdown","md","json","yaml","yml","csv","pdf","docx","xlsx","pptx",
    "readme","test","tests","experiment","experiments","project","projects","image","images","log","logs",
    "cache","temp","tmp","note","notes","paper","papers",
    "uncategorized","general","misc","other","unknown","tbd",
    "academic","coursework","fdu-related","workspace-project","reading-material",
    "web-interface","api-service","testing-suite","containerization","frontend-dev",
    "backend-dev","tool","tools","development","dev","library","libraries"
}

_SCHEMA = """
CREATE TABLE IF NOT EXISTS nodes (
  path TEXT PRIMARY KEY,
  node_type TEXT DEFAULT 'unknown',
  brief TEXT DEFAULT '',
  state TEXT DEFAULT 'warm',
  source TEXT DEFAULT 'agent',
  confidence TEXT DEFAULT 'candidate',
  seed_score REAL DEFAULT 0,
  hit_count INTEGER DEFAULT 0,
  last_access REAL,
  size INTEGER,
  mtime_ns INTEGER,
  evidence TEXT DEFAULT '[]',
  relation TEXT DEFAULT '{}',
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS node_tags (
  path TEXT NOT NULL,
  tag TEXT NOT NULL,
  state TEXT DEFAULT 'warm',
  confidence REAL DEFAULT 1.0,
  source TEXT DEFAULT 'agent',
  hit_count INTEGER DEFAULT 0,
  last_hit REAL,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  PRIMARY KEY(path, tag)
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts REAL NOT NULL,
  op TEXT NOT NULL,
  path TEXT,
  tag TEXT,
  old_state TEXT,
  new_state TEXT,
  note TEXT
);
CREATE TABLE IF NOT EXISTS ignored_paths (
  pattern TEXT PRIMARY KEY,
  path_type TEXT DEFAULT 'prefix',
  reason TEXT DEFAULT '',
  source TEXT DEFAULT 'agent',
  hit_count INTEGER DEFAULT 0,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS build_sessions (
  session_id TEXT PRIMARY KEY,
  status TEXT DEFAULT 'open',
  target_nodes INTEGER DEFAULT 1000,
  max_active INTEGER DEFAULT 220,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  meta TEXT DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS build_items (
  session_id TEXT NOT NULL,
  path TEXT NOT NULL,
  node_type TEXT DEFAULT 'file',
  suggested_state TEXT DEFAULT 'warm',
  seed_score REAL DEFAULT 0,
  evidence TEXT DEFAULT '[]',
  relation TEXT DEFAULT '{}',
  visible_terms TEXT DEFAULT '[]',
  status TEXT DEFAULT 'pending',
  batch_no INTEGER DEFAULT 0,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  PRIMARY KEY(session_id, path)
);
"""


def default_db_path() -> str:
    env = (os.environ.get("GA_FILE_INDEX_DB") or os.environ.get("FILE_INDEX_DB") or "").strip()
    return os.path.abspath(env) if env else os.path.join(_THIS_DIR, "file_index.sqlite")


def connect(db_path: Optional[str] = None) -> sqlite3.Connection:
    p = db_path or default_db_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    conn = sqlite3.connect(p, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def try_create_fts(conn: sqlite3.Connection) -> bool:
    try:
        conn.execute("""CREATE VIRTUAL TABLE IF NOT EXISTS node_fts USING fts5(
            path UNINDEXED, node_type UNINDEXED, tags_text, brief,
            tokenize='unicode61 remove_diacritics 2'
        )""")
        conn.commit()
        return True
    except sqlite3.OperationalError:
        conn.rollback()
        return False


def init_schema(conn: sqlite3.Connection) -> bool:
    conn.executescript(_SCHEMA)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_state ON nodes(state)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_type ON nodes(node_type)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_nodes_score ON nodes(seed_score)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tags_tag ON node_tags(tag)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_tags_state ON node_tags(state)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_build_items_status ON build_items(session_id,status)")
    conn.commit()
    ok = try_create_fts(conn)
    _migrate_v1_if_needed(conn, ok)
    return ok


def _migrate_v1_if_needed(conn: sqlite3.Connection, fts_ok: bool) -> None:
    tabs = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "files" not in tabs:
        return
    if conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]:
        return
    now = time.time()
    for r in conn.execute("SELECT * FROM files"):
        path = r["path"]
        ntype = infer_node_type(path)
        conn.execute("""INSERT OR IGNORE INTO nodes(path,node_type,brief,state,source,confidence,hit_count,last_access,size,mtime_ns,created_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (path, ntype, r["brief"] or "", r["state"] or "warm", "migrated-v1", "candidate", r["hit_count"] or 0,
                      r["last_access"], r["size"], r["mtime_ns"], now, now))
    if "file_tags" in tabs:
        for r in conn.execute("SELECT * FROM file_tags"):
            conn.execute("""INSERT OR IGNORE INTO node_tags(path,tag,state,confidence,source,hit_count,last_hit,created_at,updated_at)
                            VALUES(?,?,?,?,?,?,?,?,?)""",
                         (r["path"], r["tag"], r["state"] or "warm", r["confidence"] or 1.0, "migrated-v1", r["hit_count"] or 0, r["last_hit"], now, now))
    conn.commit(); fts_rebuild_all(conn, fts_ok=fts_ok)


def infer_node_type(path: str) -> str:
    try:
        if os.path.isdir(path): return "dir"
        if os.path.isfile(path): return "file"
    except OSError:
        pass
    base = os.path.basename(path)
    return "file" if os.path.splitext(base)[1] else "unknown"


def _json(x: Any, fallback: str) -> str:
    if x is None: return fallback
    if isinstance(x, str): return x
    return json.dumps(x, ensure_ascii=False)


def log_event(conn: sqlite3.Connection, op: str, *, path: Optional[str] = None, tag: Optional[str] = None,
              old_state: Optional[str] = None, new_state: Optional[str] = None, note: Optional[str] = None) -> None:
    conn.execute("INSERT INTO events(ts,op,path,tag,old_state,new_state,note) VALUES(?,?,?,?,?,?,?)",
                 (time.time(), op, path, tag, old_state, new_state, note))


def normalize_tags(tags: Sequence[str] | str) -> List[str]:
    if isinstance(tags, str):
        parts = re.split(r"[,;\n]+", tags)
    else:
        parts = [str(t) for t in tags]
    out: List[str] = []; seen: Set[str] = set()
    for raw in parts:
        t = raw.strip().lower()
        t = re.sub(r"\s+", "-", t)
        t = re.sub(r"[^a-z0-9\-_\u4e00-\u9fff]+", "-", t)
        t = re.sub(r"-+", "-", t).strip("-_")
        if not t or t in seen:
            continue
        seen.add(t); out.append(t)
    return out


def visible_terms(path: str) -> Set[str]:
    p = os.path.normpath(str(path)).lower().replace("\\", "/")
    parts = re.split(r"[/_\-.\s]+", p)
    terms = {x for x in parts if len(x) >= 2 and not re.fullmatch(r"\d+", x)}
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    if ext: terms.add(ext)
    return terms


def filter_high_info_tags(tags: Sequence[str] | str, path: str, *, extra_visible: Optional[Iterable[str]] = None) -> Tuple[List[str], List[str]]:
    norm = normalize_tags(tags)
    vis = visible_terms(path)
    if extra_visible:
        vis |= {str(x).lower().strip() for x in extra_visible if str(x).strip()}
    kept: List[str] = []; rejected: List[str] = []
    for tag in norm:
        pieces = {p for p in re.split(r"[-_]+", tag) if p}
        if tag in _GENERIC_BAD_TAGS or (pieces and pieces.issubset(_GENERIC_BAD_TAGS)):
            rejected.append(tag + ":generic")
            continue
        if tag in vis or (pieces and pieces.issubset(vis)) or (pieces and pieces.issubset(vis | _GENERIC_BAD_TAGS)) :
            rejected.append(tag + ":visible")
            continue
        if len(tag) < 3:
            rejected.append(tag + ":short")
            continue
        kept.append(tag)
    return kept, rejected


def _tags_text(conn: sqlite3.Connection, path: str) -> str:
    return " ".join(r[0] for r in conn.execute("SELECT tag FROM node_tags WHERE path=? AND state!='retired'", (path,)))


def fts_sync_row(conn: sqlite3.Connection, path: str, *, fts_ok: bool) -> None:
    if not fts_ok: return
    p = os.path.normpath(os.path.abspath(path))
    conn.execute("DELETE FROM node_fts WHERE path=?", (p,))
    r = conn.execute("SELECT node_type, brief, state FROM nodes WHERE path=?", (p,)).fetchone()
    if not r or r["state"] == "retired": return
    conn.execute("INSERT INTO node_fts(path,node_type,tags_text,brief) VALUES(?,?,?,?)", (p, r["node_type"], _tags_text(conn, p), r["brief"] or ""))


def fts_rebuild_all(conn: sqlite3.Connection, *, fts_ok: bool) -> None:
    if not fts_ok: return
    try:
        conn.execute("DELETE FROM node_fts")
        for (p,) in conn.execute("SELECT path FROM nodes WHERE state!='retired'"):
            fts_sync_row(conn, p, fts_ok=True)
        conn.commit()
    except sqlite3.OperationalError:
        conn.rollback()


def annotate_node(conn: sqlite3.Connection, path: str, tags: Sequence[str] | str = (), *, brief: str = "", node_type: Optional[str] = None,
                  state: str = "active", source: str = "agent", confidence: str = "verified", seed_score: float = 0.0,
                  evidence: Optional[Any] = None, relation: Optional[Any] = None, enforce_tag_gate: bool = True,
                  fts_ok: bool = False) -> Dict[str, Any]:
    p = os.path.normpath(os.path.abspath(path))
    now = time.time()
    st = state if state in _VALID_STATES else "warm"
    nt = node_type if node_type in _VALID_NODE_TYPES else infer_node_type(p)
    size = mt = None
    if os.path.exists(p):
        try:
            ss = os.stat(p, follow_symlinks=False)
            size = int(ss.st_size); mt = int(getattr(ss, "st_mtime_ns", int(ss.st_mtime * 1e9)))
        except OSError:
            pass
    prev = conn.execute("SELECT brief,created_at,hit_count,last_access,state FROM nodes WHERE path=?", (p,)).fetchone()
    ca = prev["created_at"] if prev else now
    final_brief = brief.strip() if brief and brief.strip() else ((prev["brief"] or "") if prev else "")
    hc = prev["hit_count"] if prev else 0
    lac = prev["last_access"] if prev else None
    conn.execute("""INSERT INTO nodes(path,node_type,brief,state,source,confidence,seed_score,hit_count,last_access,size,mtime_ns,evidence,relation,created_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(path) DO UPDATE SET node_type=excluded.node_type,
                      brief=CASE WHEN excluded.brief!='' THEN excluded.brief ELSE nodes.brief END,
                      state=excluded.state, source=excluded.source, confidence=excluded.confidence,
                      seed_score=MAX(nodes.seed_score, excluded.seed_score), size=COALESCE(excluded.size,nodes.size),
                      mtime_ns=COALESCE(excluded.mtime_ns,nodes.mtime_ns), evidence=excluded.evidence,
                      relation=excluded.relation, updated_at=excluded.updated_at""",
                 (p, nt, final_brief, st, source, confidence, float(seed_score or 0), hc, lac, size, mt,
                  _json(evidence, "[]"), _json(relation, "{}"), ca, now))
    kept, rejected = filter_high_info_tags(tags, p) if enforce_tag_gate else (normalize_tags(tags), [])
    for tg in kept:
        conn.execute("""INSERT INTO node_tags(path,tag,state,confidence,source,hit_count,last_hit,created_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(path,tag) DO UPDATE SET state=excluded.state, source=excluded.source,
                          confidence=MAX(node_tags.confidence,excluded.confidence), updated_at=excluded.updated_at""",
                     (p, tg, st, 1.0, source, 0, None, now, now))
    log_event(conn, "annotate_node", path=p, new_state=st, note=json.dumps({"tags": kept, "rejected": rejected}, ensure_ascii=False))
    fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit()
    return {"ok": True, "path": p, "node_type": nt, "state": st, "tags": kept, "rejected_tags": rejected, "brief": final_brief}


def _allowed(include_dormant: bool, include_retired: bool) -> Set[str]:
    if include_retired: return {"active","warm","cold","stale","retired"}
    if include_dormant: return {"active","warm","cold","stale"}
    return {"active","warm"}


def _state_weight(s: str) -> float:
    return {"active": 10.0, "warm": 6.5, "cold": 2.0, "stale": -3.0, "retired": -1e6}.get(s, 0.0)


def recall(conn: sqlite3.Connection, query: str, *, limit: int = 10, include_dormant: bool = False,
           include_retired: bool = False, node_types: Optional[Sequence[str]] = None, fts_ok: bool = False,
           verbose: bool = False) -> List[Dict[str, Any]]:
    q = (query or "").strip().lower()
    if not q: return []
    toks = [t for t in re.split(r"\s+", q) if t]
    allow = sorted(_allowed(include_dormant, include_retired))
    ph = ",".join("?" * len(allow))
    type_filter = set(node_types or [])
    cands: Set[str] = set()
    if fts_ok:
        try:
            expr = " AND ".join('"' + t.replace('"', '') + '"' for t in toks)
            sql = f"SELECT n.path FROM node_fts f JOIN nodes n ON n.path=f.path WHERE f MATCH ? AND n.state IN ({ph})"
            for r in conn.execute(sql, (expr, *allow)): cands.add(r[0])
        except sqlite3.OperationalError:
            pass
    for tok in toks:
        like = f"%{tok}%"
        for r in conn.execute(f"SELECT path FROM nodes WHERE state IN ({ph}) AND (LOWER(brief) LIKE ? OR LOWER(path) LIKE ?)", (*allow, like, like)):
            cands.add(r[0])
        for r in conn.execute(f"SELECT DISTINCT path FROM node_tags WHERE state IN ({ph}) AND LOWER(tag) LIKE ?", (*allow, like)):
            cands.add(r[0])
    out: List[Dict[str, Any]] = []
    for p in cands:
        n = conn.execute("SELECT * FROM nodes WHERE path=?", (p,)).fetchone()
        if not n: continue
        if type_filter and n["node_type"] not in type_filter: continue
        tags = list(conn.execute("SELECT tag,state,hit_count,last_hit FROM node_tags WHERE path=?", (p,)))
        score = _state_weight(n["state"]) + float(n["seed_score"] or 0) * 0.08 + min((n["hit_count"] or 0) * 0.15, 3.0)
        reasons: List[str] = []
        brief = (n["brief"] or "").lower(); path_l = p.lower()
        for tok in toks:
            for tr in tags:
                tag = tr["tag"].lower()
                if tok == tag:
                    score += 48; reasons.append("tag_exact")
                elif tok in tag:
                    score += 30; reasons.append("tag_partial")
            if tok in brief:
                score += 14; reasons.append("brief")
            if tok in os.path.basename(path_l):
                score += 4; reasons.append("basename")
            elif tok in path_l:
                score += 1.5; reasons.append("path_weak")
        if n["node_type"] == "dir":
            score += 2.5; reasons.append("scope_node")
        rec = {"path": p, "node_type": n["node_type"], "state": n["state"], "tags": [r["tag"] for r in tags if r["state"] in allow],
               "brief": n["brief"] or "", "score": round(score, 3), "reason": ";".join(sorted(set(reasons))) or "ranked"}
        if verbose:
            rec.update({"seed_score": n["seed_score"], "hit_count": n["hit_count"], "evidence": _loads(n["evidence"], []), "relation": _loads(n["relation"], {})})
        out.append(rec)
    out.sort(key=lambda x: (-x["score"], 0 if x["node_type"] == "dir" else 1, x["path"]))
    return out[: max(1, int(limit))]


def _loads(s: Any, default: Any) -> Any:
    try: return json.loads(s) if isinstance(s, str) else default
    except Exception: return default


def mark_used(conn: sqlite3.Connection, path: str, *, matched_tags: Optional[Sequence[str]] = None, fts_ok: bool = False) -> Dict[str, Any]:
    p = os.path.normpath(os.path.abspath(path)); now = time.time()
    n = conn.execute("SELECT state FROM nodes WHERE path=?", (p,)).fetchone()
    if not n: return {"ok": False, "error": "path not indexed", "path": p}
    old = n["state"]; new = {"cold":"warm", "warm":"active", "stale":"warm"}.get(old, old)
    conn.execute("UPDATE nodes SET hit_count=hit_count+1,last_access=?,state=?,updated_at=? WHERE path=?", (now, new, now, p))
    if new != old: log_event(conn, "promote_node", path=p, old_state=old, new_state=new)
    tagset = None if matched_tags is None else set(normalize_tags(matched_tags))
    if tagset:
        for tr in conn.execute("SELECT tag,state FROM node_tags WHERE path=?", (p,)):
            if tr["tag"] not in tagset: continue
            ot = tr["state"]; nt = {"cold":"warm", "warm":"active", "stale":"active"}.get(ot, ot)
            conn.execute("UPDATE node_tags SET hit_count=hit_count+1,last_hit=?,state=?,updated_at=? WHERE path=? AND tag=?", (now, nt, now, p, tr["tag"]))
            if nt != ot: log_event(conn, "promote_tag", path=p, tag=tr["tag"], old_state=ot, new_state=nt)
    fts_sync_row(conn, p, fts_ok=fts_ok); conn.commit()
    return {"ok": True, "path": p, "state": new}


def set_state(conn: sqlite3.Connection, path: str, state: str, *, tag: Optional[str] = None, fts_ok: bool = False) -> Dict[str, Any]:
    p = os.path.normpath(os.path.abspath(path)); st = state if state in _VALID_STATES else "warm"; now = time.time()
    if tag:
        tg = normalize_tags([tag])[0]
        old = conn.execute("SELECT state FROM node_tags WHERE path=? AND tag=?", (p, tg)).fetchone()
        conn.execute("UPDATE node_tags SET state=?,updated_at=? WHERE path=? AND tag=?", (st, now, p, tg))
        log_event(conn, "set_tag_state", path=p, tag=tg, old_state=old[0] if old else None, new_state=st)
    else:
        old = conn.execute("SELECT state FROM nodes WHERE path=?", (p,)).fetchone()
        conn.execute("UPDATE nodes SET state=?,updated_at=? WHERE path=?", (st, now, p))
        log_event(conn, "set_node_state", path=p, old_state=old[0] if old else None, new_state=st)
    fts_sync_row(conn, p, fts_ok=fts_ok); conn.commit(); return {"ok": True, "path": p, "state": st}


def rebalance(conn: sqlite3.Connection, *, max_nodes: int = 1000, max_active: int = 220, fts_ok: bool = False) -> Dict[str, Any]:
    rows = list(conn.execute("SELECT path,state,seed_score,hit_count,last_access,node_type,brief FROM nodes WHERE state!='retired'"))
    now = time.time()
    scored = []
    for r in rows:
        tag_n = conn.execute("SELECT COUNT(*) FROM node_tags WHERE path=? AND state!='retired'", (r["path"],)).fetchone()[0]
        has_brief = bool((r["brief"] or "").strip())
        exists = os.path.exists(r["path"])
        score = float(r["seed_score"] or 0) + min((r["hit_count"] or 0) * 4, 40)
        if r["node_type"] == "dir":
            score += 6
        if r["last_access"]:
            age = (now - r["last_access"]) / 86400
            if age < 7: score += 20
            elif age < 30: score += 10
        if tag_n: score += 14
        if has_brief: score += 4
        if not tag_n: score -= 18
        if not has_brief: score -= 12
        if not exists: score -= 1000
        if r["state"] == "stale": score -= 40
        # Only nodes with at least one kept tag and brief may enter active by rebalance.
        active_eligible = bool(tag_n and has_brief and exists)
        scored.append((score, r["path"], r["state"], active_eligible))
    scored.sort(reverse=True)
    active_set = {p for _, p, _, ok in scored if ok}
    active_set = set(list(active_set)[:max_active])
    keep_set = {p for _, p, _, _ in scored[:max_nodes]}
    changed = {"active":0,"warm":0,"cold":0,"retired":0}
    for idx, (_, p, old, active_ok) in enumerate(scored):
        if p not in keep_set or not os.path.exists(p):
            new = "retired"
        elif p in active_set and active_ok:
            new = "active"
        elif not active_ok:
            # A node without both brief and at least one kept tag is only a verified reserve.
            new = "cold"
        elif idx < max_nodes * 0.65:
            new = "warm"
        else:
            new = "cold"
        if new != old:
            conn.execute("UPDATE nodes SET state=?,updated_at=? WHERE path=?", (new, now, p))
            conn.execute("UPDATE node_tags SET state=? WHERE path=? AND state!='retired'", (new, p))
            log_event(conn, "rebalance", path=p, old_state=old, new_state=new)
            changed[new] = changed.get(new,0)+1
            fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit(); return {"ok": True, "changed": changed, "max_nodes": max_nodes, "max_active": max_active}


def decay(conn: sqlite3.Connection, *, active_days: float = 30, warm_days: float = 90, fts_ok: bool = False) -> Dict[str, int]:
    now = time.time(); out = {"active_to_warm":0,"warm_to_cold":0}
    for r in conn.execute("SELECT path,state,last_access FROM nodes WHERE state IN ('active','warm')"):
        age = None if not r["last_access"] else (now-r["last_access"])/86400
        new = None
        if r["state"] == "active" and (age is None or age > active_days): new = "warm"; out["active_to_warm"] += 1
        elif r["state"] == "warm" and (age is None or age > warm_days): new = "cold"; out["warm_to_cold"] += 1
        if new:
            set_state(conn, r["path"], new, fts_ok=fts_ok)
    return out


def check_stale(conn: sqlite3.Connection, path: Optional[str] = None, *, fts_ok: bool = False) -> Dict[str, int]:
    rows = [(os.path.normpath(os.path.abspath(path)),)] if path else list(conn.execute("SELECT path FROM nodes"))
    stale = retired = 0; now = time.time()
    for (p,) in rows:
        r = conn.execute("SELECT mtime_ns,state FROM nodes WHERE path=?", (p,)).fetchone()
        if not r: continue
        if not os.path.exists(p):
            conn.execute("UPDATE nodes SET state='retired',updated_at=? WHERE path=?", (now,p)); retired += 1; continue
        try:
            ss = os.stat(p, follow_symlinks=False); mt = int(getattr(ss,"st_mtime_ns",int(ss.st_mtime*1e9)))
        except OSError:
            continue
        if r["mtime_ns"] and mt != r["mtime_ns"]:
            conn.execute("UPDATE nodes SET state='stale',mtime_ns=?,updated_at=? WHERE path=?", (mt,now,p)); stale += 1
            conn.execute("UPDATE node_tags SET state='stale',updated_at=? WHERE path=?", (now,p))
            fts_sync_row(conn, p, fts_ok=fts_ok)
    conn.commit(); return {"marked_stale": stale, "marked_retired": retired}


def add_ignored_path(conn: sqlite3.Connection, pattern: str, *, reason: str = "", path_type: str = "prefix", source: str = "agent") -> Dict[str, Any]:
    now = time.time(); pat = os.path.normpath(pattern)
    conn.execute("""INSERT INTO ignored_paths(pattern,path_type,reason,source,hit_count,created_at,updated_at)
                    VALUES(?,?,?,?,0,?,?) ON CONFLICT(pattern) DO UPDATE SET reason=excluded.reason,source=excluded.source,updated_at=excluded.updated_at""",
                 (pat,path_type,reason,source,now,now)); conn.commit(); return {"ok": True, "pattern": pat}


def ignored_paths(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    return [dict(r) for r in conn.execute("SELECT * FROM ignored_paths ORDER BY updated_at DESC")]


def list_candidates(conn: sqlite3.Connection, *, state: Optional[str] = None, node_type: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    cond = []; params: List[Any] = []
    if state: cond.append("state=?"); params.append(state)
    if node_type: cond.append("node_type=?"); params.append(node_type)
    where = " WHERE " + " AND ".join(cond) if cond else ""
    rows = conn.execute(f"SELECT path,node_type,brief,state,seed_score,hit_count,evidence,relation FROM nodes{where} ORDER BY state='active' DESC, seed_score DESC LIMIT ?", (*params, max(1,limit))).fetchall()
    return [{"path":r["path"],"node_type":r["node_type"],"brief":r["brief"],"state":r["state"],"seed_score":r["seed_score"],"hit_count":r["hit_count"],"evidence":_loads(r["evidence"],[]),"relation":_loads(r["relation"],{})} for r in rows]


def facets(conn: sqlite3.Connection, *, limit: int = 30) -> Dict[str, Any]:
    return {
        "nodes_by_state": dict(conn.execute("SELECT state,COUNT(*) FROM nodes GROUP BY state")),
        "nodes_by_type": dict(conn.execute("SELECT node_type,COUNT(*) FROM nodes GROUP BY node_type")),
        "top_tags": [dict(r) for r in conn.execute("SELECT tag,state,COUNT(*) n FROM node_tags GROUP BY tag,state ORDER BY n DESC LIMIT ?", (limit,))],
        "top_dirs": _top_dirs(conn, limit),
        "recent_used": [dict(r) for r in conn.execute("SELECT path,node_type,brief,state,hit_count,last_access FROM nodes ORDER BY COALESCE(last_access,0) DESC LIMIT ?", (limit,))]
    }


def _top_dirs(conn: sqlite3.Connection, limit: int) -> List[Dict[str, Any]]:
    c: Dict[str,int] = {}
    for (p,) in conn.execute("SELECT path FROM nodes WHERE node_type='file'"):
        par = os.path.dirname(p)
        if par: c[par] = c.get(par,0)+1
    return [{"parent":k,"n":v} for k,v in sorted(c.items(), key=lambda kv:-kv[1])[:limit]]


def stats(conn: sqlite3.Connection, *, fts_ok: bool, db_path: str, es_ok: bool) -> Dict[str, Any]:
    return {"db_path":db_path,"fts_enabled":fts_ok,"es_exe_configured":es_ok,
            "nodes_total":conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0],
            "tags_total":conn.execute("SELECT COUNT(*) FROM node_tags").fetchone()[0],
            "nodes_by_state":dict(conn.execute("SELECT state,COUNT(*) FROM nodes GROUP BY state")),
            "nodes_by_type":dict(conn.execute("SELECT node_type,COUNT(*) FROM nodes GROUP BY node_type")),
            "open_build_sessions":conn.execute("SELECT COUNT(*) FROM build_sessions WHERE status='open'").fetchone()[0]}


def list_by_tag(conn: sqlite3.Connection, tag: str, *, include_dormant: bool=False, include_retired: bool=False, limit: int=50) -> List[Dict[str, Any]]:
    t = normalize_tags([tag])[0]; allow = sorted(_allowed(include_dormant, include_retired)); ph = ",".join("?"*len(allow))
    rows = conn.execute(f"SELECT n.path,n.node_type,n.brief,n.state,t.tag FROM nodes n JOIN node_tags t ON n.path=t.path WHERE t.tag=? AND n.state IN ({ph}) ORDER BY n.state='active' DESC,n.seed_score DESC LIMIT ?", (t,*allow,limit)).fetchall()
    return [dict(r) for r in rows]


def list_under_parent(conn: sqlite3.Connection, parent: str, *, include_dormant: bool=False, include_retired: bool=False, limit: int=50) -> List[Dict[str, Any]]:
    par = os.path.normpath(os.path.abspath(parent)).rstrip("/\\"); pfx = par + os.sep; allow = _allowed(include_dormant, include_retired)
    out=[]
    for r in conn.execute("SELECT path,node_type,brief,state FROM nodes ORDER BY path"):
        p = os.path.normpath(os.path.abspath(r["path"]))
        if r["state"] in allow and (p == par or p.startswith(pfx)):
            out.append(dict(r))
            if len(out) >= limit: break
    return out


def export_jsonl(conn: sqlite3.Connection, fh: Any) -> int:
    n=0
    for r in conn.execute("SELECT * FROM nodes"):
        fh.write(json.dumps({"type":"node", **dict(r)}, ensure_ascii=False)+"\n"); n+=1
    for r in conn.execute("SELECT * FROM node_tags"):
        fh.write(json.dumps({"type":"tag", **dict(r)}, ensure_ascii=False)+"\n"); n+=1
    return n
