"""file_index_sop v6: Agent-driven semantic coverage over Everything/es.exe."""
__version__ = "v6"
