"""Correctness-first thin wrapper over voidtools Everything/es.exe.

No semantic query expansion happens here. `locate()` may plan variants; this module
only executes the query/scope it is given and returns structured filesystem facts.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Sequence

from . import everything_core as core

_LAST_DIAGNOSTIC: Dict[str, Any] = {}


def resolve_es_exe() -> Optional[str]:
    return core.resolve_es_exe()


def last_search_diagnostic() -> Dict[str, Any]:
    return dict(_LAST_DIAGNOSTIC)


def _row(path: str) -> Dict[str, Any]:
    p = os.path.normpath(path)
    row: Dict[str, Any] = {"path": p, "basename": os.path.basename(p), "parent": os.path.dirname(p)}
    try:
        st = os.stat(p, follow_symlinks=False)
        row["size"] = int(st.st_size)
        row["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
        row["is_dir"] = os.path.isdir(p)
    except OSError:
        row["is_dir"] = False
    return row


def raw_search(query: str, *, limit: int = 50, scope: Optional[str] = None, extra_args: Optional[Sequence[str]] = None, timeout: float = 120.0) -> List[str]:
    global _LAST_DIAGNOSTIC
    res = core.query_es(query, limit=limit, scope=scope, extra_args=extra_args, timeout=timeout)
    _LAST_DIAGNOSTIC = {k: v for k, v in res.items() if k != "paths"}
    if not res.get("ok") and not res.get("paths"):
        raise RuntimeError(res.get("error") or res.get("stderr") or "es.exe query failed")
    return list(res.get("paths") or [])


def search(query: str, *, limit: int = 50, scope: Optional[str] = None, timeout: float = 120.0, sort_mtime_desc: bool = False) -> List[Dict[str, Any]]:
    paths = raw_search(query, limit=limit, scope=scope, timeout=timeout)
    rows = [_row(p) for p in paths]
    if sort_mtime_desc:
        rows.sort(key=lambda r: int(r.get("mtime_ns") or 0), reverse=True)
    return rows[: max(1, int(limit))]


def search_detailed(query: str, *, limit: int = 50, scope: Optional[str] = None, timeout: float = 120.0, sort_mtime_desc: bool = False) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    err: Optional[str] = None
    try:
        rows = search(query, limit=limit, scope=scope, timeout=timeout, sort_mtime_desc=sort_mtime_desc)
    except Exception as e:
        err = str(e)
    diag = last_search_diagnostic()
    # Keep diagnostic nested, but also surface the common debug fields at the
    # top level. Prior tests and Agent scripts expect argv/scope/stderr/encoding
    # next to hit_count; exposing both forms avoids return-shape guessing while
    # preserving the richer diagnostic object.
    return {
        "ok": err is None,
        "query": query,
        "scope": scope if scope is not None else diag.get("scope"),
        "hits": rows,
        "hit_count": len(rows),
        "argv": diag.get("argv"),
        "encoding": diag.get("encoding"),
        "stderr": diag.get("stderr"),
        "stdout": diag.get("stdout"),
        "returncode": diag.get("returncode"),
        "diagnostic": diag,
        "error": err,
    }


def recent(*, limit: int = 1000, scope: Optional[str] = None, query: str = "*", timeout: float = 120.0) -> List[Dict[str, Any]]:
    # Keep this thin and robust: retrieve more and sort locally by stat mtime.
    over = max(int(limit), min(int(limit) * 4, 20000))
    rows = search(query, limit=over, scope=scope, timeout=timeout)
    rows.sort(key=lambda r: int(r.get("mtime_ns") or 0), reverse=True)
    return rows[: max(1, int(limit))]
