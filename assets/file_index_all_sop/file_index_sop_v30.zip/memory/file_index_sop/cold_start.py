"""Cold-start review-transaction scaffold for file_index_sop v30.

Cold start is Agent-led and transaction-oriented. This module manages a
candidate ledger, source-budgeted discovery, rough/expanded evidence, and honest
finish reports. It never generates semantic route tags or briefs.
"""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import everything
from .policy import load_index_policy
from .store import conn, stats as index_stats, apply_index_plan as _store_apply_index_plan, log_event, top_tags


def _now() -> float:
    return time.time()


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _scope_contains(scope: str, path: str) -> bool:
    try:
        s = _norm(scope)
        p = _norm(path)
        return os.path.commonpath([s, p]) == s
    except Exception:
        return False


def _parts(path: str) -> List[str]:
    return [x.lower() for x in re.split(r"[\\/]+", _norm(path)) if x]


def _candidate_discovery() -> Dict[str, Any]:
    p = load_index_policy()
    return p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}


def _cold_policy() -> Dict[str, Any]:
    p = load_index_policy()
    return p.get("cold_start", {}) if isinstance(p.get("cold_start"), dict) else {}


def _document_exts() -> set[str]:
    cd = _candidate_discovery()
    return set(str(x).lower() for x in cd.get("document_extensions", []))


def _text_exts() -> set[str]:
    cd = _candidate_discovery()
    return set(str(x).lower() for x in cd.get("text_extensions", []))


def _office_exts() -> set[str]:
    cd = _candidate_discovery()
    return set(str(x).lower() for x in cd.get("office_extensions", [".doc", ".docx", ".ppt", ".pptx", ".xls", ".xlsx"]))


def _evidence_names() -> set[str]:
    cd = _candidate_discovery()
    return set(str(x).lower() for x in cd.get("evidence_file_names", []))


def _default_queries() -> List[str]:
    cd = _candidate_discovery()
    q = cd.get("default_queries")
    if isinstance(q, list):
        return [str(x).strip() for x in q if str(x).strip()]
    return ["*.md", "*.txt", "*.pdf", "*.docx", "*.pptx", "*.xlsx", "README.md"]


def _hard_ignored(path: str, policy: Optional[Dict[str, Any]] = None) -> bool:
    p = policy or load_index_policy()
    cd = p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}
    hard = set(str(x).lower() for x in cd.get("hard_ignore_dirs", []))
    return any(part in hard for part in _parts(path))


def _is_hashlike_name(name: str) -> bool:
    base = str(name or "").strip()
    if not base:
        return False
    if re.fullmatch(r"[a-f0-9]{10,}", base.lower()):
        return True
    if len(base) >= 16:
        digits = sum(ch.isdigit() for ch in base)
        if digits >= 6 and digits / max(1, len(base)) > 0.35:
            return True
        if re.fullmatch(r"[a-z0-9]{18,}", base) and digits >= 3:
            return True
    return False


def _soft_noise(path: str, policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    p = policy or load_index_policy()
    cd = p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}
    terms = [str(x).lower() for x in cd.get("soft_downrank_terms", [])]
    hits: List[str] = []
    for part in _parts(path):
        for t in terms:
            if t and t in part:
                hits.append(t)
    score = min(50, len(set(hits)) * 12)
    base = os.path.basename(_norm(path))
    if _is_hashlike_name(base):
        hits.append("hashlike-name")
        score += 8
    return {"score": score, "reasons": sorted(set(hits))}


def _mtime_ns(path: str) -> int:
    try:
        st = os.stat(path, follow_symlinks=False)
        return int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
    except OSError:
        return 0


def _query_kind(query: str) -> str:
    q = str(query).lower().strip()
    # Source kind affects only candidate budget; it does not create semantic tags.
    m = re.fullmatch(r"\*([.][a-z0-9]+)", q)
    if m and m.group(1) in _document_exts():
        return "document_parent"
    if q in _evidence_names() or q.endswith(".sln") or q.endswith(".csproj"):
        return "marker_parent"
    return "other_query_parent"


def _source_class(source: str) -> str:
    if source.startswith("query_parent:"):
        return _query_kind(source.split(":", 1)[1])
    return source


def _candidate_facts(path: str, sample_limit: int = 80) -> Dict[str, Any]:
    p = _norm(path)
    facts: Dict[str, Any] = {
        "dir_count_sampled": 0,
        "file_count_sampled": 0,
        "file_type_mix_sampled": {},
        "document_file_count": 0,
        "office_file_count": 0,
        "text_file_count": 0,
        "evidence_file_count": 0,
        "representative_files": [],
    }
    if not os.path.isdir(p):
        ext = os.path.splitext(p)[1].lower()
        facts["file_count_sampled"] = 1 if os.path.isfile(p) else 0
        facts["file_type_mix_sampled"] = {ext: 1} if ext else {}
        facts["document_file_count"] = int(ext in _document_exts())
        facts["office_file_count"] = int(ext in _office_exts())
        facts["text_file_count"] = int(ext in _text_exts())
        facts["representative_files"] = [{"name": os.path.basename(p), "path": p, "extension": ext}]
        return facts
    exts: Counter[str] = Counter()
    reps: List[Dict[str, Any]] = []
    try:
        with os.scandir(p) as it:
            for ent in it:
                if facts["dir_count_sampled"] + facts["file_count_sampled"] >= sample_limit:
                    break
                if _hard_ignored(ent.path):
                    continue
                if ent.is_dir(follow_symlinks=False):
                    facts["dir_count_sampled"] += 1
                    continue
                if not ent.is_file(follow_symlinks=False):
                    continue
                facts["file_count_sampled"] += 1
                ext = os.path.splitext(ent.name)[1].lower()
                if ext:
                    exts[ext] += 1
                if ext in _document_exts():
                    facts["document_file_count"] += 1
                if ext in _office_exts():
                    facts["office_file_count"] += 1
                if ext in _text_exts():
                    facts["text_file_count"] += 1
                if ent.name.lower() in _evidence_names():
                    facts["evidence_file_count"] += 1
                if len(reps) < 20 and (ext in _document_exts() or ent.name.lower() in _evidence_names()):
                    reps.append({"name": ent.name, "path": os.path.normpath(ent.path), "extension": ext})
    except OSError:
        pass
    facts["file_type_mix_sampled"] = dict(exts.most_common(20))
    facts["representative_files"] = reps
    return facts


def _priority(path: str, *, source: str, source_mtime_ns: int = 0) -> float:
    p = _norm(path)
    source_class = _source_class(source)
    base = {
        "top_level": 70,
        "second_level": 64,
        "recent_parent": 56,
        "document_parent": 66,
        "marker_parent": 62,
        "other_query_parent": 48,
    }.get(source_class, 40)
    score = float(base)
    facts = _candidate_facts(p)
    if os.path.isdir(p):
        score += 8
    if facts["dir_count_sampled"]:
        score += min(10, facts["dir_count_sampled"])
    if facts["file_count_sampled"]:
        score += min(6, facts["file_count_sampled"] / 4)
    if len(facts["file_type_mix_sampled"]) > 1:
        score += min(8, len(facts["file_type_mix_sampled"]))
    # These are evidence-discovery boosts only; they never imply semantic tags.
    if facts["document_file_count"]:
        score += min(18, facts["document_file_count"] * 2.5)
    if facts["office_file_count"]:
        score += min(16, facts["office_file_count"] * 3)
    if facts["evidence_file_count"]:
        score += min(18, facts["evidence_file_count"] * 5)
    if facts["file_count_sampled"] <= 2 and not (facts["document_file_count"] or facts["evidence_file_count"]):
        score -= 8  # soft penalty only
    mt = max(_mtime_ns(p), int(source_mtime_ns or 0))
    if mt:
        age_days = max(0.0, (_now() - mt / 1e9) / 86400.0)
        if age_days < 3:
            score += 16
        elif age_days < 14:
            score += 10
        elif age_days < 60:
            score += 5
    score -= _soft_noise(p)["score"]
    return score


def _parent_entries_for_path(path: str, scope: str, parent_levels: int = 2) -> List[str]:
    p = _norm(path)
    scope = _norm(scope)
    if os.path.isdir(p):
        return [p] if _scope_contains(scope, p) and not _hard_ignored(p) else []
    if not os.path.isfile(p):
        return []
    out: List[str] = []
    cur = os.path.dirname(p)
    for _ in range(max(1, int(parent_levels))):
        if not cur or cur == os.path.dirname(cur):
            break
        if _scope_contains(scope, cur) and not _hard_ignored(cur):
            out.append(cur)
        cur = os.path.dirname(cur)
    return list(dict.fromkeys(out))


def _ensure_tables() -> None:
    c = conn()
    try:
        c.execute("""CREATE TABLE IF NOT EXISTS cold_sessions (
          session_id TEXT PRIMARY KEY,
          scope TEXT NOT NULL,
          target_nodes INTEGER NOT NULL DEFAULT 1000,
          status TEXT NOT NULL DEFAULT 'open',
          collection_done INTEGER NOT NULL DEFAULT 0,
          rounds INTEGER NOT NULL DEFAULT 0,
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS cold_candidates (
          session_id TEXT NOT NULL,
          path TEXT NOT NULL,
          node_type TEXT NOT NULL DEFAULT 'dir',
          status TEXT NOT NULL DEFAULT 'pending',
          priority REAL NOT NULL DEFAULT 0,
          source TEXT NOT NULL DEFAULT '',
          source_paths_json TEXT NOT NULL DEFAULT '[]',
          evidence_json TEXT NOT NULL DEFAULT '{}',
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL,
          PRIMARY KEY(session_id, path)
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cold_candidates_status ON cold_candidates(session_id,status,priority)")
        c.execute("""CREATE TABLE IF NOT EXISTS cold_reviews (
          review_id TEXT PRIMARY KEY,
          session_id TEXT NOT NULL,
          candidate_id TEXT NOT NULL,
          path TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'open',
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cold_reviews_session_status ON cold_reviews(session_id,status,updated_at)")
        c.execute("""CREATE TABLE IF NOT EXISTS review_evidence_items (
          review_id TEXT NOT NULL,
          evidence_id TEXT NOT NULL,
          evidence_type TEXT NOT NULL,
          path TEXT,
          name TEXT,
          text TEXT,
          metadata_json TEXT NOT NULL DEFAULT '{}',
          PRIMARY KEY(review_id,evidence_id)
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS review_commits (
          commit_id TEXT PRIMARY KEY,
          review_id TEXT NOT NULL,
          session_id TEXT NOT NULL,
          candidate_id TEXT NOT NULL,
          path TEXT NOT NULL,
          decision TEXT NOT NULL,
          brief TEXT NOT NULL DEFAULT '',
          route_tags_json TEXT NOT NULL DEFAULT '[]',
          facets_json TEXT NOT NULL DEFAULT '[]',
          evidence_refs_json TEXT NOT NULL DEFAULT '[]',
          evidence_note TEXT NOT NULL DEFAULT '',
          quality_flags_json TEXT NOT NULL DEFAULT '[]',
          created_at REAL NOT NULL
        )""")
        c.commit()
    finally:
        c.close()


def begin_cold_start(scope: str, *, target_nodes: int = 1000, reset_session: bool = False) -> Dict[str, Any]:
    _ensure_tables()
    sc = _norm(scope)
    sid = "cs_" + uuid.uuid4().hex[:12]
    c = conn()
    try:
        t = _now()
        if reset_session:
            c.execute("DELETE FROM cold_sessions WHERE scope=?", (sc,))
        c.execute(
            "INSERT INTO cold_sessions(session_id,scope,target_nodes,status,created_at,updated_at) VALUES(?,?,?,?,?,?)",
            (sid, sc, int(target_nodes), "open", t, t),
        )
        c.commit()
        return {
            "ok": True,
            "session_id": sid,
            "scope": sc,
            "target_nodes": int(target_nodes),
            "note": "target_nodes is a budget/cap hint, not a required commit count.",
            "next": "collect_cold_start_entries(session_id), then repeat: next_review_candidate(session_id) -> review_candidate(session_id, candidate_id) -> commit_review(...)."
        }
    finally:
        c.close()


def _session(session_id: str) -> Optional[Dict[str, Any]]:
    _ensure_tables()
    c = conn()
    try:
        r = c.execute("SELECT * FROM cold_sessions WHERE session_id=?", (session_id,)).fetchone()
        return dict(r) if r else None
    finally:
        c.close()


def _read_head(path: str, max_chars: int) -> Optional[str]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read(max_chars).replace("\x00", "").strip()
    except Exception:
        return None


def _candidate_evidence(path: str, source_seed_paths: Sequence[str], *, expanded: bool = False, max_children_override: Optional[int] = None, max_heads_override: Optional[int] = None) -> Dict[str, Any]:
    p = _norm(path)
    policy = load_index_policy()
    max_children = int(max_children_override if max_children_override is not None else policy.get("evidence_max_children", 80))
    max_heads = int(max_heads_override if max_heads_override is not None else policy.get("evidence_max_heads", 4))
    max_head_chars = int(policy.get("text_head_max_chars", 1200))
    doc_exts = _document_exts()
    text_exts = _text_exts()
    office_exts = _office_exts()
    ev: Dict[str, Any] = {
        "path": p,
        "node_type": "dir" if os.path.isdir(p) else "file" if os.path.isfile(p) else "missing",
        "exists": os.path.exists(p),
        "evidence_level": "expanded" if expanded else "rough",
        "soft_downrank": _soft_noise(p),
        "source_seed_paths": [_norm(x) for x in source_seed_paths or []][:30],
        "candidate_facts": _candidate_facts(p),
        "annotation_contract": [
            "Helper does not generate tags; Agent must decide from evidence.",
            "Rough batch evidence is not enough to apply tags; expand_candidate is required.",
            "Do not use file_count, extension set, parent folder name, or path keyword as sole reason to apply/skip.",
            "If evidence is insufficient, use defer/need_more_evidence rather than skip.",
            "Office/PDF/text-document directories are valid candidates even when small or generic-named."
        ],
    }
    try:
        st = os.stat(p, follow_symlinks=False)
        ev.update({"size": int(st.st_size), "mtime_ns": int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))})
    except OSError as e:
        ev["stat_error"] = str(e)
        return ev
    if os.path.isfile(p):
        ext = os.path.splitext(p)[1].lower()
        ev["extension"] = ext
        ev["is_document_ext"] = ext in doc_exts
        ev["is_office_ext"] = ext in office_exts
        if expanded and ext in text_exts:
            head = _read_head(p, max_head_chars)
            if head:
                ev["content_head"] = head
                ev["content_head_note"] = "Evidence for this file only; distinguish self-description from external references/examples."
        return ev
    if not os.path.isdir(p):
        return ev
    children: List[Dict[str, Any]] = []
    heads: List[Dict[str, Any]] = []
    ext_counter: Counter[str] = Counter()
    representative_docs: List[Dict[str, Any]] = []
    dir_count = file_count = 0
    try:
        entries = []
        with os.scandir(p) as it:
            for ent in it:
                if _hard_ignored(ent.path):
                    continue
                entries.append(ent)
        entries.sort(key=lambda e: (not e.is_dir(follow_symlinks=False), e.name.lower()))
        for ent in entries[:max_children]:
            is_dir = ent.is_dir(follow_symlinks=False)
            is_file = ent.is_file(follow_symlinks=False)
            if is_dir:
                dir_count += 1
            if is_file:
                file_count += 1
            ext = os.path.splitext(ent.name)[1].lower() if is_file else ""
            if ext:
                ext_counter[ext] += 1
            item: Dict[str, Any] = {"name": ent.name, "path": os.path.normpath(ent.path), "is_dir": is_dir, "is_file": is_file, "extension": ext}
            try:
                st = ent.stat(follow_symlinks=False)
                item["size"] = int(st.st_size)
                item["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
            except OSError:
                pass
            children.append(item)
            if is_file and ext in doc_exts and len(representative_docs) < 30:
                representative_docs.append({k: item.get(k) for k in ("name", "path", "extension", "size", "mtime_ns") if k in item})
            if expanded and is_file and len(heads) < max_heads and ext in text_exts:
                head = _read_head(ent.path, max_head_chars)
                if head:
                    heads.append({"path": os.path.normpath(ent.path), "name": ent.name, "head": head, "note": "Evidence for this child only; do not treat external references/examples as parent route tags."})
    except OSError as e:
        ev["scandir_error"] = str(e)
        return ev
    ev.update({
        "dir_count_sampled": dir_count,
        "file_count_sampled": file_count,
        "file_type_mix_sampled": dict(ext_counter.most_common(20)),
        "children_sample": children,
        "representative_document_files": representative_docs,
    })
    if expanded:
        ev["document_heads"] = heads
        ev["expanded_evidence_note"] = "Use representative_document_files and document_heads/content_head when writing evidence_note. If still insufficient, defer; do not skip because of generic name or low child count."
    return ev


def _source_budget(source_class: str, pol: Dict[str, Any]) -> int:
    defaults = {
        "top_level": int(pol.get("top_level_limit", 40)),
        "second_level": int(pol.get("second_level_total_limit", 120)),
        "recent_parent": int(pol.get("recent_parent_budget", 80)),
        "document_parent": int(pol.get("document_parent_budget", 180)),
        "marker_parent": int(pol.get("marker_parent_budget", 120)),
        "other_query_parent": int(pol.get("other_query_parent_budget", 80)),
    }
    return max(0, defaults.get(source_class, int(pol.get("other_query_parent_budget", 80))))


def _merge_candidate(candidates: Dict[str, Dict[str, Any]], path: str, source: str, source_paths: Sequence[str], priority: float) -> None:
    p = _norm(path)
    if _hard_ignored(p):
        return
    existing = candidates.get(p)
    if existing is None:
        candidates[p] = {"path": p, "source": source, "sources": [source], "source_paths": list(dict.fromkeys(_norm(x) for x in source_paths if x)), "priority": priority}
    else:
        existing["priority"] = max(float(existing.get("priority", 0)), priority)
        existing.setdefault("sources", [])
        if source not in existing["sources"]:
            existing["sources"].append(source)
        if existing.get("source", "").startswith("query_parent:") is False and source.startswith("query_parent:"):
            existing["source"] = source
        existing["source_paths"] = list(dict.fromkeys(existing.get("source_paths", []) + [_norm(x) for x in source_paths if x]))[:80]


def _insert_candidates(session_id: str, candidates: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    by_class: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    pol = _cold_policy()
    for cand in candidates.values():
        cls = _source_class(cand["source"])
        by_class[cls].append(cand)
    selected: List[Dict[str, Any]] = []
    source_counts: Dict[str, int] = {}
    for cls, rows in by_class.items():
        rows.sort(key=lambda r: (-float(r.get("priority", 0)), r["path"]))
        budget = _source_budget(cls, pol)
        chosen = rows[:budget] if budget else []
        source_counts[cls] = len(chosen)
        selected.extend(chosen)
    # Keep a global cap only after source budgets have had a chance to contribute.
    max_candidates = int(pol.get("max_candidates", 600) or 600)
    selected.sort(key=lambda r: (-float(r.get("priority", 0)), r["path"]))
    selected = selected[:max_candidates]
    t = _now()
    c = conn()
    inserted = 0
    try:
        for cand in selected:
            ev = _candidate_evidence(cand["path"], cand.get("source_paths", []), expanded=False)
            ev["source_classes"] = sorted(set(_source_class(x) for x in cand.get("sources", [cand["source"]])))
            cur = c.execute(
                """INSERT OR IGNORE INTO cold_candidates(session_id,path,node_type,status,priority,source,source_paths_json,evidence_json,created_at,updated_at)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (session_id, cand["path"], "dir" if os.path.isdir(cand["path"]) else "file", "pending", float(cand.get("priority", 0)), cand["source"], json.dumps(cand.get("source_paths", []), ensure_ascii=False), json.dumps(ev, ensure_ascii=False), t, t),
            )
            inserted += int(cur.rowcount or 0)
        c.commit()
    finally:
        c.close()
    source_counts["inserted"] = inserted
    return source_counts


def collect_cold_start_entries(session_id: str, queries: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    scope = s["scope"]
    pol = _cold_policy()
    top_limit = int(pol.get("top_level_limit", 40))
    second_per_parent = int(pol.get("second_level_limit_per_parent", 20))
    recent_limit = int(pol.get("recent_limit", 300))
    limit_per_query = int(pol.get("limit_per_query", 80))
    parent_levels = int(pol.get("parent_levels", 2))
    before = cold_start_status(session_id).get("total_candidates", 0)
    candidates: Dict[str, Dict[str, Any]] = {}
    # Top and second level directories.
    top_dirs: List[str] = []
    if os.path.isdir(scope):
        try:
            with os.scandir(scope) as it:
                for ent in it:
                    if len(top_dirs) >= top_limit:
                        break
                    if ent.is_dir(follow_symlinks=False) and not _hard_ignored(ent.path):
                        top_dirs.append(ent.path)
                        _merge_candidate(candidates, ent.path, "top_level", [ent.path], _priority(ent.path, source="top_level"))
        except OSError:
            pass
        for td in top_dirs:
            try:
                seen = 0
                with os.scandir(td) as it:
                    for ent in it:
                        if seen >= second_per_parent:
                            break
                        if ent.is_dir(follow_symlinks=False) and not _hard_ignored(ent.path):
                            seen += 1
                            _merge_candidate(candidates, ent.path, "second_level", [ent.path], _priority(ent.path, source="second_level"))
            except OSError:
                continue
    # Recent file parents.
    try:
        for row in everything.recent(scope=scope, limit=recent_limit):
            p = row.get("path") if isinstance(row, dict) else str(row)
            if not p:
                continue
            mt = int(row.get("mtime_ns") or 0) if isinstance(row, dict) else 0
            for parent in _parent_entries_for_path(p, scope, parent_levels):
                _merge_candidate(candidates, parent, "recent_parent", [p], _priority(parent, source="recent_parent", source_mtime_ns=mt))
    except Exception:
        pass
    # Query/file-pattern seed parents. These have their own source budgets and cannot
    # be starved by top-level/recent candidates.
    qlist = [str(x) for x in (queries or _default_queries()) if str(x).strip()]
    for q in qlist:
        source = f"query_parent:{q}"
        try:
            for row in everything.search(q, scope=scope, limit=limit_per_query):
                p = row.get("path") if isinstance(row, dict) else str(row)
                if not p:
                    continue
                for parent in _parent_entries_for_path(p, scope, parent_levels):
                    _merge_candidate(candidates, parent, source, [p], _priority(parent, source=source, source_mtime_ns=int(row.get("mtime_ns") or 0) if isinstance(row, dict) else 0))
        except Exception:
            continue
    inserted_sources = _insert_candidates(session_id, candidates)
    c = conn()
    try:
        c.execute("UPDATE cold_sessions SET rounds=rounds+1,collection_done=1,updated_at=? WHERE session_id=?", (_now(), session_id))
        c.commit()
    finally:
        c.close()
    after = cold_start_status(session_id).get("total_candidates", 0)
    return {"ok": True, "session_id": session_id, "added": int(after) - int(before), "total_candidates": after, "source_budgets": inserted_sources, "next": "Use next_review_candidate(session_id) -> review_candidate(session_id, candidate_id) -> commit_review(...)."}


def cold_start_batch(session_id: str, batch_size: Optional[int] = None, include_needs_more_evidence: bool = False) -> Dict[str, Any]:
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    pol = _cold_policy()
    batch_size = int(batch_size if batch_size is not None else pol.get("default_batch_size", 8))
    statuses = ["pending"] + (["needs_more_evidence"] if include_needs_more_evidence else [])
    placeholders = ",".join("?" for _ in statuses)
    c = conn()
    try:
        rows = c.execute(f"SELECT * FROM cold_candidates WHERE session_id=? AND status IN ({placeholders}) ORDER BY priority DESC, updated_at DESC LIMIT ?", [session_id] + statuses + [max(1, int(batch_size))]).fetchall()
        items = []
        for r in rows:
            ev = json.loads(r["evidence_json"] or "{}")
            items.append({
                "path": r["path"],
                "node_type": r["node_type"],
                "status": r["status"],
                "priority": r["priority"],
                "source": r["source"],
                "source_seed_paths": json.loads(r["source_paths_json"] or "[]"),
                "evidence": ev,
                "needs_expand_before_apply": ev.get("evidence_level") != "expanded",
                "contract": {
                    "helper_does_not_generate_tags": True,
                    "agent_must_write_brief_tags_evidence_note": True,
                    "action_choices": ["apply", "skip", "defer", "need_more_evidence"],
                    "apply_requires_expanded_evidence": True,
                    "rough_batch_is_not_a_classifier": True,
                    "do_not_skip_for": ["too-few-items", "generic-directory", "unsupported-extension", "office-document-dir"],
                },
            })
        return {
            "ok": True,
            "session_id": session_id,
            "items": items,
            "batch": items,  # compatibility only; not for cold-start building.
            "count": len(items),
            "candidate_status": cold_start_status(session_id).get("candidate_status", {}),
            "diagnostic_only": True,
            "not_for_bulk_commit": True,
            "warning": "cold_start_batch is diagnostic/observation only in v30. Do not loop over it to commit tags.",
            "next": "Use next_review_candidate(session_id) -> review_candidate(session_id, candidate_id) -> commit_review(...)."
        }
    finally:
        c.close()


def cold_start_evidence_batch(session_id: str, batch_size: Optional[int] = None) -> Dict[str, Any]:
    return cold_start_batch(session_id, batch_size=batch_size)


def _set_candidate_status(session_id: str, path: str, status: str) -> bool:
    c = conn()
    try:
        cur = c.execute("UPDATE cold_candidates SET status=?,updated_at=? WHERE session_id=? AND path=?", (status, _now(), session_id, _norm(path)))
        c.commit()
        return cur.rowcount > 0
    finally:
        c.close()


def candidate_evidence_level(session_id: str, path: str) -> Dict[str, Any]:
    _ensure_tables()
    p = _norm(path)
    c = conn()
    try:
        r = c.execute("SELECT status,evidence_json FROM cold_candidates WHERE session_id=? AND path=?", (session_id, p)).fetchone()
        if not r:
            return {"ok": False, "error": "candidate not found", "session_id": session_id, "path": p, "expanded": False}
        ev = json.loads(r["evidence_json"] or "{}")
        level = ev.get("evidence_level") or "rough"
        return {"ok": True, "session_id": session_id, "path": p, "status": r["status"], "evidence_level": level, "expanded": level == "expanded"}
    finally:
        c.close()


def expand_candidate(session_id: str, path: str, *, max_children: Optional[int] = None, max_heads: Optional[int] = None) -> Dict[str, Any]:
    _ensure_tables()
    p = _norm(path)
    c = conn()
    try:
        r = c.execute("SELECT * FROM cold_candidates WHERE session_id=? AND path=?", (session_id, p)).fetchone()
        if not r:
            return {"ok": False, "error": "candidate not found", "session_id": session_id, "path": p}
        source_paths = json.loads(r["source_paths_json"] or "[]")
        ev = _candidate_evidence(p, source_paths, expanded=True, max_children_override=max_children, max_heads_override=max_heads)
        c.execute("UPDATE cold_candidates SET evidence_json=?,status='pending',updated_at=? WHERE session_id=? AND path=?", (json.dumps(ev, ensure_ascii=False), _now(), session_id, p))
        c.commit()
        return {"ok": True, "session_id": session_id, "path": p, "item": {"path": p, "node_type": r["node_type"], "status": "pending", "priority": r["priority"], "source": r["source"], "source_seed_paths": source_paths, "evidence": ev, "needs_expand_before_apply": False}}
    finally:
        c.close()


_FORBIDDEN_SKIP_REASON_TERMS = {
    "generic", "generic directory", "too few", "few items", "unsupported extension",
    "file_count", "children_count", "office", "docx", "ppt", "pptx", "xlsx", "document type",
}
_ALLOWED_SKIP_REASON_PREFIXES = (
    "duplicate", "already-indexed", "out-of-scope", "system", "dependency", "build", "confirmed-noise", "user-excluded", "not-useful-after-expanded-evidence",
)


def _validate_skip_reason(reason: str) -> Optional[str]:
    r = str(reason or "").strip().lower()
    if not r:
        return "skip reason required"
    if any(term in r for term in _FORBIDDEN_SKIP_REASON_TERMS):
        return "skip reason is not allowed; use defer/need_more_evidence for insufficient evidence or generic-looking document candidates"
    if not any(r.startswith(prefix) for prefix in _ALLOWED_SKIP_REASON_PREFIXES):
        return "skip reason must be specific: duplicate/already-indexed, out-of-scope, system/dependency/build, confirmed-noise, user-excluded, or not-useful-after-expanded-evidence"
    return None


def skip_candidate(session_id: str, path: str, reason: str = "") -> Dict[str, Any]:
    err = _validate_skip_reason(reason)
    if err:
        ok = _set_candidate_status(session_id, path, "needs_more_evidence")
        return {"ok": False, "session_id": session_id, "path": _norm(path), "status": "needs_more_evidence", "error": err, "reason": reason, "next": "defer_candidate(...) or expand_candidate(...); do not skip high-value/unknown candidates."}
    ok = _set_candidate_status(session_id, path, "skipped")
    return {"ok": ok, "session_id": session_id, "path": _norm(path), "status": "skipped", "reason": reason}


def defer_candidate(session_id: str, path: str, reason: str = "needs more evidence") -> Dict[str, Any]:
    ok = _set_candidate_status(session_id, path, "needs_more_evidence")
    return {"ok": ok, "session_id": session_id, "path": _norm(path), "status": "needs_more_evidence", "reason": reason}


def mark_candidates(session_id: str, *, applied_paths: Sequence[str] = (), skipped_paths: Sequence[str] = (), deferred_paths: Sequence[str] = (), needs_more_evidence_paths: Sequence[str] = ()) -> Dict[str, Any]:
    _ensure_tables()
    c = conn()
    try:
        t = _now()
        for p in applied_paths:
            c.execute("UPDATE cold_candidates SET status='applied',updated_at=? WHERE session_id=? AND path=?", (t, session_id, _norm(p)))
        for p in skipped_paths:
            c.execute("UPDATE cold_candidates SET status='skipped',updated_at=? WHERE session_id=? AND path=?", (t, session_id, _norm(p)))
        for p in deferred_paths:
            c.execute("UPDATE cold_candidates SET status='deferred',updated_at=? WHERE session_id=? AND path=?", (t, session_id, _norm(p)))
        for p in needs_more_evidence_paths:
            c.execute("UPDATE cold_candidates SET status='needs_more_evidence',updated_at=? WHERE session_id=? AND path=?", (t, session_id, _norm(p)))
        c.commit()
        return {"ok": True, "session_id": session_id, "applied": len(list(applied_paths)), "skipped": len(list(skipped_paths)), "deferred": len(list(deferred_paths)), "needs_more_evidence": len(list(needs_more_evidence_paths))}
    finally:
        c.close()


def cold_start_status(session_id: str) -> Dict[str, Any]:
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    c = conn()
    try:
        rows = c.execute("SELECT status,COUNT(*) FROM cold_candidates WHERE session_id=? GROUP BY status", (session_id,)).fetchall()
        by_status = {r[0]: r[1] for r in rows}
        src_rows = c.execute("SELECT source,COUNT(*) FROM cold_candidates WHERE session_id=? GROUP BY source ORDER BY COUNT(*) DESC", (session_id,)).fetchall()
        by_source_class: Counter[str] = Counter()
        for r in src_rows:
            by_source_class[_source_class(r[0])] += int(r[1])
        top = [dict(r) for r in c.execute("SELECT path,priority,source,status,evidence_json FROM cold_candidates WHERE session_id=? ORDER BY priority DESC LIMIT 20", (session_id,)).fetchall()]
        for r in top:
            try:
                ev = json.loads(r.pop("evidence_json") or "{}")
                r["soft_downrank"] = ev.get("soft_downrank")
                r["source_seed_paths"] = ev.get("source_seed_paths", [])[:5]
                r["evidence_level"] = ev.get("evidence_level", "rough")
                r["candidate_facts"] = ev.get("candidate_facts", {})
            except Exception:
                pass
        return {"ok": True, "session": s, "candidate_status": by_status, "source_classes": dict(by_source_class), "total_candidates": sum(by_status.values()), "top_candidates": top}
    finally:
        c.close()



# ---------------------------------------------------------------------------
# v30 review transaction API
# ---------------------------------------------------------------------------

def _norm_tag_value(t: str) -> str:
    s = re.sub(r"\s+", "-", str(t).strip().lower())
    s = re.sub(r"[^a-z0-9_\-\u4e00-\u9fff]+", "", s)
    return s


def _weak_route_tags() -> set[str]:
    q = load_index_policy().get("quality", {})
    vals = q.get("weak_route_tags", []) if isinstance(q, dict) else []
    built_in = {
        "python-code", "python-project", "web-frontend", "web-development", "java-code", "java-project",
        "cpp-code", "c-code", "documents", "document-archive", "pdf-documents", "presentations",
        "data-files", "markdown-docs", "wechat-files", "workspace", "project", "general", "archive",
        "materials", "course-materials", "files", "folder", "directory", "configuration", "config"
    }
    return {_norm_tag_value(x) for x in vals if str(x).strip()} | built_in


_CLASSIFIER_PATTERNS = [
    "based on file mix", "file mix", "主要类型", "文件类型", "扩展名", "个文件", "个子目录",
    "contains ", "file_count", "children_count", "path_lower", "路径包含", "位于", "located under"
]


def _candidate_id(session_id: str, path: str) -> str:
    import hashlib
    raw = (str(session_id) + "|" + _norm(path)).encode("utf-8", errors="replace")
    return "cand_" + hashlib.sha1(raw).hexdigest()[:16]


def _candidate_by_id(session_id: str, candidate_id: str) -> Optional[Dict[str, Any]]:
    _ensure_tables()
    c = conn()
    try:
        rows = c.execute("SELECT * FROM cold_candidates WHERE session_id=?", (session_id,)).fetchall()
        for r in rows:
            if _candidate_id(session_id, r["path"]) == candidate_id or r["path"] == candidate_id:
                d = dict(r)
                d["candidate_id"] = _candidate_id(session_id, r["path"])
                return d
        return None
    finally:
        c.close()


def _semantic_filename_score(name: str) -> int:
    """Heuristic for whether a file name is semantic evidence rather than a structural artifact.

    This is not a domain classifier. It only distinguishes human-authored titles
    such as reports/slides/papers from generic/config/build filenames.
    """
    n = str(name or "").strip()
    if not n:
        return 0
    base, ext = os.path.splitext(n)
    low = base.lower()
    generic = {
        "readme", "requirements", "package", "package-lock", "pnpm-lock", "yarn", "dockerfile",
        "makefile", "license", "setup", "config", "settings", "index", "main", "app", "test",
        "model", "train", "predict", "inference", "cache", "data"
    }
    if low in generic or low.startswith((".", "__")):
        return 0
    score = 0
    if re.search(r"[\u4e00-\u9fff]", n):
        score += 3
    if any(ch in n for ch in (" ", "_", "-", "（", "(", "【", "[")):
        score += 1
    if len(base) >= 8:
        score += 1
    if ext.lower() in _document_exts() or ext.lower() in _office_exts():
        score += 1
    return score


def _review_evidence_items_from_ev(review_id: str, ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    items: List[Dict[str, Any]] = []
    seq = 1
    def add(evidence_type: str, *, path: Optional[str] = None, name: Optional[str] = None, text: Optional[str] = None, metadata: Optional[Dict[str, Any]] = None) -> None:
        nonlocal seq
        eid = f"ev_{seq:03d}"
        seq += 1
        md = dict(metadata or {})
        items.append({
            "id": eid,
            "evidence_id": eid,
            "type": evidence_type,
            "evidence_type": evidence_type,
            "path": path,
            "name": name,
            "text": text,
            "metadata": md,
        })
    facts = ev.get("candidate_facts") or {}
    source_seeds = ev.get("source_seed_paths") or []
    if source_seeds:
        add("source_seed_paths", text="\n".join(str(x) for x in source_seeds[:8]), metadata={"count": len(source_seeds), "strength": "weak_structural", "route_support": False, "diagnostic_only": True})
    if ev.get("file_type_mix_sampled") or ev.get("children_sample"):
        # Diagnostic only; should not by itself support route tags.
        add("children_summary", text=json.dumps({
            "dir_count_sampled": ev.get("dir_count_sampled"),
            "file_count_sampled": ev.get("file_count_sampled"),
            "file_type_mix_sampled": ev.get("file_type_mix_sampled", {}),
        }, ensure_ascii=False), metadata={"diagnostic_only": True, "not_sufficient_for_route_tag": True, "strength": "diagnostic", "route_support": False})

    rep_files = list((ev.get("representative_document_files") or facts.get("representative_files") or [])[:10])
    semantic_names: List[str] = []
    for rf in rep_files:
        name = rf.get("name")
        score = _semantic_filename_score(str(name or ""))
        strength = "semantic_filename" if score >= 3 else "weak_structural"
        if strength == "semantic_filename" and name:
            semantic_names.append(str(name))
        md = {k: v for k, v in rf.items() if k not in ("path", "name")}
        md.update({"strength": strength, "route_support": strength == "semantic_filename", "semantic_filename_score": score})
        add("representative_file", path=rf.get("path"), name=name, metadata=md)
    if len(semantic_names) >= 2:
        add("semantic_filename_set", text="\n".join(semantic_names[:12]), metadata={"strength": "semantic_filename_set", "route_support": True, "count": len(semantic_names)})
    for h in (ev.get("document_heads") or [])[:4]:
        add("document_head", path=h.get("path"), name=h.get("name"), text=h.get("head"), metadata={"note": h.get("note"), "strength": "strong_semantic", "route_support": True})
    if ev.get("content_head"):
        add("content_head", path=ev.get("path"), name=os.path.basename(str(ev.get("path") or "")), text=ev.get("content_head"), metadata={"note": ev.get("content_head_note"), "strength": "strong_semantic", "route_support": True})
    return items


def _suggest_weak_facets(ev: Dict[str, Any]) -> List[str]:
    mix = ev.get("file_type_mix_sampled") or (ev.get("candidate_facts") or {}).get("file_type_mix_sampled") or {}
    facets: List[str] = []
    exts = set(mix.keys())
    if any(x in exts for x in (".py", ".ipynb")):
        facets.append("python-code")
    if any(x in exts for x in (".js", ".ts", ".vue", ".html", ".css")):
        facets.append("web-code")
    if any(x in exts for x in (".java",)):
        facets.append("java-code")
    if any(x in exts for x in (".cpp", ".c", ".h", ".hpp", ".cs")):
        facets.append("native-code")
    if any(x in exts for x in (".doc", ".docx", ".pdf", ".txt", ".md", ".tex")):
        facets.append("documents")
    if any(x in exts for x in (".ppt", ".pptx")):
        facets.append("presentations")
    if any(x in exts for x in (".xls", ".xlsx", ".csv")):
        facets.append("data-files")
    return list(dict.fromkeys(facets))


def next_review_candidate(session_id: str, include_needs_more_evidence: bool = False) -> Dict[str, Any]:
    """Return one candidate to review. This is the v30 cold-start main entry."""
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    statuses = ["pending"] + (["needs_more_evidence"] if include_needs_more_evidence else [])
    placeholders = ",".join("?" for _ in statuses)
    c = conn()
    try:
        r = c.execute(f"SELECT * FROM cold_candidates WHERE session_id=? AND status IN ({placeholders}) ORDER BY priority DESC, created_at ASC LIMIT 1", [session_id] + statuses).fetchone()
        if not r:
            return {"ok": True, "session_id": session_id, "done": True, "candidate": None, "next": "finish_cold_start(session_id)"}
        ev = json.loads(r["evidence_json"] or "{}")
        cid = _candidate_id(session_id, r["path"])
        return {
            "ok": True,
            "session_id": session_id,
            "candidate_id": cid,
            "path": r["path"],
            "status": r["status"],
            "priority": r["priority"],
            "source": r["source"],
            "rough_facts": ev.get("candidate_facts") or {},
            "source_seed_paths": json.loads(r["source_paths_json"] or "[]")[:8],
            "next": "review_candidate(session_id, candidate_id)",
        }
    finally:
        c.close()


def review_candidate(session_id: str, candidate_id: str, *, max_children: Optional[int] = None, max_heads: Optional[int] = None) -> Dict[str, Any]:
    """Expand one candidate and create an evidence-bound review_id."""
    _ensure_tables()
    cand = _candidate_by_id(session_id, candidate_id)
    if not cand:
        return {"ok": False, "error": "candidate not found", "session_id": session_id, "candidate_id": candidate_id}
    p = cand["path"]
    source_paths = json.loads(cand["source_paths_json"] or "[]")
    ev = _candidate_evidence(p, source_paths, expanded=True, max_children_override=max_children, max_heads_override=max_heads)
    rid = "rv_" + uuid.uuid4().hex[:12]
    cid = _candidate_id(session_id, p)
    evidence_items = _review_evidence_items_from_ev(rid, ev)
    c = conn()
    try:
        t = _now()
        c.execute("UPDATE cold_candidates SET evidence_json=?,status='in_review',updated_at=? WHERE session_id=? AND path=?", (json.dumps(ev, ensure_ascii=False), t, session_id, p))
        c.execute("INSERT INTO cold_reviews(review_id,session_id,candidate_id,path,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)", (rid, session_id, cid, p, "open", t, t))
        for it in evidence_items:
            c.execute(
                "INSERT INTO review_evidence_items(review_id,evidence_id,evidence_type,path,name,text,metadata_json) VALUES(?,?,?,?,?,?,?)",
                (rid, it["id"], it["type"], it.get("path"), it.get("name"), it.get("text"), json.dumps(it.get("metadata") or {}, ensure_ascii=False)),
            )
        c.commit()
    finally:
        c.close()
    return {
        "ok": True,
        "session_id": session_id,
        "candidate_id": cid,
        "review_id": rid,
        "path": p,
        "evidence_items": evidence_items,
        "weak_facets_suggested": _suggest_weak_facets(ev),
        "annotation_contract": [
            "Commit must reference evidence item ids from this review.",
            "File mix / extension / path words alone are diagnostic facets, not route tags.",
            "If no route tag is directly supported by evidence ids, defer.",
        ],
        "next": "commit_review(session_id, review_id, decision='apply|defer|skip|need_more_evidence', ...)"
    }



def next_needs_more_candidate(session_id: str) -> Dict[str, Any]:
    """Return one candidate from the explicit needs-more-evidence queue.

    This queue is intentionally separate from the main pending queue so normal
    review does not loop on the same high-priority unresolved item.
    """
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    c = conn()
    try:
        r = c.execute("SELECT * FROM cold_candidates WHERE session_id=? AND status='needs_more_evidence' ORDER BY priority DESC, created_at ASC LIMIT 1", (session_id,)).fetchone()
        if not r:
            return {"ok": True, "session_id": session_id, "done": True, "candidate": None, "next": "continue main pending queue or finish_cold_start(session_id)"}
        ev = json.loads(r["evidence_json"] or "{}")
        cid = _candidate_id(session_id, r["path"])
        return {
            "ok": True, "session_id": session_id, "candidate_id": cid, "path": r["path"], "status": r["status"],
            "priority": r["priority"], "source": r["source"], "rough_facts": ev.get("candidate_facts") or {},
            "source_seed_paths": json.loads(r["source_paths_json"] or "[]")[:8],
            "next": "review_candidate(session_id, candidate_id, max_children=160, max_heads=8)",
        }
    finally:
        c.close()


def review_more_evidence(session_id: str, *, review_id: Optional[str] = None, candidate_id: Optional[str] = None, max_children: int = 160, max_heads: int = 8) -> Dict[str, Any]:
    """Create a deeper review packet for an unresolved candidate.

    Passing a review_id reuses that review's candidate. This creates a new
    review_id with larger evidence limits; the old review remains auditable.
    """
    if review_id:
        rv = _load_review(session_id, review_id)
        if not rv:
            return {"ok": False, "error": "review not found", "session_id": session_id, "review_id": review_id}
        candidate_id = rv.get("candidate_id")
    if not candidate_id:
        return {"ok": False, "error": "candidate_id or review_id required"}
    return review_candidate(session_id, str(candidate_id), max_children=max_children, max_heads=max_heads)

def _load_review(session_id: str, review_id: str) -> Optional[Dict[str, Any]]:
    _ensure_tables()
    c = conn()
    try:
        r = c.execute("SELECT * FROM cold_reviews WHERE session_id=? AND review_id=?", (session_id, review_id)).fetchone()
        return dict(r) if r else None
    finally:
        c.close()


def _load_review_evidence(review_id: str) -> Dict[str, Dict[str, Any]]:
    c = conn()
    try:
        rows = c.execute("SELECT * FROM review_evidence_items WHERE review_id=?", (review_id,)).fetchall()
        out: Dict[str, Dict[str, Any]] = {}
        for r in rows:
            out[r["evidence_id"]] = {
                "id": r["evidence_id"],
                "type": r["evidence_type"],
                "path": r["path"],
                "name": r["name"],
                "text": r["text"],
                "metadata": json.loads(r["metadata_json"] or "{}"),
            }
        return out
    finally:
        c.close()


def _validate_review_commit(decision: str, route_tags: Sequence[str], facets: Sequence[str], evidence_refs: Sequence[str], evidence_note: str, brief: str, evidence_by_id: Dict[str, Dict[str, Any]]) -> Tuple[List[str], List[str], List[str], List[str]]:
    errors: List[str] = []
    flags: List[str] = []
    weak = _weak_route_tags()
    tags_norm = [_norm_tag_value(x) for x in route_tags or [] if str(x).strip()]
    facets_norm = [_norm_tag_value(x) for x in facets or [] if str(x).strip()]
    weak_as_facets = [t for t in tags_norm if t in weak]
    route = [t for t in tags_norm if t not in weak]
    merged_facets = list(dict.fromkeys(facets_norm + weak_as_facets))
    refs = [str(x).strip() for x in evidence_refs or [] if str(x).strip()]
    missing = [x for x in refs if x not in evidence_by_id]
    note_l = str(evidence_note or "").lower()
    brief_l = str(brief or "").lower()
    if decision == "apply":
        if not refs:
            errors.append("evidence_refs required")
        if missing:
            errors.append(f"unknown evidence_refs: {missing}")
        if not route:
            errors.append("no high-quality route tag; weak type labels must be facets")
        route_supporting_refs: List[str] = []
        for rid in refs:
            md = (evidence_by_id.get(rid, {}).get("metadata") or {})
            strength = str(md.get("strength") or "")
            if md.get("route_support") or strength in {"strong_semantic", "semantic_filename", "semantic_filename_set"}:
                route_supporting_refs.append(rid)
        if refs and not route_supporting_refs:
            errors.append("route tag must be supported by strong semantic evidence or semantic filename evidence; path/file-mix refs are facets only")
            flags.append("no_route_supporting_evidence")
        if any(p.lower() in note_l for p in _CLASSIFIER_PATTERNS):
            flags.append("classifier_evidence_note")
            # Classifier-like notes are allowed only as supplementary context when strong refs exist.
            if not route_supporting_refs:
                errors.append("classifier evidence note without route-supporting evidence_refs")
        if any(p.lower() in brief_l for p in ["主要类型", "文件类型", "包含", "contains", "file types"]):
            flags.append("template_brief")
        if refs and all((evidence_by_id.get(r, {}).get("metadata") or {}).get("diagnostic_only") for r in refs):
            errors.append("only diagnostic evidence refs supplied; use document_head/content_head/semantic_filename evidence or defer")
    return errors, route, merged_facets, flags


def _reject_review_state(session_id: str, review_id: str, path: str, *, review_status: str = "rejected", candidate_status: str = "needs_more_evidence", reason: str = "") -> None:
    """Move a failed review out of in_review so the candidate is not stranded."""
    try:
        if candidate_status == "pending":
            # direct SQL because mark_candidates has no pending helper
            c = conn()
            try:
                c.execute("UPDATE cold_candidates SET status='pending',updated_at=? WHERE session_id=? AND path=?", (_now(), session_id, path))
                c.commit()
            finally:
                c.close()
        else:
            mark_candidates(session_id, needs_more_evidence_paths=[path])
    except Exception:
        pass
    c = conn()
    try:
        c.execute("UPDATE cold_reviews SET status=?,updated_at=? WHERE review_id=?", (review_status, _now(), review_id))
        c.commit()
    finally:
        c.close()
    if reason:
        log_event("review_state_recovered", {"session_id": session_id, "review_id": review_id, "path": path, "review_status": review_status, "candidate_status": candidate_status, "reason": reason})


def commit_review(session_id: str, review_id: str, *, decision: str, brief: str = "", route_tags: Optional[Sequence[str]] = None, tags: Optional[Sequence[str]] = None, facets: Optional[Sequence[str]] = None, evidence_refs: Optional[Sequence[str]] = None, evidence_note: str = "", tier: str = "warm", leaf_candidates: Optional[Sequence[Any]] = None, reason: str = "") -> Dict[str, Any]:
    """Commit exactly one review. This is the only v30 cold-start commit path."""
    decision = str(decision or "").strip().lower()
    if decision not in {"apply", "defer", "skip", "need_more_evidence", "needs_more_evidence"}:
        return {"ok": False, "error": "decision must be apply/defer/skip/need_more_evidence", "decision": decision}
    rv = _load_review(session_id, review_id)
    if not rv:
        return {"ok": False, "error": "review not found", "session_id": session_id, "review_id": review_id}
    if rv.get("status") != "open":
        return {"ok": False, "error": f"review is {rv.get('status')}", "review_id": review_id}
    path = rv["path"]
    cid = rv["candidate_id"]
    evidence_by_id = _load_review_evidence(review_id)
    refs = [str(x).strip() for x in (evidence_refs or []) if str(x).strip()]
    route_input = list(route_tags if route_tags is not None else (tags or []))
    facets_input = list(facets or [])
    errors, route, merged_facets, flags = _validate_review_commit(decision if decision != "needs_more_evidence" else "need_more_evidence", route_input, facets_input, refs, evidence_note, brief, evidence_by_id)
    if decision == "skip":
        err = _validate_skip_reason(reason or evidence_note)
        if err:
            _reject_review_state(session_id, review_id, path, review_status="rejected", candidate_status="needs_more_evidence", reason=err)
            return {"ok": False, "status": "needs_more_evidence", "review_id": review_id, "path": path, "error": err, "next": "commit_review(..., decision='defer')"}
    if decision == "apply" and errors:
        _reject_review_state(session_id, review_id, path, review_status="rejected", candidate_status="needs_more_evidence", reason="; ".join(errors))
        log_event("review_commit_rejected", {"session_id": session_id, "review_id": review_id, "path": path, "errors": errors, "quality_flags": flags})
        return {"ok": False, "status": "needs_verification", "review_id": review_id, "path": path, "errors": errors, "quality_flags": flags, "suggested_facets": merged_facets, "next": "rewrite using evidence item ids, request review_more_evidence(...), or defer"}
    if decision in {"defer", "need_more_evidence", "needs_more_evidence"}:
        status = "needs_more_evidence" if decision in {"need_more_evidence", "needs_more_evidence"} else "deferred"
        if status == "deferred":
            mark_candidates(session_id, deferred_paths=[path])
        else:
            mark_candidates(session_id, needs_more_evidence_paths=[path])
        c = conn()
        try:
            t = _now()
            c.execute("UPDATE cold_reviews SET status=?,updated_at=? WHERE review_id=?", (status, t, review_id))
            c.execute("INSERT INTO review_commits(commit_id,review_id,session_id,candidate_id,path,decision,brief,route_tags_json,facets_json,evidence_refs_json,evidence_note,quality_flags_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      ("rc_" + uuid.uuid4().hex[:12], review_id, session_id, cid, path, decision, brief or reason, "[]", json.dumps(merged_facets, ensure_ascii=False), json.dumps(refs, ensure_ascii=False), evidence_note or reason, json.dumps(flags, ensure_ascii=False), t))
            c.commit()
        finally:
            c.close()
        return {"ok": True, "status": status, "review_id": review_id, "path": path, "decision": decision, "facets": merged_facets}
    if decision == "skip":
        mark_candidates(session_id, skipped_paths=[path])
        c = conn()
        try:
            t = _now()
            c.execute("UPDATE cold_reviews SET status='skipped',updated_at=? WHERE review_id=?", (t, review_id))
            c.execute("INSERT INTO review_commits(commit_id,review_id,session_id,candidate_id,path,decision,brief,route_tags_json,facets_json,evidence_refs_json,evidence_note,quality_flags_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      ("rc_" + uuid.uuid4().hex[:12], review_id, session_id, cid, path, "skip", reason or brief, "[]", json.dumps(merged_facets, ensure_ascii=False), json.dumps(refs, ensure_ascii=False), evidence_note or reason, json.dumps(flags, ensure_ascii=False), t))
            c.commit()
        finally:
            c.close()
        return {"ok": True, "status": "skipped", "review_id": review_id, "path": path, "decision": "skip", "reason": reason or evidence_note}
    # apply
    auto_leafs: List[Any] = list(leaf_candidates or [])
    if not auto_leafs:
        for rid in refs:
            item = evidence_by_id.get(rid) or {}
            pth = item.get("path")
            if pth and _norm(pth) != _norm(path):
                auto_leafs.append(pth)
        auto_leafs = list(dict.fromkeys(auto_leafs))[: int(load_index_policy().get("leaf_cap_per_entry", 8) or 8)]
    plan = [{
        "path": path,
        "role": "entry",
        "tier": tier,
        "brief": brief,
        "tags": route,
        "facets": merged_facets,
        "evidence_note": evidence_note,
        "leaf_candidates": auto_leafs,
    }]
    res = _store_apply_index_plan(plan)
    if res.get("ok"):
        mark_candidates(session_id, applied_paths=[path])
        c = conn()
        try:
            t = _now()
            c.execute("UPDATE cold_reviews SET status='committed',updated_at=? WHERE review_id=?", (t, review_id))
            c.execute("INSERT INTO review_commits(commit_id,review_id,session_id,candidate_id,path,decision,brief,route_tags_json,facets_json,evidence_refs_json,evidence_note,quality_flags_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      ("rc_" + uuid.uuid4().hex[:12], review_id, session_id, cid, path, "apply", brief, json.dumps(route, ensure_ascii=False), json.dumps(merged_facets, ensure_ascii=False), json.dumps(refs, ensure_ascii=False), evidence_note, json.dumps(flags, ensure_ascii=False), t))
            c.commit()
        finally:
            c.close()
        log_event("review_commit_applied", {"session_id": session_id, "review_id": review_id, "path": path, "route_tags": route, "facets": merged_facets, "evidence_refs": refs, "quality_flags": flags})
        res["review_id"] = review_id
        res["route_tags"] = route
        res["facets"] = merged_facets
        res["evidence_refs"] = refs
        res["quality_flags"] = flags
    return res



def _session_index_stats(session_id: str) -> Dict[str, Any]:
    """Stats for entries created by this cold-start session, not the whole DB."""
    _ensure_tables()
    c = conn()
    try:
        paths = [r["path"] for r in c.execute("SELECT DISTINCT path FROM review_commits WHERE session_id=? AND decision='apply'", (session_id,)).fetchall()]
        if not paths:
            return {"entries": 0, "leaf": 0, "tagged_nodes": 0, "nodes": 0, "review_applied_paths": []}
        placeholders = ",".join("?" for _ in paths)
        entries = c.execute(f"SELECT COUNT(*) AS n FROM nodes WHERE role='entry' AND path IN ({placeholders})", paths).fetchone()["n"]
        leaf = c.execute(f"SELECT COUNT(*) AS n FROM nodes WHERE role='leaf' AND parent_entry IN ({placeholders})", paths).fetchone()["n"]
        tagged = c.execute(f"SELECT COUNT(DISTINCT path) AS n FROM node_tags WHERE path IN ({placeholders})", paths).fetchone()["n"]
        return {"entries": int(entries or 0), "leaf": int(leaf or 0), "tagged_nodes": int(tagged or 0), "nodes": int(entries or 0) + int(leaf or 0), "review_applied_paths": paths}
    finally:
        c.close()


def _normalize_template_text(txt: str) -> str:
    s = re.sub(r"[A-Za-z]:\\[^\s,;，；]+", "<PATH>", str(txt or "").lower())
    s = re.sub(r"\d+", "<N>", s)
    s = re.sub(r"[\s,;，；：:]+", " ", s).strip()
    return s[:220]

def audit_cold_start_protocol(session_id: Optional[str] = None) -> Dict[str, Any]:
    _ensure_tables()
    c = conn()
    try:
        where = "WHERE session_id=?" if session_id else ""
        params = (session_id,) if session_id else ()
        review_rows = c.execute(f"SELECT status,COUNT(*) AS n FROM cold_reviews {where} GROUP BY status", params).fetchall()
        commit_rows = c.execute(f"SELECT decision,quality_flags_json,route_tags_json,facets_json,evidence_refs_json,evidence_note,brief,created_at FROM review_commits {where} ORDER BY created_at ASC", params).fetchall()
        applied_candidates = 0
        if session_id:
            r = c.execute("SELECT COUNT(*) AS n FROM cold_candidates WHERE session_id=? AND status='applied'", (session_id,)).fetchone()
            applied_candidates = int(r["n"] or 0) if r else 0
        else:
            r = c.execute("SELECT COUNT(*) AS n FROM cold_candidates WHERE status='applied'").fetchone()
            applied_candidates = int(r["n"] or 0) if r else 0
    finally:
        c.close()
    reviews_by_status = {r["status"]: int(r["n"]) for r in review_rows}
    applied_reviews = 0
    classifier_notes = 0
    weak_only = 0
    total_apply = 0
    note_templates: Counter[str] = Counter()
    brief_templates: Counter[str] = Counter()
    tag_counter: Counter[str] = Counter()
    apply_times: List[float] = []
    for r in commit_rows:
        if r["decision"] == "apply":
            total_apply += 1
            applied_reviews += 1
            note = str(r["evidence_note"] or "")
            brief = str(r["brief"] or "")
            flags = json.loads(r["quality_flags_json"] or "[]")
            tags = json.loads(r["route_tags_json"] or "[]")
            if "classifier_evidence_note" in flags or "no_route_supporting_evidence" in flags or any(p.lower() in note.lower() for p in _CLASSIFIER_PATTERNS):
                classifier_notes += 1
            if not tags:
                weak_only += 1
            for t in tags:
                tag_counter[str(t)] += 1
            if note:
                note_templates[_normalize_template_text(note)] += 1
            if brief:
                brief_templates[_normalize_template_text(brief)] += 1
            try:
                apply_times.append(float(r["created_at"] or 0))
            except Exception:
                pass
    unreviewed_applied = max(0, applied_candidates - applied_reviews)
    warnings: List[str] = []
    status = "healthy"
    if unreviewed_applied:
        warnings.append(f"applied_without_review={unreviewed_applied}")
    if total_apply and classifier_notes / max(1, total_apply) > 0.25:
        warnings.append(f"classifier_evidence_dominates={classifier_notes}/{total_apply}")
    if weak_only:
        warnings.append(f"weak_only_applied_commits={weak_only}")
    st = _session_index_stats(session_id) if session_id else index_stats()
    if int(st.get("entries") or 0) >= 60 and int(st.get("leaf") or 0) == 0:
        warnings.append("entry_many_but_leaf_zero")
    elif int(st.get("entries") or 0) >= 30 and int(st.get("leaf") or 0) == 0:
        warnings.append("entry_many_but_leaf_zero_warning")
    # Scripted one-by-one loops tend to have very repetitive note/brief templates,
    # highly concentrated route tags, and many commits in a short span.
    if total_apply >= 12:
        top_note = note_templates.most_common(1)[0][1] if note_templates else 0
        top_brief = brief_templates.most_common(1)[0][1] if brief_templates else 0
        top_tag = tag_counter.most_common(1)[0][1] if tag_counter else 0
        if top_note >= 5 and top_note / total_apply >= 0.30:
            warnings.append(f"template_evidence_note_repetition={top_note}/{total_apply}")
        if top_brief >= 5 and top_brief / total_apply >= 0.30:
            warnings.append(f"template_brief_repetition={top_brief}/{total_apply}")
        if top_tag >= 10 and top_tag / total_apply >= 0.50:
            warnings.append(f"route_tag_distribution_concentrated={top_tag}/{total_apply}")
        if len(apply_times) >= 20 and (max(apply_times) - min(apply_times)) <= 120:
            warnings.append(f"rapid_review_commits={len(apply_times)}_within_120s")
    unhealthy_prefixes = (
        "applied_without_review", "classifier_evidence_dominates", "entry_many_but_leaf_zero",
        "template_evidence_note_repetition", "template_brief_repetition",
        "route_tag_distribution_concentrated", "rapid_review_commits"
    )
    if warnings:
        status = "protocol_unhealthy" if any(x.startswith(unhealthy_prefixes) for x in warnings) else "incomplete"
    return {
        "ok": status == "healthy",
        "status": status,
        "session_id": session_id,
        "reviews_by_status": reviews_by_status,
        "applied_candidates": applied_candidates,
        "applied_review_commits": applied_reviews,
        "unreviewed_applied": unreviewed_applied,
        "classifier_evidence_notes": classifier_notes,
        "session_index_stats": st,
        "template_note_top": note_templates.most_common(3),
        "template_brief_top": brief_templates.most_common(3),
        "route_tag_top": tag_counter.most_common(5),
        "warnings": warnings,
    }


def finish_cold_start(session_id: str, *, allow_pending: bool = False) -> Dict[str, Any]:
    """Report honest cold-start status without treating entry counts as failure thresholds.

    Counts are diagnostics/reference targets. Failure is reserved for protocol/tool
    failures or no usable entry at all. Small high-confidence indexes are usable_partial.
    """
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    global_stats = index_stats()
    st = _session_index_stats(session_id)
    entries = int(st.get("entries") or 0)
    tagged_nodes = int(st.get("tagged_nodes") or 0)
    leaf = int(st.get("leaf") or 0)
    st0 = cold_start_status(session_id)
    cand = st0.get("candidate_status") or {}
    pending_count = int(cand.get("pending") or 0)
    needs_more = int(cand.get("needs_more_evidence") or 0)
    deferred_count = int(cand.get("deferred") or 0)
    warnings: List[str] = []
    errors: List[str] = []
    if pending_count and not allow_pending:
        warnings.append(f"pending_candidates={pending_count}")
    if needs_more:
        warnings.append(f"needs_more_evidence_candidates={needs_more}")
    if deferred_count:
        warnings.append(f"deferred_candidates={deferred_count}")
    if entries == 0 or tagged_nodes == 0:
        errors.append("no_high_confidence_tagged_entries")
    if leaf == 0:
        warnings.append("no_leaf_nodes_attached")
    pol = _cold_policy()
    reference = {
        "target_nodes_budget": int(s.get("target_nodes") or pol.get("target_nodes", 1000) or 1000),
        "reference_usable_entries": int(pol.get("reference_usable_entries", 60) or 60),
        "reference_complete_entries": int(pol.get("reference_complete_entries", 120) or 120),
        "reference_tagged_usable": int(pol.get("reference_tagged_usable", 40) or 40),
        "reference_tagged_complete": int(pol.get("reference_tagged_complete", 80) or 80),
    }
    protocol = audit_cold_start_protocol(session_id)
    if protocol.get("warnings"):
        warnings.extend(["protocol:" + str(x) for x in protocol.get("warnings", [])])
    if errors:
        status = "failed"
    elif protocol.get("status") == "protocol_unhealthy":
        status = "protocol_unhealthy"
    elif (pending_count or needs_more or deferred_count) and not allow_pending:
        status = "incomplete"
    elif tagged_nodes >= reference["reference_tagged_complete"] and entries >= reference["reference_complete_entries"] and not warnings:
        status = "complete"
    else:
        status = "usable_partial"
    c = conn()
    try:
        c.execute("UPDATE cold_sessions SET status=?,updated_at=? WHERE session_id=?", (status, _now(), session_id))
        c.commit()
    finally:
        c.close()
    return {
        "ok": status in ("complete", "usable_partial"),
        "status": status,
        "session_id": session_id,
        "warnings": warnings,
        "errors": errors,
        "stats": st,
        "global_stats": global_stats,
        "cold_start_status": st0,
        "protocol_health": protocol,
        "reference_targets_not_thresholds": reference,
        "note": "Entry counts are diagnostics and capacity/coverage references, not failure thresholds. Do not lower evidence standards to increase counts."
    }
