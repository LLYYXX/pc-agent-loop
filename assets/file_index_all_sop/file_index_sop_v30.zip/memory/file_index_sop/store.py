"""SQLite overlay for file_index_sop v30.

This module stores Agent-authored semantic notes and runtime after-effects.
It does not infer route tags. Tier management is intentionally small but real:
hits warm nodes up, rebalancing caps active/warm and demotes stale/overflow nodes.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import time
import uuid
from typing import Any, Dict, List, Optional, Sequence

from .policy import load_index_policy

_THIS = os.path.dirname(os.path.abspath(__file__))
_DEFAULT_DB = os.path.join(_THIS, "file_index.sqlite")
_db_path_override: Optional[str] = None


def db_path() -> str:
    return os.path.abspath(os.environ.get("FILE_INDEX_DB") or _db_path_override or _DEFAULT_DB)


def set_db_path(path: str) -> None:
    global _db_path_override
    _db_path_override = os.path.abspath(path)


DDL = """
CREATE TABLE IF NOT EXISTS nodes (
  path TEXT PRIMARY KEY,
  node_type TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'entry',
  tier TEXT NOT NULL DEFAULT 'warm',
  brief TEXT NOT NULL DEFAULT '',
  evidence_note TEXT NOT NULL DEFAULT '',
  parent_entry TEXT,
  size INTEGER,
  mtime_ns INTEGER,
  hit_count INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL,
  last_used REAL
);
CREATE TABLE IF NOT EXISTS node_tags (
  path TEXT NOT NULL,
  tag TEXT NOT NULL,
  evidence_note TEXT NOT NULL DEFAULT '',
  PRIMARY KEY(path, tag)
);
CREATE TABLE IF NOT EXISTS node_facets (
  path TEXT NOT NULL,
  facet TEXT NOT NULL,
  PRIMARY KEY(path, facet)
);
CREATE TABLE IF NOT EXISTS query_aliases (
  alias TEXT PRIMARY KEY,
  path TEXT NOT NULL,
  evidence_note TEXT NOT NULL DEFAULT '',
  hit_count INTEGER NOT NULL DEFAULT 0,
  updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS update_plans (
  plan_id TEXT PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'draft',
  query TEXT NOT NULL DEFAULT '',
  draft_json TEXT NOT NULL,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS task_ledger (
  task_id TEXT PRIMARY KEY,
  query TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'open',
  semantic_hits_json TEXT NOT NULL DEFAULT '[]',
  filesystem_hits_json TEXT NOT NULL DEFAULT '[]',
  fallback_used INTEGER NOT NULL DEFAULT 0,
  dirty INTEGER NOT NULL DEFAULT 0,
  created_at REAL NOT NULL,
  updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_nodes_tier ON nodes(tier);
CREATE INDEX IF NOT EXISTS idx_nodes_role ON nodes(role);
CREATE INDEX IF NOT EXISTS idx_node_tags_tag ON node_tags(tag);
"""


def conn() -> sqlite3.Connection:
    p = db_path()
    os.makedirs(os.path.dirname(p), exist_ok=True)
    c = sqlite3.connect(p, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c


def init_db(path: Optional[str] = None) -> Dict[str, Any]:
    if path:
        set_db_path(path)
    c = conn()
    try:
        for stmt in DDL.split(";"):
            s = stmt.strip()
            if s:
                c.execute(s)
        c.commit()
        return {"ok": True, "db": db_path()}
    finally:
        c.close()


def reset_db(path: Optional[str] = None) -> Dict[str, Any]:
    if path:
        set_db_path(path)
    p = db_path()
    for cand in (p, p + "-wal", p + "-shm"):
        try:
            if os.path.exists(cand):
                os.remove(cand)
        except OSError:
            pass
    return init_db()


def _now() -> float:
    return time.time()


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _stat(path: str) -> Dict[str, Any]:
    try:
        st = os.stat(path, follow_symlinks=False)
        return {"size": int(st.st_size), "mtime_ns": int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))}
    except OSError:
        return {"size": None, "mtime_ns": None}


def _node_type(path: str, explicit: Optional[str] = None) -> str:
    if explicit in ("file", "dir"):
        return explicit
    if os.path.isdir(path):
        return "dir"
    return "file"


def _tags(tags: Sequence[str]) -> List[str]:
    out: List[str] = []
    for t in tags or []:
        s = re.sub(r"\s+", "-", str(t).strip().lower())
        s = re.sub(r"[^a-z0-9_\-\u4e00-\u9fff]+", "", s)
        if s and s not in out:
            out.append(s)
    return out


def _generic_tags() -> set[str]:
    return set(str(x).strip().lower() for x in load_index_policy().get("generic_route_tags", []))


def validate_tags(tags: Sequence[str], evidence_note: str = "") -> List[str]:
    bad: List[str] = []
    generic = _generic_tags()
    for t in _tags(tags):
        if t in generic:
            bad.append(f"generic tag: {t}")
        if len(t) < 3:
            bad.append(f"too short tag: {t}")
    if tags and not str(evidence_note or "").strip():
        bad.append("tags require evidence_note")
    return bad


def log_event(event_type: str, payload: Dict[str, Any], con: Optional[sqlite3.Connection] = None) -> None:
    own = con is None
    c = con or conn()
    try:
        c.execute("INSERT INTO events(event_type,payload_json,created_at) VALUES(?,?,?)", (event_type, json.dumps(payload, ensure_ascii=False), _now()))
        if own:
            c.commit()
    finally:
        if own:
            c.close()


def upsert_node(path: str, *, node_type: Optional[str] = None, role: str = "entry", tier: str = "warm", brief: str = "", evidence_note: str = "", parent_entry: Optional[str] = None, con: Optional[sqlite3.Connection] = None) -> Dict[str, Any]:
    p = _norm(path)
    nt = _node_type(p, node_type)
    if role not in ("entry", "leaf"):
        role = "entry"
    if tier not in ("active", "warm", "cold"):
        tier = "warm"
    st = _stat(p)
    own = con is None
    c = con or conn()
    try:
        t = _now()
        c.execute(
            """INSERT INTO nodes(path,node_type,role,tier,brief,evidence_note,parent_entry,size,mtime_ns,created_at,updated_at)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?)
                 ON CONFLICT(path) DO UPDATE SET
                   node_type=excluded.node_type,
                   role=excluded.role,
                   tier=excluded.tier,
                   brief=CASE WHEN excluded.brief!='' THEN excluded.brief ELSE nodes.brief END,
                   evidence_note=CASE WHEN excluded.evidence_note!='' THEN excluded.evidence_note ELSE nodes.evidence_note END,
                   parent_entry=COALESCE(excluded.parent_entry,nodes.parent_entry),
                   size=COALESCE(excluded.size,nodes.size),
                   mtime_ns=COALESCE(excluded.mtime_ns,nodes.mtime_ns),
                   updated_at=excluded.updated_at""",
            (p, nt, role, tier, brief.strip(), evidence_note.strip(), _norm(parent_entry) if parent_entry else None, st["size"], st["mtime_ns"], t, t),
        )
        if own:
            c.commit()
        return {"ok": True, "path": p, "node_type": nt, "role": role, "tier": tier}
    finally:
        if own:
            c.close()


def set_tags(path: str, tags: Sequence[str], evidence_note: str, *, replace: bool = True, con: Optional[sqlite3.Connection] = None) -> Dict[str, Any]:
    p = _norm(path)
    ts = _tags(tags)
    errors = validate_tags(ts, evidence_note)
    if errors:
        return {"ok": False, "path": p, "errors": errors}
    own = con is None
    c = con or conn()
    try:
        if replace:
            c.execute("DELETE FROM node_tags WHERE path=?", (p,))
        for t in ts:
            c.execute("INSERT OR REPLACE INTO node_tags(path,tag,evidence_note) VALUES(?,?,?)", (p, t, evidence_note.strip()))
        if own:
            c.commit()
        return {"ok": True, "path": p, "tags": ts}
    finally:
        if own:
            c.close()


def set_facets(path: str, facets: Sequence[str], *, replace: bool = True, con: Optional[sqlite3.Connection] = None) -> Dict[str, Any]:
    p = _norm(path)
    fs = _tags(facets)
    own = con is None
    c = con or conn()
    try:
        if replace:
            c.execute("DELETE FROM node_facets WHERE path=?", (p,))
        for f in fs:
            c.execute("INSERT OR IGNORE INTO node_facets(path,facet) VALUES(?,?)", (p, f))
        if own:
            c.commit()
        return {"ok": True, "path": p, "facets": fs}
    finally:
        if own:
            c.close()




def validate_entry_semantics(brief: str, tags: Sequence[str], evidence_note: str) -> List[str]:
    """Lightweight anti-degeneration checks. Does not infer semantics."""
    errors: List[str] = []
    b = str(brief or "").strip().lower()
    e = str(evidence_note or "").strip().lower()
    generic_briefs = {
        "python project", "python项目", "web project", "unity project", "documents",
        "documentation", "dataset", "generic directory", "directory", "folder",
        "project", "misc", "general", "archive", "data"
    }
    if b in generic_briefs:
        errors.append("generic brief without specific evidence")
    if re.fullmatch(r"(files?|exts?|extensions?)\s*[:：].*", e):
        errors.append("evidence_note only lists file types/extensions")
    if any(x in e for x in ["generic directory", "too few items", "children_count", "file_count", "located under pythonproject", "位于pythonproject", "路径包含", "名称表明"]):
        errors.append("path/count-only evidence_note is not sufficient")
    if tags and len(e) < 12:
        errors.append("evidence_note too short for tagged entry")
    return errors

def annotate_entry(path: str, brief: str, tags: Sequence[str], evidence_note: str, *, tier: str = "warm", facets: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    errors = []
    if not brief.strip():
        errors.append("brief required")
    if not tags:
        errors.append("at least one route tag required for entry")
    errors += validate_tags(tags, evidence_note)
    errors += validate_entry_semantics(brief, tags, evidence_note)
    if errors:
        return {"ok": False, "path": _norm(path), "errors": errors}
    c = conn()
    try:
        upsert_node(path, node_type="dir" if os.path.isdir(path) else None, role="entry", tier=tier, brief=brief, evidence_note=evidence_note, con=c)
        tr = set_tags(path, tags, evidence_note, replace=True, con=c)
        if not tr.get("ok"):
            c.rollback(); return tr
        if facets:
            set_facets(path, facets, replace=True, con=c)
        log_event("annotate_entry", {"path": _norm(path), "tags": list(tags), "tier": tier}, con=c)
        c.commit()
        rb = rebalance_tiers()
        return {"ok": True, "path": _norm(path), "tier": tier, "tags": _tags(tags), "rebalance": rb}
    finally:
        c.close()


def annotate_leaf(path: str, brief: str = "", *, parent_entry: Optional[str] = None, evidence_note: str = "", tier: str = "cold") -> Dict[str, Any]:
    r = upsert_node(path, role="leaf", tier=tier, brief=brief, evidence_note=evidence_note, parent_entry=parent_entry)
    if r.get("ok"):
        r["rebalance"] = rebalance_tiers()
    return r


def attach_leaf(entry_path: str, leaf_path: str, note: str = "") -> Dict[str, Any]:
    ep = _norm(entry_path)
    lp = _norm(leaf_path)
    return annotate_leaf(lp, brief=note, evidence_note=note, parent_entry=ep, tier="cold")


def apply_index_plan(plan: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Apply Agent-authored index plan.

    This function never invents semantic tags. It treats skip/defer as first-class
    outcomes instead of rejected errors so cold-start state can advance without
    loops.
    """
    applied: List[Dict[str, Any]] = []
    skipped: List[Dict[str, Any]] = []
    deferred: List[Dict[str, Any]] = []
    rejected: List[Dict[str, Any]] = []
    for item in plan or []:
        action = str(item.get("action") or "apply").lower()
        path = item.get("path")
        if action == "skip":
            skipped.append({"path": _norm(str(path)) if path else None, "reason": item.get("reason") or "skip"})
            continue
        if action in ("defer", "need_more_evidence", "needs_more_evidence"):
            deferred.append({"path": _norm(str(path)) if path else None, "reason": item.get("reason") or "need_more_evidence"})
            continue
        if not path:
            rejected.append({"item": item, "reason": "missing path"})
            continue
        role = str(item.get("role") or item.get("relation", {}).get("role") or "entry")
        tier = str(item.get("tier") or "warm")
        brief = str(item.get("brief") or "")
        evidence_note = str(item.get("evidence_note") or item.get("evidence") or "")
        if isinstance(item.get("evidence"), list):
            evidence_note = "; ".join(str(x) for x in item.get("evidence"))
        facets = item.get("facets") or item.get("relation", {}).get("facets") or []
        tags = item.get("tags") or item.get("route_tags") or []
        if role == "leaf":
            r = upsert_node(path, role="leaf", tier=tier if tier in ("active","warm","cold") else "cold", brief=brief, evidence_note=evidence_note, parent_entry=item.get("parent_entry"))
        else:
            r = annotate_entry(path, brief, tags, evidence_note, tier=tier, facets=facets)
        if r.get("ok"):
            applied.append(r)
            leaf_paths = item.get("leaf_paths") or item.get("leaf_candidates") or []
            cap = int(load_index_policy().get("leaf_cap_per_entry", 8) or 8)
            for lp in leaf_paths[:cap]:
                if isinstance(lp, dict):
                    lp = lp.get("path")
                if lp:
                    upsert_node(str(lp), role="leaf", tier="cold", brief=f"leaf attached by Agent plan for {path}", evidence_note=f"leaf attached by Agent plan for {path}", parent_entry=str(path))
        else:
            rejected.append({"path": _norm(str(path)), "errors": r.get("errors") or r})
    rb = rebalance_tiers()
    return {
        "ok": not rejected,
        "applied": applied,
        "skipped": skipped,
        "deferred": deferred,
        "rejected": rejected,
        "applied_count": len(applied),
        "skipped_count": len(skipped),
        "deferred_count": len(deferred),
        "rejected_count": len(rejected),
        "rebalance": rb,
    }

def node(path: str) -> Optional[Dict[str, Any]]:
    p = _norm(path)
    c = conn()
    try:
        r = c.execute("SELECT * FROM nodes WHERE path=?", (p,)).fetchone()
        if not r:
            return None
        d = dict(r)
        d["tags"] = [x[0] for x in c.execute("SELECT tag FROM node_tags WHERE path=? ORDER BY tag", (p,)).fetchall()]
        d["facets"] = [x[0] for x in c.execute("SELECT facet FROM node_facets WHERE path=? ORDER BY facet", (p,)).fetchall()]
        return d
    finally:
        c.close()


def is_indexed(path: str) -> bool:
    return node(path) is not None


def _tier_rank(row: sqlite3.Row) -> float:
    last = row["last_used"] or 0
    updated = row["updated_at"] or 0
    hit = int(row["hit_count"] or 0)
    role_bonus = 100000 if row["role"] == "entry" else 0
    tag_bonus = 50000 if row["tag_count"] else 0
    alias_bonus = 25000 if row["alias_count"] else 0
    return role_bonus + tag_bonus + alias_bonus + hit * 1000 + max(last, updated)


def rebalance_tiers(*, max_active: Optional[int] = None, max_warm: Optional[int] = None, max_nodes: Optional[int] = None) -> Dict[str, Any]:
    """Enforce active/warm caps and simple TTL decay. No background watcher needed."""
    p = load_index_policy()
    max_active = int(max_active if max_active is not None else p.get("max_active", 80))
    max_warm = int(max_warm if max_warm is not None else p.get("max_warm", 420))
    max_nodes = int(max_nodes if max_nodes is not None else p.get("max_nodes", p.get("target_nodes", 1000)))
    active_ttl = float(p.get("active_ttl_days", 30) or 30) * 86400.0
    warm_ttl = float(p.get("warm_ttl_days", 180) or 180) * 86400.0
    now = _now()
    demoted_active_ttl = demoted_warm_ttl = overflow_active = overflow_warm = deleted_cold = 0
    c = conn()
    try:
        # TTL decay: active -> warm, warm -> cold if low-use and stale.
        for r in c.execute("SELECT path,last_used,updated_at,hit_count FROM nodes WHERE tier='active'").fetchall():
            last = r["last_used"] or r["updated_at"] or 0
            if active_ttl > 0 and now - float(last) > active_ttl:
                c.execute("UPDATE nodes SET tier='warm',updated_at=? WHERE path=?", (now, r["path"]))
                demoted_active_ttl += 1
        for r in c.execute("SELECT path,last_used,updated_at,hit_count FROM nodes WHERE tier='warm'").fetchall():
            last = r["last_used"] or r["updated_at"] or 0
            if warm_ttl > 0 and now - float(last) > warm_ttl and int(r["hit_count"] or 0) <= 1:
                c.execute("UPDATE nodes SET tier='cold',updated_at=? WHERE path=?", (now, r["path"]))
                demoted_warm_ttl += 1
        c.commit()
        def ranked(tier: str) -> List[sqlite3.Row]:
            return c.execute(
                """SELECT n.*, 
                          (SELECT COUNT(*) FROM node_tags t WHERE t.path=n.path) AS tag_count,
                          (SELECT COUNT(*) FROM query_aliases a WHERE a.path=n.path) AS alias_count
                   FROM nodes n WHERE n.tier=?""",
                (tier,),
            ).fetchall()
        active = sorted(ranked("active"), key=_tier_rank, reverse=True)
        for r in active[max_active:]:
            c.execute("UPDATE nodes SET tier='warm',updated_at=? WHERE path=?", (now, r["path"]))
            overflow_active += 1
        c.commit()
        warm = sorted(ranked("warm"), key=_tier_rank, reverse=True)
        for r in warm[max_warm:]:
            c.execute("UPDATE nodes SET tier='cold',updated_at=? WHERE path=?", (now, r["path"]))
            overflow_warm += 1
        c.commit()
        total = c.execute("SELECT COUNT(*) FROM nodes").fetchone()[0]
        if max_nodes > 0 and total > max_nodes:
            excess = int(total - max_nodes)
            cold = sorted(ranked("cold"), key=_tier_rank)  # delete least valuable cold first
            for r in cold[:excess]:
                c.execute("DELETE FROM nodes WHERE path=?", (r["path"],))
                c.execute("DELETE FROM node_tags WHERE path=?", (r["path"],))
                c.execute("DELETE FROM node_facets WHERE path=?", (r["path"],))
                deleted_cold += 1
            c.commit()
        tiers = {r[0]: r[1] for r in c.execute("SELECT tier,COUNT(*) FROM nodes GROUP BY tier").fetchall()}
        log_event("rebalance_tiers", {"demoted_active_ttl": demoted_active_ttl, "demoted_warm_ttl": demoted_warm_ttl, "overflow_active": overflow_active, "overflow_warm": overflow_warm, "deleted_cold": deleted_cold, "tiers": tiers}, con=c)
        c.commit()
        return {"ok": True, "demoted_active_ttl": demoted_active_ttl, "demoted_warm_ttl": demoted_warm_ttl, "overflow_active": overflow_active, "overflow_warm": overflow_warm, "deleted_cold": deleted_cold, "tiers": tiers, "caps": {"max_active": max_active, "max_warm": max_warm, "max_nodes": max_nodes}}
    finally:
        c.close()


def warm_path(path: str, *, con: Optional[sqlite3.Connection] = None) -> bool:
    p = _norm(path)
    own = con is None
    c = con or conn()
    try:
        r = c.execute("SELECT tier,hit_count FROM nodes WHERE path=?", (p,)).fetchone()
        if not r:
            return False
        c.execute("UPDATE nodes SET hit_count=hit_count+1,last_used=?,updated_at=?,tier=? WHERE path=?", (_now(), _now(), "active", p))
        if own:
            c.commit()
        return True
    finally:
        if own:
            c.close()


def add_alias(alias: str, path: str, evidence_note: str = "", *, con: Optional[sqlite3.Connection] = None) -> None:
    a = str(alias or "").strip().lower()
    if not a:
        return
    p = _norm(path)
    own = con is None
    c = con or conn()
    try:
        c.execute("""INSERT INTO query_aliases(alias,path,evidence_note,hit_count,updated_at)
                     VALUES(?,?,?,?,?)
                     ON CONFLICT(alias) DO UPDATE SET path=excluded.path,evidence_note=excluded.evidence_note,hit_count=query_aliases.hit_count+1,updated_at=excluded.updated_at""", (a, p, evidence_note, 1, _now()))
        if own:
            c.commit()
    finally:
        if own:
            c.close()


def alias_lookup(query: str) -> Optional[Dict[str, Any]]:
    q = str(query or "").strip().lower()
    if not q:
        return None
    c = conn()
    try:
        r = c.execute("SELECT * FROM query_aliases WHERE alias=?", (q,)).fetchone()
        if not r:
            return None
        warm_path(r["path"], con=c)
        c.execute("UPDATE query_aliases SET hit_count=hit_count+1,updated_at=? WHERE alias=?", (_now(), q))
        c.commit()
        rebalance_tiers()
        return dict(r)
    finally:
        c.close()


def _terms(query: str) -> List[str]:
    raw = re.split(r"[\s,;，；/\\]+", str(query or "").lower())
    terms: List[str] = []
    for x in raw:
        x = x.strip()
        if x:
            terms.append(x)
            terms.extend([p for p in re.split(r"[-_]+", x) if p and p != x])
    return list(dict.fromkeys(terms))


def _text_tokens(text: str) -> set[str]:
    return set(x for x in re.split(r"[^a-z0-9\u4e00-\u9fff]+", str(text or "").lower()) if x)


def _term_hit(term: str, text: str, tokens: set[str]) -> bool:
    # Short English terms such as ai/ml/os must be exact token matches; substring
    # matching would make "ai" match "containerization" or unrelated text.
    if re.fullmatch(r"[a-z0-9]{1,2}", term):
        return term in tokens
    # Chinese and longer English terms can use substring for recall.
    return term in text



def _norm_query_value(query: str) -> str:
    return re.sub(r"\s+", " ", str(query or "").strip().lower())


def _negative_paths_for_query(query: str, con: Optional[sqlite3.Connection] = None) -> Dict[str, str]:
    """Return exact-query negative paths from correction/not_relevant events.

    Conservative by design: only exact normalized query matches suppress recall.
    This ensures explicit user feedback reduces repeated false positives without
    adding semantic query expansion or hidden classification rules.
    """
    q = _norm_query_value(query)
    if not q:
        return {}
    own = con is None
    c = con or conn()
    negatives: Dict[str, str] = {}
    try:
        rows = c.execute(
            "SELECT event_type,payload_json FROM events WHERE event_type IN ('not_relevant','negative_evidence','correction') ORDER BY created_at DESC"
        ).fetchall()
        for r in rows:
            try:
                payload = json.loads(r["payload_json"] or "{}")
            except Exception:
                continue
            pq = _norm_query_value(payload.get("query") or "")
            if pq != q:
                continue
            et = r["event_type"]
            if et in ("not_relevant", "negative_evidence"):
                pth = payload.get("path")
                if pth:
                    negatives[_norm(str(pth))] = str(payload.get("reason") or payload.get("evidence_note") or et)
            elif et == "correction":
                for pth in payload.get("wrong_paths") or []:
                    if pth:
                        negatives[_norm(str(pth))] = str(payload.get("note") or "correction wrong_path")
        return negatives
    finally:
        if own:
            c.close()

def recall(query: str, limit: int = 20, include_cold: bool = False) -> List[Dict[str, Any]]:
    ts = _terms(query)
    if not ts:
        return []
    c = conn()
    try:
        negatives = _negative_paths_for_query(query, con=c)
        rows = c.execute("""SELECT n.*, group_concat(DISTINCT t.tag) AS tags, group_concat(DISTINCT f.facet) AS facets
                            FROM nodes n
                            LEFT JOIN node_tags t ON n.path=t.path
                            LEFT JOIN node_facets f ON n.path=f.path
                            GROUP BY n.path""").fetchall()
        out: List[Dict[str, Any]] = []
        for r in rows:
            if (r["tier"] == "cold") and not include_cold:
                continue
            if _norm(r["path"]) in negatives:
                continue
            text = " ".join([r["path"] or "", r["brief"] or "", r["evidence_note"] or "", r["tags"] or "", r["facets"] or ""]).lower()
            tokens = _text_tokens(text)
            hits = sum(1 for t in ts if _term_hit(t, text, tokens))
            if hits <= 0:
                continue
            tier_boost = {"active": 8, "warm": 4, "cold": 0}.get(r["tier"], 0)
            role_boost = 3 if r["role"] == "entry" else 0
            score = hits * 10 + tier_boost + role_boost + min(int(r["hit_count"] or 0), 10)
            d = dict(r); d["score"] = score; d["tags"] = (r["tags"] or "").split(",") if r["tags"] else []; d["facets"] = (r["facets"] or "").split(",") if r["facets"] else []
            out.append(d)
        out.sort(key=lambda x: (-x["score"], x["path"]))
        return out[: max(1, int(limit))]
    finally:
        c.close()

def begin_file_task(query: str = "") -> Dict[str, Any]:
    task_id = "ft_" + uuid.uuid4().hex[:12]
    c = conn()
    try:
        t = _now()
        c.execute("INSERT INTO task_ledger(task_id,query,created_at,updated_at) VALUES(?,?,?,?)", (task_id, str(query or ""), t, t))
        c.commit()
        return {"ok": True, "task_id": task_id, "query": query}
    finally:
        c.close()


def _json(v: Any) -> str:
    return json.dumps(v, ensure_ascii=False)


def record_task_hits(task_id: str, *, semantic_hits: Optional[Sequence[Any]] = None, filesystem_hits: Optional[Sequence[Any]] = None, fallback_used: bool = False, dirty: Optional[bool] = None) -> None:
    c = conn()
    try:
        row = c.execute("SELECT * FROM task_ledger WHERE task_id=?", (task_id,)).fetchone()
        if not row:
            return
        sem = semantic_hits if semantic_hits is not None else json.loads(row["semantic_hits_json"] or "[]")
        fs = filesystem_hits if filesystem_hits is not None else json.loads(row["filesystem_hits_json"] or "[]")
        d = bool(dirty) if dirty is not None else bool(row["dirty"] or fallback_used)
        c.execute("UPDATE task_ledger SET semantic_hits_json=?,filesystem_hits_json=?,fallback_used=?,dirty=?,updated_at=? WHERE task_id=?", (_json(sem), _json(fs), int(bool(row["fallback_used"]) or fallback_used), int(d), _now(), task_id))
        c.commit()
    finally:
        c.close()


def draft_update_plan(query: str = "", *, found_paths: Optional[Sequence[str]] = None, used_paths: Optional[Sequence[str]] = None, rejected_paths: Optional[Sequence[str]] = None, evidence_note: str = "") -> Dict[str, Any]:
    found = [_norm(p) for p in (found_paths or []) if p]
    used = [_norm(p) for p in (used_paths or []) if p]
    rejected = [_norm(p) for p in (rejected_paths or []) if p]
    actions: List[Dict[str, Any]] = []
    for p in list(dict.fromkeys(used + found)):
        if not is_indexed(p):
            actions.append({"action": "add_leaf", "path": p, "tier": "cold", "brief": "task-discovered path; Agent may annotate later", "evidence_note": evidence_note or "draft_update_plan discovered path"})
        if p in used and query:
            actions.append({"action": "alias", "alias": query, "path": p, "evidence_note": evidence_note or "query used this path"})
    for p in rejected:
        actions.append({"action": "negative", "query": query, "path": p, "evidence_note": evidence_note or "rejected during task"})
    plan = {"query": query, "found_paths": found, "used_paths": used, "rejected_paths": rejected, "actions": actions}
    plan_id = "up_" + uuid.uuid4().hex[:12]
    c = conn()
    try:
        t = _now()
        c.execute("INSERT INTO update_plans(plan_id,status,query,draft_json,created_at,updated_at) VALUES(?,?,?,?,?,?)", (plan_id, "draft", query or "", _json(plan), t, t))
        c.commit()
        return {"ok": True, "plan_id": plan_id, "status": "draft", "plan": plan}
    finally:
        c.close()


def apply_update_plan(plan_id: str) -> Dict[str, Any]:
    c = conn()
    applied: List[Dict[str, Any]] = []
    try:
        r = c.execute("SELECT * FROM update_plans WHERE plan_id=?", (plan_id,)).fetchone()
        if not r:
            return {"ok": False, "error": "plan not found", "plan_id": plan_id}
        if r["status"] != "draft":
            return {"ok": False, "error": f"plan is {r['status']}", "plan_id": plan_id}
        plan = json.loads(r["draft_json"])
        for a in plan.get("actions", []):
            if a.get("action") == "add_leaf":
                upsert_node(a["path"], role="leaf", tier=a.get("tier") or "cold", brief=a.get("brief") or "", evidence_note=a.get("evidence_note") or "", con=c)
                applied.append(a)
            elif a.get("action") == "alias" and a.get("alias") and a.get("path"):
                add_alias(a["alias"], a["path"], a.get("evidence_note") or "", con=c)
                applied.append(a)
            elif a.get("action") == "negative":
                log_event("negative_evidence", a, con=c)
                applied.append(a)
        c.execute("UPDATE update_plans SET status='applied',updated_at=? WHERE plan_id=?", (_now(), plan_id))
        c.commit()
    finally:
        c.close()
    rb = rebalance_tiers()
    return {"ok": True, "plan_id": plan_id, "applied": applied, "rebalance": rb}


def list_pending_update_plans(limit: int = 20) -> Dict[str, Any]:
    c = conn()
    try:
        rows = c.execute("SELECT plan_id,query,status,draft_json,created_at FROM update_plans WHERE status='draft' ORDER BY created_at DESC LIMIT ?", (int(limit),)).fetchall()
        return {"ok": True, "plans": [{**dict(r), "plan": json.loads(r["draft_json"])} for r in rows]}
    finally:
        c.close()


def finalize_file_task(task_id: Optional[str] = None, *, query: str = "", used_paths: Optional[Sequence[str]] = None, found_paths: Optional[Sequence[str]] = None, rejected_paths: Optional[Sequence[str]] = None, fallback_used: bool = False, mode: str = "draft") -> Dict[str, Any]:
    used = [_norm(p) for p in (used_paths or []) if p]
    found = [_norm(p) for p in (found_paths or []) if p]
    rejected = [_norm(p) for p in (rejected_paths or []) if p]
    warmed: List[str] = []
    for p in used:
        if warm_path(p):
            warmed.append(p)
            if query:
                add_alias(query, p, "finalize_file_task used path")
    external = [p for p in list(dict.fromkeys(used + found)) if not is_indexed(p)]
    plan_res: Optional[Dict[str, Any]] = None
    if external or rejected or fallback_used:
        plan_res = draft_update_plan(query=query, found_paths=found, used_paths=used, rejected_paths=rejected, evidence_note="finalize_file_task")
        if mode == "apply" and plan_res.get("ok"):
            plan_res = apply_update_plan(plan_res["plan_id"])
    # Query-level negative feedback should be immediately visible to recall/search_index.
    for p in rejected:
        log_event("not_relevant", {"query": query, "path": p, "reason": "finalize_file_task rejected path"})
    if task_id:
        record_task_hits(task_id, filesystem_hits=found, fallback_used=fallback_used, dirty=bool(external or rejected or fallback_used))
        c = conn()
        try:
            c.execute("UPDATE task_ledger SET status='closed',updated_at=? WHERE task_id=?", (_now(), task_id))
            c.commit()
        finally:
            c.close()
    rb = rebalance_tiers()
    event_payload = {
        "task_id": task_id,
        "query": query,
        "used_paths": used,
        "found_paths": found,
        "rejected_paths": rejected,
        "fallback_used": bool(fallback_used),
        "warmed": warmed,
        "external_paths": external,
        "update_plan_id": (plan_res or {}).get("plan_id") if isinstance(plan_res, dict) else None,
        "update_status": (plan_res or {}).get("status") if isinstance(plan_res, dict) else None,
    }
    log_event("task_finalized", event_payload)
    return {"ok": True, "task_id": task_id, "warmed": warmed, "external_paths": external, "update": plan_res or {"ok": True, "status": "noop"}, "rebalance": rb}


def stats() -> Dict[str, Any]:
    c = conn()
    try:
        one = lambda q: c.execute(q).fetchone()[0]
        tiers = {r[0]: r[1] for r in c.execute("SELECT tier,COUNT(*) FROM nodes GROUP BY tier").fetchall()}
        roles = {r[0]: r[1] for r in c.execute("SELECT role,COUNT(*) FROM nodes GROUP BY role").fetchall()}
        return {
            "ok": True,
            "db": db_path(),
            "nodes": one("SELECT COUNT(*) FROM nodes"),
            "entries": roles.get("entry", 0),
            "leaf": roles.get("leaf", 0),
            "tags": one("SELECT COUNT(*) FROM node_tags"),
            "tagged_nodes": one("SELECT COUNT(DISTINCT path) FROM node_tags"),
            "tiers": tiers,
            "roles": roles,
            "aliases": one("SELECT COUNT(*) FROM query_aliases"),
            "pending_update_plans": one("SELECT COUNT(*) FROM update_plans WHERE status='draft'"),
        }
    finally:
        c.close()


def audit_index(fix: bool = False) -> Dict[str, Any]:
    warnings: List[str] = []
    errors: List[str] = []
    c = conn()
    try:
        missing = []
        for r in c.execute("SELECT path FROM nodes").fetchall():
            if not os.path.exists(r["path"]):
                missing.append(r["path"])
        if missing:
            warnings.append(f"missing_paths={len(missing)}")
            if fix:
                for p in missing:
                    c.execute("DELETE FROM nodes WHERE path=?", (p,))
                    c.execute("DELETE FROM node_tags WHERE path=?", (p,))
                    c.execute("DELETE FROM node_facets WHERE path=?", (p,))
        generic = _generic_tags()
        bad_tags = [dict(r) for r in c.execute("SELECT path,tag FROM node_tags").fetchall() if r["tag"] in generic]
        if bad_tags:
            errors.append(f"generic_route_tags={len(bad_tags)}")
        leaf_parent_missing = []
        for r in c.execute("SELECT path,parent_entry FROM nodes WHERE role='leaf' AND parent_entry IS NOT NULL").fetchall():
            if not c.execute("SELECT 1 FROM nodes WHERE path=?", (r["parent_entry"],)).fetchone():
                leaf_parent_missing.append(dict(r))
        if leaf_parent_missing:
            warnings.append(f"leaf_parent_missing={len(leaf_parent_missing)}")
        if fix:
            c.commit()
        s = stats()
        p = load_index_policy()
        if int(s["tiers"].get("active", 0)) > int(p.get("max_active", 80) or 80):
            errors.append("active_count_exceeds_cap")
        if int(s["tiers"].get("warm", 0)) > int(p.get("max_warm", 420) or 420):
            errors.append("warm_count_exceeds_cap")
        return {"ok": not errors, "errors": errors, "warnings": warnings, "stats": s, "total_nodes": s.get("nodes", 0), "tiers": s.get("tiers", {}), "total_tags": s.get("tags", 0), "missing_paths_sample": missing[:20], "bad_tags_sample": bad_tags[:20], "leaf_parent_missing_sample": leaf_parent_missing[:20]}
    finally:
        c.close()


def virtual_tree(limit: int = 20) -> Dict[str, Any]:
    c = conn()
    try:
        hot = [dict(r) for r in c.execute("SELECT path,brief,tier,role FROM nodes WHERE tier='active' ORDER BY last_used DESC LIMIT ?", (limit,)).fetchall()]
        tags = [dict(r) for r in c.execute("SELECT tag,COUNT(*) AS n FROM node_tags GROUP BY tag ORDER BY n DESC, tag LIMIT ?", (limit,)).fetchall()]
        facets = [dict(r) for r in c.execute("SELECT facet,COUNT(*) AS n FROM node_facets GROUP BY facet ORDER BY n DESC, facet LIMIT ?", (limit,)).fetchall()]
        entries = [dict(r) for r in c.execute("SELECT path,brief,tier FROM nodes WHERE role='entry' ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()]
        return {"ok": True, "views": {"hot": hot, "recent_entries": entries, "top_route_tags": tags, "top_facets": facets}}
    finally:
        c.close()


def get_node(path: str) -> Optional[Dict[str, Any]]:
    return node(path)


def list_nodes(*, role: Optional[str] = None, tier: Optional[str] = None, tag: Optional[str] = None, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
    where: List[str] = []
    args: List[Any] = []
    join = ""
    if role:
        where.append("n.role=?")
        args.append(role)
    if tier:
        where.append("n.tier=?")
        args.append(tier)
    if tag:
        join = "JOIN node_tags tt ON tt.path=n.path"
        where.append("tt.tag=?")
        args.append(tag)
    wh = ("WHERE " + " AND ".join(where)) if where else ""
    lim = max(1, min(int(limit), 500))
    off = max(0, int(offset))
    q = f"""SELECT n.path,n.node_type,n.role,n.tier,n.brief,n.parent_entry,n.hit_count,n.last_used,n.updated_at
             FROM nodes n {join} {wh}
             ORDER BY CASE n.tier WHEN 'active' THEN 0 WHEN 'warm' THEN 1 ELSE 2 END, n.updated_at DESC
             LIMIT ? OFFSET ?"""
    c = conn()
    try:
        rows = [dict(r) for r in c.execute(q, args + [lim, off]).fetchall()]
        for r in rows:
            r["tags"] = [x[0] for x in c.execute("SELECT tag FROM node_tags WHERE path=? ORDER BY tag", (r["path"],)).fetchall()]
        return {"ok": True, "nodes": rows, "limit": lim, "offset": off, "filters": {"role": role, "tier": tier, "tag": tag}}
    finally:
        c.close()



def search_index(query: str = "", *, tags_any: Optional[Sequence[str]] = None, tags_all: Optional[Sequence[str]] = None, role: Optional[str] = "entry", tier: Optional[str] = None, include_cold: bool = False, limit: int = 50) -> Dict[str, Any]:
    """Structured DB search for Agent use. Avoid raw SQL/importing store internals.

    Stable return: {ok, query, hits, count, filters}.
    `query` is matched against path/brief/evidence/tags. `tags_any` / `tags_all`
    are exact normalized tag filters. This function is intentionally a DB wrapper,
    not a semantic detector.
    """
    lim = max(1, min(int(limit), 500))
    tags_any_norm = set(_tags(tags_any or []))
    tags_all_norm = set(_tags(tags_all or []))

    if str(query or "").strip():
        base = recall(query, limit=max(200, lim * 4), include_cold=include_cold)
    else:
        res = list_nodes(role=role, tier=tier, limit=max(200, lim * 4))
        base = res.get("nodes", [])

    out: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for n in base or []:
        if not isinstance(n, dict):
            continue
        path = n.get("path")
        if not path or path in seen:
            continue
        if role and n.get("role") != role:
            continue
        if tier and n.get("tier") != tier:
            continue
        if not include_cold and n.get("tier") == "cold":
            continue
        node_tags = set(_tags(n.get("tags") or []))
        if tags_any_norm and not (node_tags & tags_any_norm):
            continue
        if tags_all_norm and not tags_all_norm.issubset(node_tags):
            continue
        seen.add(path)
        out.append(n)
        if len(out) >= lim:
            break
    return {"ok": True, "query": query, "hits": out, "count": len(out), "filters": {"tags_any": sorted(tags_any_norm), "tags_all": sorted(tags_all_norm), "role": role, "tier": tier, "include_cold": include_cold}}


def nodes_by_tag(tag: str, *, role: Optional[str] = "entry", limit: int = 100) -> Dict[str, Any]:
    return search_index("", tags_any=[tag], role=role, limit=limit)

def list_entries(limit: int = 50, offset: int = 0, tag: Optional[str] = None) -> Dict[str, Any]:
    return list_nodes(role="entry", tag=tag, limit=limit, offset=offset)


def list_leaf(entry_path: Optional[str] = None, limit: int = 100) -> Dict[str, Any]:
    c = conn()
    try:
        lim = max(1, min(int(limit), 1000))
        if entry_path:
            p = _norm(entry_path)
            rows = [dict(r) for r in c.execute("SELECT path,brief,tier,parent_entry,updated_at FROM nodes WHERE role='leaf' AND parent_entry=? ORDER BY updated_at DESC LIMIT ?", (p, lim)).fetchall()]
        else:
            rows = [dict(r) for r in c.execute("SELECT path,brief,tier,parent_entry,updated_at FROM nodes WHERE role='leaf' ORDER BY updated_at DESC LIMIT ?", (lim,)).fetchall()]
        return {"ok": True, "leaf": rows, "entry_path": _norm(entry_path) if entry_path else None}
    finally:
        c.close()


def top_tags(limit: int = 50) -> Dict[str, Any]:
    c = conn()
    try:
        rows = [dict(r) for r in c.execute("SELECT tag,COUNT(*) AS count FROM node_tags GROUP BY tag ORDER BY count DESC, tag LIMIT ?", (max(1, min(int(limit), 200)),)).fetchall()]
        return {"ok": True, "tags": rows}
    finally:
        c.close()


def index_summary() -> Dict[str, Any]:
    return {"stats": stats(), "top_tags": top_tags(20), "entries": list_entries(20), "tree": virtual_tree(10)}
