# v30 smoke test notes

- `from file_index_sop import *` exports `next_review_candidate`, `next_needs_more_candidate`, `review_candidate`, `review_more_evidence`, `commit_review`.
- `apply_index_plan(..., session_id=sid)` rejects all cold-start apply actions, including one item at a time.
- `next_review_candidate()` defaults to pending candidates only; `needs_more_evidence` is handled by `next_needs_more_candidate()` / `review_more_evidence()`.
- `commit_review()` requires route-supporting evidence refs for route tags; diagnostic/file-mix refs alone are rejected.
- `finish_cold_start()` is session-scoped and returns `incomplete` when pending/deferred/needs-more evidence remains unless explicitly allowed.
- `audit_cold_start_protocol()` checks review coverage, classifier evidence, leaf ratio, template repetition, tag concentration, and rapid scripted review commits.
