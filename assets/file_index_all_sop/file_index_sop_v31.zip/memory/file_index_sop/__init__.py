"""file_index_sop v31.

Stable public surface for Agent use. Prefer:
    from file_index_sop import *

Runtime SOP and cold-start SOP are separate. The package provides a lightweight
Everything substrate, an Agent-authored SQLite overlay, runtime after-effect
tracking, and a cold-start session scaffold. It does not auto-generate semantic
route tags.
"""
from .helper import *  # noqa: F401,F403

__version__ = "31.0"
