# 文件语义索引 Skill（v13-clean）

本文件只写给 Agent 执行。设计解释放在 `file_index_design.md`。

## 0. 边界

- 使用 Everything / `es.exe` 做全量事实检索。
- 本索引只维护约 1000 条高价值语义节点：`active / warm / cold` + `entry / leaf` + `brief / route_tags / facets`。
- 不后台 watcher，不 hook `file_read` / `file_write`，不接管文件操作。
- 不引入向量库，不把缓存、日志、构建产物、软件自动目录写入主索引。
- route tag 必须有证据，不允许从路径名或项目名直接猜。

## 1. import 与初始化

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop import *

print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

## 2. 模式选择

用户要求“给某盘建索引”：执行 **冷启动建库模式**。

用户要求找、读、总结、整理、移动、重命名本地文件：执行 **运行时文件任务模式**。

运行时检索没有命中，但 Agent 通过 Everything、列目录、读取文件找到了结果：执行 **未命中更新计划模式**。

## 3. 冷启动建库模式

### 3.1 创建 session

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=80,
    scope=r"F:\\",
    memory_text="可用的简短上下文；没有就留空",
    agent_queries=[],  # 只放用户本轮明确给出的搜索提示；不要写死历史 case
)
print_json(res)
session_id = res["session_id"]
```

### 3.2 分批收集候选

```python
while True:
    status = cold_start_status(session_id)
    if status.get("pending", 0) >= 40 or status.get("collection_done"):
        break
    print_json(collect_cold_start_entries(
        session_id,
        max_queries=6,
        limit_per_query=100,
        recent_limit=1000,
        max_entries=100,
        time_budget_sec=30,
    ))
```

候选收集由多流完成：recent、文档/config、项目 marker、材料根、用户显式 query。文档/config 会加权，但不是全量文档扫描。

### 3.3 自动生成并应用 draft plan

禁止手写批量 `if/elif` 标注。使用系统 draft：

```python
while True:
    status = cold_start_status(session_id)
    if status.get("pending", 0) <= 0:
        if status.get("remaining_nodes", 1) <= 0 or status.get("collection_done"):
            break
        print_json(collect_cold_start_entries(session_id, max_queries=6, limit_per_query=100, recent_limit=1000, max_entries=100, time_budget_sec=30))
        continue

    draft = propose_index_plan(session_id, batch_size=30)
    print_json(draft)
    print_json(apply_index_plan(draft["plan"], session_id=session_id))
```

也可以用：

```python
print_json(auto_apply_index_plan(session_id, batch_size=30))
```

但如果 diagnostics 显示大量 `insufficient-route-evidence`，继续 collect，不要手写模板 tag。

### 3.4 完成与验收

```python
print_json(finish_cold_start(session_id, max_nodes=1000, max_active=80, max_warm=420))
print_json(audit_index(fix=False))
print_json(stats())
print_json(virtual_tree(limit_per_group=10))
```

合格结构：

- 总节点接近 1000；`active + warm <= 500`。
- active 小；warm 是冷启动主体；cold 是支撑 leaf / 弱证据候选。
- entry 是语义入口，leaf 是支撑文件。
- active/warm entry 有 brief 和 route tags。
- route tag 不能高频出现 `archive / materials / project / folder / workspace` 等分类词。
- audit 的 missing、ignored、bad tag、generic brief 接近 0。

## 4. 运行时文件任务模式

### 4.1 建议开始任务 ledger

```python
task = begin_file_task("用户原始问题", intent="可选意图", scope=None)
```

### 4.2 定位

优先使用：

```python
res = locate("用户语义意图", limit=10)
print_json(res)
```

`locate()` 会查 query alias、recall active/warm、识别 anchor/intent、生成事实查询变体、在 entry scope 内搜索、再 fallback 到 Everything。

低层使用方式：

```python
hits = recall("用户语义意图", limit=8)
# 若命中 dir entry，用 Everything 在 scope 内找事实文件
files = search_files("事实词，如 invoice receipt final config ssh", scope=hits[0]["path"], limit=20)
```

Agent 正常执行 `file_read`、列目录、移动、重命名、写文件等操作；本 Skill 不接管这些工具。

## 5. 未命中更新计划模式

只要任务中出现以下任一情况，就生成 update plan：

- 语义索引没有直接命中，但 fallback 找到了结果。
- 找到了索引外的高价值文件或目录。
- 用户指出之前结果错了，并给出正确路径或线索。
- 执行了创建、修改、移动、删除文件。
- 搜索中出现明显噪声路径。

默认先 draft，不直接改主索引：

```python
plan = commit_file_task(
    task_id=task.get("task_id") if "task" in locals() else None,
    query="用户原始问题",
    outcome="success",
    found_paths=[...],
    used_paths=[...],
    rejected_paths=[...],
    fallback_used=True,
    intent="可选意图",
    mode="draft",
)
print_json(plan)
```

确认这些路径确实是最终结果后再应用：

```python
print_json(apply_update_plan(plan["draft"]["plan_id"]))
```

如果路径已经由用户确认、且是本次最终使用/修改/创建的文件，可以直接：

```python
print_json(commit_file_task(
    query="用户原始问题",
    found_paths=[...],
    used_paths=[...],
    fallback_used=True,
    intent="可选意图",
    mode="apply",
))
```

查看未应用计划：

```python
print_json(list_pending_update_plans(limit=20))
```

## 6. route tag 与 facet

- `node_tags` 存 route tags，参与 recall。
- `node_facets` 存组织信息，用于虚拟目录树。
- `tier` 和 `role` 也视为特殊 facet。

route tag 必须由证据支持。证据可以来自：README、requirements、package/manifest、配置文件 head、文档 head、同级文件簇、用户任务确认、query alias。

如果只有路径名，没有证据：写 facet 或跳过，不写 route tag。

例子：

```text
requirements / README 出现 diffusers / checkpoint / ControlNet
→ image-generation, diffusion-model-ui

manifest / package 出现 com.unity.ml-agents
→ reinforcement-learning, unity-ml-agents

文件簇包含 invoice / receipt / bill / 发票 / 收据
→ reimbursement-records, software-subscription-billing

文档 head 或文件簇出现 thesis / final / 定稿 / 答辩
→ thesis-final-materials, thesis-writing

文档或配置出现 ssh / HostName / IdentityFile / 服务器
→ runtime-environment, local-tools-config
```

避免：

```text
project, folder, file, materials, archive, workspace, python-project, unity-project,
readme, markdown, json, config, result, test, notes
```

## 7. 虚拟目录树

虚拟目录树只组织 tag/facet/tier/role，不模拟真实目录。

```python
print_json(virtual_tree(limit_per_group=12))
print_json(list_virtual_roots())
print_json(list_entries_by_facet("billing-records", limit=20))
print_json(list_by_tag("runtime-environment", limit=20))
```

## 8. 低层维护入口

优先使用 update plan。低层函数仅在明确需要时使用：

```python
mark_used(path)
report_file_deleted(path, reason="file_read_failed 或用户删除")
report_file_changed(path, note="agent edited")
report_file_moved(old_path, new_path)
report_file_created(path, brief="...", tags=["..."], tier="warm")
```

不要在 `file_read` 前额外做存在性检查；文件操作成功/失败后再同步索引。
