"""
Thin Everything CLI wrapper.

This module deliberately does not sniff, patch memory, or start Everything.
Environment preparation belongs to ensure_es.py. This wrapper only executes an
already configured es.exe and returns structured rows.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
from typing import Any, Dict, List, Optional, Sequence

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
_GLOBAL_MEM = os.path.join(_REPO_ROOT, "memory", "global_mem.txt")


def _default_encoding() -> str:
    return "mbcs" if os.name == "nt" else "utf-8"


def resolve_es_exe() -> Optional[str]:
    """Resolve configured es.exe only: env -> memory/global_mem LOCAL_TOOLS."""
    for key in ("EVERYTHING_ES_EXE", "GA_ES_EXE"):
        v = (os.environ.get(key) or "").strip().strip('"').strip("'")
        if v and os.path.isfile(v):
            return os.path.normpath(os.path.abspath(v))
    if not os.path.isfile(_GLOBAL_MEM):
        return None
    try:
        raw = open(_GLOBAL_MEM, encoding="utf-8", errors="replace").read()
    except OSError:
        return None
    in_lt = False
    for line in raw.splitlines():
        st = line.strip()
        if re.match(r"^##\s*\[LOCAL_TOOLS\]\s*$", st, re.I):
            in_lt = True
            continue
        if in_lt and re.match(r"^##\s*\[", st):
            break
        if in_lt:
            m = re.match(r"^\s*es\.exe\s*=\s*(.+)$", line, re.I)
            if m:
                cand = m.group(1).strip().strip('"').strip("'")
                if cand and os.path.isfile(cand):
                    return os.path.normpath(os.path.abspath(cand))
    return None


def _path_arg(scope: str) -> str:
    s = os.path.normpath(os.path.abspath(scope))
    if len(s) == 2 and s[1] == ":":
        return s + "\\"
    return s


def _run(argv: Sequence[str], *, timeout: float = 90.0) -> subprocess.CompletedProcess[str]:
    enc = (os.environ.get("FILE_INDEX_ES_STDOUT_ENCODING") or "").strip() or _default_encoding()
    kwargs: Dict[str, Any] = {
        "args": list(argv),
        "capture_output": True,
        "text": True,
        "encoding": enc,
        "errors": "replace",
        "timeout": float(timeout),
    }
    if os.name == "nt":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return subprocess.run(**kwargs)


def raw_search(query: str, *, limit: int = 50, scope: Optional[str] = None, extra_args: Optional[Sequence[str]] = None,
               timeout: float = 90.0) -> List[str]:
    exe = resolve_es_exe()
    if not exe:
        raise FileNotFoundError("es.exe not configured. Run: python memory/file_index_sop/ensure_es.py --start")
    q = (query or "").strip()
    if not q:
        raise ValueError("Everything query is empty")
    limit = max(1, min(int(limit), 50000))
    argv: List[str] = [exe, "-n", str(limit)]
    if extra_args:
        argv.extend(list(extra_args))
    if scope:
        argv.extend(["-path", _path_arg(scope)])
    argv.append(q)
    r = _run(argv, timeout=timeout)
    if r.returncode != 0 and not (r.stdout or "").strip():
        err = (r.stderr or "").strip() or f"exit {r.returncode}"
        hint = ""
        if "ipc" in err.lower() or "everything" in err.lower():
            hint = " — Everything may not be running. Run ensure_es.py --start."
        raise RuntimeError(f"es.exe failed: {err}{hint}")
    return [os.path.normpath(x.strip()) for x in (r.stdout or "").splitlines() if x.strip()]


def _row(path: str) -> Dict[str, Any]:
    p = os.path.normpath(path)
    row: Dict[str, Any] = {"path": p, "basename": os.path.basename(p), "parent": os.path.dirname(p)}
    try:
        st = os.stat(p, follow_symlinks=False)
        row["size"] = int(st.st_size)
        row["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
        row["is_dir"] = os.path.isdir(p)
    except OSError:
        row["is_dir"] = False
    return row


def search(query: str, *, limit: int = 50, scope: Optional[str] = None, timeout: float = 90.0,
           sort_mtime_desc: bool = False) -> List[Dict[str, Any]]:
    """Stable structured es.exe search. Sorting by mtime is done locally after retrieval."""
    paths = raw_search(query, limit=limit, scope=scope, timeout=timeout)
    rows = [_row(p) for p in paths]
    if sort_mtime_desc:
        rows.sort(key=lambda r: int(r.get("mtime_ns") or 0), reverse=True)
    return rows[: max(1, int(limit))]


def recent(*, limit: int = 1000, scope: Optional[str] = None, query: str = "*", timeout: float = 120.0) -> List[Dict[str, Any]]:
    """Best-effort recent files. Try Everything sort flags, then local sort fallback."""
    exe = resolve_es_exe()
    if not exe:
        raise FileNotFoundError("es.exe not configured. Run: python memory/file_index_sop/ensure_es.py --start")
    # Known Everything CLI supports -sort with display names. If this fails, fallback.
    attempts = [
        ["-sort", "Date Modified", "-sort-descending"],
        ["-sort", "date-modified", "-sort-descending"],
        ["-sort", "dm", "-sort-descending"],
        [],
    ]
    last_err: Optional[BaseException] = None
    for extra in attempts:
        try:
            over = max(int(limit), min(int(limit) * 4, 20000)) if not extra else int(limit)
            paths = raw_search(query, limit=over, scope=scope, extra_args=extra, timeout=timeout)
            rows = [_row(p) for p in paths]
            rows.sort(key=lambda r: int(r.get("mtime_ns") or 0), reverse=True)
            return rows[: max(1, int(limit))]
        except BaseException as e:
            last_err = e
            continue
    assert last_err is not None
    raise last_err


def search_error_json(err: BaseException) -> str:
    return json.dumps({"ok": False, "error": str(err), "hint": "python memory/file_index_sop/ensure_es.py --start"}, ensure_ascii=False)
