"""file_index_sop v13-clean: evidence-first semantic file index with two-phase update plans."""
__version__ = "v13-clean"

# Re-export the stable Agent-facing helper API so natural imports work:
#   from file_index_sop import locate, search_files, commit_file_task
try:
    from .helper import *  # noqa: F401,F403
except Exception:
    # Keep package importable even if runtime environment is not ready yet.
    pass
