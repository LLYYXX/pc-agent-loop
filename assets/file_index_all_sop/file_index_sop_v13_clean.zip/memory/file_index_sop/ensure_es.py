#!/usr/bin/env python3
"""
Environment preparation for Everything/es.exe.

This script owns both discovery (sniffing) and optional auto-start. Query code in
everything.py intentionally does not do either.

Usage:
  python memory/file_index_sop/ensure_es.py --dry-run
  python memory/file_index_sop/ensure_es.py --start
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import time
from typing import Dict, Optional, Tuple

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_REPO_ROOT = os.path.abspath(os.path.join(_THIS_DIR, "..", ".."))
_GLOBAL_MEM = os.path.join(_REPO_ROOT, "memory", "global_mem.txt")
_SECTION = "LOCAL_TOOLS"


def _norm(p: str) -> str:
    return os.path.normpath(os.path.abspath(p.strip().strip('"').strip("'")))


def parse_local_tools(content: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    in_lt = False
    for line in content.splitlines():
        st = line.strip()
        if re.match(r"^##\s*\[LOCAL_TOOLS\]\s*$", st, re.I):
            in_lt = True
            continue
        if in_lt and re.match(r"^##\s*\[", st):
            break
        if in_lt:
            m = re.match(r"^\s*([^=]+?)\s*=\s*(.+)$", line)
            if m:
                out[m.group(1).strip()] = m.group(2).strip().strip('"').strip("'")
    return out


def read_global_mem() -> str:
    try:
        return open(_GLOBAL_MEM, encoding="utf-8", errors="replace").read()
    except FileNotFoundError:
        return ""


def discover_es_and_everything() -> Tuple[Optional[str], Optional[str], str]:
    """Return (es.exe, Everything.exe, source)."""
    raw = read_global_mem()
    lt = parse_local_tools(raw)
    for key in ("EVERYTHING_ES_EXE", "GA_ES_EXE"):
        v = (os.environ.get(key) or "").strip()
        if v and os.path.isfile(_norm(v)):
            es = _norm(v)
            ev = _everything_for_es(es)
            return es, ev, f"env:{key}"
    if lt.get("es.exe") and os.path.isfile(_norm(lt["es.exe"])):
        es = _norm(lt["es.exe"])
        return es, _everything_for_es(es), "LOCAL_TOOLS:es.exe"
    w = shutil.which("es.exe")
    if w and os.path.isfile(w):
        es = _norm(w)
        return es, _everything_for_es(es), "PATH"

    if sys.platform == "win32":
        try:
            import winreg
            for hive_name, root in (("HKLM", winreg.HKEY_LOCAL_MACHINE), ("HKCU", winreg.HKEY_CURRENT_USER)):
                for sub in (r"SOFTWARE\voidtools\Everything", r"SOFTWARE\WOW6432Node\voidtools\Everything"):
                    try:
                        with winreg.OpenKey(root, sub) as k:
                            base, _ = winreg.QueryValueEx(k, "InstallLocation")
                        if isinstance(base, str) and base.strip():
                            es = os.path.join(base, "es.exe")
                            ev = os.path.join(base, "Everything.exe")
                            if os.path.isfile(es):
                                return _norm(es), _norm(ev) if os.path.isfile(ev) else None, f"registry:{hive_name}:{sub}"
                    except OSError:
                        continue
        except Exception:
            pass
    for base in _common_dirs():
        es = os.path.join(base, "es.exe")
        ev = os.path.join(base, "Everything.exe")
        if os.path.isfile(es):
            return _norm(es), _norm(ev) if os.path.isfile(ev) else None, "common-path"
    return None, None, "not-found"


def _common_dirs():
    vals = []
    for key in ("ProgramFiles", "ProgramFiles(x86)", "LocalAppData"):
        base = os.environ.get(key) or ""
        if base:
            vals.append(os.path.join(base, "Everything"))
            vals.append(os.path.join(base, "voidtools", "Everything"))
    return vals


def _everything_for_es(es_path: str) -> Optional[str]:
    d = os.path.dirname(es_path)
    for name in ("Everything.exe", "Everything64.exe", "Everything32.exe"):
        cand = os.path.join(d, name)
        if os.path.isfile(cand):
            return _norm(cand)
    return None


def patch_local_tools(es_path: str, everything_path: Optional[str], raw: str) -> str:
    es_path = os.path.normpath(es_path)
    lines = raw.splitlines(keepends=True)
    if not lines:
        lines = ["# Global memory L2\n"]
    head_re = re.compile(r"^##\s*\[([^\]]+)\]\s*$", re.I)
    out = []
    in_lt = False
    found = False
    wrote_es = False
    wrote_ev = False
    insert_at = -1
    i = 0
    while i < len(lines):
        line = lines[i]
        m = head_re.match(line.strip())
        if m and m.group(1).strip().upper() == _SECTION:
            found = True
            in_lt = True
            insert_at = len(out) + 1
            out.append(line)
            i += 1
            continue
        if in_lt and m and m.group(1).strip().upper() != _SECTION:
            if not wrote_es:
                out.insert(insert_at, f"es.exe={es_path}\n"); insert_at += 1
            if everything_path and not wrote_ev:
                out.insert(insert_at, f"Everything.exe={os.path.normpath(everything_path)}\n"); insert_at += 1
            in_lt = False
            out.append(line)
            i += 1
            continue
        if in_lt:
            if re.match(r"^\s*es\.exe\s*=", line, re.I):
                out.append(f"es.exe={es_path}\n"); wrote_es = True
            elif re.match(r"^\s*Everything\.exe\s*=", line, re.I):
                if everything_path:
                    out.append(f"Everything.exe={os.path.normpath(everything_path)}\n"); wrote_ev = True
                else:
                    out.append(line)
            else:
                out.append(line)
        else:
            out.append(line)
        i += 1
    if in_lt:
        if not wrote_es:
            out.insert(insert_at, f"es.exe={es_path}\n"); insert_at += 1
        if everything_path and not wrote_ev:
            out.insert(insert_at, f"Everything.exe={os.path.normpath(everything_path)}\n")
    if not found:
        text = "".join(out).rstrip()
        block = f"\n\n## [{_SECTION}]\nes.exe={es_path}\n"
        if everything_path:
            block += f"Everything.exe={os.path.normpath(everything_path)}\n"
        return (text + block).lstrip("\n")
    return "".join(out)


def _run_es_probe(es_path: str, timeout: float = 8.0) -> Tuple[bool, str]:
    try:
        kwargs = dict(args=[es_path, "-n", "1", "*"], capture_output=True, text=True,
                      encoding="mbcs" if os.name == "nt" else "utf-8", errors="replace", timeout=timeout)
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        r = subprocess.run(**kwargs)
        if r.returncode == 0 or (r.stdout or "").strip():
            return True, "es.exe query OK"
        return False, (r.stderr or "").strip() or f"exit {r.returncode}"
    except Exception as e:
        return False, str(e)


def start_everything(everything_path: Optional[str], es_path: Optional[str], wait_seconds: float = 10.0) -> Tuple[bool, str]:
    ev = everything_path or (_everything_for_es(es_path) if es_path else None)
    if not ev or not os.path.isfile(ev):
        return False, "Everything.exe not found; configure it or start Everything manually"
    try:
        kwargs = dict(args=[ev, "-startup"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen(**kwargs)
    except Exception as e:
        return False, f"failed to start Everything: {e}"
    if es_path:
        deadline = time.time() + wait_seconds
        last = ""
        while time.time() < deadline:
            ok, msg = _run_es_probe(es_path, timeout=3.0)
            if ok:
                return True, "Everything started and es.exe IPC is ready"
            last = msg
            time.sleep(0.7)
        return False, "Everything start attempted but es.exe IPC not ready: " + last
    return True, "Everything start attempted"


def ensure_ready(*, start: bool = True, patch: bool = True, dry_run: bool = False) -> Dict[str, object]:
    es, ev, source = discover_es_and_everything()
    if not es:
        return {"ok": False, "error": "could not locate es.exe", "source": source,
                "hint": "Install voidtools Everything or set EVERYTHING_ES_EXE."}
    raw = read_global_mem()
    new_raw = patch_local_tools(es, ev, raw) if patch else raw
    probe_ok, probe_msg = _run_es_probe(es)
    started = False
    start_msg = ""
    if not probe_ok and start:
        started, start_msg = start_everything(ev, es)
        probe_ok, probe_msg = _run_es_probe(es)
    if patch and not dry_run and new_raw != raw:
        os.makedirs(os.path.dirname(_GLOBAL_MEM), exist_ok=True)
        with open(_GLOBAL_MEM, "w", encoding="utf-8", newline="\n") as f:
            f.write(new_raw)
    return {
        "ok": bool(probe_ok),
        "es_exe": es,
        "everything_exe": ev,
        "source": source,
        "configured": bool(patch),
        "would_write": bool(dry_run and patch and new_raw != raw),
        "started": started,
        "start_message": start_msg,
        "probe": probe_msg,
        "global_mem": _GLOBAL_MEM,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Discover/configure es.exe and optionally start Everything.")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--start", dest="start", action="store_true", default=True, help="start Everything when es IPC is not ready")
    ap.add_argument("--no-start", dest="start", action="store_false")
    ap.add_argument("--no-patch", dest="patch", action="store_false", default=True)
    args = ap.parse_args()
    res = ensure_ready(start=args.start, patch=args.patch, dry_run=args.dry_run)
    import json
    print(json.dumps(res, ensure_ascii=False, indent=2))
    return 0 if res.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
