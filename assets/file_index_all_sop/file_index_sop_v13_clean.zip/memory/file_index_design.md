# 文件语义索引 Skill 设计说明（v13-clean）

本文件给开发者/维护者看，不作为 Agent 执行 SOP。

## 目标

本 Skill 是 Everything / `es.exe` 上的轻量正交语义覆盖层。Everything 负责事实检索；本索引维护少量高价值语义节点，帮助 Agent 快速找到 scope，再在 scope 内精确搜索。

## 核心约束

- 不替代 Everything。
- 不 hook Agent 的 `file_read` / `file_write`。
- 不后台 watcher。
- 不向量库。
- 不为某个用户文件系统、研究项目、测试 case 写硬编码规则。
- 冷启动是 prior；真实任务通过 update plan 沉淀后效性。

## 层级

- active：近期真实任务热集，小容量，强 boost。
- warm：冷启动语义核心层和 active 衰减层，默认 recall 主体。
- cold：支撑 leaf、弱证据候选和长期未用节点。

默认总量约 1000，active + warm 不超过约 500。

## v13-clean 相比 v12

- `propose_index_plan` 去除路径/项目名特判。
- route tag 必须有 evidence refs。
- `commit_file_task` 默认生成 draft update plan，不直接改主索引。
- 新增 `draft_update_plan / apply_update_plan / list_pending_update_plans`。
- Agent-facing SOP 与设计说明分离。

## 后续可调参数

- `max_active`、`max_warm`、`max_nodes`。
- 文档/config discovery quota。
- 每个 entry 的 leaf materialization 数量。
- update plan 自动 apply 的条件。
