# file_index_sop v20 — 运行时 Agent 操作协议

定位：file_index 是 Agent 的 L5 文件语义索引层。Everything/es.exe 负责事实检索；Agent 负责语义判断；SQLite 负责记录和复用。

本文件只描述**运行时文件任务**。冷启动建库请读 `file_index_cold_start_sop.md`。

## 运行时文件任务

适用：用户要找文件、读文件、总结目录、整理/移动/重命名文件，或任何本地文件定位任务。

1. 先调用：

```python
res = recall(query)      # 语义索引优先
# 或
res = locate(query)      # recall 不足时可 fallback 到 search_files
```

2. 若语义命中不足，调用：

```python
search_files(query, scope=None, limit=50)
search_files_detailed(query, scope=scope, limit=50)
path_evidence(path)
```

`search_files` 是薄 es.exe 封装，只做事实检索；不做语义推断。

3. Agent 正常执行文件读取、目录遍历、总结、移动、重命名等任务。

4. 最终回答前调用：

```python
finalize_file_task(
    task_id=res.get("task_id"),
    query=query,
    used_paths=[...],
    found_paths=[...],
    rejected_paths=[...],
    fallback_used=..., 
    mode="draft",
)
```

规则：

- 命中已有索引并实际使用：升温、更新 hit_count/last_used。
- fallback 找到索引外路径：生成 draft update plan。
- 默认不直接污染主库；用户确认或低风险时再 `apply_update_plan(plan_id)`。

## route tag 规则

不是少打 tag，而是打一条对一条。

route tag 必须：

- 描述当前 entry 的主要搜索用途。
- 可作为 recall 入口。
- 有 `evidence_note` 支撑。
- 不来自邻居项目、外部引用、模板示例、依赖或局部弱证据的无条件冒泡。
- 不复读路径，不使用泛词：file/folder/project/document/general/config 等。

## 常用接口

```python
ensure_search_ready(start=True, patch=True)
init_db()
recall(query)
locate(query)
search_files(query, scope=None)
path_evidence(path)
annotate_entry(path, brief, tags, evidence_note)
attach_leaf(entry_path, leaf_path)
apply_index_plan(plan)
finalize_file_task(...)
draft_update_plan(...)
apply_update_plan(plan_id)
stats()
audit_index()
```

## memory 分层

- L1：只保留 file_index_sop 触发词。
- L2：只放 LOCAL_TOOLS/es.exe 等环境事实。
- L3：本目录放 SOP、代码、极简 policy。
- L5：SQLite 存 nodes/tags/aliases/update plans/hit_count。

禁止把索引内容、route tags、冷启动结果写进 L1/L2。
