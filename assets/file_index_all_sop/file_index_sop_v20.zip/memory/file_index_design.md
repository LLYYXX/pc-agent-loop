# file_index_sop v20 design note

v20 restores the earlier split: runtime index usage and cold-start initialization are separate protocols.

- Runtime SOP: `file_index_sop.md`.
- Cold-start SOP: `file_index_cold_start_sop.md`.

The helper is intentionally light. It provides Everything search, path evidence, SQLite overlay storage, hit/fallback after-effects, and cold-start session bookkeeping. It does not auto-generate semantic route tags.
