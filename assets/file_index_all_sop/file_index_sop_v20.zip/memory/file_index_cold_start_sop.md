# file_index_cold_start_sop v20 — 冷启动建库协议

定位：冷启动是 Agent 主导的索引初始化任务。helper 只提供 session、候选、证据、状态、报告；不自动理解全盘、不自动生成 route tag。

运行时文件任务请读 `file_index_sop.md`。

## 原则

- 冷启动目标是建立一批能缩小搜索范围的 entry，而不是把文件批量塞进库。
- 文件/document seed 只作为 entry evidence；不要把大量文档直接刷成主索引。
- Agent 基于 evidence packet 判断 brief/tag；helper 只校验、存储和记录进度。
- `collection_done` 只表示当前候选足够/本轮收集结束，不表示磁盘没有更多高价值内容。
- `finish_cold_start(status="partial")` 时不得向用户报告“已完成”。

## 标准流程

```python
ensure_search_ready(start=True, patch=True)
init_db()

cs = begin_cold_start(scope=r"F:\\", target_nodes=1000)
sid = cs["session_id"]

collect_cold_start_entries(sid, recent_limit=300, limit_per_query=80)

batch = cold_start_batch(sid, batch_size=8)
```

Agent 对 `batch["items"]` 逐个阅读 evidence packet：

- 如果该目录是有用 entry：写 brief/tags/evidence_note。
- 如果不确定：调用 `path_evidence(path)` 补证据，或 skip/defer。
- 不要根据历史 case、外部对话、邻居项目给当前 entry 打 tag。

示例 plan：

```python
plan = [
  {
    "path": "...",
    "role": "entry",
    "tier": "warm",
    "brief": "...",
    "tags": ["..."],
    "evidence_note": "依据 batch item 中的 README/head/children/文件名等证据",
    "leaf_paths": ["...", "..."]
  },
  {"path": "...", "action": "skip"}
]

apply_index_plan(plan, session_id=sid)
```

重复：

```python
collect_cold_start_entries(sid, queries=[...])   # 可选：Agent 自己提出额外探索词
cold_start_batch(sid)
apply_index_plan(..., session_id=sid)
```

最后：

```python
finish_cold_start(sid, min_entries=30, min_tagged_entries=20)
stats()
audit_index()
```

若 finish 返回 `ok=False` 或 `status="partial"`，只能报告“部分索引/初步索引”，不能说完整建成。

## 冷启动时 Agent 应做的判断

优先选择能缩小范围的目录作为 entry：

- 工作区、项目根、材料根、文档集合、课程/论文/账单/配置等有实际搜索价值的范围。
- 不是某个深层依赖目录、缓存目录、随机临时目录。

但不要写特判规则。某目录是否重要，由本次 evidence packet 证明。

## 工具分工

- `collect_cold_start_entries`：收集候选 entry 路径，不打 tag。
- `cold_start_batch`：返回 entry evidence packet。
- `path_evidence`：补充单路径事实。
- `apply_index_plan`：存 Agent 标注结果，并标记 cold-start 进度。
- `finish_cold_start`：诚实报告结构进度。
