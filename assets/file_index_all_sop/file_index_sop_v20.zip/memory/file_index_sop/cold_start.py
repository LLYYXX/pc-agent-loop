"""Lightweight cold-start session helpers for file_index_sop v20.

This module is intentionally *not* an automatic semantic builder. It provides
only a runnable scaffold for Agent-led cold start:

- keep a cold-start session ledger;
- collect factual candidate *entry paths* from top-level dirs, recent files,
  and optional Everything queries;
- return isolated evidence packets for Agent annotation;
- mark applied/skipped candidates after the Agent calls apply_index_plan;
- report structural progress honestly.

Route tags, briefs, and semantic decisions are authored by the Agent.
"""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from typing import Any, Dict, Iterable, List, Optional, Sequence

from . import everything
from .policy import load_index_policy
from .store import conn, stats as index_stats, node


def _now() -> float:
    return time.time()


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _scope_contains(scope: str, path: str) -> bool:
    try:
        s = _norm(scope)
        p = _norm(path)
        return os.path.commonpath([s, p]) == s
    except Exception:
        return False


def _is_ignored(path: str, policy: Optional[Dict[str, Any]] = None) -> bool:
    pol = policy or load_index_policy()
    ignored = set(str(x).lower() for x in pol.get("ignore_dirs", []))
    parts = [x.lower() for x in re.split(r"[\\/]+", _norm(path)) if x]
    return any(part in ignored for part in parts)


def _mtime_ns(path: str) -> int:
    try:
        st = os.stat(path, follow_symlinks=False)
        return int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
    except OSError:
        return 0


def _candidate_type(path: str) -> str:
    if os.path.isdir(path):
        return "dir"
    if os.path.isfile(path):
        return "file"
    return "missing"


def _default_queries() -> List[str]:
    pol = load_index_policy()
    q = pol.get("cold_start_default_queries")
    if isinstance(q, list):
        return [str(x).strip() for x in q if str(x).strip()]
    # Structural, not semantic: these are optional evidence discovery patterns.
    return ["*.md", "*.txt", "*.pdf", "*.docx", "*.pptx", "*.xlsx", "README.md"]


def _parent_entries_for_path(path: str, scope: str, parent_levels: int = 2) -> List[str]:
    """Return candidate entry dirs for a path. No semantic choice is made."""
    p = _norm(path)
    scope = _norm(scope)
    if os.path.isdir(p):
        return [p] if _scope_contains(scope, p) and not _is_ignored(p) else []
    if not os.path.isfile(p):
        return []
    out: List[str] = []
    cur = os.path.dirname(p)
    for _ in range(max(1, int(parent_levels))):
        if not cur or cur == os.path.dirname(cur):
            break
        if _scope_contains(scope, cur) and not _is_ignored(cur):
            out.append(cur)
        cur = os.path.dirname(cur)
    return list(dict.fromkeys(out))


def _ensure_tables() -> None:
    c = conn()
    try:
        c.execute(
            """CREATE TABLE IF NOT EXISTS cold_sessions (
              session_id TEXT PRIMARY KEY,
              scope TEXT NOT NULL,
              target_nodes INTEGER NOT NULL DEFAULT 1000,
              status TEXT NOT NULL DEFAULT 'open',
              collection_done INTEGER NOT NULL DEFAULT 0,
              rounds INTEGER NOT NULL DEFAULT 0,
              created_at REAL NOT NULL,
              updated_at REAL NOT NULL
            )"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS cold_candidates (
              session_id TEXT NOT NULL,
              path TEXT NOT NULL,
              node_type TEXT NOT NULL DEFAULT 'dir',
              status TEXT NOT NULL DEFAULT 'pending',
              priority REAL NOT NULL DEFAULT 0,
              source TEXT NOT NULL DEFAULT '',
              source_paths_json TEXT NOT NULL DEFAULT '[]',
              evidence_json TEXT NOT NULL DEFAULT '{}',
              created_at REAL NOT NULL,
              updated_at REAL NOT NULL,
              PRIMARY KEY(session_id, path)
            )"""
        )
        c.commit()
    finally:
        c.close()


def begin_cold_start(scope: str, *, target_nodes: int = 1000, reset_session: bool = False) -> Dict[str, Any]:
    """Start an Agent-led cold-start session. Does not scan the disk."""
    _ensure_tables()
    sc = _norm(scope)
    sid = "cs_" + uuid.uuid4().hex[:12]
    c = conn()
    try:
        t = _now()
        if reset_session:
            c.execute("DELETE FROM cold_sessions WHERE scope=?", (sc,))
        c.execute(
            "INSERT INTO cold_sessions(session_id,scope,target_nodes,status,created_at,updated_at) VALUES(?,?,?,?,?,?)",
            (sid, sc, int(target_nodes), "open", t, t),
        )
        c.commit()
        return {
            "ok": True,
            "session_id": sid,
            "scope": sc,
            "target_nodes": int(target_nodes),
            "next": "collect_cold_start_entries(session_id), then cold_start_batch(session_id). Agent annotates returned evidence packets and calls apply_index_plan(..., session_id=session_id).",
        }
    finally:
        c.close()


def _session(session_id: str) -> Optional[Dict[str, Any]]:
    _ensure_tables()
    c = conn()
    try:
        r = c.execute("SELECT * FROM cold_sessions WHERE session_id=?", (session_id,)).fetchone()
        return dict(r) if r else None
    finally:
        c.close()


def _upsert_candidate(session_id: str, path: str, *, source: str, source_path: Optional[str] = None, priority: float = 0.0) -> bool:
    s = _session(session_id)
    if not s:
        return False
    p = _norm(path)
    if not _scope_contains(s["scope"], p) or _is_ignored(p):
        return False
    nt = _candidate_type(p)
    # Cold-start entry candidates should be dirs. File paths are evidence, not primary candidates.
    if nt != "dir":
        return False
    t = _now()
    src_paths = [source_path] if source_path else []
    c = conn()
    try:
        row = c.execute("SELECT source_paths_json,priority,source FROM cold_candidates WHERE session_id=? AND path=?", (session_id, p)).fetchone()
        if row:
            old = json.loads(row["source_paths_json"] or "[]")
            merged = list(dict.fromkeys(old + src_paths))
            merged_source = ",".join(list(dict.fromkeys([x for x in (row["source"] or "").split(",") + [source] if x])))
            c.execute(
                "UPDATE cold_candidates SET priority=?,source=?,source_paths_json=?,updated_at=? WHERE session_id=? AND path=?",
                (max(float(row["priority"] or 0), float(priority)), merged_source, json.dumps(merged, ensure_ascii=False), t, session_id, p),
            )
        else:
            c.execute(
                "INSERT INTO cold_candidates(session_id,path,node_type,status,priority,source,source_paths_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (session_id, p, nt, "pending", float(priority), source, json.dumps(src_paths, ensure_ascii=False), t, t),
            )
        c.commit()
        return True
    finally:
        c.close()


def collect_cold_start_entries(
    session_id: str,
    *,
    queries: Optional[Sequence[str]] = None,
    use_default_queries: bool = True,
    recent_limit: int = 300,
    limit_per_query: int = 80,
    max_candidates: int = 200,
    parent_levels: int = 2,
) -> Dict[str, Any]:
    """Collect factual candidate entry dirs for Agent annotation.

    This function does not generate tags or briefs. It only adds directory
    candidates derived from top-level dirs, recent files, and optional search
    results. File hits are aggregated upward to parent directories.
    """
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    scope = s["scope"]
    added = 0
    considered = 0
    sources: Dict[str, int] = {}

    # 1) Always include top-level dirs as possible entry anchors.
    if os.path.isdir(scope):
        try:
            with os.scandir(scope) as it:
                for ent in it:
                    considered += 1
                    if ent.is_dir(follow_symlinks=False) and not _is_ignored(ent.path):
                        if _upsert_candidate(session_id, ent.path, source="top_level", priority=50 + _mtime_ns(ent.path) / 1e18):
                            added += 1; sources["top_level"] = sources.get("top_level", 0) + 1
        except OSError:
            pass

    # 2) Recent files/dirs provide activity evidence.
    try:
        for row in everything.recent(scope=scope, limit=recent_limit):
            considered += 1
            rp = row.get("path") or ""
            for cand in _parent_entries_for_path(rp, scope, parent_levels=parent_levels):
                if _upsert_candidate(session_id, cand, source="recent", source_path=rp, priority=80 + int(row.get("mtime_ns") or 0) / 1e18):
                    added += 1; sources["recent"] = sources.get("recent", 0) + 1
    except Exception as e:
        sources["recent_error"] = sources.get("recent_error", 0) + 1

    # 3) Optional evidence discovery queries. Structural patterns are configurable.
    qlist: List[str] = []
    if queries:
        qlist.extend([str(q).strip() for q in queries if str(q).strip()])
    if use_default_queries:
        qlist.extend(_default_queries())
    qlist = list(dict.fromkeys(qlist))[:50]
    for q in qlist:
        try:
            hits = everything.search(q, scope=scope, limit=limit_per_query)
        except Exception:
            continue
        for row in hits:
            considered += 1
            rp = row.get("path") or ""
            for cand in _parent_entries_for_path(rp, scope, parent_levels=parent_levels):
                if _upsert_candidate(session_id, cand, source=f"query:{q}", source_path=rp, priority=60 + int(row.get("mtime_ns") or 0) / 1e18):
                    added += 1; sources["query"] = sources.get("query", 0) + 1

    c = conn()
    try:
        # Mark collection done if we have enough pending candidates for Agent work, not if the disk is exhausted.
        pending = c.execute("SELECT COUNT(*) FROM cold_candidates WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
        rounds = int(s["rounds"] or 0) + 1
        done = 1 if pending >= int(max_candidates) else 0
        c.execute("UPDATE cold_sessions SET rounds=?,collection_done=?,updated_at=? WHERE session_id=?", (rounds, done, _now(), session_id))
        c.commit()
    finally:
        c.close()
    return {
        "ok": True,
        "session_id": session_id,
        "scope": scope,
        "considered": considered,
        "added_or_merged": added,
        "sources": sources,
        "status": cold_start_status(session_id),
        "note": "collection_done means enough candidates for this round, not that the disk has no more valuable files.",
    }


def cold_start_status(session_id: str) -> Dict[str, Any]:
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    c = conn()
    try:
        counts = {r[0]: r[1] for r in c.execute("SELECT status,COUNT(*) FROM cold_candidates WHERE session_id=? GROUP BY status", (session_id,)).fetchall()}
        total = c.execute("SELECT COUNT(*) FROM cold_candidates WHERE session_id=?", (session_id,)).fetchone()[0]
        return {
            "ok": True,
            "session_id": session_id,
            "scope": s["scope"],
            "status": s["status"],
            "collection_done": bool(s["collection_done"]),
            "rounds": int(s["rounds"] or 0),
            "candidates_total": total,
            "candidate_status": counts,
            "index_stats": index_stats(),
        }
    finally:
        c.close()


def _candidate_rows(session_id: str, limit: int) -> List[Dict[str, Any]]:
    c = conn()
    try:
        rows = c.execute(
            "SELECT * FROM cold_candidates WHERE session_id=? AND status='pending' ORDER BY priority DESC, updated_at DESC LIMIT ?",
            (session_id, int(limit)),
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        c.close()


def _path_evidence(path: str, max_children: int = 80, max_heads: int = 3) -> Dict[str, Any]:
    # Lazy import to avoid a helper<->cold_start import cycle at module import time.
    from .helper import path_evidence
    return path_evidence(path, max_children=max_children, max_heads=max_heads)


def cold_start_batch(session_id: str, batch_size: int = 8, *, max_children: int = 80, max_heads: int = 3) -> Dict[str, Any]:
    """Return pending entry evidence packets for Agent annotation."""
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    packets: List[Dict[str, Any]] = []
    rows = _candidate_rows(session_id, batch_size)
    for r in rows:
        ev = _path_evidence(r["path"], max_children=max_children, max_heads=max_heads)
        ev["cold_start"] = {
            "session_id": session_id,
            "candidate_status": r["status"],
            "priority": r["priority"],
            "source": r["source"],
            "source_seed_paths": json.loads(r["source_paths_json"] or "[]"),
            "instruction": "Agent must decide whether this directory is a useful entry. Helper does not infer route tags.",
        }
        packets.append(ev)
        # Store latest evidence for traceability; keep status pending until Agent applies/skips.
        c = conn()
        try:
            c.execute("UPDATE cold_candidates SET evidence_json=?,updated_at=? WHERE session_id=? AND path=?", (json.dumps(ev, ensure_ascii=False), _now(), session_id, r["path"]))
            c.commit()
        finally:
            c.close()
    return {
        "ok": True,
        "session_id": session_id,
        "batch_size": len(packets),
        "items": packets,
        "annotation_contract": [
            "Annotate entries only when evidence supports a useful search scope.",
            "Use path_evidence fields from this packet; do not infer from external conversation examples.",
            "If unsure, return action='skip' or ask for more evidence using path_evidence(path).",
            "After apply_index_plan(..., session_id=session_id), applied candidates are marked applied.",
        ],
    }


# Common alias retained for older transcripts.
def cold_start_evidence_batch(session_id: str, batch_size: int = 8, **kwargs: Any) -> Dict[str, Any]:
    return cold_start_batch(session_id, batch_size=batch_size, **kwargs)


def mark_candidates(session_id: str, *, applied_paths: Optional[Sequence[str]] = None, skipped_paths: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    _ensure_tables()
    applied = [_norm(p) for p in (applied_paths or []) if p]
    skipped = [_norm(p) for p in (skipped_paths or []) if p]
    c = conn()
    try:
        for p in applied:
            c.execute("UPDATE cold_candidates SET status='applied',updated_at=? WHERE session_id=? AND path=?", (_now(), session_id, p))
        for p in skipped:
            c.execute("UPDATE cold_candidates SET status='skipped',updated_at=? WHERE session_id=? AND path=?", (_now(), session_id, p))
        c.commit()
        return {"ok": True, "session_id": session_id, "applied": applied, "skipped": skipped, "status": cold_start_status(session_id)}
    finally:
        c.close()


def finish_cold_start(session_id: str, *, min_entries: int = 30, min_tagged_entries: int = 20, allow_pending: bool = False) -> Dict[str, Any]:
    """Finish/report a cold start session honestly.

    This is not a semantic quality oracle. It prevents false "completed" reports
    when no entry layer was built, while still allowing Agent-led partial indexes.
    """
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    st = index_stats()
    entries = int(st.get("entries") or 0)
    tagged_nodes = int(st.get("tagged_nodes") or 0)
    warnings: List[str] = []
    if entries < int(min_entries):
        warnings.append(f"entry_count_below_min:{entries}<{min_entries}")
    if tagged_nodes < int(min_tagged_entries):
        warnings.append(f"tagged_nodes_below_min:{tagged_nodes}<{min_tagged_entries}")
    st0 = cold_start_status(session_id)
    pending_count = int((st0.get("candidate_status") or {}).get("pending") or 0)
    if pending_count and not allow_pending:
        warnings.append(f"pending_candidates={pending_count}")
    status = "complete" if not warnings else "partial"
    c = conn()
    try:
        c.execute("UPDATE cold_sessions SET status=?,updated_at=? WHERE session_id=?", (status, _now(), session_id))
        c.commit()
    finally:
        c.close()
    return {
        "ok": status == "complete",
        "status": status,
        "session_id": session_id,
        "warnings": warnings,
        "stats": st,
        "cold_start_status": st0 if "st0" in locals() else cold_start_status(session_id),
        "note": "If status=partial, report it as partial. Do not say the index is fully established.",
    }
