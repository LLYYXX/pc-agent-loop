"""file_index_sop v14-clean: evidence-packet semantic file index with robust Everything substrate."""
__version__ = "v14-clean"

try:
    from .helper import *  # noqa: F401,F403
except Exception:
    pass
