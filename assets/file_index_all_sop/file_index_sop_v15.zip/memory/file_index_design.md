# 文件语义索引 v14-clean 设计说明

本设计收敛为：helper 负责候选发现、证据打包、正确搜索、状态记录、校验入库；语义判断交给 Agent。

## 正确结论

1. Everything / es.exe 是全量事实检索 backing store。
2. 本索引只维护约 1000 条高价值语义节点，不替代桌面搜索。
3. route tag 的目标是缩小 Agent 搜索范围；错误 tag 比没有 tag 更不可接受。
4. 冷启动应产生 evidence packet，而不是由规则库自动打语义 tag。
5. 文档文件是一等候选：PDF/MD/DOCX/PPTX/JSON/YAML/config-like 文件可直接作为种子，再由 Agent 决定是否抽象父级。
6. 命中后负责升温；未命中但 fallback 成功负责 draft update；不 hook file_read，不后台 watcher。
7. search_files 必须是正确性优先薄封装，复杂语义策略只属于 locate。

## 抛弃的错误方向

- 不为具体 case、路径、项目名写 detector。
- 不把 README 里提到的外部项目/引用直接当成本项目 route tag。
- 不把局部 leaf 的弱语义无条件冒泡到父级 entry。
- 不用 helper 规则生成语义标签。
- 不用错误 wrapper 替代 Agent 直接调用 es.exe。

## 概率空间

对任意文件任务，状态分为：

- 已命中索引且路径被使用：升温。
- 语义索引未命中，但 Everything/目录遍历找到：draft update。
- 搜索为空但用户给出强线索：低置信失败，继续检查 scope/query/wrapper，不断言不存在。
- 候选证据不足：不打 route tag，保留 cold/facet/evidence 或 skip。
- 复杂集合任务：索引给范围和候选，Agent 读少量证据完成总结；不能把 tag 错误当成验证补丁。

## 实现计划 Todo

- [x] 吸收旧工具中的 Everything substrate：路径解析、LOCAL_TOOLS patch、自启动、mbcs 编码、argv 构造、诊断。
- [x] search_files 退回薄封装；search_files_detailed 暴露 argv/stderr/encoding。
- [x] 关闭 auto_apply_index_plan 的语义自动打标。
- [x] cold_start_evidence_batch 返回证据包，由 Agent 标注。
- [x] apply_index_plan 校验 route_tag_evidence。
- [x] finish_cold_start 修复 ok/error 冲突，并初始化少量 active。
- [x] finalize_file_task：命中升温；miss/fallback 生成 draft update plan。
- [ ] 后续真实运行评估 tag 正确率、文档种子覆盖率、finalize 自触发稳定性。
