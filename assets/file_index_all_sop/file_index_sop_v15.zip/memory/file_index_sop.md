# 文件语义索引 Skill（v14-clean）

本文件只写给 Agent 执行。目标：用 Everything 做事实检索，用约 1000 条轻量语义节点做正交补充。不要把本索引当桌面搜索替代品。

## 0. 不可违反的边界

- `search_files()` 是正确性优先的 `es.exe` 薄封装：只执行给定 query/scope，不做语义扩展。
- `locate()` 可以做语义策略：query alias、recall、scope search、fallback。
- 不后台 watcher，不 hook `file_read/file_write`，不向量库。
- helper 不自动生成 route tag；语义判断由 Agent 基于 evidence packet 完成。
- route tag 必须“打一条，对一条”：每个 tag 都要有 `route_tag_evidence`。
- 错误 tag 比没有 tag 更不可接受。证据不足时 skip / cold / facet-only，不猜。

## 1. import 与初始化

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop import *

print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

## 2. 冷启动建库模式

### 2.1 创建 session

```python
res = begin_cold_start(target_nodes=1000, max_active=80, scope=r"F:\\", memory_text="", agent_queries=[])
print_json(res)
session_id = res["session_id"]
```

### 2.2 分批收集候选

```python
while True:
    status = cold_start_status(session_id)
    if status.get("pending", 0) >= 30 or status.get("collection_done"):
        break
    print_json(collect_cold_start_entries(session_id, max_queries=6, limit_per_query=100, recent_limit=1000, max_entries=100, time_budget_sec=30))
```

### 2.3 证据包标注（禁止自动语义打标）

```python
batch = cold_start_evidence_batch(session_id, batch_size=8)
print_json(batch)
```

Agent 对每个 item 做判断并构造 plan。计划格式：

```python
plan = [
  {
    "path": item["path"],
    "node_type": item["node_type"],
    "tier": "warm",             # 冷启动一般用 warm/cold；active 由 finish 初始化
    "brief": "一句话说明这个路径作为可复用搜索范围/文件的真实用途",
    "tags": ["准确的-route-tag"],
    "relation": {
      "role": "entry",          # 或 leaf
      "facets": ["用于组织的宽松 facet"],
      "route_tag_evidence": {
        "准确的-route-tag": ["probe.readme_excerpt", "leaf_candidates[0].basename"]
      }
    },
    "evidence": ["agent-annotated-from-evidence-packet"]
  },
  {"path": "...", "action": "skip", "reason": "insufficient evidence"}
]
print_json(apply_index_plan(plan, session_id=session_id))
```

规则：
- 不要手写路径特判或 if/elif 模板。
- 不要把局部 leaf 的弱语义无条件冒泡成父级 route tag。
- README/链接/引用/依赖只是 evidence，不能自动等价于项目主语义。
- 一个节点可以有多个 tag；关键是每个 tag 都必须准确、有证据。

### 2.4 完成与验收

```python
res = finish_cold_start(session_id, max_nodes=1000, max_active=80, max_warm=420)
print_json(res)
print_json(audit_index(fix=False))
print_json(stats())
print_json(virtual_tree(limit_per_group=10))
```

若 `finish_cold_start()` 返回 `ok=False` 或 `status != "complete"`，不得向用户报告“索引已完成”；继续收集/标注或如实报告 partial。

## 3. 运行时文件任务模式

遇到找、读、总结、整理、移动、重命名本地文件：

```python
res = locate("用户语义意图", limit=10)
print_json(res)
task_id = res.get("task_id")
```

执行正常文件操作：`file_read`、`os.listdir`、`search_files()`、移动/写入等。本 Skill 不接管这些工具。

需要事实搜索时：

```python
hits = search_files("事实词，如 final pdf invoice ssh", scope=r"明确目录", limit=30)
# 如怀疑封装问题：
print_json(search_files_detailed("事实词", scope=r"明确目录", limit=30))
```

## 4. 任务结束前 finalize

最终回答前，如果本轮使用了文件路径，调用：

```python
print_json(finalize_file_task(
    task_id=task_id,
    query="用户原始问题",
    used_paths=["最终采用/读取/修改的路径"],
    found_paths=["本轮找到的相关路径"],
    rejected_paths=["明确噪声路径"],
    fallback_used=bool(res.get("fallback_filesystem_hits")),
    mode="draft",
))
```

语义：
- 命中已有索引并被使用：升温到 active / 更新 hit_count。
- fallback 或索引外路径：生成 draft update plan。
- 没有 dirty evidence：no-op。

确认 update plan 可用后：

```python
print_json(apply_update_plan(plan_id))
```

## 5. tag / facet

- `node_tags`：参与 recall 的 route tags，必须准确、有 evidence。
- `node_facets`：组织和虚拟目录树，可宽松，但不能胡扯。
- `tier/role` 也是特殊 facet。
- route tag 描述节点的主用途或可路由语义；不是文件类型、路径复读、泛分类。

## 6. search wrapper 契约

`search_files(query, scope=...)` 必须等价于：

```text
es.exe -n <limit> -path <scope> <query>
```

它不做语义扩展。空结果不等于文件不存在；如果用户给了强线索但结果为空，检查 scope、query、`search_files_detailed()` 的 argv/stderr，再考虑直接 `code_run` 调 es.exe 或 `os.walk`。
