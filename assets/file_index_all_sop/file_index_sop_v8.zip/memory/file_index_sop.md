# 文件语义索引 Skill（v8：父级语义入口 + 文件支撑层）

本 Skill 是 Everything / `es.exe` 之上的**正交语义覆盖层**。用户只提出任务或触发“冷启动”；Agent 自行完成搜索、建库、补库、升降级和复用。

v8 重新回到原始目标：

```text
高价值文件候选
→ 向父目录 / 祖父目录 / 项目根 / 材料根聚合
→ 优先语义化这些父级范围节点
→ 文件节点作为支撑材料挂在范围下面
→ Agent 先 recall 命中语义范围，再用 es.exe 在 scope 内精确找最终文件
```

不要把冷启动做成“1000 个 path 逐项填表”。冷启动应先找到可作为搜索范围的语义入口，再从入口下派生代表文件/目录节点。

## 核心边界

- `es.exe` 负责文件事实检索：文件名、路径、扩展名、时间、scope。
- 本索引负责语义覆盖：路径看不出来或不稳定表达的用途、任务关系、材料归属、项目语义、查询别名。
- 主索引库只保存当前可用节点：`file / dir` + `active / warm / cold` + `brief / tags`。
- 语义入口节点通过 `relation.role = entry` 表示；支撑节点通过 `relation.role = leaf` 表示。
- 日志和溯源写入 `events.jsonl`；负向规则写入 `ignore_rules.json`。
- 不改 GenericAgent 主流程，不注册工具，不 hook `file_read`，不后台 watcher，不向量库。

## import

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop.helper import *
```

## 使用索引前：先确保 Everything 可用

首次使用索引或冷启动前，Agent 必须显式执行：

```python
print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

`ensure_search_ready()` 负责嗅探 `es.exe` / `Everything.exe`、patch `memory/global_mem.txt` 的 `## [LOCAL_TOOLS]`、必要时自启动 Everything 并 probe IPC。

`everything.py` 只执行已配置好的 `es.exe` 查询，不嗅探、不启动、不写 memory。

## 运行时检索流程

遇到文件相关任务时，Agent 必须先用语义索引缩小范围：

```python
hits = recall("用户语义意图", limit=8)
```

优先使用 `role == "entry"` 且 `node_type == "dir"` 的命中作为 scope：

```python
search_files("文件事实词，如 result csv config invoice", scope=hits[0]["path"], limit=20)
```

如果命中文件节点：

```python
# 直接 file_read(path)
mark_used(path, matched_tags=["实际命中的tag"])
```

如果语义索引没有命中或命中很差：

```python
summary = miss_recovery_batch("用户查询", memory_text="可用的 Agent Memory 摘要", limit=80)
# Agent 标注 summary["entries"] 中的父级范围节点
apply_index_plan(plan)
rebalance(max_nodes=1000, max_active=220)
```

文件操作后的同步：

```python
report_file_deleted(path, reason="file_read_failed 或 agent 删除")
report_file_changed(path, note="agent edited")
report_file_moved(old_path, new_path)
report_file_created(path, brief="...", tags=["..."], tier="warm")
```

不要在 `file_read` 前额外做存在性检查；文件操作成功/失败后再同步索引。

## 冷启动目标

用户要求“针对 F 盘建索引”或点击冷启动时，最终应产出：

- 一批高质量语义入口节点（项目根、材料根、实验根、报销根、课程根、工具根等）；
- 每个入口有具体 brief 和 route tags；
- 入口下自动挂载若干代表性 leaf 文件/目录节点；
- 总节点约 1000，但完成质量主要看入口是否足够有用，而不是 1000 个 path 是否都被逐条标注。

合格冷启动应满足：

- 节点只允许 `file / dir`；不允许 `unknown`。
- 热度只允许 `active / warm / cold`；不允许 `stale / retired` 作为主索引状态。
- 所有节点必须来自 `es.exe` 或文件系统验证；Agent 不得发明路径。
- `.git`、`node_modules`、`$RECYCLE.BIN`、缓存、日志、构建产物、依赖目录不应入库。
- `entry` 节点必须有具体 brief 和至少一个 route tag。
- `leaf` 节点是代表性支撑材料，通常为 `cold`，不要求独立 tag；它们通过 entry scope 被使用。

## 冷启动流程

### 1. 开始冷启动

Agent 先根据 Memory / 当前长期任务生成 `agent_queries`。例如 MCP、trajectory、元应用、论文、实验、报销、invoice、ml-agents、LLM 等。然后：

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=220,
    scope=r"F:\\",
    memory_text="这里填可用的 Agent Memory 摘要",
    agent_queries=["mcp", "trajectory", "轨迹", "元应用", "论文", "实验", "报销", "invoice", "receipt", "ml-agents", "llm", "paddle"],
)
print_json(res)
session_id = res["session_id"]
```

v8 的 `begin_cold_start()` 暂存的是语义入口候选，不是 1000 个 raw paths。返回中会出现 `mode = v8-entry-first`、`staged_entries`、`target_entries`。

### 2. Agent 分批标注入口节点

循环执行，直到 `remaining_entries == 0`：

```python
status = cold_start_status(session_id)
while status["remaining_entries"] > 0:
    batch = cold_start_batch(session_id, batch_size=30)
    print_json(batch)
    # Agent 阅读 batch["items"]，只针对这些 staged entry 生成 plan
    print_json(apply_index_plan(plan, session_id=session_id))
    status = cold_start_status(session_id)
```

每个 plan item：

```python
{
  "path": r"F:\\...\\某真实父级范围",      # 必须来自 batch items
  "node_type": "dir",                     # 通常是 dir
  "tier": "active" / "warm" / "cold",
  "brief": "一行说明该范围未来为什么值得进入、能定位哪些任务材料。",
  "tags": ["route-tag", "query-alias"],   # entry 必须至少 1 个，推荐 2-4 个
  "source": "agent-cold-start"
}
```

若某项不值得入库：

```python
{"path": batch_path, "action": "skip", "reason": "generated/dependency/low-value"}
```

通过 `apply_index_plan()` 接受 entry 后，系统会自动把该 entry 下的代表性 `leaf_candidates` 作为 `cold` leaf 节点入库并挂到 `relation.entry` 下。Agent 不需要逐个标注 leaf。

### 3. tag 规则：route tag，不是路径复读

Tag 是语义路由键，不是分类标签，也不是路径关键词提取。

只写：

- 用户未来可能用这个语义来找；
- 能显著缩小搜索范围；
- 能把自然语言意图映射到一个 scope；
- 可以是路径看不出来的语义，也可以是路径无法稳定服务的查询别名。

避免：

- `readme`, `markdown`, `python`, `json`, `csv`, `config`, `test`, `result`, `project`, `folder`, `file`；
- `uncategorized`, `general`, `misc`, `academic`, `coursework`, `reading-material`, `workspace-project`；
- 纯路径复读，如 `stable-diffusion-webui`、`pc-agent-loop`、`paddleocr-release`。

允许并鼓励查询别名：

```text
PaddleOCR-release-2.5       → ocr-recognition, document-text-extraction
stable-diffusion-webui      → image-generation-workspace, ai-drawing
LLaMA-Factory               → llm-finetuning, model-training-workflow
Unity + ML-Agents 项目      → unity-ml-agents, reinforcement-learning
pc-agent-loop               → gui-automation-agent, llm-agent-runtime
cursor账单                  → cursor-reimbursement, subscription-billing
```

好的 tag 示例：

```text
trajectory-reuse-evaluation
mcp-service-statistics
unity-ml-agents
local-file-semantic-index
llm-agent-runtime
cursor-reimbursement
paper-evidence-table
ocr-recognition
image-generation-workspace
```

### 4. brief 规则

brief 是一行解释，用于帮助 Agent 判断是否值得进入该 scope。

好的 brief：

```text
保存 Cursor 订阅报销相关发票与收据，适合作为报销材料检索范围。
包含 GenericAgent 的运行时、SOP、工具封装和文件语义索引实现。
Stable Diffusion WebUI 主项目，适合作为图像生成与插件相关文件的搜索范围。
```

禁止泛泛 brief：

```text
Directory: xxx
Project workspace: xxx
Web application project: xxx
LLM/language model project: xxx
Subdirectory of xxx
```

### 5. 完成冷启动

达到目标入口数量后：

```python
print_json(finish_cold_start(session_id, max_nodes=1000, max_active=220))
print_json(audit_index(fix=False))
print_json(stats())
print_json(facets(limit=30))
```

如果 `finish_cold_start()` 返回 `ok=False` / `status=partial`，Agent 不能宣称完成，必须继续 `cold_start_batch()` + `apply_index_plan()`，或重新 `begin_cold_start()` / `miss_recovery_batch()` 补候选。

## 三层热度

- `active`: 默认强召回；冷启动后数量受限。
- `warm`: 默认召回但弱于 active；通常是次要入口。
- `cold`: 支撑文件、低优先节点、备用候选；默认不作为强语义入口。

`cold` 不应用来凑“语义入口完成数”。它可以贡献文件覆盖，但不能代替 route tag/brief 的入口层。

## audit

`audit_index()` 是建库/大批量更新后的验收函数，不参与普通检索。

检查：

- 路径是否存在；
- 是否命中 ignore_rules；
- node_type 是否只有 file/dir；
- active/warm 是否缺 brief/tag；
- 是否出现坏 tag、泛泛 brief；
- entry/leaf 比例是否异常。

## 关键原则

1. 不要让 Agent 给 1000 个 path 填表。
2. 先语义化父级范围，再自动派生代表文件节点。
3. recall 的主对象是 entry；leaf 主要服务于 scope 内展开。
4. tag 的目标是把自然语言需求映射到可用搜索范围。
5. Everything 负责精确事实搜索；语义索引负责先缩小范围。
