"""file_index_sop v8: entry-first semantic coverage over Everything/es.exe."""
__version__ = "v8"
