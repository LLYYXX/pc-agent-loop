# 文件语义索引 Skill（v11：文档优先冷启动 + 任务级后效性 + 虚拟语义树）

本 Skill 是 Everything / `es.exe` 之上的**轻量正交语义覆盖层**。`es.exe` 负责全量文件事实检索；本索引只维护用户最可能需要掌握的一小层语义索引，补充路径/文件名无法稳定表达的用途、任务关系、材料归属、项目语义和查询别名。

v11 的目标是把基本需求闭环，而不是为单个 case 打补丁：

```text
冷启动：全盘多流发现高价值文件候选
→ 文档/配置类优先加权，必要时读轻量 head
→ 向父目录 / 祖父目录 / 项目根 / 材料根聚合
→ 语义化父级范围节点（entry）
→ 自动挂载代表性文件/目录（leaf）
→ 按 active / warm / cold 预算归一化

运行时：Agent 先 locate / recall 命中 entry scope
→ 用 es.exe 在 scope 内精确搜索
→ 完成任务前 commit_file_task 提交路径证据
→ 索引沉淀 query alias、父级 entry、leaf 使用记录和负反馈
```

## 不可漂移边界

- 不替代 Everything；不做全量桌面搜索引擎。
- 不后台 watcher，不 hook `file_read` / `file_write`，不侵入 Agent 工具层。
- 不引入向量库，不要求常驻服务。
- 主索引只保存当前可用节点：`file / dir` + `active / warm / cold` + `brief / route tags`。
- `relation.role = entry` 表示语义入口；`relation.role = leaf` 表示入口下支撑节点。
- route tag 不是分类标签、路径复读、文件类型词；它必须能把用户自然语言意图路由到 scope。
- facet / signal 可以宽松，用于组织、排序和虚拟目录树；不能污染 route tag。

## import

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop import *
```

`__init__.py` 已 re-export 常用 helper，`from file_index_sop import locate, search_files, commit_file_task` 应该可用。

## 使用前准备

```python
print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

`ensure_search_ready()` 负责嗅探/自启动 Everything，并 patch `LOCAL_TOOLS`。`everything.py` 只执行已配置好的 `es.exe` 查询。

## tier 语义与数量预算

v11 中，tier 表示默认语义召回链路里的可见性，不等价于文件好坏。

```text
active:
  热工作集。来自近期真实任务命中、读取、修改、创建、query alias 成功。
  小容量，强 boost，短 TTL。

warm:
  稳定语义索引层。冷启动主要产物。
  包括高质量 entry、读过 head 的高价值文档/config、active 衰减节点。
  默认 recall 主体。

cold:
  自动支撑/弱证据候选层。
  包括 entry 下自动 materialize 的 leaf、弱证据 entry、长期未用节点。
  默认不抢 recall，只在 scope 展开、fallback 或 include_cold 时使用。
```

默认预算：

```text
max_nodes  = 1000
max_active = 80
max_warm   = 420
active + warm <= 500
cold 补足到 1000 左右
```

冷启动后不是 active 越多越好。正确形态是：

```text
active: warm 中最近/最可能马上用的一小部分
warm:   冷启动语义核心层
cold:   支撑 leaf / 弱证据候选
```

## 运行时检索流程

优先使用 `locate()`：

```python
res = locate("用户语义意图", limit=10)
print_json(res)
```

`locate()` 会：

```text
1. 查 query_alias；
2. recall active/warm 语义索引；
3. 识别 anchor / intent，例如 zotero、cursor、报销、论文、毕设；
4. 生成事实查询变体，例如 cursor invoice / cursor receipt；
5. 在 entry scope 内调用 search_files；
6. 对 AppData/log/cache 等进行意图相关降噪；
7. 必要时 fallback 到全局 search_files。
```

若直接使用低层接口：

```python
hits = recall("用户语义意图", limit=8)
# 命中 role == entry 且 node_type == dir 后：
search_files("文件事实词，如 invoice receipt config final", scope=hits[0]["path"], limit=20)
```

如果命中文件并读取成功，任务完成前调用 `commit_file_task(...)`，不要只 `mark_used` 后就回答。

## 任务级后效性 commit

不要求每次文件操作后调用 hook；不侵入 Agent 的 file tool。复杂文件任务结束前，提交一次任务证据：

```python
task = begin_file_task("今年 cursor 报销材料", intent="billing")  # 可选

# Agent 自己执行 locate/search_files/file_read/移动/改名/写入等任意复杂流程

print_json(commit_file_task(
    task_id=task.get("task_id"),
    query="今年 cursor 报销材料",
    outcome="success",
    found_paths=[r"F:\...\cursor账单\Invoice\xxx.pdf"],
    used_paths=[r"F:\...\cursor账单\Invoice\xxx.pdf"],
    rejected_paths=[r"C:\Users\...\Cursor\logs\..."],
    fallback_used=True,
    intent="billing",
))
```

`commit_file_task()` 会统一执行：

```text
- 对 used/found 路径 mark/promote；
- 不在索引内的路径创建 leaf；
- 推断父级 entry 并写入或强化；
- 记录 query alias：用户说法 → entry/path；
- 记录意图相关负反馈；
- 同步 created/modified/moved/deleted；
- rebalance(max_nodes=1000, max_active=80, max_warm=420)。
```

这是一等入口。不要指望 Agent 记住手工拼 `mark_used + apply_index_plan + rebalance`。

## 冷启动目标

用户要求“针对 F 盘建索引”时，目标是维护约 1000 条最可能有用的语义节点：

- active + warm 不超过约 500；
- cold 作为支撑 leaf / 弱证据候选补足到约 1000；
- 文档类和配置类文件加权；
- 父级语义来自子文件 evidence，不应只来自路径模板；
- `.git`、`node_modules`、`$RECYCLE.BIN`、缓存、日志、构建产物、应用数据目录、QQ 图片缓存等不应进入主索引。

## v11 冷启动流程

### 1. 创建 session（快速返回）

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=80,
    scope=r"F:\\",
    memory_text="这里填可用的 Agent Memory 摘要",
    agent_queries=["mcp", "trajectory", "轨迹", "元应用", "论文", "实验", "报销", "invoice", "receipt", "ml-agents", "llm", "paddle"],
)
print_json(res)
session_id = res["session_id"]
```

`begin_cold_start()` 只创建 session，不扫描 F 盘。返回 `mode = v11-document-first-task-learning`。

### 2. 多轮收集 entry 候选

```python
while True:
    print_json(collect_cold_start_entries(
        session_id,
        max_queries=6,
        limit_per_query=100,
        recent_limit=1000,
        max_entries=100,
        time_budget_sec=30,
    ))
    status = cold_start_status(session_id)
    if status["pending"] >= 40 or status["collection_done"]:
        break
```

候选收集使用多流发现：recent-by-type、document-first、config-like、项目 marker、文档类型、Memory/query。多轮保证覆盖面，单轮有预算。

### 3. Agent 标注 entry

```python
batch = cold_start_batch(session_id, batch_size=30)
print_json(batch)
```

每个 item 包含：`path`、`probe`、`signals`、`facets`、`suggested_route_tags`、`leaf_candidates`。Agent 只标注 batch 里的真实 entry，不能自造路径。

Plan item：

```python
{
  "path": r"F:\\...\\真实父级范围",
  "node_type": "dir",
  "tier": "warm",   # 冷启动即使写 active，系统也会归一化为 warm
  "brief": "一行说明该范围未来为什么值得进入、能定位哪些任务材料。",
  "tags": ["route-tag", "query-alias"],
  "source": "agent-cold-start"
}
```

若不值得入库：

```python
{"path": batch_path, "action": "skip", "reason": "generated/dependency/low-value"}
```

### 4. route tag 准则

只写：

- 用户未来可能用这个语义来找；
- 能显著缩小搜索范围；
- 能把自然语言意图映射到 scope；
- 可以是路径看不出来的语义，也可以是路径无法稳定服务的查询别名。

避免：

- `readme`, `markdown`, `python`, `json`, `csv`, `config`, `test`, `result`, `project`, `folder`, `file`；
- `archive`, `materials`, `general-materials`, `unity-project`, `python-project`, `development-workspace`, `workspace-project`, `game-dev`；
- 纯路径复读，如 `stable-diffusion-webui`、`pc-agent-loop`、`paddleocr-release`。

例子：

```text
PaddleOCR-release-2.5      → ocr-recognition, document-text-extraction, text-recognition
stable-diffusion-webui     → image-generation, diffusion-model-ui, ai-drawing
LLaMA-Factory              → llm-finetuning, model-training-workflow
Unity ML-Agents 项目        → reinforcement-learning, unity-ml-agents, agent-training-simulation
pc-agent-loop              → llm-agent-runtime, gui-automation-agent, local-file-semantic-index
cursor账单                 → software-subscription-billing, reimbursement-records
Agent memory/config        → skill-registry, local-tools-config, runtime-environment
```

### 5. 完成与验收

```python
print_json(finish_cold_start(session_id, max_nodes=1000, max_active=80, max_warm=420))
print_json(audit_index(fix=False))
print_json(stats())
print_json(facets(limit=30))
print_json(virtual_tree(limit_per_group=10))
```

合格结果不是固定测试集通过，而是结构合理：

- active 数量小；warm 是冷启动主体；cold 是支撑层；
- active + warm 不超过约 500；总节点接近 1000；
- active/warm entry 有有效 route tag 和 brief；
- leaf 可以无独立 tag，但应挂在 entry 下；
- route tag 中不应高频出现 `archive/materials/development-workspace/unity-project` 等分类词；
- 文档类、配置类、项目类、材料类根都有覆盖；
- ignored/missing/bad tag/bad brief 接近 0；
- recall 能优先返回有用 entry scope，而不是内部随机文件。

## route tag / facet / 虚拟目录树

- `node_tags` 存 route tags，参与 recall。
- `node_facets` 存 facets/signals，用于组织、过滤、解释和虚拟目录树。
- `tier` 和 `role` 也视为特殊 facet。

接口：

```python
print_json(virtual_tree(limit_per_group=12))
print_json(list_virtual_roots())
print_json(list_entries_by_facet("billing-records", limit=20))
print_json(list_by_tag("local-file-semantic-index", limit=20))
```

虚拟目录树不模拟真实目录；它只是对 tag/facet/tier/role 的组织视图，例如 Hot、Research、Projects、Documents、Config、Cold Support。

## 维护入口

低层文件状态同步仍保留：

```python
mark_used(path)
report_file_deleted(path, reason="file_read_failed 或 agent 删除")
report_file_changed(path, note="agent edited")
report_file_moved(old_path, new_path)
report_file_created(path, brief="...", tags=["..."], tier="warm")
```

但真实任务优先使用 `commit_file_task(...)`。

不要在 `file_read` 前额外做存在性检查；文件操作成功/失败后再同步索引。
