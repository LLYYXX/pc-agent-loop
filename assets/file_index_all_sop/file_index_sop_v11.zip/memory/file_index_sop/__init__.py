"""file_index_sop v11: document-first semantic file index with task-level after-hit learning."""
__version__ = "v11"

# Re-export the stable Agent-facing helper API so natural imports work:
#   from file_index_sop import locate, search_files, commit_file_task
try:
    from .helper import *  # noqa: F401,F403
except Exception:
    # Keep package importable even if runtime environment is not ready yet.
    pass
