# 文件语义索引 Skill（v7：高质量冷启动 + 极简主模型）

本 Skill 是 Everything / `es.exe` 之上的**正交语义覆盖层**。它不是替代 Everything 的搜索器，也不是用户手工维护的数据库。用户只提出任务或触发“冷启动”；Agent 必须自行完成搜索、建库、补库、升降级和复用。

## 核心边界

- `es.exe` 负责文件事实检索：文件名、路径、扩展名、时间、scope。
- 本索引负责语义覆盖：路径看不出来的用途、任务关系、材料归属、项目语义。
- 主索引库只保存当前可用节点：`file / dir` + `active / warm / cold` + `brief / tags`。
- 日志和溯源写入 `events.jsonl`；负向规则写入 `ignore_rules.json`。
- 不改 GenericAgent 主流程，不注册工具，不 hook `file_read`，不后台 watcher，不向量库。

## import

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop.helper import *
```

## 使用索引前：先确保 Everything 可用

首次使用索引或冷启动前，Agent 必须显式执行：

```python
print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

`ensure_search_ready()` 负责嗅探 `es.exe` / `Everything.exe`、patch `memory/global_mem.txt` 的 `## [LOCAL_TOOLS]`、必要时自启动 Everything 并 probe IPC。

`everything.py` 只执行已配置好的 `es.exe` 查询，不嗅探、不启动、不写 memory。

## 运行时检索流程

遇到文件相关任务时，Agent 必须先用语义索引缩小范围：

```python
hits = recall("用户语义意图", limit=8)
```

如果命中 `dir` 节点：

```python
search_files("文件事实词，如 result csv config invoice", scope=hits[0]["path"], limit=20)
```

如果语义索引没有命中或命中很差：

```python
summary = miss_recovery_batch("用户查询", memory_text="可用的 Agent Memory 摘要", limit=80)
```

Agent 根据 `summary` 自行生成 `index_plan`，必须包含具体 `brief` 和高信息 `tags`，然后：

```python
apply_index_plan(plan)
rebalance(max_nodes=1000, max_active=220)
```

任务完成后：

```python
mark_used(path, matched_tags=["实际命中的tag"])
```

如果文件操作导致索引变化：

```python
report_file_deleted(path, reason="file_read_failed 或 agent 删除")
report_file_changed(path, note="agent edited")
report_file_moved(old_path, new_path)
report_file_created(path, brief="...", tags=["..."], tier="warm")
```

不要在 `file_read` 前额外做存在性检查；文件操作成功/失败后再同步索引。

## 冷启动目标

用户要求“针对 F 盘建索引”或点击冷启动时，最终必须产出**约 1000 条真实、高价值、可用的语义节点**，而不是候选池。

合格冷启动应满足：

- 节点只允许 `file / dir`；不允许 `unknown`。
- 热度只允许 `active / warm / cold`；不允许 `stale / retired` 作为主索引状态。
- 所有节点必须来自 `es.exe` 或文件系统验证；Agent 不得发明路径。
- `.git`、`node_modules`、`$RECYCLE.BIN`、缓存、日志、构建产物、依赖目录不应入库。
- `active / warm` 必须有具体 brief 和至少一个高信息 tag。
- `cold` 是真实但低优先级的保留节点，必须有 brief，tag 可选。

## 冷启动流程

### 1. 开始冷启动

Agent 先根据 Memory / 当前长期任务生成 `agent_queries`。例如 MCP、trajectory、元应用、论文、实验、报销、invoice、ml-agents、LLM 等。然后：

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=220,
    scope=r"F:\\",
    memory_text="这里填可用的 Agent Memory 摘要",
    agent_queries=["mcp", "trajectory", "轨迹", "元应用", "论文", "实验", "报销", "invoice", "receipt", "ml-agents", "llm", "paddle"],
)
print_json(res)
session_id = res["session_id"]
```

`begin_cold_start()` 会 oversample：目标 1000 时会 stage 更多候选，允许 Agent 跳过低价值项，只写入高质量节点。

### 2. Agent 分批标注并入库

循环执行，直到 `remaining_to_target == 0`：

```python
status = cold_start_status(session_id)
while status["remaining_to_target"] > 0:
    batch = cold_start_batch(session_id, batch_size=40)
    print_json(batch)
    # Agent 阅读 batch["items"]，只针对这些 staged path 生成 plan
    print_json(apply_index_plan(plan, session_id=session_id))
    status = cold_start_status(session_id)
```

每个 plan item：

```python
{
  "path": r"F:\\...\\某真实路径",      # 必须来自 batch items
  "node_type": "file" 或 "dir",       # 必须与文件系统一致
  "tier": "active" / "warm" / "cold",
  "brief": "一行短说明该节点未来为什么值得读或作为范围入口。",
  "tags": ["high-info-residual-tag"],  # active/warm 必须至少 1 个
  "source": "agent-cold-start"
}
```

若某项不值得入库：

```python
{"path": batch_path, "action": "skip", "reason": "generated/dependency/low-value"}
```

禁止：

- 标注 batch 之外的路径；
- 使用不存在路径；
- 使用 `uncategorized/general/misc/academic/coursework/reading-material/workspace-project` 等假 tag；
- 用 `dir节点 / 项目说明 / 课程资料 / 文件:xxx` 这类泛泛 brief。

### 3. 完成冷启动

达到目标数量后：

```python
print_json(finish_cold_start(session_id, max_nodes=1000, max_active=220))
print_json(audit_index(fix=False))
print_json(stats())
print_json(facets(limit=30))
```

如果 `finish_cold_start()` 返回 `not enough applied high-quality nodes`，Agent 必须继续 `cold_start_batch()` + `apply_index_plan()`。

## tag 规则

Tag 是高信息路由键，不是分类标签。

只写：

- 路径 / 文件名 / 扩展名 / 父目录看不出来；
- 未来 Agent 可能用这个语义来找；
- 能显著缩小搜索范围。

避免：

- `readme`, `markdown`, `python`, `json`, `csv`, `config`, `test`, `result`, `project`, `folder`, `file`；
- `uncategorized`, `general`, `misc`, `academic`, `coursework`, `reading-material`, `workspace-project`；
- 路径词的同义重复；
- 扩展名和普通文件类型。

好的 tag 示例：

```text
trajectory-reuse-evaluation
mcp-service-statistics
unity-ml-agents
local-file-semantic-index
llm-agent-runtime
cursor-reimbursement
paper-evidence-table
```

brief 是一行解释，用于帮助 Agent 判断是否值得 `file_read` 或作为 `search_files(..., scope=dir)` 的范围入口。

## 三层热度

- `active`: 默认强召回；冷启动后数量受限。
- `warm`: 默认召回但弱于 active；冷启动主体。
- `cold`: 默认不召回，`include_dormant=True` 才出。

不存在 `stale / retired / unknown` 主状态。路径不存在时，调用 `report_file_deleted()` 从主库删除并写日志。

## ignore_rules.json

负向规则存放在：

```text
memory/file_index_sop/ignore_rules.json
```

它是一个 JSON 数组。匹配规则：

- 含 `*` 的规则：glob 匹配完整路径；
- `*.xxx`：匹配文件名 / 扩展名；
- 普通字符串：按路径分段匹配。

Agent 可通过：

```python
add_ignore_rule("some_generated_dir")
print_json(ignore_rules())
```

## events.jsonl

日志存放在：

```text
memory/file_index_sop/events.jsonl
```

用于记录 candidate ignored、tag rejected、node deleted、session path rejected、cold start started/finished 等。Agent 需要自查时：

```python
print_json(recent_events(limit=50))
```

日志不参与默认 recall。

## audit_index

`audit_index()` 是建库或大批量补库后的验收函数，不参与普通检索。

```python
print_json(audit_index(fix=False))
```

检查：

- 不存在路径；
- 命中 ignore rules 的节点；
- `active / warm` 缺 brief 或缺有效 tag；
- bad tags；
- generic briefs；
- node_type 是否只有 `file / dir`；
- active 是否超过上限。

冷启动完成后必须跑 audit，不合格就继续修。

## 验收目标

冷启动完成后应满足：

- `stats()["nodes_total"]` 约 1000；
- `node_type` 只有 `file / dir`；
- `active / warm` 大多有具体 brief 和高信息 tag；
- `audit_index()` 的 `missing_paths / ignored_rule_violations / bad_tag_count` 为 0 或接近 0；
- `facets()` 能看到有意义的 tag；
- `recall("机器学习")`、`recall("Agent开发")`、`recall("OCR识别")` 能命中合理节点；
- 命中目录节点后，Agent 能用 `search_files(..., scope=dir)` 快速展开。
