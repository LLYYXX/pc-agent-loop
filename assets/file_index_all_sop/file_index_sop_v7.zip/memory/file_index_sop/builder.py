"""Agent-facing cold-start and miss-recovery builder.

The builder never generates semantic tags by itself. It collects verified paths,
filters them, stages compact batches, and enforces quality gates over Agent
labels. The final cold-start output is a high-value usable semantic index, not a
candidate dump.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from collections import Counter, defaultdict
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import everything, store

TEXTISH_EXTS = {
    ".md", ".txt", ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cs", ".go", ".rs",
    ".json", ".yaml", ".yml", ".toml", ".ini", ".csv", ".tsv", ".tex", ".ipynb",
    ".sql", ".pdf", ".docx", ".xlsx", ".xls", ".pptx", ".html", ".vue",
}
MEDIA_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".mp4", ".mov", ".avi", ".mkv"}
ARCHIVE_EXTS = {".zip", ".7z", ".rar", ".tar", ".gz", ".bz2"}
ENTRY_BASENAMES = {
    "readme.md", "readme.txt", "package.json", "pyproject.toml", "requirements.txt",
    "dockerfile", "docker-compose.yml", "docker-compose.yaml", "pom.xml", "cargo.toml", "go.mod",
    "main.py", "app.py", "index.js", "index.ts", "setup.py", "makefile", "cmakelists.txt",
    "environment.yml", "conda.yml", "manifest.json", "dockerfile",
}
GENERIC_CONTAINER_NAMES = {
    "workspace", "workspaces", "pythonproject", "unityproject", "document", "documents",
    "books", "fdu", "sunglink", "zhongduo", "from thinkpad", "temp", "tmp", "download", "downloads",
}
LOW_VALUE_TEST_SEGMENTS = {"test", "tests", "example", "examples", "demo", "demos", "sample", "samples"}
COLLECTION_MARKERS = {"invoice", "receipt", "发票", "收据", "账单", "论文", "papers", "paper", "notes", "materials", "材料", "实验", "results", "简历"}
DEFAULT_DISCOVERY_QUERIES = [
    "README.md", "pyproject.toml", "package.json", "requirements.txt", "docker-compose", "Dockerfile",
    "论文", "paper", "thesis", "实验", "experiment", "results", "报销", "发票", "账单", "invoice", "receipt",
    "mcp", "agent", "trajectory", "memory", "ml-agents", "llm", "llama", "paddle", "diffusion", "zotero",
    "课程", "简历", "毕业", "毕设", "GenericAgent", "Micro-Agent", "元应用", "仿真", "轨迹",
]


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _path_l(path: str) -> str:
    return _norm(path).lower().replace("\\", "/")


def _segments(path: str) -> List[str]:
    p = _norm(path); out: List[str] = []
    while True:
        h, t = os.path.split(p)
        if t:
            out.append(t.lower()); p = h
        else:
            if h: out.append(h.lower())
            break
        if h == p: break
    return list(reversed(out))


def _node_type(path: str) -> Optional[str]:
    return store.infer_node_type(path)


def _direct_names(path: str, limit: int = 800) -> set[str]:
    try:
        return {x.lower() for x in os.listdir(path)[:limit]}
    except OSError:
        return set()


def _is_generic_container_dir(path: str) -> bool:
    return os.path.basename(_norm(path)).lower() in GENERIC_CONTAINER_NAMES


def _low_value_segment(path: str) -> bool:
    return any(s in LOW_VALUE_TEST_SEGMENTS for s in _segments(path))


def _project_marker_score(path: str) -> Tuple[float, List[str]]:
    p = _norm(path)
    if not os.path.isdir(p):
        return 0.0, []
    names = _direct_names(p)
    score = 0.0; reasons: List[str] = []
    if ".git" in names:
        score += 30; reasons.append("project-root:git")
    if "assets" in names and "projectsettings" in names:
        score += 32; reasons.append("project-root:unity")
    for marker in ["package.json", "pyproject.toml", "requirements.txt", "setup.py", "pom.xml", "cargo.toml", "go.mod", "docker-compose.yml", "docker-compose.yaml"]:
        if marker in names:
            score += 18; reasons.append("project-marker:" + marker); break
    if names & {x.lower() for x in COLLECTION_MARKERS}:
        score += 12; reasons.append("collection-marker")
    return score, reasons


def _find_project_root(path: str, *, scope: Optional[str] = None, max_levels: int = 8) -> Optional[Tuple[str, float, List[str]]]:
    cur = _norm(path)
    if os.path.isfile(cur):
        cur = os.path.dirname(cur)
    stop = _norm(scope) if scope else None
    for _ in range(max_levels):
        if not cur or cur == os.path.dirname(cur):
            break
        if stop and not _path_l(cur).startswith(_path_l(stop)):
            break
        if store.match_ignore_rules(cur):
            break
        score, reasons = _project_marker_score(cur)
        if score > 0 and not _is_generic_container_dir(cur):
            return cur, score, reasons
        nxt = os.path.dirname(cur)
        if nxt == cur:
            break
        cur = nxt
    return None


def memory_queries(memory_text: str = "", *, max_queries: int = 30) -> List[str]:
    text = memory_text or ""
    latin = re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", text)
    chinese = re.findall(r"[\u4e00-\u9fff]{2,10}", text)
    stop = {"the", "and", "with", "from", "that", "this", "agent", "model", "user", "project", "file", "系统", "用户", "当前", "研究", "项目", "实现", "文件", "方向", "需要", "相关", "设计"}
    cnt: Counter[str] = Counter()
    for x in latin + chinese:
        if len(x) <= 42 and x.lower() not in stop and x not in stop:
            cnt[x] += 1
    return [k for k, _ in cnt.most_common(max_queries)]


def merge_queries(agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", *, max_queries: int = 90) -> List[str]:
    out: List[str] = []; seen = set()
    for q in list(agent_queries or []) + memory_queries(memory_text) + DEFAULT_DISCOVERY_QUERIES:
        qs = str(q).strip()
        if qs and qs.lower() not in seen:
            out.append(qs); seen.add(qs.lower())
        if len(out) >= max_queries:
            break
    return out


def _purpose_allows_media(purpose: Optional[str]) -> bool:
    p = (purpose or "").lower()
    return any(x in p for x in ["image", "screenshot", "素材", "图片", "截图", "报销", "invoice", "receipt", "发票", "账单"])


def classify_candidate(row: Dict[str, Any], *, purpose: Optional[str] = None, memory_terms: Optional[Sequence[str]] = None, scope: Optional[str] = None) -> Dict[str, Any]:
    path = _norm(row.get("path", ""))
    reasons: List[str] = []
    score = 0.0
    nt = _node_type(path)
    if nt is None:
        return {"path": path, "hard_exclude": True, "reasons": ["missing-or-unresolved-type"]}
    ignored = store.match_ignore_rules(path)
    if ignored:
        store.append_event("candidate_ignored", path=path, reason="ignore_rule:" + ",".join(ignored), source="builder")
        return {"path": path, "node_type": nt, "hard_exclude": True, "reasons": ["ignore_rule:" + ",".join(ignored)]}
    base = os.path.basename(path); bl = base.lower(); ext = os.path.splitext(bl)[1]
    if nt == "file":
        if ext in TEXTISH_EXTS or bl in ENTRY_BASENAMES or (not ext and bl in {"dockerfile", "makefile", "license"}):
            score += 10; reasons.append("textish-or-entry")
        if bl in ENTRY_BASENAMES:
            score += 14; reasons.append("entry-file")
        if ext in MEDIA_EXTS and not _purpose_allows_media(purpose):
            score -= 12; reasons.append("media-downrank")
        if ext in ARCHIVE_EXTS and not _purpose_allows_media(purpose):
            score -= 5; reasons.append("archive-downrank")
    else:
        ms, mr = _project_marker_score(path)
        if ms:
            score += ms; reasons.extend(mr)
        elif _is_generic_container_dir(path):
            score -= 15; reasons.append("generic-container")
    p_l = _path_l(path)
    for sig in ["mcp", "agent", "trajectory", "轨迹", "元应用", "simulation", "仿真", "paper", "论文", "experiment", "实验", "benchmark", "zotero", "invoice", "receipt", "发票", "账单", "llm", "llama", "paddle", "ocr", "nlp", "diffusion", "ml-agents"]:
        if sig.lower() in p_l:
            score += 5; reasons.append("path-signal:" + sig)
    for term in memory_terms or []:
        t = str(term).lower().strip()
        if t and len(t) >= 3 and t in p_l:
            score += 4; reasons.append("memory-signal:" + str(term)[:30])
    try:
        mt = int(row.get("mtime_ns") or os.stat(path, follow_symlinks=False).st_mtime_ns)
        age_days = max(0, (time.time() - mt / 1e9) / 86400)
        if age_days < 7: score += 14; reasons.append("recent-7d")
        elif age_days < 30: score += 9; reasons.append("recent-30d")
        elif age_days < 180: score += 4; reasons.append("recent-180d")
        elif age_days < 730: score += 1
    except OSError:
        pass
    if _low_value_segment(path):
        score -= 6; reasons.append("low-value-subdir")
    return {"path": path, "node_type": nt, "score": score, "reasons": reasons, "hard_exclude": False, "row": row}


def collect_candidates(agent_queries: Optional[Sequence[str]] = None, *, memory_text: str = "", scope: Optional[str] = None,
                       limit_per_query: int = 160, include_recent: bool = True, recent_limit: int = 2500,
                       purpose: Optional[str] = None) -> List[Dict[str, Any]]:
    queries = merge_queries(agent_queries, memory_text)
    rows: Dict[str, Dict[str, Any]] = {}
    if include_recent:
        try:
            for r in everything.recent(limit=recent_limit, scope=scope):
                rows[_norm(r["path"])] = r
        except Exception as e:
            store.append_event("recent_search_failed", reason=str(e), source="builder")
    for q in queries:
        try:
            for r in everything.search(q, limit=limit_per_query, scope=scope):
                rows[_norm(r["path"])] = r
        except Exception as e:
            store.append_event("query_search_failed", reason=f"{q}: {e}", source="builder")
    terms = memory_queries(memory_text, max_queries=60)
    cands: Dict[str, Dict[str, Any]] = {}
    for r in rows.values():
        c = classify_candidate(r, purpose=purpose, memory_terms=terms, scope=scope)
        if c.get("hard_exclude"):
            continue
        p = c["path"]
        cands[p] = max([c, cands.get(p, c)], key=lambda x: float(x.get("score") or 0))
        root = _find_project_root(p, scope=scope)
        if root:
            rp, bonus, reasons = root
            if not store.match_ignore_rules(rp) and _node_type(rp) == "dir":
                old = cands.get(rp)
                root_c = {"path": rp, "node_type": "dir", "score": float(c.get("score") or 0) + bonus, "reasons": list(set(c.get("reasons", []) + reasons + ["project-root-from-child"])), "hard_exclude": False, "row": {"path": rp, "is_dir": True}}
                if old is None or root_c["score"] > old.get("score", 0):
                    cands[rp] = root_c
    return sorted(cands.values(), key=lambda x: float(x.get("score") or 0), reverse=True)


def diversify_by_parent(cands: Sequence[Dict[str, Any]], *, target: int, per_parent: int = 8) -> List[Dict[str, Any]]:
    buckets: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for c in cands:
        parent = os.path.dirname(c["path"]) if c.get("node_type") == "file" else os.path.dirname(c["path"])
        buckets[parent].append(c)
    for b in buckets.values():
        b.sort(key=lambda x: float(x.get("score") or 0), reverse=True)
    selected: List[Dict[str, Any]] = []
    cap = max(1, per_parent)
    while len(selected) < target:
        changed = False
        for parent in sorted(buckets, key=lambda p: max([x.get("score", 0) for x in buckets[p]] or [0]), reverse=True):
            take = [x for x in buckets[parent] if not x.get("_taken")][:cap]
            for x in take:
                x["_taken"] = True; selected.append(x); changed = True
                if len(selected) >= target:
                    break
            if len(selected) >= target:
                break
        if len(selected) >= target or not changed:
            break
        cap += 2
        if cap > 24:
            break
    return selected[:target]


def _safe_parent_chain(path: str, levels: int, *, scope: Optional[str] = None) -> List[str]:
    out: List[str] = []
    cur = os.path.dirname(_norm(path))
    stop = _norm(scope) if scope else None
    for _ in range(levels):
        if not cur or cur == os.path.dirname(cur):
            break
        if stop and not _path_l(cur).startswith(_path_l(stop)):
            break
        if store.match_ignore_rules(cur) or _is_generic_container_dir(cur):
            cur = os.path.dirname(cur); continue
        if _node_type(cur) == "dir":
            out.append(cur)
        cur = os.path.dirname(cur)
    return out


def build_nodes_for_pool(cands: Sequence[Dict[str, Any]], *, target_nodes: int = 1000, max_active: int = 220, parent_levels: int = 2, scope: Optional[str] = None) -> List[Dict[str, Any]]:
    # Oversampled high-value candidates are staged; not all must be used.
    fileish: List[Dict[str, Any]] = []
    dirs: Dict[str, Dict[str, Any]] = {}
    for c in cands:
        p = c["path"]; nt = c["node_type"]
        if nt == "dir":
            dirs[p] = {"path": p, "node_type": "dir", "score": c.get("score", 0), "reasons": c.get("reasons", []), "children": []}
        else:
            fileish.append(c)
            for par in _safe_parent_chain(p, parent_levels, scope=scope):
                d = dirs.setdefault(par, {"path": par, "node_type": "dir", "score": 0.0, "reasons": [], "children": []})
                d["score"] += max(float(c.get("score") or 0) * 0.08, 1)
                d["children"].append(os.path.basename(p))
    nodes: List[Dict[str, Any]] = []
    for d in dirs.values():
        if store.match_ignore_rules(d["path"]):
            continue
        child_count = len(d.get("children") or [])
        score = float(d.get("score") or 0) + min(child_count, 20)
        if child_count < 2 and score < 25:
            continue
        suggested = "active" if score >= 45 else "warm" if score >= 20 else "cold"
        nodes.append({
            "path": d["path"], "node_type": "dir", "suggested_tier": suggested, "seed_score": score,
            "evidence": [f"children_in_pool={child_count}"] + list(d.get("reasons", []))[:8] + list(d.get("children", []))[:8],
            "relation": {"child_count": child_count, "sample_children": list(d.get("children", []))[:12]},
            "visible_terms": sorted(store.visible_terms(d["path"]))[:30],
        })
    for c in fileish:
        score = float(c.get("score") or 0)
        suggested = "active" if score >= 32 else "warm" if score >= 12 else "cold"
        nodes.append({
            "path": c["path"], "node_type": "file", "suggested_tier": suggested, "seed_score": score,
            "evidence": c.get("reasons", [])[:14],
            "relation": {"parent": os.path.dirname(c["path"]), "basename": os.path.basename(c["path"]), "ext": os.path.splitext(c["path"])[1]},
            "visible_terms": sorted(store.visible_terms(c["path"]))[:30],
        })
    # Stage high scoring dir/file mix. Prefer dirs, but keep majority files.
    nodes.sort(key=lambda x: (x["node_type"] == "dir", float(x.get("seed_score") or 0)), reverse=True)
    return nodes[:max(target_nodes, len(nodes))]


def prepare_cold_start(conn, *, target_nodes: int = 1000, max_active: int = 220, scope: Optional[str] = None,
                       agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", purpose: Optional[str] = None,
                       recent_limit: int = 3000, limit_per_query: int = 180, parent_levels: int = 2) -> Dict[str, Any]:
    target = max(20, int(target_nodes)); stage_target = int(target * 1.65)
    cands = collect_candidates(agent_queries, memory_text=memory_text, scope=scope, limit_per_query=limit_per_query, include_recent=True, recent_limit=recent_limit, purpose=purpose)
    selected = diversify_by_parent(cands, target=stage_target, per_parent=8)
    nodes = build_nodes_for_pool(selected, target_nodes=stage_target, max_active=max_active, parent_levels=parent_levels, scope=scope)
    nodes = nodes[:stage_target]
    sid = "cs_" + hashlib.sha1((str(time.time()) + str(scope) + str(len(nodes))).encode()).hexdigest()[:12]
    now = time.time()
    conn.execute("INSERT INTO build_sessions(session_id,status,target_nodes,max_active,created_at,updated_at,meta) VALUES(?,?,?,?,?,?,?)", (sid, "open", target, max_active, now, now, json.dumps({"scope": scope, "candidate_count": len(cands), "staged_items": len(nodes)}, ensure_ascii=False)))
    for n in nodes:
        conn.execute("""INSERT OR REPLACE INTO build_items(session_id,path,node_type,suggested_tier,seed_score,evidence,relation,visible_terms,status,batch_no,created_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?, 'pending',0,?,?)""",
                     (sid, n["path"], n["node_type"], n["suggested_tier"], float(n.get("seed_score") or 0), json.dumps(n.get("evidence", []), ensure_ascii=False), json.dumps(n.get("relation", {}), ensure_ascii=False), json.dumps(n.get("visible_terms", []), ensure_ascii=False), now, now))
    store.append_event("cold_start_started", reason=sid, source="builder", extra={"target_nodes": target, "staged_items": len(nodes), "candidate_count": len(cands), "scope": scope})
    conn.commit()
    return {"ok": True, "session_id": sid, "candidate_count": len(cands), "staged_items": len(nodes), "target_nodes": target, "max_active": max_active, "remaining_to_target": target}


def cold_start_batch(conn, session_id: str, *, batch_size: int = 50) -> Dict[str, Any]:
    rows = conn.execute("SELECT * FROM build_items WHERE session_id=? AND status='pending' ORDER BY seed_score DESC LIMIT ?", (session_id, max(1, int(batch_size)))).fetchall()
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    applied = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    items = []
    for r in rows:
        items.append({
            "path": r["path"], "node_type": r["node_type"], "suggested_tier": r["suggested_tier"], "seed_score": r["seed_score"],
            "visible_terms": json.loads(r["visible_terms"] or "[]"), "evidence": json.loads(r["evidence"] or "[]"), "relation": json.loads(r["relation"] or "{}"),
            "required_output": {"brief": "specific one-line value statement", "tags": "1-3 high-information residual tags for active/warm; cold may omit tags"},
        })
    return {"ok": True, "session_id": session_id, "pending": pending, "applied": applied, "items": items}


def _staged_map(conn, session_id: str) -> Dict[str, Dict[str, Any]]:
    return {r["path"]: dict(r) for r in conn.execute("SELECT * FROM build_items WHERE session_id=?", (session_id,))}


def apply_index_plan(conn, plan: Sequence[Dict[str, Any]], *, default_tier: str = "warm", default_state: Optional[str] = None, default_source: str = "agent-builder", enforce_tag_gate: bool = True, fts_ok: bool = False, session_id: Optional[str] = None) -> Dict[str, Any]:
    staged = _staged_map(conn, session_id) if session_id else {}
    applied = 0; skipped = 0; errors: List[Dict[str, Any]] = []; rejected_tags: List[Dict[str, str]] = []
    now = time.time()
    for item in plan:
        p = _norm(item.get("path", ""))
        if not p:
            errors.append({"item": item, "error": "missing path"}); continue
        if item.get("action") == "skip":
            if session_id and p in staged:
                conn.execute("UPDATE build_items SET status='skipped',updated_at=? WHERE session_id=? AND path=?", (now, session_id, p))
            store.append_event("cold_start_skipped", path=p, reason=str(item.get("reason") or "agent skip"), source=item.get("source") or default_source)
            skipped += 1; continue
        if session_id and p not in staged:
            errors.append({"item": item, "error": "path not in cold-start staged items; do not invent paths"})
            store.append_event("session_path_rejected", path=p, reason="not_in_build_items", source="builder")
            continue
        if not os.path.exists(p):
            errors.append({"item": item, "error": "path does not exist"}); continue
        if store.match_ignore_rules(p):
            errors.append({"item": item, "error": "path matches ignore_rules"}); continue
        inferred = store.infer_node_type(p)
        nt = item.get("node_type") or (staged.get(p) or {}).get("node_type") or inferred
        if inferred is None or nt != inferred or nt not in {"file", "dir"}:
            errors.append({"item": item, "error": f"invalid node_type; inferred {inferred}"}); continue
        tier = item.get("tier") or item.get("state") or default_state or default_tier
        if tier not in {"active", "warm", "cold"}:
            errors.append({"item": item, "error": "tier must be active/warm/cold"}); continue
        brief = (item.get("brief") or "").strip()
        if (tier in {"active", "warm"} or session_id) and store.bad_brief_reason(brief, p):
            errors.append({"item": item, "error": f"bad brief: {store.bad_brief_reason(brief, p)}"}); continue
        extra_visible = []
        if session_id and p in staged:
            try: extra_visible = json.loads(staged[p].get("visible_terms") or "[]")
            except Exception: extra_visible = []
        tags = item.get("tags") or []
        kept, rejected = store.filter_high_info_tags(tags, p, extra_visible=extra_visible) if enforce_tag_gate else (store.normalize_tags(tags), [])
        if tier in {"active", "warm"} and not kept:
            errors.append({"item": item, "error": "active/warm requires at least one valid high-info tag", "rejected_tags": rejected}); continue
        evidence = item.get("evidence") if "evidence" in item else (json.loads(staged[p]["evidence"]) if session_id and p in staged else [])
        relation = item.get("relation") if "relation" in item else (json.loads(staged[p]["relation"]) if session_id and p in staged else {})
        res = store.annotate_node(conn, p, kept, brief=brief, node_type=nt, tier=tier, source=item.get("source") or default_source, confidence=item.get("confidence") or "agent-judged", seed_score=float(item.get("seed_score") if "seed_score" in item else (staged.get(p, {}).get("seed_score") or 0)), evidence=evidence, relation=relation, enforce_tag_gate=False, fts_ok=fts_ok)
        if not res.get("ok"):
            errors.append({"item": item, "error": res.get("error")}); continue
        for r in rejected:
            rejected_tags.append({p: r})
        if session_id:
            conn.execute("UPDATE build_items SET status='applied',updated_at=? WHERE session_id=? AND path=?", (now, session_id, p))
        applied += 1
    conn.commit()
    return {"applied": applied, "skipped": skipped, "errors": errors, "rejected_tags": rejected_tags}


def cold_start_status(conn, session_id: str) -> Dict[str, Any]:
    sess = conn.execute("SELECT * FROM build_sessions WHERE session_id=?", (session_id,)).fetchone()
    if not sess:
        return {"ok": False, "error": "session not found", "session_id": session_id}
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    applied = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    skipped = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='skipped'", (session_id,)).fetchone()[0]
    target = int(sess["target_nodes"])
    return {"ok": True, "session_id": session_id, "status": sess["status"], "pending": pending, "applied": applied, "skipped": skipped, "target_nodes": target, "remaining_to_target": max(0, target - applied), "max_active": sess["max_active"]}


def audit_index(conn, *, fix: bool = False, fts_ok: bool = False) -> Dict[str, Any]:
    missing: List[str] = []; ignored: List[str] = []; bad_tags: List[Dict[str, str]] = []; bad_briefs: List[str] = []; bad_types: List[str] = []; active_without_tags: List[str] = []
    for r in conn.execute("SELECT path,node_type,tier,brief FROM nodes"):
        p = r["path"]
        if r["node_type"] not in {"file", "dir"}:
            bad_types.append(p)
        if not os.path.exists(p):
            missing.append(p)
        m = store.match_ignore_rules(p)
        if m:
            ignored.append(p)
        if r["tier"] in {"active", "warm"}:
            if store.bad_brief_reason(r["brief"] or "", p):
                bad_briefs.append(p)
            tag_n = conn.execute("SELECT COUNT(*) FROM node_tags WHERE path=?", (p,)).fetchone()[0]
            if tag_n == 0:
                active_without_tags.append(p)
    for r in conn.execute("SELECT path,tag FROM node_tags"):
        kept, rejected = store.filter_high_info_tags([r["tag"]], r["path"])
        if rejected:
            bad_tags.append({r["path"]: r["tag"]})
    if fix:
        for p in set(missing + ignored + bad_types):
            store.delete_node(conn, p, reason="audit_fix_remove_unusable", source="audit", fts_ok=fts_ok)
        for bt in bad_tags:
            for p, tag in bt.items():
                conn.execute("DELETE FROM node_tags WHERE path=? AND tag=?", (p, tag))
                store.append_event("audit_bad_tag_deleted", path=p, tag=tag, reason="bad_tag", source="audit")
        conn.commit(); store.fts_rebuild_all(conn, fts_ok=fts_ok)
    return {"nodes_total": conn.execute("SELECT COUNT(*) FROM nodes").fetchone()[0], "missing_paths": len(missing), "ignored_rule_violations": len(ignored), "bad_node_types": len(bad_types), "bad_tag_count": len(bad_tags), "generic_brief_count": len(bad_briefs), "active_warm_without_tags": len(active_without_tags), "samples": {"missing": missing[:10], "ignored": ignored[:10], "bad_tags": bad_tags[:10], "bad_briefs": bad_briefs[:10], "active_warm_without_tags": active_without_tags[:10]}, "fixed": bool(fix)}


def finish_cold_start(conn, session_id: str, *, max_nodes: int = 1000, max_active: int = 220, fts_ok: bool = False) -> Dict[str, Any]:
    status = cold_start_status(conn, session_id)
    if not status.get("ok"):
        return status
    if status["applied"] < status["target_nodes"]:
        return {"ok": False, "error": "not enough applied high-quality nodes; continue cold_start_batch + apply_index_plan", **status}
    now = time.time()
    conn.execute("UPDATE build_items SET status='skipped',updated_at=? WHERE session_id=? AND status='pending'", (now, session_id))
    conn.execute("UPDATE build_sessions SET status='finished',updated_at=? WHERE session_id=?", (now, session_id))
    audit = audit_index(conn, fix=True, fts_ok=fts_ok)
    reb = store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, fts_ok=fts_ok)
    store.append_event("cold_start_finished", reason=session_id, source="builder", extra={"applied": status["applied"], "audit": audit, "rebalance": reb})
    conn.commit()
    return {"ok": True, "session_id": session_id, "applied": status["applied"], "audit": audit, "rebalance": reb}


def label_worklist(conn, *, limit: int = 80, node_types: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
    cond = ["(brief='' OR path NOT IN (SELECT path FROM node_tags))"]
    params: List[Any] = []
    if node_types:
        nts = [x for x in node_types if x in {"file", "dir"}]
        if nts:
            cond.append("node_type IN (%s)" % ",".join("?" * len(nts))); params.extend(nts)
    rows = conn.execute(f"SELECT path,node_type,tier,brief,seed_score,evidence,relation FROM nodes WHERE {' AND '.join(cond)} ORDER BY tier='active' DESC,seed_score DESC LIMIT ?", (*params, limit)).fetchall()
    return [{"path": r["path"], "node_type": r["node_type"], "tier": r["tier"], "brief": r["brief"], "seed_score": r["seed_score"], "evidence": json.loads(r["evidence"] or "[]"), "relation": json.loads(r["relation"] or "{}"), "visible_terms": sorted(store.visible_terms(r["path"]))[:30]} for r in rows]


def miss_recovery_batch(conn, query: str, *, memory_text: str = "", scope: Optional[str] = None, limit: int = 80) -> Dict[str, Any]:
    cands = collect_candidates([query], memory_text=memory_text, scope=scope, limit_per_query=max(80, limit), include_recent=False, recent_limit=0)
    nodes = build_nodes_for_pool(diversify_by_parent(cands, target=limit, per_parent=6), target_nodes=limit, scope=scope)
    return {"ok": True, "query": query, "items": nodes[:limit], "instruction": "Agent should choose useful real paths, write specific brief + high-info tags, then call apply_index_plan(plan)."}
