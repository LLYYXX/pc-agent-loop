"""file_index_sop v7: high-quality Agent-driven semantic coverage over Everything/es.exe."""
__version__ = "v7"
