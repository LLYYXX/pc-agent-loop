# file_index_sop v29 — cold start review SOP

Use this only when the user asks to build or rebuild an initial index for a scope such as `F:\`.

Cold start is a **single-candidate semantic review process**, not a batch classification task. Helper provides candidates, review evidence, session status, and storage. It does not generate semantic route tags.

## Import and start

```python
from file_index_sop import *
ensure_search_ready(start=True, patch=True)
init_db()
res = begin_cold_start(scope="F:\\", target_nodes=1000)
sid = res["session_id"]
collect_cold_start_entries(sid)
```

`target_nodes` is a budget/cap hint, not a required commit count.

## Main review loop

Use this one-candidate transaction loop:

```python
item = next_review_candidate(sid)
if item.get("done"):
    finish_cold_start(sid)
else:
    review = review_candidate(sid, item["candidate_id"])
```

Read `review["evidence_items"]`. Every evidence item has an `id` such as `ev_001`.

Then choose exactly one action:

```python
# Apply only when the route tag is directly supported by evidence ids.
commit_review(
    sid,
    review_id=review["review_id"],
    decision="apply",
    brief="Agent-written scope description grounded in the reviewed evidence",
    route_tags=["specific-route-tag"],
    facets=["optional-diagnostic-facet"],
    evidence_refs=["ev_002", "ev_004"],
    evidence_note="Based on ev_002 and ev_004: ...",
    leaf_candidates=["optional representative paths from the reviewed evidence"]
)

# Defer when evidence is insufficient, generic-looking, small, Office-heavy, or otherwise unknown.
commit_review(
    sid,
    review_id=review["review_id"],
    decision="defer",
    evidence_note="Evidence insufficient for a high-confidence route tag."
)

# Skip only for confirmed reasons: duplicate/already-indexed, out-of-scope,
# system/dependency/build, confirmed-noise, user-excluded, or not-useful-after-expanded-evidence.
commit_review(
    sid,
    review_id=review["review_id"],
    decision="skip",
    reason="duplicate: already covered by parent entry"
)

# Need more evidence when this review packet is not enough.
commit_review(
    sid,
    review_id=review["review_id"],
    decision="need_more_evidence",
    evidence_note="Need more document heads or deeper sample before tagging."
)
```

## Important API shape

`cold_start_batch(...)` is diagnostic only in v29. Do not use it as the build loop.

Do not call bulk `apply_index_plan(plans, session_id=sid)` for cold-start entry creation. In v29, cold-start commits must bind a `review_id` and reviewed evidence item ids through `commit_review`.

## Route tags vs facets

Route tags are semantic search routes. Facets are diagnostic/file-form/technology hints.

Weak labels such as `python-code`, `python-project`, `web-frontend`, `java-code`, `cpp-code`, `documents`, `document-archive`, `pdf-documents`, `presentations`, `data-files`, `markdown-docs`, `wechat-files`, `workspace`, `project`, `general`, `archive`, `materials`, and `course-materials` may be useful as facets, but must not be the only route tags.

If the review only supports weak facets, defer rather than commit a route-tagged entry.

## Finish

```python
finish = finish_cold_start(sid)
audit = audit_index()
summary = index_summary()
```

Finish status semantics:
- `complete`: broad verified coverage and healthy review protocol.
- `usable_partial`: some high-confidence review-backed entries exist and protocol is healthy.
- `incomplete`: pending or needs-more-evidence work remains, but no severe pollution.
- `protocol_unhealthy`: bulk/classifier-style commits, weak tags dominate, review coverage is poor, 0 leaf with many entries, or template evidence dominates.
- `failed`: tool failure, no usable entries, or unusable state.

Entry counts are diagnostics/reference targets, not failure thresholds. Never lower evidence standards to increase counts.

## Do not

- do not write `for item in batch` classifiers;
- do not derive route tags from file extensions, file mix, children count, or path words;
- do not use `Based on file mix...` as evidence for route tags;
- do not commit weak facets as route tags;
- do not skip because of `children_count < 3`, `Generic directory`, unsupported extension, or Office/document-heavy content;
- do not call a small or protocol-unhealthy index complete.
