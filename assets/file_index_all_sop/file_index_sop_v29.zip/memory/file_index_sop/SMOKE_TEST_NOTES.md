# v29 smoke test notes

- `from file_index_sop import *` imports v29 review APIs.
- `cold_start_batch` is diagnostic-only.
- bulk `apply_index_plan(..., session_id=sid)` with multiple apply items is rejected.
- `next_review_candidate -> review_candidate -> commit_review` succeeds for an evidence-backed route tag.
- weak/type-only tags are treated as facets or rejected as insufficient route tags.
- `finish_cold_start` includes `protocol_health` and can return `protocol_unhealthy`.
- runtime v27/v28 fixes remain: `recall_hits`, `search_files_rows/paths`, `finish_local_file_task`, `record_correction`, `audit_runtime`.
