"""Cold-start scaffold for file_index_sop v24.

Cold start is Agent-led. This module keeps a session ledger, collects factual
candidate entry directories with configurable discovery weights, returns isolated
evidence packets, and reports progress. It never generates route tags or briefs.
"""
from __future__ import annotations

import json
import os
import re
import time
import uuid
from collections import Counter
from typing import Any, Dict, List, Optional, Sequence

from . import everything
from .policy import load_index_policy
from .store import conn, stats as index_stats


def _now() -> float:
    return time.time()


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _scope_contains(scope: str, path: str) -> bool:
    try:
        s = _norm(scope)
        p = _norm(path)
        return os.path.commonpath([s, p]) == s
    except Exception:
        return False


def _parts(path: str) -> List[str]:
    return [x.lower() for x in re.split(r"[\\/]+", _norm(path)) if x]


def _hard_ignored(path: str, policy: Optional[Dict[str, Any]] = None) -> bool:
    """Only exact high-confidence system/dependency/build dirs are hard ignored."""
    p = policy or load_index_policy()
    cd = p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}
    hard = set(str(x).lower() for x in cd.get("hard_ignore_dirs", []))
    return any(part in hard for part in _parts(path))


def _is_hashlike_name(name: str) -> bool:
    """Conservative hash/random-looking basename detector.

    Mixed-case human-readable names must not be penalized.
    """
    base = str(name or "").strip()
    if not base:
        return False
    if re.fullmatch(r"[a-f0-9]{10,}", base.lower()):
        return True
    if len(base) >= 16:
        digits = sum(ch.isdigit() for ch in base)
        alpha = sum(ch.isalpha() for ch in base)
        if digits >= 6 and digits / max(1, len(base)) > 0.35:
            return True
        # long no-separator lowercase/digit blobs are suspicious, but only when
        # they do not look like ordinary words/names.
        if re.fullmatch(r"[a-z0-9]{18,}", base) and digits >= 3:
            return True
    return False


def _soft_noise(path: str, policy: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Soft downrank only. Never removes a candidate from factual search."""
    p = policy or load_index_policy()
    cd = p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}
    terms = [str(x).lower() for x in cd.get("soft_downrank_terms", [])]
    hits = []
    parts = _parts(path)
    for part in parts:
        for t in terms:
            if t and t in part:
                hits.append(t)
    score = min(50, len(set(hits)) * 12)
    base = os.path.basename(_norm(path))
    if _is_hashlike_name(base):
        hits.append("hashlike-name")
        score += 8
    return {"score": score, "reasons": sorted(set(hits))}

def _mtime_ns(path: str) -> int:
    try:
        st = os.stat(path, follow_symlinks=False)
        return int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
    except OSError:
        return 0


def _cold_policy() -> Dict[str, Any]:
    p = load_index_policy()
    return p.get("cold_start", {}) if isinstance(p.get("cold_start"), dict) else {}


def _candidate_discovery() -> Dict[str, Any]:
    p = load_index_policy()
    return p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}


def _default_queries() -> List[str]:
    cd = _candidate_discovery()
    q = cd.get("default_queries")
    if isinstance(q, list):
        return [str(x).strip() for x in q if str(x).strip()]
    return ["*.md", "*.txt", "*.pdf", "README.md"]


def _priority(path: str, *, source: str, source_mtime_ns: int = 0) -> float:
    p = _norm(path)
    mt = max(_mtime_ns(p), int(source_mtime_ns or 0))
    score = 0.0
    if source == "top_level":
        score += 75
    elif source == "second_level":
        score += 68
    elif source == "recent_parent":
        score += 58
    elif source.startswith("query_parent:"):
        score += 55
    else:
        score += 40
    if os.path.isdir(p):
        score += 10
        try:
            sample = dirs = files = 0
            exts: set[str] = set()
            hashlike_dirs = 0
            doc_or_text_files = 0
            evidence_files = 0
            cd = _candidate_discovery()
            doc_exts = set(str(x).lower() for x in cd.get("document_extensions", []))
            text_exts = set(str(x).lower() for x in cd.get("text_extensions", []))
            evidence_names = set(str(x).lower() for x in cd.get("evidence_file_names", []))
            with os.scandir(p) as it:
                for ent in it:
                    if sample >= 80:
                        break
                    if _hard_ignored(ent.path):
                        continue
                    sample += 1
                    name_l = ent.name.lower()
                    if ent.is_dir(follow_symlinks=False):
                        dirs += 1
                        if re.fullmatch(r"[a-f0-9]{8,}|[a-z0-9]{10,}", name_l):
                            hashlike_dirs += 1
                    elif ent.is_file(follow_symlinks=False):
                        files += 1
                        ext = os.path.splitext(ent.name)[1].lower()
                        exts.add(ext)
                        if ext in doc_exts or ext in text_exts:
                            doc_or_text_files += 1
                        if name_l in evidence_names:
                            evidence_files += 1
            if dirs:
                score += min(14, dirs)
            if files:
                score += min(8, files / 4)
            if len(exts) > 1:
                score += min(8, len(exts))
            # Candidate discovery may prioritize useful evidence types, but it must not
            # semantically classify the directory. These are only structural boosts.
            if doc_or_text_files:
                score += min(14, doc_or_text_files * 2)
            if evidence_files:
                score += min(16, evidence_files * 4)
            # Auto-generated/container-like structure is a soft penalty only. It never
            # excludes the path, and explicit Agent/user exploration can still index it.
            if hashlike_dirs and not (doc_or_text_files or evidence_files):
                score -= min(30, hashlike_dirs * 10)
            if sample <= 2 and not (doc_or_text_files or evidence_files):
                score -= 10
        except OSError:
            pass
    if mt:
        age_days = max(0.0, (_now() - mt / 1e9) / 86400.0)
        if age_days < 3:
            score += 16
        elif age_days < 14:
            score += 10
        elif age_days < 60:
            score += 5
    score -= _soft_noise(p)["score"]
    return score


def _parent_entries_for_path(path: str, scope: str, parent_levels: int = 2) -> List[str]:
    p = _norm(path)
    scope = _norm(scope)
    if os.path.isdir(p):
        return [p] if _scope_contains(scope, p) and not _hard_ignored(p) else []
    if not os.path.isfile(p):
        return []
    out: List[str] = []
    cur = os.path.dirname(p)
    for _ in range(max(1, int(parent_levels))):
        if not cur or cur == os.path.dirname(cur):
            break
        if _scope_contains(scope, cur) and not _hard_ignored(cur):
            out.append(cur)
        cur = os.path.dirname(cur)
    return list(dict.fromkeys(out))


def _ensure_tables() -> None:
    c = conn()
    try:
        c.execute("""CREATE TABLE IF NOT EXISTS cold_sessions (
          session_id TEXT PRIMARY KEY,
          scope TEXT NOT NULL,
          target_nodes INTEGER NOT NULL DEFAULT 1000,
          status TEXT NOT NULL DEFAULT 'open',
          collection_done INTEGER NOT NULL DEFAULT 0,
          rounds INTEGER NOT NULL DEFAULT 0,
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS cold_candidates (
          session_id TEXT NOT NULL,
          path TEXT NOT NULL,
          node_type TEXT NOT NULL DEFAULT 'dir',
          status TEXT NOT NULL DEFAULT 'pending',
          priority REAL NOT NULL DEFAULT 0,
          source TEXT NOT NULL DEFAULT '',
          source_paths_json TEXT NOT NULL DEFAULT '[]',
          evidence_json TEXT NOT NULL DEFAULT '{}',
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL,
          PRIMARY KEY(session_id, path)
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cold_candidates_status ON cold_candidates(session_id,status,priority)")
        c.commit()
    finally:
        c.close()


def begin_cold_start(scope: str, *, target_nodes: int = 1000, reset_session: bool = False) -> Dict[str, Any]:
    _ensure_tables()
    sc = _norm(scope)
    sid = "cs_" + uuid.uuid4().hex[:12]
    c = conn()
    try:
        t = _now()
        if reset_session:
            c.execute("DELETE FROM cold_sessions WHERE scope=?", (sc,))
        c.execute(
            "INSERT INTO cold_sessions(session_id,scope,target_nodes,status,created_at,updated_at) VALUES(?,?,?,?,?,?)",
            (sid, sc, int(target_nodes), "open", t, t),
        )
        c.commit()
        return {"ok": True, "session_id": sid, "scope": sc, "target_nodes": int(target_nodes), "next": "collect_cold_start_entries(session_id), cold_start_batch(session_id), Agent annotates, apply_index_plan(..., session_id=session_id)."}
    finally:
        c.close()


def _session(session_id: str) -> Optional[Dict[str, Any]]:
    _ensure_tables()
    c = conn()
    try:
        r = c.execute("SELECT * FROM cold_sessions WHERE session_id=?", (session_id,)).fetchone()
        return dict(r) if r else None
    finally:
        c.close()


def _read_head(path: str, max_chars: int) -> Optional[str]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read(max_chars).replace("\x00", "").strip()
    except Exception:
        return None


def _text_exts() -> set[str]:
    p = load_index_policy()
    cd = p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}
    return set(str(x).lower() for x in cd.get("text_extensions", []))


def _candidate_evidence(path: str, source_paths: Sequence[str], *, expanded: bool = False) -> Dict[str, Any]:
    """Return evidence packet for a candidate.

    Rough batch evidence is for triage only. Expanded evidence includes document
    heads and is required before applying a tagged entry during cold start.
    """
    p = _norm(path)
    noise = _soft_noise(p)
    pol = load_index_policy()
    max_children = int(pol.get("evidence_max_children", 80) or 80)
    max_heads = int(pol.get("evidence_max_heads", 3) or 3)
    max_head_chars = int(pol.get("text_head_max_chars", 1200) or 1200)
    text_exts = _text_exts()
    ev: Dict[str, Any] = {
        "path": p,
        "node_type": "dir" if os.path.isdir(p) else "file",
        "soft_downrank": noise,
        "source_seed_paths": list(dict.fromkeys(str(x) for x in source_paths))[:20],
        "evidence_level": "expanded" if expanded else "rough",
        "evidence_sufficient_for_tag": bool(expanded),
        "next": "call expand_candidate(session_id, path) before apply" if not expanded else "Agent may annotate from this packet or gather more evidence if still unsure",
    }
    if os.path.isfile(p):
        ext = os.path.splitext(p)[1].lower()
        ev["extension"] = ext
        if expanded and ext in text_exts:
            head = _read_head(p, max_head_chars)
            if head:
                ev["content_head"] = head
        return ev
    if os.path.isdir(p):
        children: List[Dict[str, Any]] = []
        heads: List[Dict[str, Any]] = []
        ext_counter: Counter[str] = Counter()
        try:
            with os.scandir(p) as it:
                for ent in it:
                    if len(children) >= max_children:
                        break
                    if _hard_ignored(ent.path):
                        continue
                    is_dir = ent.is_dir(follow_symlinks=False)
                    is_file = ent.is_file(follow_symlinks=False)
                    ext = os.path.splitext(ent.name)[1].lower() if is_file else ""
                    if ext:
                        ext_counter[ext] += 1
                    item: Dict[str, Any] = {"name": ent.name, "path": os.path.normpath(ent.path), "is_dir": is_dir, "is_file": is_file, "extension": ext, "soft_downrank": _soft_noise(ent.path)}
                    try:
                        st = ent.stat(follow_symlinks=False)
                        item["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
                        item["size"] = int(st.st_size)
                    except OSError:
                        pass
                    children.append(item)
                    if expanded and is_file and len(heads) < max_heads and ext in text_exts:
                        head = _read_head(ent.path, max_head_chars)
                        if head:
                            heads.append({
                                "path": os.path.normpath(ent.path),
                                "name": ent.name,
                                "head": head,
                                "note": "Evidence for this child only. Distinguish current entry's own purpose from external references/examples/dependencies.",
                            })
        except OSError as e:
            ev["scandir_error"] = str(e)
        ev["children_sample"] = children
        ev["file_type_mix_sampled"] = dict(ext_counter.most_common(20))
        if expanded:
            ev["document_heads"] = heads
    ev["annotation_contract"] = [
        "Agent decides brief/route_tags; helper does not infer semantics.",
        "Rough batch evidence is not enough for apply; expand_candidate first.",
        "Soft downrank reasons are warnings only, not exclusion rules.",
        "Route tags must describe this path's main search use and need evidence_note.",
        "Do not use sibling/neighbor project semantics as evidence.",
        "Do not turn external references, templates, examples, or dependencies into parent route tags.",
        "If expanded evidence is still insufficient, skip or defer.",
    ]
    return ev

def _upsert_candidate(session_id: str, path: str, *, source: str, source_paths: Sequence[str], priority: float) -> None:
    p = _norm(path)
    if _hard_ignored(p):
        return
    ev = _candidate_evidence(p, source_paths)
    c = conn()
    try:
        t = _now()
        old = c.execute("SELECT priority,source_paths_json,source FROM cold_candidates WHERE session_id=? AND path=?", (session_id, p)).fetchone()
        if old:
            old_paths = json.loads(old["source_paths_json"] or "[]")
            merged = list(dict.fromkeys(old_paths + list(source_paths)))[:50]
            new_priority = max(float(old["priority"] or 0), float(priority))
            new_source = old["source"] if source in old["source"] else f"{old['source']};{source}"
            ev["source_seed_paths"] = merged[:20]
            c.execute("UPDATE cold_candidates SET priority=?,source=?,source_paths_json=?,evidence_json=?,updated_at=? WHERE session_id=? AND path=?", (new_priority, new_source, json.dumps(merged, ensure_ascii=False), json.dumps(ev, ensure_ascii=False), t, session_id, p))
        else:
            c.execute("INSERT INTO cold_candidates(session_id,path,node_type,status,priority,source,source_paths_json,evidence_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)", (session_id, p, "dir" if os.path.isdir(p) else "file", "pending", float(priority), source, json.dumps(list(source_paths), ensure_ascii=False), json.dumps(ev, ensure_ascii=False), t, t))
        c.commit()
    finally:
        c.close()


def collect_cold_start_entries(session_id: str, *, max_candidates: Optional[int] = None, queries: Optional[Sequence[str]] = None, recent_limit: Optional[int] = None, limit_per_query: Optional[int] = None) -> Dict[str, Any]:
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    scope = s["scope"]
    pol = _cold_policy()
    max_candidates = int(max_candidates if max_candidates is not None else pol.get("max_candidates", 300))
    recent_limit = int(recent_limit if recent_limit is not None else pol.get("recent_limit", 500))
    limit_per_query = int(limit_per_query if limit_per_query is not None else pol.get("limit_per_query", 120))
    parent_levels = int(pol.get("parent_levels", 2) or 2)
    before = cold_start_status(session_id).get("total_candidates", 0)
    added_sources: Dict[str, int] = {}

    def add(path: str, source: str, source_paths: Sequence[str], source_mtime_ns: int = 0) -> None:
        if len_status_candidates(session_id) >= max_candidates:
            return
        if not _scope_contains(scope, path) or _hard_ignored(path):
            return
        pr = _priority(path, source=source, source_mtime_ns=source_mtime_ns)
        _upsert_candidate(session_id, path, source=source, source_paths=source_paths, priority=pr)
        added_sources[source] = added_sources.get(source, 0) + 1

    # Top-level / second-level directory sampling: recovers old-project roots without semantic rules.
    if os.path.isdir(scope):
        top_limit = int(pol.get("top_level_limit", 120) or 120)
        second_limit = int(pol.get("second_level_limit_per_parent", 80) or 80)
        top_dirs: List[str] = []
        try:
            with os.scandir(scope) as it:
                for ent in it:
                    if len(top_dirs) >= top_limit:
                        break
                    if ent.is_dir(follow_symlinks=False) and not _hard_ignored(ent.path):
                        top_dirs.append(ent.path)
                        add(ent.path, "top_level", [ent.path])
        except OSError:
            pass
        for td in top_dirs:
            try:
                seen = 0
                with os.scandir(td) as it:
                    for ent in it:
                        if seen >= second_limit:
                            break
                        if ent.is_dir(follow_symlinks=False) and not _hard_ignored(ent.path):
                            seen += 1
                            add(ent.path, "second_level", [ent.path])
            except OSError:
                continue

    # Recent files are seeds; parent directories become candidates.
    try:
        for row in everything.recent(scope=scope, limit=recent_limit):
            p = row.get("path") if isinstance(row, dict) else str(row)
            if not p:
                continue
            mt = int(row.get("mtime_ns") or 0) if isinstance(row, dict) else 0
            for parent in _parent_entries_for_path(p, scope, parent_levels):
                add(parent, "recent_parent", [p], mt)
    except Exception:
        pass

    # Query/file-pattern seeds become parent candidates, not route tags.
    qlist = [str(x) for x in (queries or _default_queries()) if str(x).strip()]
    for q in qlist:
        try:
            for row in everything.search(q, scope=scope, limit=limit_per_query):
                p = row.get("path") if isinstance(row, dict) else str(row)
                if not p:
                    continue
                for parent in _parent_entries_for_path(p, scope, parent_levels):
                    add(parent, f"query_parent:{q}", [p])
        except Exception:
            continue

    c = conn()
    try:
        c.execute("UPDATE cold_sessions SET rounds=rounds+1,collection_done=1,updated_at=? WHERE session_id=?", (_now(), session_id))
        c.commit()
    finally:
        c.close()
    after = cold_start_status(session_id).get("total_candidates", 0)
    return {"ok": True, "session_id": session_id, "added": int(after) - int(before), "total_candidates": after, "sources": added_sources, "next": "cold_start_batch(session_id); Agent writes brief/tags; apply_index_plan(..., session_id=session_id)."}


def len_status_candidates(session_id: str) -> int:
    c = conn()
    try:
        return int(c.execute("SELECT COUNT(*) FROM cold_candidates WHERE session_id=?", (session_id,)).fetchone()[0])
    finally:
        c.close()


def cold_start_batch(session_id: str, batch_size: Optional[int] = None, include_needs_more_evidence: bool = False) -> Dict[str, Any]:
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    pol = _cold_policy()
    batch_size = int(batch_size if batch_size is not None else pol.get("default_batch_size", 8))
    statuses = ["pending"] + (["needs_more_evidence"] if include_needs_more_evidence else [])
    placeholders = ",".join("?" for _ in statuses)
    c = conn()
    try:
        rows = c.execute(f"SELECT * FROM cold_candidates WHERE session_id=? AND status IN ({placeholders}) ORDER BY priority DESC, updated_at DESC LIMIT ?", [session_id] + statuses + [max(1, int(batch_size))]).fetchall()
        items = []
        for r in rows:
            ev = json.loads(r["evidence_json"] or "{}")
            items.append({
                "path": r["path"],
                "node_type": r["node_type"],
                "status": r["status"],
                "priority": r["priority"],
                "source": r["source"],
                "source_seed_paths": json.loads(r["source_paths_json"] or "[]"),
                "evidence": ev,
                "needs_expand_before_apply": ev.get("evidence_level") != "expanded",
                "contract": {
                    "helper_does_not_generate_tags": True,
                    "agent_must_write_brief_tags_evidence_note": True,
                    "action_choices": ["apply", "skip", "defer", "need_more_evidence"],
                    "apply_requires_expanded_evidence": True,
                }
            })
        return {
            "ok": True,
            "session_id": session_id,
            "items": items,
            "batch": items,  # compatibility only; SOP should use items.
            "count": len(items),
            "candidate_status": cold_start_status(session_id).get("candidate_status", {}),
            "next": "For apply: call expand_candidate(session_id, path) first; then apply_index_plan(plan, session_id=session_id)."
        }
    finally:
        c.close()

def cold_start_evidence_batch(session_id: str, batch_size: Optional[int] = None) -> Dict[str, Any]:
    return cold_start_batch(session_id, batch_size=batch_size)


def _set_candidate_status(session_id: str, path: str, status: str) -> bool:
    c = conn()
    try:
        cur = c.execute("UPDATE cold_candidates SET status=?,updated_at=? WHERE session_id=? AND path=?", (status, _now(), session_id, _norm(path)))
        c.commit()
        return cur.rowcount > 0
    finally:
        c.close()


def expand_candidate(session_id: str, path: str, *, max_children: Optional[int] = None, max_heads: Optional[int] = None) -> Dict[str, Any]:
    """Upgrade a rough cold-start candidate to expanded evidence.

    This is the required step before applying route tags in cold start. It reads
    only small text heads, never parses binary docs, and never infers tags.
    """
    _ensure_tables()
    p = _norm(path)
    c = conn()
    try:
        r = c.execute("SELECT * FROM cold_candidates WHERE session_id=? AND path=?", (session_id, p)).fetchone()
        if not r:
            return {"ok": False, "error": "candidate not found", "session_id": session_id, "path": p}
        source_paths = json.loads(r["source_paths_json"] or "[]")
        ev = _candidate_evidence(p, source_paths, expanded=True)
        # caller-specified limits are accepted for API stability; policy limits are used internally.
        c.execute("UPDATE cold_candidates SET evidence_json=?, status='pending', updated_at=? WHERE session_id=? AND path=?", (json.dumps(ev, ensure_ascii=False), _now(), session_id, p))
        c.commit()
        return {"ok": True, "session_id": session_id, "path": p, "item": {"path": p, "node_type": r["node_type"], "status": "pending", "priority": r["priority"], "source": r["source"], "source_seed_paths": source_paths, "evidence": ev, "needs_expand_before_apply": False}}
    finally:
        c.close()


def skip_candidate(session_id: str, path: str, reason: str = "skipped by Agent") -> Dict[str, Any]:
    ok = _set_candidate_status(session_id, path, "skipped")
    return {"ok": ok, "session_id": session_id, "path": _norm(path), "status": "skipped", "reason": reason}


def defer_candidate(session_id: str, path: str, reason: str = "needs more evidence") -> Dict[str, Any]:
    ok = _set_candidate_status(session_id, path, "needs_more_evidence")
    return {"ok": ok, "session_id": session_id, "path": _norm(path), "status": "needs_more_evidence", "reason": reason}


def mark_candidates(session_id: str, *, applied_paths: Sequence[str] = (), skipped_paths: Sequence[str] = (), deferred_paths: Sequence[str] = (), needs_more_evidence_paths: Sequence[str] = ()) -> Dict[str, Any]:
    _ensure_tables()
    c = conn()
    try:
        t = _now()
        for p in applied_paths:
            c.execute("UPDATE cold_candidates SET status='applied',updated_at=? WHERE session_id=? AND path=?", (t, session_id, _norm(p)))
        for p in skipped_paths:
            c.execute("UPDATE cold_candidates SET status='skipped',updated_at=? WHERE session_id=? AND path=?", (t, session_id, _norm(p)))
        for p in list(deferred_paths) + list(needs_more_evidence_paths):
            c.execute("UPDATE cold_candidates SET status='needs_more_evidence',updated_at=? WHERE session_id=? AND path=?", (t, session_id, _norm(p)))
        c.commit()
        return {"ok": True, "session_id": session_id, "applied": len(list(applied_paths)), "skipped": len(list(skipped_paths)), "needs_more_evidence": len(list(deferred_paths)) + len(list(needs_more_evidence_paths))}
    finally:
        c.close()

def cold_start_status(session_id: str) -> Dict[str, Any]:
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    c = conn()
    try:
        rows = c.execute("SELECT status,COUNT(*) FROM cold_candidates WHERE session_id=? GROUP BY status", (session_id,)).fetchall()
        by_status = {r[0]: r[1] for r in rows}
        top = [dict(r) for r in c.execute("SELECT path,priority,source,status,evidence_json FROM cold_candidates WHERE session_id=? ORDER BY priority DESC LIMIT 20", (session_id,)).fetchall()]
        for r in top:
            try:
                ev = json.loads(r.pop("evidence_json") or "{}")
                r["soft_downrank"] = ev.get("soft_downrank")
                r["source_seed_paths"] = ev.get("source_seed_paths", [])[:5]
            except Exception:
                pass
        return {"ok": True, "session": s, "candidate_status": by_status, "total_candidates": sum(by_status.values()), "top_candidates": top}
    finally:
        c.close()


def finish_cold_start(session_id: str, *, min_entries: Optional[int] = None, min_tagged_entries: Optional[int] = None, allow_pending: bool = False) -> Dict[str, Any]:
    _ensure_tables()
    s = _session(session_id)
    if not s:
        return {"ok": False, "error": "unknown cold-start session", "session_id": session_id}
    pol = _cold_policy()
    target = int(s.get("target_nodes") or 1000)
    complete_entries = int(min_entries if min_entries is not None else pol.get("min_complete_entries", max(120, int(target * 0.10))))
    usable_entries = int(pol.get("min_usable_entries", 60))
    complete_tagged = int(min_tagged_entries if min_tagged_entries is not None else pol.get("min_tagged_complete", max(80, int(complete_entries * 0.65))))
    usable_tagged = int(pol.get("min_tagged_usable", 40))
    st = index_stats()
    entries = int(st.get("entries") or 0)
    tagged_nodes = int(st.get("tagged_nodes") or 0)
    leaf = int(st.get("leaf") or 0)
    warnings: List[str] = []
    hard: List[str] = []
    st0 = cold_start_status(session_id)
    pending_count = int((st0.get("candidate_status") or {}).get("pending") or 0)
    needs_more = int((st0.get("candidate_status") or {}).get("needs_more_evidence") or 0)
    if pending_count and not allow_pending:
        warnings.append(f"pending_candidates={pending_count}")
    if needs_more:
        warnings.append(f"needs_more_evidence_candidates={needs_more}")
    if entries < usable_entries:
        hard.append(f"entry_count_below_usable:{entries}<{usable_entries}")
    elif entries < complete_entries:
        warnings.append(f"entry_count_below_complete:{entries}<{complete_entries}")
    if tagged_nodes < usable_tagged:
        hard.append(f"tagged_nodes_below_usable:{tagged_nodes}<{usable_tagged}")
    elif tagged_nodes < complete_tagged:
        warnings.append(f"tagged_nodes_below_complete:{tagged_nodes}<{complete_tagged}")
    # Leaf is not mandatory for a usable initial index, but zero leaf means it is an entry-only partial index.
    if leaf == 0:
        warnings.append("no_leaf_nodes_attached")
    if hard:
        status = "failed"
    elif warnings:
        status = "usable_partial"
    else:
        status = "complete"
    c = conn()
    try:
        c.execute("UPDATE cold_sessions SET status=?,updated_at=? WHERE session_id=?", (status, _now(), session_id))
        c.commit()
    finally:
        c.close()
    return {"ok": status == "complete", "status": status, "session_id": session_id, "warnings": warnings, "errors": hard, "stats": st, "cold_start_status": st0, "thresholds": {"usable_entries": usable_entries, "complete_entries": complete_entries, "usable_tagged": usable_tagged, "complete_tagged": complete_tagged}, "note": "Only status=complete may be reported as fully established. usable_partial/failed must be reported honestly."}
