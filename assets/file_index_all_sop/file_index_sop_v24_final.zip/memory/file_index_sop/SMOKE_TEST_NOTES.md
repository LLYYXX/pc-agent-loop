# file_index_sop v24 smoke-test notes

Implemented as a final minimum-work version after v22/v23 protocol failures.

Validated in this environment with a synthetic scope and temporary SQLite DB:

- `python -m py_compile memory/file_index_sop/*.py`
- `from file_index_sop import *`
- `begin_cold_start -> collect_cold_start_entries -> cold_start_batch`
- rough batch direct `apply_index_plan(..., session_id=...)` is rejected and candidate moves to `needs_more_evidence`
- `expand_candidate` returns expanded evidence with `document_heads` for text files
- expanded candidate can be applied with Agent-authored brief/tags/evidence_note
- `search_index` returns stable `{ok, query, hits, count, filters}` and does not iterate over recall dict keys
- `recall` returns stable `{ok, task_id, query, hits, finalize_required}`
- `finalize_file_task` warms used indexed paths and triggers rebalance
- `rebalance_tiers(max_active, max_warm, max_nodes)` enforces caps
- `finish_cold_start` does not report a tiny index as `complete`
- `skip_candidate` advances cold-start state

No semantic case/project hardcode was added. Candidate discovery uses structural signals only.
