"""Policy loading for file_index_sop.

Policy is structural configuration only. It must not contain semantic tag rules,
user projects, research terms, or specific paths. Environment/tool facts remain
in Agent L2 (global_mem ## [LOCAL_TOOLS]); index state remains in SQLite.
"""
from __future__ import annotations

import json
import os
from copy import deepcopy
from typing import Any, Dict, Mapping, Optional

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(_THIS_DIR, "config")
DEFAULT_POLICY_PATH = os.path.join(CONFIG_DIR, "default_policy.json")
LOCAL_POLICY_PATH = os.path.join(CONFIG_DIR, "local_policy.json")


def _read_json(path: str, default: Any) -> Any:
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError:
        return deepcopy(default)
    except Exception:
        return deepcopy(default)


def _deep_merge(base: Any, override: Any) -> Any:
    if isinstance(base, dict) and isinstance(override, dict):
        out = deepcopy(base)
        for k, v in override.items():
            out[k] = _deep_merge(out.get(k), v)
        return out
    return deepcopy(override) if override is not None else deepcopy(base)


def _ensure_local_policy() -> None:
    os.makedirs(CONFIG_DIR, exist_ok=True)
    if not os.path.exists(LOCAL_POLICY_PATH):
        with open(LOCAL_POLICY_PATH, "w", encoding="utf-8", newline="\n") as fh:
            json.dump({"version": 1, "inherits": "default_policy.json", "overrides": {}}, fh, ensure_ascii=False, indent=2)


def load_index_policy() -> Dict[str, Any]:
    """Load default_policy + local_policy.overrides.

    The local file is intentionally small and patch-oriented. It should only
    override structural budgets/sampling limits after explicit user request or
    confirmed audit findings.
    """
    _ensure_local_policy()
    default = _read_json(DEFAULT_POLICY_PATH, {})
    local = _read_json(LOCAL_POLICY_PATH, {"overrides": {}})
    return _deep_merge(default, local.get("overrides") or {})


def policy_paths() -> Dict[str, str]:
    return {"config_dir": CONFIG_DIR, "default_policy": DEFAULT_POLICY_PATH, "local_policy": LOCAL_POLICY_PATH}


def policy_get(policy: Mapping[str, Any], dotted: str, default: Any = None) -> Any:
    cur: Any = policy
    for part in dotted.split("."):
        if not isinstance(cur, Mapping) or part not in cur:
            return default
        cur = cur[part]
    return cur


def update_local_policy_patch(patch: Mapping[str, Any]) -> Dict[str, Any]:
    """Patch local_policy.overrides using dotted keys.

    Example: {"cold_start.max_active": 80}. This never rewrites Agent L2 and
    never stores semantic tags or user-specific path meanings.
    """
    _ensure_local_policy()
    local = _read_json(LOCAL_POLICY_PATH, {"version": 1, "inherits": "default_policy.json", "overrides": {}})
    overrides = local.setdefault("overrides", {})
    for dotted, value in patch.items():
        parts = str(dotted).split(".")
        cur = overrides
        for part in parts[:-1]:
            cur = cur.setdefault(part, {})
        cur[parts[-1]] = value
    with open(LOCAL_POLICY_PATH, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(local, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    return {"ok": True, "local_policy": LOCAL_POLICY_PATH, "overrides": overrides}


def audit_policy(policy: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    p = dict(policy or load_index_policy())
    warnings = []
    target = int(policy_get(p, "cold_start.target_nodes", 1000) or 1000)
    max_active = int(policy_get(p, "cold_start.max_active", 80) or 80)
    max_warm = int(policy_get(p, "cold_start.max_warm", 420) or 420)
    if max_active + max_warm > target:
        warnings.append("max_active + max_warm exceeds target_nodes")
    doc_budget_max = int(policy_get(p, "document_seeds.budget_max", 260) or 260)
    if doc_budget_max > target:
        warnings.append("document seed budget exceeds target_nodes")
    if policy_get(p, "document_seeds.binary_parse", False):
        warnings.append("binary document parsing is enabled; this may be expensive")
    # Policy must remain structural. A coarse guard catches obvious path-like
    # values; semantic/project-name review is handled by human/code review, not
    # by embedding a forbidden-domain list in the helper.
    serialized = json.dumps(p, ensure_ascii=False)
    if any(x in serialized for x in [":\\", ":/", "\\\\"]):
        warnings.append("policy appears to contain path-like values; keep environment facts in L2 or runtime arguments")
    return {"ok": not warnings, "warnings": warnings, "paths": policy_paths()}
