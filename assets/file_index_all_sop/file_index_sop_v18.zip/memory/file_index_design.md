# 文件语义索引 v18 设计说明

本文件给开发者/维护者看；Agent 常规执行只读 `file_index_sop.md`。

## 1. 分层

file_index 是 Agent 的 L5 memory：

- L1 只保留触发词。
- L2 只保留环境事实，例如 `## [LOCAL_TOOLS] es.exe=...`。
- L3 保存本 SOP、Python 实现和结构策略配置。
- L5 SQLite 保存索引状态、使用记录、query alias、update plans。

索引内容、route tags、active/warm/cold 状态不写入 L1/L2。

## 2. 配置

`config/default_policy.json` 和 `config/local_policy.json` 只保存结构策略：预算、采样限制、聚合层数、文档 seed 扩展名、finish/audit 阈值等。

policy 禁止承载语义规则、具体路径、用户项目名、研究方向词或历史 case 名。环境工具路径仍通过 L2 `LOCAL_TOOLS` 适配。

## 3. 冷启动

v18 采用 entry-first 修正：文档/config/recent seed 不直接刷入主索引，而是聚合成父级 entry evidence packet。Agent 基于 packet 判断语义并打 route tag；helper 只校验 evidence ref 与结构约束。

## 4. 运行时

命中已有索引时通过 `finalize_file_task` 升温；fallback/索引外路径生成 draft update plan。默认不直接污染主库。

## 5. 不做的事

- 不做 case detector。
- 不做自动语义打标。
- 不做全量内容解析。
- 不 hook 文件读写工具。
- 不后台 watcher。
