# 文件语义索引 Skill（v18）

本文件只写给 Agent 执行。file_index 是 Agent 的 **L5 文件语义索引层**：Everything/es.exe 负责全量事实检索；本 Skill 维护约 1000 条可导航、可治理、可升降级的语义节点。

## 0. 必守边界

- 不后台 watcher，不 hook `file_read` / `file_write`，不接管文件操作。
- 不引入向量库。
- `search_files()` 是正确性优先的薄封装，只调用 es.exe，不做语义扩展。
- helper 不生成 route tag；route tag 必须由 Agent 基于 evidence packet 标注。
- 错误 tag 比没有 tag 更不可接受：打一条，对一条；每条必须准确并带 evidence ref。
- 文档文件是一等候选，但不能直接刷成文件采样库：document/config/recent seed 必须优先聚合成父级 entry；代表文件只作为 leaf 挂在已确认 entry 下。
- 不写 case 特判、具体项目名、研究方向词、特定路径或软件专用规则。

## 1. 与 Agent Memory 的关系

- L1 只保留触发词：本地文件任务按 `file_index_sop`。
- L2 `global_mem.txt` 只放环境事实，例如 `## [LOCAL_TOOLS] es.exe=...`。file_index 可读取或 patch 该小节，但不能写索引内容。
- L3 `memory/file_index_sop/` 放 SOP、代码和策略配置。
- L5 SQLite 放索引运行状态：nodes、tags、facets、query_alias、update_plan、hit_count、active/warm/cold。

配置分层：

```python
print_json(policy_paths())
print_json(load_index_policy())
print_json(audit_policy())
```

- `config/default_policy.json`：结构策略默认值，不能写语义规则。
- `config/local_policy.json`：本机覆盖项，初始应为空；修改用 `update_local_policy_patch({...})`。
- 不要把 route tag、用户路径、历史 case 或用户画像写入 policy。

## 2. 初始化

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop import *

print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(audit_policy())
```

`ensure_search_ready()` 只做 es.exe 路径解析、必要自启动和 L2 `LOCAL_TOOLS` 小节 patch；不扫描文件，不生成索引策略。

## 3. 冷启动建库模式

### 3.1 创建 session

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=80,
    scope=r"F:\\",
    memory_text="本轮用户明确提供的简短上下文；没有就留空",
    agent_queries=[],
)
print_json(res)
session_id = res["session_id"]
```

默认预算来自 policy。不要把 `collection_done=True` 理解为“没有更多高价值文件”，它只表示当前 discovery jobs 用完。

### 3.2 分批收集 entry candidates

```python
while True:
    status = cold_start_status(session_id)
    if status.get("pending", 0) >= 40 or status.get("collection_done"):
        break
    print_json(collect_cold_start_entries(
        session_id,
        max_queries=6,
        limit_per_query=100,
        recent_limit=1000,
        max_entries=100,
        time_budget_sec=30,
    ))
```

收集阶段只做：candidate seed → 父级/祖先目录 entry candidate。文件 seed 不得直接成为主索引主体。

### 3.3 Agent 标注 entry evidence packet

```python
batch = cold_start_evidence_batch(session_id, batch_size=8)
print_json(batch)
```

packet 主要是目录 entry candidate，包含：

- `entry_aggregation`：文件/文档 seed 如何聚合到该目录。
- `document_seeds`：提供证据的文档文件。
- `evidence_files`：通用证据文件。
- `leaf_candidates`：该 entry 被确认后可挂载的支撑 leaf。
- `probe`：该目录直接子项、文件类型分布、少量文本 head。

Agent 对每个 packet 判断语义，生成 plan。每个 route tag 必须引用本 packet 内证据。

```python
plan = [
    {
        "path": packet["path"],
        "action": "apply",
        "node_type": packet["node_type"],
        "tier": "warm",
        "brief": "...",
        "tags": ["accurate-route-tag"],
        "relation": {
            "role": "entry",
            "facets": packet.get("facets", []),
            "route_tag_evidence": {
                "accurate-route-tag": ["document_seeds[0].head", "leaf_candidates[0].basename"]
            },
        },
        "evidence": ["agent-annotated-from-entry-evidence-packet"],
    }
]
print_json(apply_index_plan(plan, session_id=session_id))
```

禁止：

- 手写路径 if/elif。
- 调 `auto_apply_index_plan()`。
- 把邻居项目、外部引用、模板示例、父目录泛语义、局部配置语义冒泡成父级 route tag。

循环处理：

```python
while True:
    status = cold_start_status(session_id)
    if status.get("pending", 0) <= 0:
        if status.get("collection_done"):
            break
        print_json(collect_cold_start_entries(session_id, max_queries=6, limit_per_query=100, recent_limit=1000, max_entries=100, time_budget_sec=30))
        continue
    batch = cold_start_evidence_batch(session_id, batch_size=8)
    print_json(batch)
    # Agent 标注 batch -> plan
    # print_json(apply_index_plan(plan, session_id=session_id))
```

### 3.4 完成与强验收

```python
result = finish_cold_start(session_id, max_nodes=1000, max_active=80, max_warm=420)
print_json(result)
if not result.get("ok") or result.get("status") != "complete":
    # 不得向用户报告“索引已完成”。
    print_json(result)
else:
    print_json(audit_index(fix=False))
    print_json(stats())
    print_json(virtual_tree(limit_per_group=10))
```

合格要求：

- 总节点接近且不超过 `max_nodes`。
- 必须形成 entry 层：默认 1000 节点目标下，目录 entry 应有几十到一百多个。
- tagged entry 数量足够支撑 recall。
- active 小；warm 是稳定语义入口层；cold 是支撑 leaf / 弱证据候选。
- leaf 必须挂在已索引 entry 下，不能形成孤立文件采样库。
- `finish_cold_start()` 若返回 `ok=False`，不得报告完成。
- `audit_index()` 若有 `structural_warnings`，不得报告质量通过。

## 4. 运行时文件任务模式

### 4.1 定位

```python
res = locate("用户原始语义问题", limit=10)
print_json(res)
task_id = res.get("task_id")
```

`locate()` 会创建轻量 task ledger，查 query alias，查 active/warm recall，并在命中 scope 内用薄 `search_files()` 搜索。它不做 case-specific query expansion。需要变体时，Agent 自己调用：

```python
print_json(search_files("事实查询词", scope="已知目录", limit=20))
print_json(search_files_detailed("事实查询词", scope="已知目录", limit=20))
```

### 4.2 正常文件操作

Agent 正常使用文件工具读取、列目录、移动、重命名、写文件。本 Skill 不接管这些操作。

### 4.3 任务结束前 finalize

若本轮使用了本地路径，最终回答前调用：

```python
print_json(finalize_file_task(
    task_id=task_id,
    query="用户原始问题",
    used_paths=[...],
    found_paths=[...],
    rejected_paths=[...],
    fallback_used=bool(res.get("fallback_filesystem_hits")),
    mode="draft",
))
```

行为：

- 已在索引内且被使用的路径：升温 / 更新 hit_count / last_used。
- 索引外但被找到或使用的路径：生成 draft update plan。
- 无变化：no-op。

确认结果后再应用：

```python
print_json(apply_update_plan(plan_id))
```

## 5. 未命中更新计划

未命中但 fallback 找到结果时，默认只 draft，不直接生成 route tag：

```python
plan = draft_update_plan(
    query="用户原始问题",
    task_id=task_id,
    found_paths=[...],
    used_paths=[...],
    rejected_paths=[...],
    fallback_used=True,
)
print_json(plan)
```

`draft_update_plan()` 只记录 entry/leaf、query alias、negative evidence。新 route tag 仍需 Agent 基于 evidence packet 另行标注。
