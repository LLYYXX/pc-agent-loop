# 文件语义索引 Skill（纯 Agent 驱动版）

本 Skill 是 Everything / `es.exe` 之上的**正交语义覆盖层**。它不是替代 Everything 的搜索器，也不是用户手工维护的数据库。用户只提出任务或触发“冷启动”；Agent 必须自行使用本 SOP 完成搜索、建库、补库、升降级和复用。

## 核心边界

- `es.exe` 负责文件事实检索：文件名、路径、扩展名、时间、scope。
- 本索引负责语义覆盖：路径看不出来的用途、任务关系、材料归属、项目语义。
- LLM 能力在 Agent 层；Python helper 只做确定性执行：嗅探/启动、es 查询、候选压缩、写库、召回、升降级。
- 不改 GenericAgent 主流程，不注册工具，不 hook `file_read`，不后台 watcher，不向量库。

## import

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop.helper import *
```

## 使用索引前：先确保 Everything 可用

Agent 在首次使用索引或冷启动前，必须显式执行：

```python
print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

`ensure_search_ready()` 负责：

1. 嗅探 `es.exe`；
2. 嗅探 `Everything.exe`；
3. patch `memory/global_mem.txt` 的 `## [LOCAL_TOOLS]`；
4. 如果 es IPC 不可用，则尝试启动 Everything；
5. 再 probe `es.exe` 是否可查。

`everything.py` 只执行已配置的 `es.exe` 查询，不嗅探、不启动、不写 memory。

## 运行时检索流程

遇到文件相关任务时，Agent 必须先用语义索引缩小范围：

```python
hits = recall("用户语义意图", limit=8)
```

如果命中 `dir` 节点：

```python
search_files("文件事实词，如 result csv config invoice", scope=hits[0]["path"], limit=20)
```

如果语义索引没有命中或命中很差：

```python
summary = miss_recovery_batch("用户查询", memory_text="可用的 Agent Memory 摘要", limit=80)
```

Agent 根据 `summary` 自行生成 `index_plan`，必须包含 `brief` 和高信息 `tags`，然后：

```python
apply_index_plan(plan)
rebalance(max_nodes=1000, max_active=220)
```

任务完成后：

```python
mark_used(path, matched_tags=["实际命中的tag"])
```

## 冷启动：最终必须产出约 1000 条可用语义数据

用户要求“建索引”或点击冷启动时，Agent 不得只生成候选池后停止。完整冷启动是 Agent 多轮流程：

### 1. 开始冷启动

Agent 先根据 Memory / 当前长期任务生成 `agent_queries`。例如 MCP、trajectory、元应用、论文、实验、报销、invoice 等。然后：

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=220,
    memory_text="这里填可用的 Agent Memory 摘要",
    agent_queries=["mcp", "trajectory", "轨迹", "元应用", "论文", "实验", "报销", "invoice", "receipt"],
)
print_json(res)
session_id = res["session_id"]
```

### 2. Agent 分批标注并入库

循环执行，直到 `pending == 0`：

```python
batch = cold_start_batch(session_id, batch_size=40)
print_json(batch)
```

Agent 阅读 `batch["items"]` 后，必须生成 plan。每个 active/warm 节点都必须有：

- `brief`: 一行短说明，不复述文件名/扩展名/父路径；
- `tags`: 1–3 个高信息语义残差 tag；
- `node_type`: file / dir；
- `state`: active / warm / cold。

示例：

```python
plan = [
  {
    "path": r"F:\\...\\某目录",
    "node_type": "dir",
    "state": "active",
    "brief": "保存轨迹复用实验脚本、结果表和对比记录。",
    "tags": ["trajectory-reuse-evaluation"],
    "source": "agent-cold-start"
  }
]
print_json(apply_index_plan(plan, session_id=session_id))
```

规则：

- 不要让 active/warm 节点没有 tag 或 brief。
- 若某项不值得进索引，可将其标为 `cold`，但仍建议给 brief/tag；如果确定是软件产物，调用 `add_ignored_path()` 记住负向规则。
- 不要用 `python/json/csv/config/result/project/file/folder/readme` 这类低信息 tag。
- tag 必须是 Everything 不能直接表达的语义残差。

### 3. 完成冷启动

所有 batch 应用后：

```python
print_json(cold_start_status(session_id))
print_json(finish_cold_start(session_id, max_nodes=1000, max_active=220))
print_json(stats())
print_json(facets(limit=20))
```

如果 `finish_cold_start()` 返回 pending 错误，Agent 必须继续 `cold_start_batch()` + `apply_index_plan()`，不能提前结束。

## tag 规则

Tag 是高信息路由键，不是分类标签。

只写：

- 路径 / 文件名 / 扩展名 / 父目录看不出来；
- 未来 Agent 可能用这个语义来找；
- 能显著缩小搜索范围。

避免：

- `readme`, `markdown`, `python`, `json`, `csv`, `config`, `test`, `result`, `project`, `folder`, `file`；
- 路径词的同义重复；
- 扩展名和普通文件类型。

brief 是一行解释，用于帮助 Agent 判断是否值得 `file_read`。

## 状态

- `active`: 默认召回；冷启动后数量应受限。
- `warm`: 默认召回但弱于 active；冷启动主体。
- `cold`: 不默认召回，`include_dormant=True` 才出。
- `stale`: mtime 改变，需要复核。
- `retired`: 路径消失或确认不用。

维护：

```python
check_stale()
decay(active_days=30, warm_days=90)
rebalance(max_nodes=1000, max_active=220)
```

## 验证目标

冷启动完成后应满足：

- `stats()["nodes_total"]` 约 1000；
- active/warm 节点大多有 brief 和 tag；
- `facets()` 能看到有意义的 tag 和父目录聚合；
- `recall("某个研究/任务语义")` 能命中文件或目录节点；
- 命中目录节点后，Agent 能用 `search_files(..., scope=dir)` 快速展开。
