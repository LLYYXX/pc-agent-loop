"""Agent-facing cold-start and miss-recovery builder.

The builder is deterministic. It does not call an LLM API. Its job is to give the
Agent compact, high-quality batches to label, and then persist the Agent's plan.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import everything, store

HARD_EXCLUDE_SEGMENTS = {
    ".git", ".svn", ".hg", "node_modules", "__pycache__", ".venv", "venv", "env", "dist", "build", "target",
    ".cache", "cache", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".idea", ".vscode", ".vs",
    "logs", "log", "tmp", "temp", "coverage", "site-packages", "library", "obj", "bin", "debug", "release",
    "deriveddata", "$recycle.bin", "system volume information", "wandb", "tensorboard", "checkpoints", ".ipynb_checkpoints",
}
HARD_EXCLUDE_EXTS = {".pyc", ".pyo", ".class", ".o", ".obj", ".dll", ".exe", ".so", ".dylib", ".tmp", ".temp", ".cache", ".lock", ".log", ".bak", ".swp", ".swo"}
MEDIA_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".mp4", ".mov", ".avi", ".mkv"}
ARCHIVE_EXTS = {".zip", ".7z", ".rar", ".tar", ".gz", ".bz2"}
TEXTISH_EXTS = {".md", ".txt", ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cs", ".go", ".rs", ".json", ".yaml", ".yml", ".toml", ".ini", ".csv", ".tsv", ".tex", ".ipynb", ".sql", ".pdf", ".docx", ".xlsx", ".xls", ".pptx", ".html", ".vue"}
ENTRY_BASENAMES = {"readme.md", "readme.txt", "package.json", "pyproject.toml", "requirements.txt", "dockerfile", "docker-compose.yml", "docker-compose.yaml", "pom.xml", "cargo.toml", "go.mod", "main.py", "app.py", "index.js", "index.ts", "setup.py", "makefile", "cmakelists.txt", "environment.yml", "conda.yml"}
DEFAULT_DISCOVERY_QUERIES = ["README.md", "pyproject.toml", "package.json", "requirements.txt", "docker-compose", "Dockerfile", "论文", "paper", "thesis", "实验", "experiment", "results", "报销", "发票", "账单", "invoice", "receipt", "mcp", "agent", "trajectory", "memory"]


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _path_l(path: str) -> str:
    return _norm(path).lower().replace("\\", "/")


def _segments(path: str) -> List[str]:
    p = _norm(path); segs=[]
    while True:
        h,t = os.path.split(p)
        if t: segs.append(t.lower()); p=h
        else:
            if h: segs.append(h.lower())
            break
        if h == p: break
    return list(reversed(segs))


def memory_queries(memory_text: str = "", *, max_queries: int = 30) -> List[str]:
    text = memory_text or ""
    latin = re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", text)
    chinese = re.findall(r"[\u4e00-\u9fff]{2,10}", text)
    stop = {"the","and","with","from","that","this","agent","model","user","project","系统","用户","当前","研究","项目","实现","文件","方向","需要","相关","设计"}
    cnt = Counter()
    for x in latin + chinese:
        if len(x) > 42 or x.lower() in stop or x in stop: continue
        cnt[x] += 1
    return [k for k,_ in cnt.most_common(max_queries)]


def merge_queries(agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", *, max_queries: int = 50) -> List[str]:
    out=[]; seen=set()
    for q in list(agent_queries or []) + memory_queries(memory_text) + DEFAULT_DISCOVERY_QUERIES:
        qs=str(q).strip()
        if not qs: continue
        key=qs.lower()
        if key in seen: continue
        seen.add(key); out.append(qs)
        if len(out)>=max_queries: break
    return out


def _purpose_allows_media(purpose: Optional[str]) -> bool:
    p=(purpose or "").lower()
    return any(x in p for x in ["image","screenshot","素材","图片","截图","报销","invoice","receipt","发票","账单"])


def classify_candidate(row: Dict[str, Any], *, purpose: Optional[str] = None, memory_terms: Optional[Sequence[str]] = None,
                       ignored: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    path=_norm(row.get("path", "")); base=os.path.basename(path); bl=base.lower(); ext=os.path.splitext(bl)[1]
    p_l=_path_l(path); segs=_segments(path); reasons=[]; hard=False; score=0.0
    for ig in ignored or []:
        pat=str(ig.get("pattern", "")).lower().replace("\\", "/").rstrip("/")
        if pat and p_l.startswith(pat):
            hard=True; reasons.append("ignored-pattern")
            break
    bad=[s for s in segs if s in HARD_EXCLUDE_SEGMENTS]
    if bad: hard=True; reasons.append("generated-segment:"+"/".join(bad[:3]))
    if ext in HARD_EXCLUDE_EXTS: hard=True; reasons.append("generated-ext:"+ext)
    if re.match(r"^(~\$|\.?#|thumbs\.db$|desktop\.ini$)", bl): hard=True; reasons.append("auto-filename")
    if any(x in p_l for x in ["/appdata/", "/localappdata/"]) and any(x in p_l for x in ["/cache/", "/logs/", "/temp/"]): hard=True; reasons.append("appdata-generated")
    if ext in TEXTISH_EXTS: score += 6; reasons.append("textish")
    if bl in ENTRY_BASENAMES: score += 14; reasons.append("entry-file")
    if ext in MEDIA_EXTS:
        score += 1 if _purpose_allows_media(purpose) else -14; reasons.append("media")
    if ext in ARCHIVE_EXTS:
        score += 2 if _purpose_allows_media(purpose) else -5; reasons.append("archive")
    high_terms=["论文","paper","thesis","实验","experiment","result","results","eval","报销","发票","账单","invoice","receipt","resume","简历","课程","课题组","mcp","agent","trajectory","memory","simulation","benchmark","genericagent"]
    for t in high_terms:
        if t.lower() in p_l:
            score += 4; reasons.append("path-signal:"+t); break
    for t in memory_terms or []:
        tl=t.lower()
        if len(tl)>=3 and tl in p_l:
            score += 5; reasons.append("memory-signal:"+t[:24]); break
    mt=row.get("mtime_ns")
    if isinstance(mt,int) and mt>0:
        age=max(0,(time.time()-mt/1e9)/86400)
        if age<7: score+=10; reasons.append("recent-7d")
        elif age<30: score+=7; reasons.append("recent-30d")
        elif age<180: score+=4; reasons.append("recent-180d")
        elif age<730: score+=1.5; reasons.append("recent-2y")
    return {"path":path,"basename":base,"parent":os.path.dirname(path),"ext":ext,"hard_exclude":hard,"score":round(score,4),"reasons":reasons}


def collect_candidates(agent_queries: Optional[Sequence[str]] = None, *, memory_text: str = "", scope: Optional[str] = None,
                       limit_per_query: int = 160, include_recent: bool = True, recent_limit: int = 2500,
                       purpose: Optional[str] = None, ignored: Optional[Sequence[Dict[str, Any]]] = None,
                       keep_excluded: bool = False) -> List[Dict[str, Any]]:
    rows=[]
    if include_recent:
        try: rows.extend(everything.recent(limit=recent_limit, scope=scope, query="*"))
        except Exception as e: rows.append({"path":"ERROR:recent","error":str(e)})
    for q in merge_queries(agent_queries, memory_text):
        try: rows.extend(everything.search(q, limit=limit_per_query, scope=scope, sort_mtime_desc=True))
        except Exception as e: rows.append({"path":"ERROR:"+q,"error":str(e)})
    terms = memory_queries(memory_text, max_queries=40)
    out=[]; seen=set()
    for r in rows:
        if str(r.get("path","")).startswith("ERROR:"): continue
        c=classify_candidate(r,purpose=purpose,memory_terms=terms,ignored=ignored)
        if c["path"] in seen: continue
        seen.add(c["path"])
        if c["hard_exclude"] and not keep_excluded: continue
        out.append(c)
    out.sort(key=lambda x:(-x["score"], x["path"]))
    return out


def diversify_by_parent(cands: Sequence[Dict[str, Any]], *, target: int, per_parent: int = 20) -> List[Dict[str, Any]]:
    by=defaultdict(list)
    for c in cands: by[c["parent"]].append(c)
    for lst in by.values(): lst.sort(key=lambda x:-x["score"])
    out=[]; cap=per_parent
    while len(out)<target:
        added=0
        for parent,lst in sorted(by.items(), key=lambda kv:-kv[1][0]["score"] if kv[1] else 0):
            take=[x for x in lst if not x.get("_taken")][:max(0,cap)]
            if not take: continue
            x=take[0]; x["_taken"]=True; out.append(x); added+=1
            if len(out)>=target: break
        if added==0: break
        if len(out)<target and added<max(3,len(by)//8): cap+=5
    for x in out: x.pop("_taken",None)
    return out[:target]


def build_nodes_for_pool(cands: Sequence[Dict[str, Any]], *, target_nodes: int = 1000, max_active: int = 220, parent_levels: int = 2) -> List[Dict[str, Any]]:
    dir_budget=max(80,int(target_nodes*0.18)); file_budget=max(1,target_nodes-dir_budget)
    files=diversify_by_parent(cands,target=file_budget,per_parent=18)
    plan=[]; active_files=max(20,int(max_active*0.62))
    for i,c in enumerate(files):
        st="active" if i<active_files and c["score"]>=8 else ("warm" if c["score"]>=4 else "cold")
        plan.append({"path":c["path"],"node_type":"file","state":st,"brief":"","tags":[],"source":"cold-start-candidate","confidence":"candidate","seed_score":c["score"],"evidence":c["reasons"],"relation":{"parent":c["parent"],"basename":c["basename"],"ext":c["ext"]}})
    dir_map: Dict[str, Dict[str, Any]]={}
    for c in files:
        cur=c["parent"]
        for level in range(1,parent_levels+1):
            if not cur or cur==os.path.dirname(cur): break
            d=dir_map.setdefault(cur,{"path":cur,"children":[],"score":0.0,"level":level})
            d["children"].append(c["path"]); d["score"] += max(1,c["score"])*(1.0/level)
            cur=os.path.dirname(cur)
    dirs=sorted(dir_map.values(), key=lambda x:(-len(x["children"]), -x["score"], x["path"]))[:dir_budget]
    active_dirs=max(10,max_active-active_files)
    for i,d in enumerate(dirs):
        st="active" if i<active_dirs and len(d["children"])>=2 else ("warm" if len(d["children"])>=2 else "cold")
        sample=[os.path.basename(x) for x in d["children"][:12]]
        plan.append({"path":d["path"],"node_type":"dir","state":st,"brief":"","tags":[],"source":"cold-start-parent","confidence":"candidate","seed_score":round(d["score"],3),"evidence":[f"children_in_pool={len(d['children'])}"]+sample[:8],"relation":{"child_count":len(d["children"]),"sample_children":sample,"level":d["level"]}})
    return plan[:target_nodes]


def make_discovery_summary(cands: Sequence[Dict[str, Any]], *, max_files: int = 80, max_clusters: int = 40) -> Dict[str, Any]:
    top=list(cands[:max_files])
    by=defaultdict(list)
    for c in cands[:max_files*4]: by[c["parent"]].append(c)
    clusters=[]
    for parent,lst in by.items():
        lst=sorted(lst,key=lambda x:-x["score"])
        exts=Counter(x["ext"] or "<none>" for x in lst)
        clusters.append({"parent":parent,"hit_count":len(lst),"score_sum":round(sum(x["score"] for x in lst),3),"extensions":dict(exts.most_common(8)),"samples":[{"path":x["path"],"score":x["score"],"reasons":x["reasons"][:5]} for x in lst[:8]]})
    clusters.sort(key=lambda x:(-x["hit_count"], -x["score_sum"]))
    return {"candidate_files":[{k:c[k] for k in ("path","score","reasons","parent","ext")} for c in top],"directory_clusters":clusters[:max_clusters],"instruction":"Agent must choose valuable files/dirs and output index_plan with non-empty brief and high-information tags."}


def prepare_cold_start(conn, *, target_nodes: int = 1000, max_active: int = 220, scope: Optional[str] = None,
                       agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", purpose: Optional[str] = None,
                       recent_limit: int = 2500, limit_per_query: int = 160, parent_levels: int = 2,
                       ignored: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    sid = "cs_" + hashlib.sha1(f"{time.time()}:{os.getpid()}".encode()).hexdigest()[:12]
    cands=collect_candidates(agent_queries,memory_text=memory_text,scope=scope,limit_per_query=limit_per_query,include_recent=True,recent_limit=recent_limit,purpose=purpose,ignored=ignored)
    skeleton=build_nodes_for_pool(cands,target_nodes=target_nodes,max_active=max_active,parent_levels=parent_levels)
    now=time.time()
    conn.execute("INSERT INTO build_sessions(session_id,status,target_nodes,max_active,created_at,updated_at,meta) VALUES(?,?,?,?,?,?,?)", (sid,"open",target_nodes,max_active,now,now,json.dumps({"scope":scope,"queries":list(agent_queries or []),"candidate_count":len(cands)},ensure_ascii=False)))
    for item in skeleton:
        terms=sorted(store.visible_terms(item["path"]))[:32]
        conn.execute("""INSERT OR REPLACE INTO build_items(session_id,path,node_type,suggested_state,seed_score,evidence,relation,visible_terms,status,batch_no,created_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""", (sid,item["path"],item["node_type"],item["state"],item["seed_score"],json.dumps(item["evidence"],ensure_ascii=False),json.dumps(item["relation"],ensure_ascii=False),json.dumps(terms,ensure_ascii=False),"pending",0,now,now))
    conn.commit()
    return {"ok":True,"session_id":sid,"candidate_count":len(cands),"staged_items":len(skeleton),"target_nodes":target_nodes,"max_active":max_active}


def cold_start_batch(conn, session_id: str, *, batch_size: int = 50) -> Dict[str, Any]:
    rows=list(conn.execute("SELECT * FROM build_items WHERE session_id=? AND status='pending' ORDER BY suggested_state='active' DESC, seed_score DESC LIMIT ?", (session_id,max(1,batch_size))))
    pending=conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    done=conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    return {"ok":True,"session_id":session_id,"pending":pending,"applied":done,"items":[{"path":r["path"],"node_type":r["node_type"],"suggested_state":r["suggested_state"],"seed_score":r["seed_score"],"visible_terms":json.loads(r["visible_terms"] or "[]"),"evidence":json.loads(r["evidence"] or "[]"),"relation":json.loads(r["relation"] or "{}"),"required_output":{"brief":"one short line; do not restate path","tags":"1-3 high-information residual tags; leave no active/warm node untagged"}} for r in rows]}


def apply_index_plan(conn, plan: Sequence[Dict[str, Any]], *, default_state: str = "warm", default_source: str = "agent-builder", enforce_tag_gate: bool = True, fts_ok: bool = False, session_id: Optional[str] = None) -> Dict[str, Any]:
    out={"applied":0,"errors":[],"rejected_tags":[]}
    for item in plan:
        try:
            path=str(item.get("path") or "").strip()
            if not path: raise ValueError("missing path")
            brief=str(item.get("brief") or "").strip()
            tags=item.get("tags") or []
            state=str(item.get("state") or default_state)
            # Cold-start plan should be usable: non-empty brief and at least one tag for active/warm.
            if session_id and state in {"active","warm"}:
                if not brief: raise ValueError("cold-start active/warm item missing brief")
                if not tags: raise ValueError("cold-start active/warm item missing tags")
            res=store.annotate_node(conn,path,tags,brief=brief,node_type=item.get("node_type"),state=state,source=item.get("source") or default_source,confidence=item.get("confidence") or "agent-labeled",seed_score=float(item.get("seed_score") or 0),evidence=item.get("evidence"),relation=item.get("relation"),enforce_tag_gate=enforce_tag_gate,fts_ok=fts_ok)
            out["applied"]+=1; out["rejected_tags"].extend([{path:x} for x in res.get("rejected_tags",[])])
            if session_id:
                conn.execute("UPDATE build_items SET status='applied',updated_at=? WHERE session_id=? AND path=?", (time.time(),session_id,os.path.normpath(os.path.abspath(path))))
        except Exception as e:
            out["errors"].append({"item":item,"error":str(e)})
    conn.commit(); return out


def finish_cold_start(conn, session_id: str, *, max_nodes: int = 1000, max_active: int = 220, fts_ok: bool = False) -> Dict[str, Any]:
    pending=conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    applied=conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    if pending:
        return {"ok":False,"session_id":session_id,"pending":pending,"applied":applied,"error":"cold start still has pending unlabeled items"}
    res=store.rebalance(conn,max_nodes=max_nodes,max_active=max_active,fts_ok=fts_ok)
    conn.execute("UPDATE build_sessions SET status='closed',updated_at=? WHERE session_id=?", (time.time(),session_id)); conn.commit()
    return {"ok":True,"session_id":session_id,"applied":applied,"rebalance":res}


def label_worklist(conn, *, limit: int = 80, node_types: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
    cond=["(brief='' OR path NOT IN (SELECT path FROM node_tags))", "state IN ('active','warm')"]
    params=[]
    if node_types:
        ph=','.join('?'*len(node_types)); cond.append(f"node_type IN ({ph})"); params.extend(node_types)
    rows=conn.execute(f"SELECT * FROM nodes WHERE {' AND '.join(cond)} ORDER BY state='active' DESC, seed_score DESC LIMIT ?", (*params,max(1,limit))).fetchall()
    return [{"path":r["path"],"node_type":r["node_type"],"state":r["state"],"seed_score":r["seed_score"],"brief":r["brief"],"visible_terms":sorted(store.visible_terms(r["path"]))[:32],"evidence":json.loads(r["evidence"] or "[]"),"relation":json.loads(r["relation"] or "{}"),"required_output":{"brief":"one short line","tags":"1-3 high-info residual tags"}} for r in rows]


def miss_recovery_batch(conn, query: str, *, memory_text: str = "", scope: Optional[str] = None, limit: int = 80) -> Dict[str, Any]:
    cands=collect_candidates([query],memory_text=memory_text,scope=scope,limit_per_query=limit,include_recent=False,recent_limit=0,ignored=store.ignored_paths(conn))
    return make_discovery_summary(cands,max_files=min(limit,80),max_clusters=30)
