# v28 smoke test notes

Validated on a temporary synthetic scope:

- `from file_index_sop import *` imports successfully.
- `collect_cold_start_entries` discovers a candidate.
- Rough `apply_index_plan(..., session_id=sid)` is rejected before `expand_candidate`.
- After `expand_candidate`, type-only classifier submissions such as `python-project` with file-count evidence are rejected.
- `commit_candidate(..., evidence_refs=[...])` succeeds for an evidence-backed route tag and stores weak type labels as facets.
- `recall_hits(query)` returns a plain list of hits while recording task ledger state.
- `run_file_query(query)` returns `{task_id, recall_hits, search_hits, all_hits}`.
- `finish_local_file_task(query, used=[...])` warms used paths and triggers rebalance without requiring the Agent to maintain `task_id`.
- `record_correction` creates correction evidence and a draft update plan.
- `audit_index()` includes runtime audit and can flag recall hits without finalize.


Additional v28 checks:

- `finish_local_file_task` binds only to same-query open tasks; otherwise it creates a new task.
- `fallback_used=None` auto-infers fallback only when used/found contains external paths.
- `record_correction` / `mark_not_relevant` write immediate query-level negative evidence used by exact-query recall.
- `update_entry_tags(..., mode="apply")` migrates weak route labels to facets unless `force_route=True`.
- `audit_runtime` inspects finalized task events, unconsumed recall hits, fallback-without-update, and corrections without negative evidence.

v28 synthetic smoke test results:

- Weak-only cold-start commit (`python-project` + file-type evidence) is rejected with `needs_verification`.
- Evidence-backed `commit_candidate` succeeds and stores weak labels as facets.
- `record_correction(query, wrong_paths=[...])` immediately affects exact-query `recall_hits` by suppressing the corrected false positive.
- `finish_local_file_task` with a different query creates a new task instead of binding to an arbitrary open task.
- `finish_local_file_task(..., fallback_used=None)` infers fallback as `False` for indexed used paths.
- `update_entry_tags(..., add=['python-project', 'diffusion-search'], mode='apply')` stores `python-project` as a facet and `diffusion-search` as a route tag.
- `audit_runtime` reports open recall hits without finish and includes recent correction/tag-update events.
