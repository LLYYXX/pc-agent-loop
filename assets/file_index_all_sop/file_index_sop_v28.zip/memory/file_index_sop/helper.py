"""Agent-facing helper surface for file_index_sop v28.

No semantic route-tag inference. Use `from file_index_sop import *`.
"""
from __future__ import annotations

import json
import os
from collections import Counter
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import everything
from .policy import load_index_policy, policy_paths, audit_policy, update_local_policy_patch
from .store import (
    init_db, reset_db, annotate_entry, annotate_leaf, attach_leaf, apply_index_plan as _store_apply_index_plan,
    recall as _recall, begin_file_task, record_task_hits, finalize_file_task,
    draft_update_plan, apply_update_plan, list_pending_update_plans, stats, audit_index as _store_audit_index,
    virtual_tree, alias_lookup, node, get_node, list_nodes, list_entries, list_leaf, top_tags, index_summary, search_index, nodes_by_tag,
    rebalance_tiers, conn, log_event, set_tags, set_facets, is_indexed,
)
from .ensure_es import ensure_ready as ensure_search_ready
from .cold_start import (
    begin_cold_start, collect_cold_start_entries, cold_start_batch,
    cold_start_evidence_batch, cold_start_status, mark_candidates, expand_candidate, skip_candidate, defer_candidate, finish_cold_start, candidate_evidence_level
)


def print_json(obj: Any) -> Any:
    print(json.dumps(obj, ensure_ascii=False, indent=2))
    return obj


def search_files(query: str, scope: Optional[str] = None, limit: int = 50, *, task_id: Optional[str] = None) -> List[Dict[str, Any]]:
    rows = everything.search(query, scope=scope, limit=limit)
    if task_id:
        record_task_hits(task_id, filesystem_hits=rows, fallback_used=True, dirty=True)
    return rows


def search_files_detailed(query: str, scope: Optional[str] = None, limit: int = 50, *, task_id: Optional[str] = None) -> Dict[str, Any]:
    res = everything.search_detailed(query, scope=scope, limit=limit)
    if task_id:
        record_task_hits(task_id, filesystem_hits=res.get("hits") or [], fallback_used=True, dirty=bool(res.get("hits")))
    return res


def last_search_diagnostic() -> Dict[str, Any]:
    return everything.last_search_diagnostic()


def recent_files(scope: Optional[str] = None, limit: int = 200) -> List[Dict[str, Any]]:
    return everything.recent(scope=scope, limit=limit)


def _norm(p: str) -> str:
    return os.path.normpath(os.path.abspath(str(p).strip().strip('"').strip("'")))


def _hard_ignored(path: str, policy: Optional[Dict[str, Any]] = None) -> bool:
    p = policy or load_index_policy()
    cd = p.get("candidate_discovery", {}) if isinstance(p.get("candidate_discovery"), dict) else {}
    hard = set(str(x).lower() for x in cd.get("hard_ignore_dirs", []))
    parts = [x.lower() for x in path.replace("/", "\\").split("\\") if x]
    return any(part in hard for part in parts)


def _read_head(path: str, max_chars: int) -> Optional[str]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            txt = f.read(max_chars)
        return txt.replace("\x00", "").strip()
    except Exception:
        return None


def _entry_type(path: str) -> str:
    if os.path.isdir(path):
        return "dir"
    if os.path.isfile(path):
        return "file"
    return "missing"


def path_evidence(path: str, *, max_children: Optional[int] = None, max_heads: Optional[int] = None) -> Dict[str, Any]:
    """Return factual evidence for a path. No semantic tag inference."""
    pol = load_index_policy()
    p = _norm(path)
    max_children = int(max_children if max_children is not None else pol.get("evidence_max_children", 80))
    max_heads = int(max_heads if max_heads is not None else pol.get("evidence_max_heads", 3))
    max_head_chars = int(pol.get("text_head_max_chars", 1200))
    cd = pol.get("candidate_discovery", {}) if isinstance(pol.get("candidate_discovery"), dict) else {}
    text_exts = set(str(x).lower() for x in cd.get("text_extensions", []))
    doc_exts = set(str(x).lower() for x in cd.get("document_extensions", []))
    ev: Dict[str, Any] = {"path": p, "node_type": _entry_type(p), "exists": os.path.exists(p)}
    try:
        st = os.stat(p, follow_symlinks=False)
        ev.update({"size": int(st.st_size), "mtime_ns": int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))})
    except OSError as e:
        ev["stat_error"] = str(e)
        return ev
    if os.path.isfile(p):
        ext = os.path.splitext(p)[1].lower()
        ev["extension"] = ext
        ev["is_document_ext"] = ext in doc_exts
        if ext in text_exts:
            head = _read_head(p, max_head_chars)
            if head:
                ev["content_head"] = head
                ev["content_head_note"] = "Use only as evidence for this file itself; distinguish self-description from external references/examples."
        return ev
    if not os.path.isdir(p):
        return ev
    children: List[Dict[str, Any]] = []
    heads: List[Dict[str, Any]] = []
    ext_counter: Counter[str] = Counter()
    dir_count = 0
    file_count = 0
    try:
        with os.scandir(p) as it:
            for ent in it:
                if len(children) >= max_children:
                    break
                ep = ent.path
                if _hard_ignored(ep, pol):
                    continue
                is_dir = ent.is_dir(follow_symlinks=False)
                is_file = ent.is_file(follow_symlinks=False)
                if is_dir:
                    dir_count += 1
                if is_file:
                    file_count += 1
                ext = os.path.splitext(ent.name)[1].lower() if is_file else ""
                if ext:
                    ext_counter[ext] += 1
                item: Dict[str, Any] = {"name": ent.name, "path": os.path.normpath(ep), "is_dir": is_dir, "is_file": is_file, "extension": ext}
                try:
                    st = ent.stat(follow_symlinks=False)
                    item["size"] = int(st.st_size)
                    item["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
                except OSError:
                    pass
                children.append(item)
                if is_file and len(heads) < max_heads and ext in text_exts:
                    head = _read_head(ep, max_head_chars)
                    if head:
                        heads.append({"path": os.path.normpath(ep), "name": ent.name, "head": head, "note": "Evidence for this child only; do not treat external references/examples as parent route tags."})
    except OSError as e:
        ev["scandir_error"] = str(e)
        return ev
    ev.update({
        "dir_count_sampled": dir_count,
        "file_count_sampled": file_count,
        "file_type_mix_sampled": dict(ext_counter.most_common(20)),
        "children_sample": children,
        "document_heads": heads,
        "annotation_contract": [
            "Agent decides brief/route_tags; helper does not infer semantics.",
            "Route tags must describe this path's main search use.",
            "Do not use sibling/neighbor project semantics as evidence.",
            "Do not turn external references, badges, templates, examples, or dependencies into parent route tags.",
            "If evidence is insufficient, defer/need_more_evidence; do not skip merely because a directory is generic-looking or small."
        ]
    })
    return ev


def search_to_evidence(query: str, scope: Optional[str] = None, limit: int = 20, evidence_limit: int = 8) -> Dict[str, Any]:
    res = search_files_detailed(query, scope=scope, limit=limit)
    packets = [path_evidence(row["path"]) for row in (res.get("hits") or [])[: max(0, int(evidence_limit))]]
    return {"ok": res.get("ok"), "query": query, "scope": scope, "search": res, "evidence_packets": packets}


def explore_scope(scope: str, *, recent_limit: int = 100, top_level: bool = True) -> Dict[str, Any]:
    """Factual starting point for Agent-led cold start. No semantic judgment."""
    p = _norm(scope)
    out: Dict[str, Any] = {"ok": os.path.exists(p), "scope": p, "top_level": [], "recent": [], "notes": ["Use this to choose candidate entries; do not treat it as an index plan."]}
    if top_level and os.path.isdir(p):
        try:
            with os.scandir(p) as it:
                for ent in it:
                    if _hard_ignored(ent.path):
                        continue
                    item: Dict[str, Any] = {"name": ent.name, "path": os.path.normpath(ent.path), "is_dir": ent.is_dir(follow_symlinks=False), "is_file": ent.is_file(follow_symlinks=False)}
                    try:
                        st = ent.stat(follow_symlinks=False)
                        item["mtime_ns"] = int(getattr(st, "st_mtime_ns", int(st.st_mtime * 1e9)))
                    except OSError:
                        pass
                    out["top_level"].append(item)
        except OSError as e:
            out["top_level_error"] = str(e)
    try:
        out["recent"] = recent_files(scope=p, limit=recent_limit)
    except Exception as e:
        out["recent_error"] = str(e)
    return out


def recall(query: str, limit: int = 20, include_cold: bool = False, *, task_id: Optional[str] = None) -> Dict[str, Any]:
    tid = task_id or begin_file_task(query).get("task_id")
    alias = alias_lookup(query)
    hits: List[Dict[str, Any]] = []
    if alias:
        n = node(alias["path"])
        if n:
            n["alias_hit"] = True
            hits.append(n)
    hits.extend(_recall(query, limit=limit, include_cold=include_cold))
    dedup: List[Dict[str, Any]] = []
    seen = set()
    for h in hits:
        if h.get("path") not in seen:
            seen.add(h.get("path"))
            dedup.append(h)
    record_task_hits(tid, semantic_hits=dedup, dirty=False)
    return {"ok": True, "task_id": tid, "query": query, "hits": dedup[:limit], "finalize_required": True}


def locate(query: str, *, scope: Optional[str] = None, limit: int = 20, include_cold: bool = False, fallback_files: bool = True) -> Dict[str, Any]:
    r = recall(query, limit=limit, include_cold=include_cold)
    tid = r["task_id"]
    fs: List[Dict[str, Any]] = []
    fallback_used = False
    if fallback_files and not r["hits"]:
        try:
            fs = search_files(query, scope=scope, limit=limit, task_id=tid)
            fallback_used = bool(fs)
        except Exception as e:
            return {**r, "filesystem_hits": [], "fallback_used": False, "error": str(e)}
    return {**r, "filesystem_hits": fs, "fallback_used": fallback_used, "finalize_required": True}



# --- v28 runtime convenience surface -------------------------------------------------

def recall_hits(query: str, limit: int = 20, include_cold: bool = False) -> List[Dict[str, Any]]:
    """Low-friction recall: return just the hit list while still recording task_ledger."""
    return recall(query, limit=limit, include_cold=include_cold).get("hits", [])


def locate_hits(query: str, *, scope: Optional[str] = None, limit: int = 20, include_cold: bool = False, fallback_files: bool = True) -> List[Dict[str, Any]]:
    """Low-friction locate: return semantic hits plus fallback filesystem hits as rows."""
    res = locate(query, scope=scope, limit=limit, include_cold=include_cold, fallback_files=fallback_files)
    return list(res.get("hits") or []) + list(res.get("filesystem_hits") or [])


def search_files_rows(query: str, scope: Optional[str] = None, limit: int = 50, *, task_id: Optional[str] = None) -> List[Dict[str, Any]]:
    """Everything thin wrapper with stable list[dict] return."""
    return search_files(query, scope=scope, limit=limit, task_id=task_id)


def search_files_paths(query: str, scope: Optional[str] = None, limit: int = 50, *, task_id: Optional[str] = None) -> List[str]:
    """Everything thin wrapper with stable list[str] return."""
    return [str(r.get("path")) for r in search_files_rows(query, scope=scope, limit=limit, task_id=task_id) if isinstance(r, dict) and r.get("path")]


def _find_recent_task(query: str = "", *, max_age_seconds: int = 3600) -> Optional[str]:
    """Bind only to a recent open task for the same query.

    Never fall back to an arbitrary open task: wrong binding is worse than
    creating a new task, because it corrupts runtime after-effect accounting.
    """
    q = str(query or "").strip()
    if not q:
        return None
    c = conn()
    try:
        import time
        now = time.time()
        r = c.execute(
            "SELECT task_id,updated_at FROM task_ledger WHERE status='open' AND query=? ORDER BY updated_at DESC LIMIT 1",
            (q,),
        ).fetchone()
        if r and now - float(r["updated_at"] or 0) <= max_age_seconds:
            return str(r["task_id"])
        return None
    finally:
        c.close()


def run_file_query(query: str, scope: Optional[str] = None, limit: int = 20, include_cold: bool = False, fallback: bool = True) -> Dict[str, Any]:
    """One-call runtime query: recall first, then thin Everything fallback, with a task_id."""
    res = recall(query, limit=limit, include_cold=include_cold)
    task_id = res.get("task_id")
    recall_rows = list(res.get("hits") or [])
    search_rows: List[Dict[str, Any]] = []
    if fallback and (not recall_rows or len(recall_rows) < min(3, limit)):
        try:
            search_rows = search_files_rows(query, scope=scope, limit=limit, task_id=task_id)
        except Exception as e:
            return {**res, "search_hits": [], "all_hits": recall_rows, "fallback_error": str(e), "finalize_required": True}
    seen = set()
    all_hits: List[Dict[str, Any]] = []
    for row in recall_rows + search_rows:
        p = row.get("path") if isinstance(row, dict) else None
        if p and p not in seen:
            seen.add(p)
            all_hits.append(row)
    return {"ok": True, "task_id": task_id, "query": query, "recall_hits": recall_rows, "search_hits": search_rows, "all_hits": all_hits, "finalize_required": True, "fallback_used": bool(search_rows)}


def finish_local_file_task(query: str, used: Optional[Sequence[str]] = None, found: Optional[Sequence[str]] = None, rejected: Optional[Sequence[str]] = None, fallback_used: Optional[bool] = None, mode: str = "draft", task_id: Optional[str] = None) -> Dict[str, Any]:
    """Low-friction finalize. task_id is optional; bind only to same-query task or create one.

    fallback_used defaults to auto inference: True only when found/used includes
    an external path not already indexed. This avoids polluting update_plans for
    pure recall hits.
    """
    used_list = [os.path.normpath(str(p)) for p in (used or []) if p]
    found_list = [os.path.normpath(str(p)) for p in (found or []) if p]
    rejected_list = [os.path.normpath(str(p)) for p in (rejected or []) if p]
    tid = task_id or _find_recent_task(query)
    created = False
    if not tid:
        tid = begin_file_task(query).get("task_id")
        created = True
    if fallback_used is None:
        fallback_used = any(not is_indexed(p) for p in list(dict.fromkeys(used_list + found_list)))
    res = finalize_file_task(task_id=tid, query=query, used_paths=used_list, found_paths=found_list, rejected_paths=rejected_list, fallback_used=bool(fallback_used), mode=mode)
    res["bound_task_id"] = tid
    res["created_task"] = created
    res["fallback_used_inferred"] = fallback_used
    return res


def record_correction(query: str, wrong_paths: Optional[Sequence[str]] = None, missed_paths: Optional[Sequence[str]] = None, note: str = "") -> Dict[str, Any]:
    """Record user/Agent correction as first-class runtime evidence.

    Wrong paths become immediate query-level negative evidence; missed paths are
    retained in a draft update plan for Agent review.
    """
    wrong = [os.path.normpath(str(p)) for p in (wrong_paths or []) if p]
    missed = [os.path.normpath(str(p)) for p in (missed_paths or []) if p]
    payload = {"query": query, "wrong_paths": wrong, "missed_paths": missed, "note": note}
    log_event("correction", payload)
    for p in wrong:
        log_event("not_relevant", {"query": query, "path": p, "reason": note or "record_correction wrong_path"})
        log_event("negative_evidence", {"query": query, "path": p, "evidence_note": note or "record_correction wrong_path"})
    for p in missed:
        log_event("missed_relevant", {"query": query, "path": p, "note": note or "record_correction missed_path"})
    plan = draft_update_plan(query=query, found_paths=missed, rejected_paths=wrong, evidence_note=note or "record_correction")
    return {"ok": True, "event": payload, "draft_update_plan": plan, "negative_paths_recorded": wrong, "missed_paths_recorded": missed}


def mark_not_relevant(path: str, query: str, reason: str) -> Dict[str, Any]:
    pth = os.path.normpath(str(path))
    payload = {"path": pth, "query": query, "reason": reason}
    log_event("not_relevant", payload)
    log_event("negative_evidence", {"query": query, "path": pth, "evidence_note": reason or "not relevant for query"})
    plan = draft_update_plan(query=query, rejected_paths=[pth], evidence_note=reason or "not relevant for query")
    return {"ok": True, "path": pth, "query": query, "reason": reason, "draft_update_plan": plan}


def update_entry_tags(path: str, add: Optional[Sequence[str]] = None, remove: Optional[Sequence[str]] = None, evidence_note: Optional[str] = None, mode: str = "draft", force_route: bool = False) -> Dict[str, Any]:
    """Update route tags/facets with evidence.

    Weak type labels are facets by default, not route tags. Use force_route=True
    only with a strong evidence_note when a weak-looking label is intentionally a
    search route.
    """
    pth = os.path.normpath(str(path))
    note = str(evidence_note or "").strip()
    if not note:
        return {"ok": False, "path": pth, "error": "evidence_note required for tag update"}
    n = get_node(pth)
    if not n:
        return {"ok": False, "path": pth, "error": "node not found"}
    cur_tags = set(n.get("tags") or [])
    cur_facets = set(n.get("facets") or [])
    add_set = set(_norm_tag_value(x) for x in (add or []) if str(x).strip())
    rem_set = set(_norm_tag_value(x) for x in (remove or []) if str(x).strip())
    cur_weak = set() if force_route else {t for t in cur_tags if t in _weak_route_tags()}
    weak_add = set() if force_route else {t for t in add_set if t in _weak_route_tags()}
    route_add = add_set - weak_add
    # In normal mode, existing weak route tags are migrated to facets instead of
    # being preserved as route tags. This prevents runtime updates from keeping
    # type/file-form labels as semantic search routes.
    new_tags = sorted(((cur_tags - cur_weak) | route_add) - rem_set)
    new_facets = sorted((cur_facets | cur_weak | weak_add) - rem_set)
    warnings: List[str] = []
    if not new_tags and new_facets:
        warnings.append("entry_has_no_route_tags_after_weak_tag_migration")
    payload = {
        "path": pth,
        "add": sorted(add_set),
        "remove": sorted(rem_set),
        "route_add": sorted(route_add),
        "facet_add": sorted(weak_add),
        "migrated_weak_route_tags": sorted(cur_weak),
        "new_tags": new_tags,
        "new_facets": new_facets,
        "force_route": bool(force_route),
        "evidence_note": note,
        "warnings": warnings,
    }
    if mode == "draft":
        log_event("draft_tag_update", payload)
        return {"ok": True, "status": "draft", **payload}
    res = set_tags(pth, new_tags, note, replace=True)
    if res.get("ok"):
        set_facets(pth, new_facets, replace=True)
        log_event("tag_update", payload)
        res["facets"] = new_facets
        res["warnings"] = warnings
        res["rebalance"] = maintenance_tick()
    return res


def _events_by_type(event_types: Sequence[str], limit: int = 200) -> List[Dict[str, Any]]:
    c = conn()
    try:
        marks = ",".join("?" for _ in event_types)
        rows = c.execute(f"SELECT event_type,payload_json,created_at FROM events WHERE event_type IN ({marks}) ORDER BY created_at DESC LIMIT ?", list(event_types) + [int(limit)]).fetchall()
        out = []
        for r in rows:
            try:
                payload = json.loads(r["payload_json"] or "{}")
            except Exception:
                payload = {}
            out.append({"event_type": r["event_type"], "payload": payload, "created_at": r["created_at"]})
        return out
    finally:
        c.close()


def audit_runtime(limit: int = 50) -> Dict[str, Any]:
    """Audit runtime closure: task binding, consumed recall, fallback finalization, and correction effects."""
    c = conn()
    warnings: List[str] = []
    try:
        open_rows = [dict(r) for r in c.execute("SELECT task_id,query,dirty,semantic_hits_json,filesystem_hits_json,fallback_used,created_at,updated_at FROM task_ledger WHERE status='open' ORDER BY updated_at DESC LIMIT ?", (int(limit),)).fetchall()]
        dirty = [r for r in open_rows if int(r.get("dirty") or 0)]
        recall_unclosed = []
        fallback_unclosed = []
        for r in open_rows:
            try:
                sem = json.loads(r.get("semantic_hits_json") or "[]")
                fs = json.loads(r.get("filesystem_hits_json") or "[]")
            except Exception:
                sem, fs = [], []
            if sem:
                recall_unclosed.append({"task_id": r["task_id"], "query": r["query"], "hits": len(sem)})
            if fs or int(r.get("fallback_used") or 0):
                fallback_unclosed.append({"task_id": r["task_id"], "query": r["query"], "filesystem_hits": len(fs)})

        finalized_events = _events_by_type(["task_finalized"], limit=500)
        finalized_by_task = {e["payload"].get("task_id"): e["payload"] for e in finalized_events if e["payload"].get("task_id")}
        closed_rows = [dict(r) for r in c.execute("SELECT task_id,query,semantic_hits_json,filesystem_hits_json,fallback_used,dirty FROM task_ledger WHERE status='closed' ORDER BY updated_at DESC LIMIT ?", (int(limit),)).fetchall()]
        recall_not_consumed = []
        fallback_no_update = []
        hit_count_not_updated = []
        for r in closed_rows:
            try:
                sem = json.loads(r.get("semantic_hits_json") or "[]")
                fs = json.loads(r.get("filesystem_hits_json") or "[]")
            except Exception:
                sem, fs = [], []
            ev = finalized_by_task.get(r["task_id"], {})
            used = [os.path.normpath(str(p)) for p in (ev.get("used_paths") or [])]
            found = [os.path.normpath(str(p)) for p in (ev.get("found_paths") or [])]
            warmed = [os.path.normpath(str(p)) for p in (ev.get("warmed") or [])]
            external_paths = [os.path.normpath(str(p)) for p in (ev.get("external_paths") or [])]
            if not external_paths:
                # Backward-compatible inference for older task_finalized events.
                external_paths = [p for p in list(dict.fromkeys(used + found)) if p and not is_indexed(p)]
            indexed_used = [p for p in used if p and is_indexed(p)]
            if sem and not used:
                recall_not_consumed.append({"task_id": r["task_id"], "query": r["query"], "hits": len(sem)})
            if (fs or int(r.get("fallback_used") or 0)) and external_paths and not ev.get("update_plan_id"):
                fallback_no_update.append({"task_id": r["task_id"], "query": r["query"], "external_paths": len(external_paths)})
            missing_warm = sorted(set(indexed_used) - set(warmed))
            if missing_warm:
                hit_count_not_updated.append({"task_id": r["task_id"], "query": r["query"], "indexed_used_not_warmed": missing_warm[:10]})

        corr_events = _events_by_type(["correction", "not_relevant", "negative_evidence", "missed_relevant", "draft_tag_update", "tag_update"], limit=int(limit))
        corrections = [e for e in corr_events if e["event_type"] == "correction"]
        neg_events = [e for e in corr_events if e["event_type"] in ("not_relevant", "negative_evidence")]
        corrections_without_negative = []
        for e in corrections:
            wrong = set(os.path.normpath(str(p)) for p in (e["payload"].get("wrong_paths") or []))
            if not wrong:
                continue
            q = str(e["payload"].get("query") or "")
            neg_paths = set(os.path.normpath(str(n["payload"].get("path"))) for n in neg_events if str(n["payload"].get("query") or "") == q and n["payload"].get("path"))
            missing = sorted(wrong - neg_paths)
            if missing:
                corrections_without_negative.append({"query": q, "missing_negative_paths": missing})

        if dirty:
            warnings.append(f"open_dirty_tasks={len(dirty)}")
        if recall_unclosed:
            warnings.append(f"recall_hits_without_finish={len(recall_unclosed)}")
        if fallback_unclosed:
            warnings.append(f"fallback_without_finish={len(fallback_unclosed)}")
        if recall_not_consumed:
            warnings.append(f"closed_recall_hits_not_consumed={len(recall_not_consumed)}")
        if fallback_no_update:
            warnings.append(f"fallback_found_without_update={len(fallback_no_update)}")
        if hit_count_not_updated:
            warnings.append(f"used_paths_not_warmed={len(hit_count_not_updated)}")
        if corrections_without_negative:
            warnings.append(f"corrections_without_negative={len(corrections_without_negative)}")
        samples = {
            "open_dirty_tasks": dirty[:10],
            "recall_hits_without_finish": recall_unclosed[:10],
            "fallback_without_finish": fallback_unclosed[:10],
            "closed_recall_hits_not_consumed": recall_not_consumed[:10],
            "fallback_found_without_update": fallback_no_update[:10],
            "used_paths_not_warmed": hit_count_not_updated[:10],
            "corrections_without_negative": corrections_without_negative[:10],
            "recent_runtime_events": corr_events[:10],
        }
        return {"ok": not warnings, "warnings": warnings, "samples": samples}
    finally:
        c.close()


def audit_index(fix: bool = False) -> Dict[str, Any]:
    """Combined structural + runtime audit."""
    structural = _store_audit_index(fix=fix)
    runtime = audit_runtime()
    quality_warnings: List[str] = []
    try:
        policy_weak = _weak_route_tags()
        tags = top_tags(50).get("tags", [])
        weak_top = [t for t in tags if t.get("tag") in policy_weak and int(t.get("count") or 0) >= 5]
        if weak_top:
            quality_warnings.append("weak_route_tags_dominate")
        c = conn()
        try:
            entries_without_route_tags = [dict(r) for r in c.execute(
                """SELECT n.path,n.brief,n.tier,COUNT(f.facet) AS facet_count
                   FROM nodes n
                   LEFT JOIN node_tags t ON t.path=n.path
                   LEFT JOIN node_facets f ON f.path=n.path
                   WHERE n.role='entry'
                   GROUP BY n.path
                   HAVING COUNT(t.tag)=0
                   ORDER BY n.updated_at DESC
                   LIMIT 50"""
            ).fetchall()]
        finally:
            c.close()
        facet_only_entries = [r for r in entries_without_route_tags if int(r.get("facet_count") or 0) > 0]
        if entries_without_route_tags:
            quality_warnings.append(f"entries_without_route_tags={len(entries_without_route_tags)}")
        if facet_only_entries:
            quality_warnings.append(f"facet_only_entries={len(facet_only_entries)}")
        structural["quality"] = {
            "warnings": quality_warnings,
            "weak_top_tags": weak_top,
            "weak_route_tags_source": "policy.quality.weak_route_tags",
            "entries_without_route_tags": entries_without_route_tags[:10],
            "facet_only_entries": facet_only_entries[:10],
        }
    except Exception as e:
        structural["quality_error"] = str(e)
    structural["runtime"] = runtime
    structural["ok"] = bool(structural.get("ok")) and bool(runtime.get("ok")) and not quality_warnings
    return structural

def _candidate_expanded(session_id: str, path: str) -> bool:
    try:
        return bool(candidate_evidence_level(session_id, path).get("expanded"))
    except Exception:
        return False


def _invalid_skip_reason(reason: str) -> Optional[str]:
    r = str(reason or "").strip().lower()
    if not r:
        return "skip reason required"
    forbidden = ["generic", "generic directory", "too few", "few items", "children_count", "file_count", "unsupported extension", "docx", "ppt", "pptx", "xlsx", "office"]
    if any(x in r for x in forbidden):
        return "invalid skip reason; use defer/need_more_evidence for generic-looking, low-count, unsupported-extension, or Office/document candidates"
    allowed_prefixes = ("duplicate", "already-indexed", "out-of-scope", "system", "dependency", "build", "confirmed-noise", "user-excluded", "not-useful-after-expanded-evidence")
    if not any(r.startswith(x) for x in allowed_prefixes):
        return "skip reason must be specific and evidence-backed"
    return None



_DEFAULT_WEAK_ROUTE_TAGS = {
    "python-project", "document-archive", "pdf-documents", "markdown-docs", "web-development",
    "java-project", "wechat-files", "workspace", "documents", "project", "general", "archive",
    "pdf", "python", "frontend", "backend", "data", "dataset", "course-materials"
}


def _weak_route_tags() -> set:
    """Weak route tags come from policy, with a built-in fallback for safety."""
    try:
        q = load_index_policy().get("quality", {})
        vals = q.get("weak_route_tags", []) if isinstance(q, dict) else []
        normed = {_norm_tag_value(x) for x in vals if str(x).strip()}
        return normed or set(_DEFAULT_WEAK_ROUTE_TAGS)
    except Exception:
        return set(_DEFAULT_WEAK_ROUTE_TAGS)

_CLASSIFIER_NOTE_PATTERNS = [
    "主要类型", "文件类型", "个文件", "个子目录", "file types", "extensions", "file_count", "children_count",
    "path_lower", "路径包含", "位于", "located under"
]


def _norm_tag_value(t: str) -> str:
    import re as _re
    s = _re.sub(r"\s+", "-", str(t).strip().lower())
    s = _re.sub(r"[^a-z0-9_\-\u4e00-\u9fff]+", "", s)
    return s


def _anti_classifier_errors(item: Dict[str, Any], *, require_evidence_refs: bool = False) -> Tuple[List[str], List[str], List[str]]:
    """Return (errors, route_tags, facets). Blocks degenerate submission shapes; does not infer semantics."""
    tags = [_norm_tag_value(x) for x in (item.get("tags") or item.get("route_tags") or []) if str(x).strip()]
    explicit_facets = [_norm_tag_value(x) for x in (item.get("facets") or []) if str(x).strip()]
    route_tags = [t for t in tags if t and t not in _weak_route_tags()]
    weak_as_facets = [t for t in tags if t in _weak_route_tags()]
    facets = list(dict.fromkeys(explicit_facets + weak_as_facets))
    note = str(item.get("evidence_note") or item.get("evidence") or "")
    brief = str(item.get("brief") or "")
    refs = item.get("evidence_refs") or item.get("evidence_ref") or []
    if isinstance(refs, str):
        refs = [refs]
    errors: List[str] = []
    if require_evidence_refs and not refs:
        errors.append("evidence_refs required for cold-start commit")
    if not route_tags:
        errors.append("no high-quality route tag; type/file-form tags should be facets, not route_tags")
    if any(pat.lower() in note.lower() for pat in _CLASSIFIER_NOTE_PATTERNS) and not refs:
        errors.append("evidence_note appears to be file-type/path/count classifier without concrete evidence_refs")
    if brief and any(pat.lower() in brief.lower() for pat in ["包含", "主要类型", "contains", "file types"]) and not route_tags:
        errors.append("brief appears generic/file-type-only")
    return errors, route_tags, facets


def commit_candidate(session_id: str, path: str, brief: str, tags: Sequence[str], evidence_note: str, evidence_refs: Sequence[str], tier: str = "warm", leaf_candidates: Optional[Sequence[Any]] = None, facets: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    """Cold-start transactional commit. Prefer this over raw apply_index_plan in cold start."""
    level = candidate_evidence_level(session_id, path)
    if not level.get("expanded"):
        try:
            mark_candidates(session_id, needs_more_evidence_paths=[path])
        except Exception:
            pass
        return {"ok": False, "status": "needs_more_evidence", "path": os.path.normpath(str(path)), "error": "expand_candidate required before commit_candidate", "next": "expand_candidate(session_id, path)"}
    item = {"path": path, "role": "entry", "tier": tier, "brief": brief, "tags": list(tags or []), "facets": list(facets or []), "evidence_note": evidence_note, "evidence_refs": list(evidence_refs or []), "leaf_candidates": list(leaf_candidates or [])}
    errors, route_tags, merged_facets = _anti_classifier_errors(item, require_evidence_refs=True)
    if errors:
        try:
            mark_candidates(session_id, needs_more_evidence_paths=[path])
        except Exception:
            pass
        return {"ok": False, "status": "needs_verification", "path": os.path.normpath(str(path)), "errors": errors, "suggested_facets": merged_facets, "next": "rewrite using concrete expanded evidence or defer_candidate(...)"}
    item["tags"] = route_tags
    item["facets"] = merged_facets
    return apply_index_plan([item], session_id=session_id, allow_unexpanded=False)

def apply_index_plan(plan: Sequence[Dict[str, Any]], *, session_id: Optional[str] = None, allow_unexpanded: bool = False) -> Dict[str, Any]:
    """Apply Agent-authored plan and advance cold-start status.

    When session_id is provided, applying an entry requires expanded evidence
    unless allow_unexpanded=True. This prevents path-name-only tagging during
    cold start. Use expand_candidate(session_id, path) first.
    """
    plan = list(plan or [])
    blocked: List[Dict[str, Any]] = []
    executable: List[Dict[str, Any]] = []
    if session_id and not allow_unexpanded:
        for item in plan:
            action = str(item.get("action") or "apply").lower()
            path = item.get("path")
            if action == "apply" and path and not _candidate_expanded(session_id, path):
                blocked.append({"path": os.path.normpath(str(path)), "error": "expanded evidence required before apply", "next": "expand_candidate(session_id, path), then retry apply_index_plan"})
            elif action == "apply" and path:
                errors, route_tags, merged_facets = _anti_classifier_errors(item, require_evidence_refs=False)
                pure_classifier = any("no high-quality route tag" in e or "classifier" in e for e in errors)
                if pure_classifier:
                    blocked.append({"path": os.path.normpath(str(path)), "error": "; ".join(errors), "suggested_facets": merged_facets, "next": "Use commit_candidate with concrete evidence_refs, or defer_candidate(...)."})
                else:
                    item = dict(item)
                    if route_tags:
                        item["tags"] = route_tags
                    if merged_facets:
                        item["facets"] = list(dict.fromkeys(list(item.get("facets") or []) + merged_facets))
                    executable.append(item)
            elif action == "skip" and path:
                err = _invalid_skip_reason(str(item.get("reason") or ""))
                if err:
                    blocked.append({"path": os.path.normpath(str(path)), "error": err, "next": "Use defer_candidate/need_more_evidence or expand_candidate; do not skip unknown high-value candidates."})
                else:
                    executable.append(item)
            else:
                executable.append(item)
    else:
        executable = plan
    res = _store_apply_index_plan(executable)
    if blocked:
        try:
            mark_candidates(session_id, needs_more_evidence_paths=[x["path"] for x in blocked])
        except Exception as e:
            res["cold_start_mark_error"] = str(e)
        res.setdefault("rejected", [])
        res["rejected"].extend(blocked)
        res["deferred_count"] = len(res.get("deferred", []))
        res["rejected_count"] = len(res.get("rejected", []))
        res["ok"] = False
    if session_id:
        applied_paths = [x.get("path") for x in res.get("applied", []) if x.get("path")]
        skipped_paths = [x.get("path") for x in res.get("skipped", []) if x.get("path")]
        deferred_paths = [x.get("path") for x in res.get("deferred", []) if x.get("path")]
        deferred_paths.extend([x.get("path") for x in blocked if x.get("path")])
        # Explicit plan actions also count, even if store rejected nothing.
        for item in executable:
            action = str(item.get("action") or "apply").lower()
            if item.get("path") and action == "skip":
                skipped_paths.append(item.get("path"))
            elif item.get("path") and action in ("defer", "need_more_evidence", "needs_more_evidence"):
                deferred_paths.append(item.get("path"))
        try:
            res["cold_start_mark"] = mark_candidates(session_id, applied_paths=list(dict.fromkeys(applied_paths)), skipped_paths=list(dict.fromkeys(skipped_paths)), deferred_paths=list(dict.fromkeys(deferred_paths)))
        except Exception as e:
            res["cold_start_mark_error"] = str(e)
    return res


def maintenance_tick() -> Dict[str, Any]:
    return rebalance_tiers()



__all__ = [
    "ensure_search_ready", "init_db", "reset_db",
    "recall", "recall_hits", "locate", "locate_hits", "run_file_query",
    "search_files", "search_files_rows", "search_files_paths", "search_files_detailed", "last_search_diagnostic",
    "finish_local_file_task", "record_correction", "mark_not_relevant", "update_entry_tags",
    "recent_files", "explore_scope", "begin_cold_start", "collect_cold_start_entries", "cold_start_batch", "cold_start_evidence_batch", "cold_start_status", "candidate_evidence_level", "expand_candidate", "commit_candidate", "skip_candidate", "defer_candidate", "finish_cold_start", "path_evidence", "search_to_evidence", "annotate_entry", "annotate_leaf",
    "attach_leaf", "apply_index_plan", "begin_file_task", "finalize_file_task",
    "draft_update_plan", "apply_update_plan", "list_pending_update_plans", "stats", "audit_index", "audit_runtime", "virtual_tree", "rebalance_tiers",
    "get_node", "list_nodes", "list_entries", "list_leaf", "top_tags", "index_summary", "search_index", "nodes_by_tag", "maintenance_tick",
    "load_index_policy", "policy_paths", "audit_policy", "update_local_policy_patch", "print_json"
]
