"""file_index_sop v10: multistream entry-first semantic coverage over Everything/es.exe."""
__version__ = "v10"
