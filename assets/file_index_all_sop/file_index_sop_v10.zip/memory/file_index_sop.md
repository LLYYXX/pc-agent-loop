# 文件语义索引 Skill（v10：多流候选 + 父级语义入口 + 严格 route tag）

本 Skill 是 Everything / `es.exe` 之上的**正交语义覆盖层**。`es.exe` 负责文件事实检索；本索引只补充路径/文件名无法稳定表达的用途、任务关系、材料归属、项目语义和查询别名。

v10 回到最初目标：

```text
全盘多流发现高价值文件候选
→ 向父目录 / 祖父目录 / 项目根 / 材料根聚合
→ 语义化这些父级范围节点（entry）
→ 自动挂载代表性文件/目录（leaf）
→ Agent 先 recall 命中 entry scope，再用 es.exe 在 scope 内精确搜索
```

不要把冷启动做成“1000 个 path 逐项填表”。entry 是语义入口；leaf 是支撑材料。最终节点数接近 1000，但核心质量看 entry 是否能为真实任务提供 scope。

## 核心边界

- 主索引库只保存当前可用节点：`file / dir` + `active / warm / cold` + `brief / tags`。
- `relation.role = entry` 表示语义入口；`relation.role = leaf` 表示入口下的支撑节点。
- `ignore_rules.json` 是负向规则数组；`events.jsonl` 是日志。
- 不后台 watcher，不向量库，不 hook `file_read`。
- route tag 不是分类标签、路径复读、文件类型词；它必须是能把用户自然语言意图路由到 scope 的高信息语义键。

## import

```python
import os, sys
ROOT = os.path.abspath(os.path.join(os.getcwd(), ".."))
sys.path.insert(0, os.path.join(ROOT, "memory"))
from file_index_sop.helper import *
```

## 使用前准备

```python
print_json(ensure_search_ready(start=True, patch=True))
print_json(init_db())
print_json(stats())
```

`ensure_search_ready()` 负责嗅探/自启动 Everything，并 patch `LOCAL_TOOLS`。`everything.py` 只执行已配置好的 `es.exe` 查询。

## 运行时检索流程

```python
hits = recall("用户语义意图", limit=8)
```

优先使用 `role == "entry"` 且 `node_type == "dir"` 的命中作为 scope：

```python
search_files("文件事实词，如 result csv config invoice", scope=hits[0]["path"], limit=20)
```

若命中文件：直接 `file_read(path)`，成功后 `mark_used(path)`；失败后 `report_file_deleted(path, reason="file_read_failed")`。

如果语义索引没命中：

```python
summary = miss_recovery_batch("用户查询", memory_text="可用 Memory 摘要", limit=80)
# Agent 标注 summary["entries"] 中的父级范围节点
apply_index_plan(plan)
rebalance(max_nodes=1000, max_active=220)
```

## 冷启动目标

用户要求“针对 F 盘建索引”时，目标是：

- 生成一批高质量 entry：项目根、材料根、实验根、报销根、课程根、工具根等。
- 每个 active/warm entry 必须有具体 brief 和 route tags。
- leaf 自动从 entry 下 materialize，通常为 cold，不要求独立 tag。
- 总节点尽量接近 1000；不要为了凑 entry 数写 `materials/archive/unity-project/development-workspace` 这种低信息 tag。
- `.git`、`node_modules`、`$RECYCLE.BIN`、缓存、日志、构建产物、应用数据目录、QQ 图片缓存等不应进入主索引。

## v10 冷启动流程

### 1. 创建 session（快速返回）

```python
res = begin_cold_start(
    target_nodes=1000,
    max_active=220,
    scope=r"F:\\",
    memory_text="这里填可用的 Agent Memory 摘要",
    agent_queries=["mcp", "trajectory", "轨迹", "元应用", "论文", "实验", "报销", "invoice", "receipt", "ml-agents", "llm", "paddle"],
)
print_json(res)
session_id = res["session_id"]
```

v10 的 `begin_cold_start()` 只创建 session，不扫描 F 盘。返回 `mode = v10-multistream-entry-first`。

### 2. 多轮收集 entry 候选

`collect_cold_start_entries()` 内部使用多流发现：recent-by-type、项目 marker、文档类型、Memory/query。多轮调用保证覆盖面；单轮有预算，避免卡死。

```python
while True:
    print_json(collect_cold_start_entries(
        session_id,
        max_queries=6,
        limit_per_query=100,
        recent_limit=1000,
        max_entries=100,
        time_budget_sec=30,
    ))
    status = cold_start_status(session_id)
    if status["pending"] >= 40 or status["collection_done"]:
        break
```

### 3. Agent 标注 entry

```python
batch = cold_start_batch(session_id, batch_size=30)
print_json(batch)
```

每个 item 会包含：`path`、`probe`、`signals`、`suggested_route_tags`、`leaf_candidates`。Agent 应优先使用 probe 证据和 suggested route tags，而不是路径模板。

Plan item：

```python
{
  "path": r"F:\\...\\真实父级范围",  # 必须来自 batch items
  "node_type": "dir",
  "tier": "active" / "warm" / "cold",
  "brief": "一行说明该范围未来为什么值得进入、能定位哪些任务材料。",
  "tags": ["route-tag", "query-alias"],
  "source": "agent-cold-start"
}
```

若不值得入库：

```python
{"path": batch_path, "action": "skip", "reason": "generated/dependency/low-value"}
```

active/warm entry 如果只提供 generic/category tag，会被拒绝；系统会尝试用 staged item 的 `suggested_route_tags` 自动补足。仍无有效 route tag 时，应 skip 或留待后续任务晋升。

### 4. route tag 准则

只写：

- 用户未来可能用这个语义来找；
- 能显著缩小搜索范围；
- 能把自然语言意图映射到 scope；
- 可以是路径看不出来的语义，也可以是路径无法稳定服务的查询别名。

避免：

- `readme`, `markdown`, `python`, `json`, `csv`, `config`, `test`, `result`, `project`, `folder`, `file`；
- `archive`, `materials`, `general-materials`, `unity-project`, `python-project`, `development-workspace`, `workspace-project`, `game-dev`；
- 纯路径复读，如 `stable-diffusion-webui`、`pc-agent-loop`、`paddleocr-release`。

例子：

```text
PaddleOCR-release-2.5      → ocr-recognition, document-text-extraction, text-recognition
stable-diffusion-webui     → image-generation, diffusion-model-ui, ai-drawing
LLaMA-Factory              → llm-finetuning, model-training-workflow
Unity ML-Agents 项目        → reinforcement-learning, unity-ml-agents, agent-training-simulation
pc-agent-loop              → llm-agent-runtime, gui-automation-agent, local-file-semantic-index
cursor账单                 → software-subscription-billing, reimbursement-records
```

### 5. 完成与验收

```python
print_json(finish_cold_start(session_id, max_nodes=1000, max_active=220))
print_json(audit_index(fix=False))
print_json(stats())
print_json(facets(limit=30))
```

合格结果不是固定测试集通过，而是结构上合理：

- active/warm 主要是 entry；leaf 多为 cold。
- route tag 中不应高频出现 `archive/materials/development-workspace/unity-project` 等分类词。
- entry 有足够 leaf 支撑，不能只有入口没有材料。
- ignored/missing/bad tag/bad brief 接近 0。
- recall 能优先返回有用 entry scope，而不是内部随机文件。

## 维护入口

```python
mark_used(path)
report_file_deleted(path, reason="file_read_failed 或 agent 删除")
report_file_changed(path, note="agent edited")
report_file_moved(old_path, new_path)
report_file_created(path, brief="...", tags=["..."], tier="warm")
```

不要在 `file_read` 前额外做存在性检查；文件操作成功/失败后再同步索引。
