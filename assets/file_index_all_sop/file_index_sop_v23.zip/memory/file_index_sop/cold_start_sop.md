# file_index_sop v23 — cold start SOP

Use this only when the user asks to build or rebuild an initial index for a scope such as `F:\`.

Cold start is Agent-led. Helper provides candidates, rough evidence, expanded evidence, session status, and storage. It does not generate semantic route tags.

## Import and start

```python
from file_index_sop import *
ensure_search_ready(start=True, patch=True)
init_db()
res = begin_cold_start(scope="F:\\", target_nodes=1000)
sid = res["session_id"]
```

## Candidate loop

```python
collect_cold_start_entries(sid)
batch = cold_start_batch(sid, batch_size=6)
items = batch["items"]
```

`cold_start_batch` is rough triage. Do not apply route tags from rough evidence alone.

For any item to apply:

```python
expanded = expand_candidate(sid, item["path"])
# read expanded["item"]["evidence"], especially children_sample, file_type_mix_sampled, document_heads/content_head if present
```

Then the Agent chooses exactly one:

```python
# apply
apply_index_plan([
  {
    "path": path,
    "role": "entry",
    "tier": "warm",
    "brief": "Agent-written one-line scope description",
    "tags": ["accurate-route-tag"],
    "evidence_note": "Based on expanded evidence: ...",
    "leaf_candidates": [ ... optional representative paths ... ]
  }
], session_id=sid)

# skip if still not worth indexing
skip_candidate(sid, path, reason="...")

# defer if more evidence is needed later
defer_candidate(sid, path, reason="...")
```

Rejected apply results are not progress. If `apply_index_plan` says expanded evidence is required, call `expand_candidate` and retry or skip/defer.

## Finish

```python
finish = finish_cold_start(sid)
audit = audit_index()
summary = index_summary()
```

Only `finish["status"] == "complete"` may be reported as fully established.
`usable_partial`, `partial`, or `failed` must be reported honestly.

## Candidate policy

- hard-ignore only high-confidence dependency/system/build dirs from policy;
- cache/tmp/log/backup-like names are soft downrank only, not exclusion;
- default queries and marker names are candidate-discovery signals only;
- they must not become route tags automatically.

## Do not

- do not write case-specific rules;
- do not auto-generate route tags from path names;
- do not write if/elif classifiers over paths;
- do not use raw SQL or import internal store functions;
- do not accept an index with only files and no meaningful entries;
- do not call a small partial index complete.
