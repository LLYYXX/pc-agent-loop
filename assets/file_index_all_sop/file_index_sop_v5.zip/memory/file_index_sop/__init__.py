"""file_index_sop: Agent-driven semantic file coverage Skill."""
