"""Agent-facing cold-start and miss-recovery builder.

The builder is deterministic. It never calls an LLM API. Its job is to:
1. use Everything/es.exe to collect real filesystem candidates;
2. remove generated/system/cache/dependency areas before the Agent sees them;
3. stage only verified, physical paths;
4. give the Agent compact batches to label;
5. persist only session-staged paths during cold start.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from . import everything, store

# Path segments that should never become file/dir semantic nodes in cold start.
# These are excluded before directory aggregation so large generated trees cannot
# get high score merely because they contain many files.
HARD_EXCLUDE_SEGMENTS = {
    ".git", ".svn", ".hg", "node_modules", "bower_components",
    "__pycache__", ".venv", "venv", "env", "virtualenv",
    "dist", "build", "target", "out", ".next", ".nuxt", ".vite",
    ".cache", "cache", "caches", ".pytest_cache", ".mypy_cache", ".ruff_cache",
    ".idea", ".vscode", ".vs", "logs", "log", "tmp", "temp", "coverage",
    "site-packages", "library", "obj", "bin", "debug", "release", "deriveddata",
    "$recycle.bin", "system volume information", "wandb", "tensorboard", "checkpoints",
    ".ipynb_checkpoints", "__MACOSX", "wechat files", "xwechat_files",
}
HARD_EXCLUDE_EXTS = {
    ".pyc", ".pyo", ".class", ".o", ".obj", ".dll", ".exe", ".so", ".dylib",
    ".tmp", ".temp", ".cache", ".lock", ".log", ".bak", ".swp", ".swo",
    ".DS_Store", ".lnk"
}
MEDIA_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico", ".mp4", ".mov", ".avi", ".mkv"}
ARCHIVE_EXTS = {".zip", ".7z", ".rar", ".tar", ".gz", ".bz2"}
TEXTISH_EXTS = {
    ".md", ".txt", ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cs", ".go", ".rs",
    ".json", ".yaml", ".yml", ".toml", ".ini", ".csv", ".tsv", ".tex", ".ipynb",
    ".sql", ".pdf", ".docx", ".xlsx", ".xls", ".pptx", ".html", ".vue"
}
ENTRY_BASENAMES = {
    "readme.md", "readme.txt", "package.json", "pyproject.toml", "requirements.txt",
    "dockerfile", "docker-compose.yml", "docker-compose.yaml", "pom.xml", "cargo.toml", "go.mod",
    "main.py", "app.py", "index.js", "index.ts", "setup.py", "makefile", "cmakelists.txt",
    "environment.yml", "conda.yml"
}
PROJECT_MARKERS = {
    ".git", "package.json", "pyproject.toml", "requirements.txt", "setup.py", "pom.xml", "cargo.toml",
    "go.mod", "docker-compose.yml", "docker-compose.yaml", "ProjectSettings", "Assets", "Packages"
}
DEFAULT_DISCOVERY_QUERIES = [
    "README.md", "pyproject.toml", "package.json", "requirements.txt", "docker-compose", "Dockerfile",
    "论文", "paper", "thesis", "实验", "experiment", "results", "报销", "发票", "账单", "invoice", "receipt",
    "mcp", "agent", "trajectory", "memory", "ml-agents", "llm", "paddle", "diffusion", "zotero"
]


def _norm(path: str) -> str:
    return os.path.normpath(os.path.abspath(str(path).strip().strip('"').strip("'")))


def _path_l(path: str) -> str:
    return _norm(path).lower().replace("\\", "/")


def _segments(path: str) -> List[str]:
    p = _norm(path)
    segs: List[str] = []
    while True:
        h, t = os.path.split(p)
        if t:
            segs.append(t.lower())
            p = h
        else:
            if h:
                segs.append(h.lower())
            break
        if h == p:
            break
    return list(reversed(segs))


def _has_bad_segment(path: str) -> Optional[str]:
    for s in _segments(path):
        sl = s.lower()
        if sl in HARD_EXCLUDE_SEGMENTS:
            return sl
    # Additional prefix-ish generated areas.
    pl = _path_l(path)
    if "/appdata/" in pl and any(x in pl for x in ["/cache/", "/logs/", "/temp/"]):
        return "appdata-generated"
    return None


def _exists_path(path: str) -> bool:
    try:
        return os.path.exists(_norm(path))
    except OSError:
        return False


def _is_dir(path: str, row: Optional[Dict[str, Any]] = None) -> bool:
    if row and row.get("is_dir") is not None:
        return bool(row.get("is_dir"))
    try:
        return os.path.isdir(_norm(path))
    except OSError:
        return False


def memory_queries(memory_text: str = "", *, max_queries: int = 30) -> List[str]:
    text = memory_text or ""
    latin = re.findall(r"[A-Za-z][A-Za-z0-9_\-]{2,}", text)
    chinese = re.findall(r"[\u4e00-\u9fff]{2,10}", text)
    stop = {
        "the", "and", "with", "from", "that", "this", "agent", "model", "user", "project", "file",
        "系统", "用户", "当前", "研究", "项目", "实现", "文件", "方向", "需要", "相关", "设计"
    }
    cnt: Counter[str] = Counter()
    for x in latin + chinese:
        if len(x) > 42 or x.lower() in stop or x in stop:
            continue
        cnt[x] += 1
    return [k for k, _ in cnt.most_common(max_queries)]


def merge_queries(agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", *, max_queries: int = 60) -> List[str]:
    out: List[str] = []
    seen = set()
    for q in list(agent_queries or []) + memory_queries(memory_text) + DEFAULT_DISCOVERY_QUERIES:
        qs = str(q).strip()
        if not qs:
            continue
        key = qs.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(qs)
        if len(out) >= max_queries:
            break
    return out


def _purpose_allows_media(purpose: Optional[str]) -> bool:
    p = (purpose or "").lower()
    return any(x in p for x in ["image", "screenshot", "素材", "图片", "截图", "报销", "invoice", "receipt", "发票", "账单"])


def _marker_bonus(path: str) -> Tuple[float, List[str]]:
    """Small project-root/collection signal without scanning deep trees."""
    reasons: List[str] = []
    score = 0.0
    p = _norm(path)
    if os.path.isdir(p):
        # Only look at direct children; no recursive scan.
        try:
            names = set(os.listdir(p)[:500])
        except OSError:
            names = set()
        low = {x.lower() for x in names}
        if ".git" in low:
            score += 18; reasons.append("project-root:git")
        if "assets" in low and "projectsettings" in low:
            score += 18; reasons.append("project-root:unity")
        for marker in ["package.json", "pyproject.toml", "requirements.txt", "setup.py", "pom.xml", "cargo.toml", "go.mod", "docker-compose.yml"]:
            if marker in low:
                score += 10; reasons.append("project-marker:" + marker); break
        if {"invoice", "receipt"} & low:
            score += 8; reasons.append("collection-marker:billing")
    return score, reasons


def classify_candidate(row: Dict[str, Any], *, purpose: Optional[str] = None, memory_terms: Optional[Sequence[str]] = None,
                       ignored: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    path = _norm(row.get("path", ""))
    base = os.path.basename(path)
    bl = base.lower()
    ext = os.path.splitext(bl)[1]
    p_l = _path_l(path)
    reasons: List[str] = []
    hard = False
    score = 0.0

    for ig in ignored or []:
        pat = str(ig.get("pattern", "")).lower().replace("\\", "/").rstrip("/")
        if pat and p_l.startswith(pat):
            hard = True; reasons.append("ignored-pattern"); break

    bad = _has_bad_segment(path)
    if bad:
        hard = True; reasons.append("generated-segment:" + bad)
    if ext in HARD_EXCLUDE_EXTS:
        hard = True; reasons.append("generated-ext:" + ext)
    if re.match(r"^(~\$|\.?#[^/]*|thumbs\.db$|desktop\.ini$)", bl):
        hard = True; reasons.append("auto-filename")
    if not _exists_path(path):
        hard = True; reasons.append("missing-path")

    is_dir = _is_dir(path, row)
    if is_dir:
        b, rs = _marker_bonus(path)
        score += b; reasons.extend(rs)
        # Directories without project/collection markers are not files, but can be staged as scope nodes later.
        if b <= 0:
            score += 1
    else:
        if ext in TEXTISH_EXTS:
            score += 6; reasons.append("textish")
        if bl in ENTRY_BASENAMES:
            score += 14; reasons.append("entry-file")
        if ext in MEDIA_EXTS:
            score += 1 if _purpose_allows_media(purpose) else -14; reasons.append("media")
        if ext in ARCHIVE_EXTS:
            score += 2 if _purpose_allows_media(purpose) else -5; reasons.append("archive")

    high_terms = [
        "论文", "paper", "thesis", "实验", "experiment", "result", "results", "eval", "报销", "发票", "账单",
        "invoice", "receipt", "resume", "简历", "课程", "课题组", "mcp", "agent", "trajectory", "memory",
        "simulation", "benchmark", "genericagent", "ml-agents", "llm", "llama", "paddle", "ocr", "nlp", "diffusion", "zotero"
    ]
    for t in high_terms:
        if t.lower() in p_l:
            score += 4; reasons.append("path-signal:" + t); break
    for t in memory_terms or []:
        tl = t.lower()
        if len(tl) >= 3 and tl in p_l:
            score += 5; reasons.append("memory-signal:" + t[:24]); break
    mt = row.get("mtime_ns")
    if isinstance(mt, int) and mt > 0:
        age = max(0, (time.time() - mt / 1e9) / 86400)
        if age < 7:
            score += 10; reasons.append("recent-7d")
        elif age < 30:
            score += 7; reasons.append("recent-30d")
        elif age < 180:
            score += 4; reasons.append("recent-180d")
        elif age < 730:
            score += 1.5; reasons.append("recent-2y")
    return {
        "path": path, "basename": base, "parent": os.path.dirname(path), "ext": ext,
        "is_dir": is_dir, "hard_exclude": hard, "score": round(score, 4), "reasons": reasons
    }


def collect_candidates(agent_queries: Optional[Sequence[str]] = None, *, memory_text: str = "", scope: Optional[str] = None,
                       limit_per_query: int = 160, include_recent: bool = True, recent_limit: int = 2500,
                       purpose: Optional[str] = None, ignored: Optional[Sequence[Dict[str, Any]]] = None,
                       keep_excluded: bool = False) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    if include_recent:
        try:
            rows.extend(everything.recent(limit=recent_limit, scope=scope, query="*"))
        except Exception as e:
            rows.append({"path": "ERROR:recent", "error": str(e)})
    for q in merge_queries(agent_queries, memory_text):
        try:
            rows.extend(everything.search(q, limit=limit_per_query, scope=scope, sort_mtime_desc=True))
        except Exception as e:
            rows.append({"path": "ERROR:" + q, "error": str(e)})
    terms = memory_queries(memory_text, max_queries=40)
    out: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for r in rows:
        if str(r.get("path", "")).startswith("ERROR:"):
            continue
        c = classify_candidate(r, purpose=purpose, memory_terms=terms, ignored=ignored)
        if c["path"] in seen:
            continue
        seen.add(c["path"])
        if c["hard_exclude"] and not keep_excluded:
            continue
        out.append(c)
    out.sort(key=lambda x: (-x["score"], x["path"]))
    return out


def diversify_by_parent(cands: Sequence[Dict[str, Any]], *, target: int, per_parent: int = 12) -> List[Dict[str, Any]]:
    by: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for c in cands:
        by[c["parent"]].append(c)
    for lst in by.values():
        lst.sort(key=lambda x: -x["score"])
    out: List[Dict[str, Any]] = []
    cap = max(1, per_parent)
    while len(out) < target:
        added = 0
        for parent, lst in sorted(by.items(), key=lambda kv: -kv[1][0]["score"] if kv[1] else 0):
            take = [x for x in lst if not x.get("_taken")][:cap]
            if not take:
                continue
            x = take[0]
            x["_taken"] = True
            out.append(x)
            added += 1
            if len(out) >= target:
                break
        if added == 0:
            break
        if len(out) < target and added < max(3, len(by) // 10):
            cap += 3
    for x in out:
        x.pop("_taken", None)
    return out[:target]


def _safe_parent_chain(path: str, levels: int) -> List[str]:
    out: List[str] = []
    cur = os.path.dirname(_norm(path))
    for _ in range(levels):
        if not cur or cur == os.path.dirname(cur):
            break
        if _has_bad_segment(cur):
            break
        if os.path.isdir(cur):
            out.append(cur)
        cur = os.path.dirname(cur)
    return out


def build_nodes_for_pool(cands: Sequence[Dict[str, Any]], *, target_nodes: int = 1000, max_active: int = 220,
                         parent_levels: int = 2) -> List[Dict[str, Any]]:
    # Keep roughly 70-80% file nodes, 20-30% physical directory/scope nodes.
    dir_budget = max(120, int(target_nodes * 0.24))
    file_budget = max(1, target_nodes - dir_budget)

    file_cands = [c for c in cands if not c.get("is_dir") and not c.get("hard_exclude") and os.path.isfile(c["path"])]
    direct_dirs = [c for c in cands if c.get("is_dir") and not c.get("hard_exclude") and os.path.isdir(c["path"])]

    files = diversify_by_parent(file_cands, target=file_budget, per_parent=10)
    plan: List[Dict[str, Any]] = []
    active_files = max(20, int(max_active * 0.45))
    for i, c in enumerate(files):
        st = "active" if i < active_files and c["score"] >= 12 else ("warm" if c["score"] >= 5 else "cold")
        plan.append({
            "path": c["path"], "node_type": "file", "state": st, "brief": "", "tags": [],
            "source": "cold-start-candidate", "confidence": "candidate", "seed_score": c["score"],
            "evidence": c["reasons"],
            "relation": {"parent": c["parent"], "basename": c["basename"], "ext": c["ext"], "label_required": st == "active"}
        })

    dir_map: Dict[str, Dict[str, Any]] = {}
    # Physical parent/grandparent nodes from selected files.
    for c in files:
        for level, cur in enumerate(_safe_parent_chain(c["path"], parent_levels), start=1):
            d = dir_map.setdefault(cur, {"path": cur, "children": [], "score": 0.0, "level": level, "source": "parent"})
            d["children"].append(c["path"])
            d["score"] += max(1, c["score"]) * (1.0 / level)
    # Direct directory candidates with project markers.
    for c in direct_dirs:
        if c["score"] < 8:
            continue
        cur = c["path"]
        d = dir_map.setdefault(cur, {"path": cur, "children": [], "score": 0.0, "level": 0, "source": "direct"})
        d["score"] += c["score"]
        d.setdefault("reasons", []).extend(c.get("reasons", []))

    dirs = [d for d in dir_map.values() if os.path.isdir(d["path"]) and not _has_bad_segment(d["path"])]
    dirs.sort(key=lambda x: (-len(x.get("children", [])), -x["score"], x["path"]))
    dirs = dirs[:dir_budget]
    active_dirs = max(20, max_active - active_files)
    for i, d in enumerate(dirs):
        child_count = len(d.get("children", []))
        # Active dirs need evidence: multiple children, direct project marker, or high score.
        active_ok = child_count >= 2 or d.get("source") == "direct" or d["score"] >= 35
        st = "active" if i < active_dirs and active_ok else ("warm" if child_count >= 1 or d.get("source") == "direct" else "cold")
        sample = [os.path.basename(x) for x in d.get("children", [])[:12]]
        evidence = [f"children_in_pool={child_count}"] + sample[:8]
        evidence += list(dict.fromkeys(d.get("reasons", [])))[:6]
        plan.append({
            "path": d["path"], "node_type": "dir", "state": st, "brief": "", "tags": [],
            "source": "cold-start-parent", "confidence": "candidate", "seed_score": round(d["score"], 3),
            "evidence": evidence,
            "relation": {"child_count": child_count, "sample_children": sample, "level": d.get("level", 0), "label_required": st == "active"}
        })
    # Stable ordering: active/warm first for Agent labeling, but no generated/system dirs.
    plan = plan[:target_nodes]
    return plan


def make_discovery_summary(cands: Sequence[Dict[str, Any]], *, max_files: int = 80, max_clusters: int = 40) -> Dict[str, Any]:
    top = list(cands[:max_files])
    by: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for c in cands[:max_files * 4]:
        if not c.get("hard_exclude"):
            by[c["parent"]].append(c)
    clusters: List[Dict[str, Any]] = []
    for parent, lst in by.items():
        if _has_bad_segment(parent):
            continue
        lst = sorted(lst, key=lambda x: -x["score"])
        exts = Counter(x["ext"] or ("<dir>" if x.get("is_dir") else "<none>") for x in lst)
        clusters.append({
            "parent": parent, "hit_count": len(lst), "score_sum": round(sum(x["score"] for x in lst), 3),
            "extensions": dict(exts.most_common(8)),
            "samples": [{"path": x["path"], "score": x["score"], "reasons": x["reasons"][:5]} for x in lst[:8]]
        })
    clusters.sort(key=lambda x: (-x["hit_count"], -x["score_sum"]))
    return {
        "candidate_files": [{k: c[k] for k in ("path", "score", "reasons", "parent", "ext")} for c in top],
        "directory_clusters": clusters[:max_clusters],
        "instruction": "Agent must choose staged real paths only. Output high-quality brief; tags only when they add semantic routing value. Do not invent paths."
    }


def prepare_cold_start(conn, *, target_nodes: int = 1000, max_active: int = 220, scope: Optional[str] = None,
                       agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", purpose: Optional[str] = None,
                       recent_limit: int = 2500, limit_per_query: int = 160, parent_levels: int = 2,
                       ignored: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    sid = "cs_" + hashlib.sha1(f"{time.time()}:{os.getpid()}".encode()).hexdigest()[:12]
    cands = collect_candidates(agent_queries, memory_text=memory_text, scope=scope, limit_per_query=limit_per_query,
                               include_recent=True, recent_limit=recent_limit, purpose=purpose, ignored=ignored)
    skeleton = build_nodes_for_pool(cands, target_nodes=target_nodes, max_active=max_active, parent_levels=parent_levels)
    now = time.time()
    meta = {"scope": scope, "queries": list(agent_queries or []), "candidate_count": len(cands), "version": "v5"}
    conn.execute("INSERT INTO build_sessions(session_id,status,target_nodes,max_active,created_at,updated_at,meta) VALUES(?,?,?,?,?,?,?)",
                 (sid, "open", target_nodes, max_active, now, now, json.dumps(meta, ensure_ascii=False)))
    for item in skeleton:
        # Final physical existence guard before staging.
        if not _exists_path(item["path"]):
            continue
        terms = sorted(store.visible_terms(item["path"]))[:32]
        conn.execute("""INSERT OR REPLACE INTO build_items(session_id,path,node_type,suggested_state,seed_score,evidence,relation,visible_terms,status,batch_no,created_at,updated_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (sid, item["path"], item["node_type"], item["state"], item["seed_score"],
                      json.dumps(item["evidence"], ensure_ascii=False), json.dumps(item["relation"], ensure_ascii=False),
                      json.dumps(terms, ensure_ascii=False), "pending", 0, now, now))
    conn.commit()
    staged = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=?", (sid,)).fetchone()[0]
    return {"ok": True, "session_id": sid, "candidate_count": len(cands), "staged_items": staged,
            "target_nodes": target_nodes, "max_active": max_active, "note": "Only staged physical paths may be applied."}


def cold_start_batch(conn, session_id: str, *, batch_size: int = 50) -> Dict[str, Any]:
    rows = list(conn.execute("""SELECT * FROM build_items
                              WHERE session_id=? AND status='pending'
                              ORDER BY suggested_state='active' DESC, seed_score DESC
                              LIMIT ?""", (session_id, max(1, batch_size))))
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    done = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    skipped = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='skipped'", (session_id,)).fetchone()[0]
    items = []
    for r in rows:
        rel = json.loads(r["relation"] or "{}")
        items.append({
            "path": r["path"], "node_type": r["node_type"], "suggested_state": r["suggested_state"],
            "seed_score": r["seed_score"], "visible_terms": json.loads(r["visible_terms"] or "[]"),
            "evidence": json.loads(r["evidence"] or "[]"), "relation": rel,
            "required_output": {
                "brief": "one short line; do not restate path",
                "tags": "0-3 high-information residual tags; active nodes require at least one kept tag; warm may be brief-only",
                "no_invented_paths": "path must be exactly this staged path"
            }
        })
    return {"ok": True, "session_id": session_id, "pending": pending, "applied": done, "skipped": skipped, "items": items}


def _staged_map(conn, session_id: str) -> Dict[str, Dict[str, Any]]:
    rows = conn.execute("SELECT * FROM build_items WHERE session_id=?", (session_id,)).fetchall()
    out: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        p = os.path.normpath(os.path.abspath(r["path"]))
        out[p] = dict(r)
    return out


def apply_index_plan(conn, plan: Sequence[Dict[str, Any]], *, default_state: str = "warm", default_source: str = "agent-builder",
                     enforce_tag_gate: bool = True, fts_ok: bool = False, session_id: Optional[str] = None) -> Dict[str, Any]:
    out: Dict[str, Any] = {"applied": 0, "skipped": 0, "errors": [], "warnings": [], "rejected_tags": []}
    staged = _staged_map(conn, session_id) if session_id else {}
    for item in plan:
        try:
            path = str(item.get("path") or "").strip()
            if not path:
                raise ValueError("missing path")
            p = os.path.normpath(os.path.abspath(path))
            if session_id:
                st_row = staged.get(p)
                if not st_row:
                    raise ValueError("path not in cold-start staged items; do not invent paths")
                if st_row.get("status") not in ("pending",):
                    out["warnings"].append({p: f"build item already {st_row.get('status')}"})
                    continue
            if not os.path.exists(p):
                raise ValueError("path does not exist on disk")
            action = str(item.get("action") or "").lower().strip()
            if action in {"skip", "ignore"}:
                if session_id:
                    conn.execute("UPDATE build_items SET status='skipped',updated_at=? WHERE session_id=? AND path=?",
                                 (time.time(), session_id, p))
                if action == "ignore":
                    store.add_ignored_path(conn, p, reason=str(item.get("reason") or "agent ignored"), source=item.get("source") or default_source)
                out["skipped"] += 1
                continue
            brief = str(item.get("brief") or "").strip()
            tags = item.get("tags") or []
            state = str(item.get("state") or default_state)
            if state not in {"active", "warm", "cold", "stale", "retired"}:
                state = default_state
            if session_id:
                if not brief:
                    raise ValueError("cold-start item missing brief")
                # In v5, only active nodes require a retained tag. Warm can be brief-only.
                kept_preview, rejected_preview = store.filter_high_info_tags(tags, p) if enforce_tag_gate else (store.normalize_tags(tags), [])
                if state == "active" and not kept_preview:
                    raise ValueError("cold-start active item has no kept high-information tag")
                if state == "warm" and not kept_preview:
                    out["warnings"].append({p: "warm node accepted without kept tag; brief-only recall"})
            # Preserve staged evidence/relation if Agent did not provide it.
            evidence = item.get("evidence")
            relation = item.get("relation")
            seed_score = float(item.get("seed_score") or 0)
            node_type = item.get("node_type")
            if session_id and staged.get(p):
                st_row = staged[p]
                if evidence is None:
                    evidence = json.loads(st_row.get("evidence") or "[]")
                if relation is None:
                    relation = json.loads(st_row.get("relation") or "{}")
                if not seed_score:
                    seed_score = float(st_row.get("seed_score") or 0)
                if not node_type:
                    node_type = st_row.get("node_type")
            res = store.annotate_node(
                conn, p, tags, brief=brief, node_type=node_type, state=state,
                source=item.get("source") or default_source, confidence=item.get("confidence") or "agent-labeled",
                seed_score=seed_score, evidence=evidence, relation=relation,
                enforce_tag_gate=enforce_tag_gate, fts_ok=fts_ok,
            )
            out["applied"] += 1
            out["rejected_tags"].extend([{p: x} for x in res.get("rejected_tags", [])])
            if session_id:
                conn.execute("UPDATE build_items SET status='applied',updated_at=? WHERE session_id=? AND path=?",
                             (time.time(), session_id, p))
        except Exception as e:
            out["errors"].append({"item": item, "error": str(e)})
    conn.commit()
    return out


def finish_cold_start(conn, session_id: str, *, max_nodes: int = 1000, max_active: int = 220, fts_ok: bool = False) -> Dict[str, Any]:
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    applied = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    skipped = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='skipped'", (session_id,)).fetchone()[0]
    if pending:
        return {"ok": False, "session_id": session_id, "pending": pending, "applied": applied, "skipped": skipped,
                "error": "cold start still has pending unlabeled items"}
    audit = audit_index(conn, fix=True, fts_ok=fts_ok)
    res = store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, fts_ok=fts_ok)
    conn.execute("UPDATE build_sessions SET status='closed',updated_at=? WHERE session_id=?", (time.time(), session_id))
    conn.commit()
    return {"ok": True, "session_id": session_id, "applied": applied, "skipped": skipped, "audit": audit, "rebalance": res}


def label_worklist(conn, *, limit: int = 80, node_types: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
    cond = ["(brief='' OR (state='active' AND path NOT IN (SELECT path FROM node_tags)))", "state IN ('active','warm')"]
    params: List[Any] = []
    if node_types:
        ph = ','.join('?' * len(node_types))
        cond.append(f"node_type IN ({ph})")
        params.extend(node_types)
    rows = conn.execute(f"SELECT * FROM nodes WHERE {' AND '.join(cond)} ORDER BY state='active' DESC, seed_score DESC LIMIT ?",
                        (*params, max(1, limit))).fetchall()
    return [{
        "path": r["path"], "node_type": r["node_type"], "state": r["state"], "seed_score": r["seed_score"],
        "brief": r["brief"], "visible_terms": sorted(store.visible_terms(r["path"]))[:32],
        "evidence": json.loads(r["evidence"] or "[]"), "relation": json.loads(r["relation"] or "{}"),
        "required_output": {"brief": "one short line", "tags": "0-3 high-info residual tags; active should have at least one"}
    } for r in rows]


def miss_recovery_batch(conn, query: str, *, memory_text: str = "", scope: Optional[str] = None, limit: int = 80) -> Dict[str, Any]:
    cands = collect_candidates([query], memory_text=memory_text, scope=scope, limit_per_query=limit,
                               include_recent=False, recent_limit=0, ignored=store.ignored_paths(conn))
    return make_discovery_summary(cands, max_files=min(limit, 80), max_clusters=30)


def audit_index(conn, *, fix: bool = False, fts_ok: bool = False) -> Dict[str, Any]:
    """Detect/fix nonexistent paths and banned placeholder tags."""
    nonexistent: List[str] = []
    bad_tags: List[Dict[str, str]] = []
    banned = {"uncategorized", "general", "misc", "other", "unknown", "tbd"}
    now = time.time()
    for r in conn.execute("SELECT path,state FROM nodes WHERE state!='retired'"):
        p = r["path"]
        if not os.path.exists(p):
            nonexistent.append(p)
            if fix:
                conn.execute("UPDATE nodes SET state='retired',updated_at=? WHERE path=?", (now, p))
                conn.execute("UPDATE node_tags SET state='retired',updated_at=? WHERE path=?", (now, p))
                store.log_event(conn, "audit_retire_missing", path=p, old_state=r["state"], new_state="retired")
                store.fts_sync_row(conn, p, fts_ok=fts_ok)
    for r in conn.execute("SELECT path,tag FROM node_tags"):
        if r["tag"] in banned:
            bad_tags.append({r["path"]: r["tag"]})
            if fix:
                conn.execute("DELETE FROM node_tags WHERE path=? AND tag=?", (r["path"], r["tag"]))
                store.log_event(conn, "audit_delete_bad_tag", path=r["path"], tag=r["tag"])
                store.fts_sync_row(conn, r["path"], fts_ok=fts_ok)
    if fix:
        conn.commit()
    return {"ok": True, "fix": fix, "nonexistent_count": len(nonexistent), "bad_tag_count": len(bad_tags),
            "nonexistent_sample": nonexistent[:30], "bad_tag_sample": bad_tags[:30]}
