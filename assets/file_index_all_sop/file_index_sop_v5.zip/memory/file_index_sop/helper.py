"""Agent-facing entry points for file_index_sop.

No GenericAgent imports. The Agent calls these functions via code_run.
"""
from __future__ import annotations

import json
import os
import sqlite3
import sys
from typing import Any, Dict, List, Optional, Sequence, Tuple

from . import builder, ensure_es, everything, store

_PATH_OVERRIDE: Optional[str] = None
_CONN: Optional[sqlite3.Connection] = None
_FTS_OK = False


def _db_path_used() -> str:
    return _PATH_OVERRIDE if _PATH_OVERRIDE else store.default_db_path()


def _ensure_conn() -> Tuple[sqlite3.Connection, bool, str]:
    global _CONN, _FTS_OK
    if _CONN is None:
        _CONN = store.connect(_PATH_OVERRIDE)
        _FTS_OK = store.init_schema(_CONN)
    return _CONN, _FTS_OK, _db_path_used()


def _close_conn() -> None:
    global _CONN
    if _CONN is not None:
        _CONN.close(); _CONN = None


def init_db(db_path: Optional[str] = None) -> Dict[str, Any]:
    global _PATH_OVERRIDE
    _PATH_OVERRIDE = os.path.abspath(db_path) if db_path else None
    _close_conn(); _, fts, p = _ensure_conn()
    return {"ok": True, "db_path": p, "fts_enabled": fts}


def ensure_search_ready(*, start: bool = True, patch: bool = True, dry_run: bool = False) -> Dict[str, Any]:
    """Sniff es.exe, patch LOCAL_TOOLS, and optionally start Everything. Explicit environment-prep step."""
    return ensure_es.ensure_ready(start=start, patch=patch, dry_run=dry_run)


# Runtime --------------------------------------------------------------------

def search_files(query: str, *, limit: int = 50, scope: Optional[str] = None, sort_mtime_desc: bool = False) -> List[Dict[str, Any]]:
    return everything.search(query, limit=limit, scope=scope, sort_mtime_desc=sort_mtime_desc)


def recent_files(*, limit: int = 500, scope: Optional[str] = None, query: str = "*") -> List[Dict[str, Any]]:
    return everything.recent(limit=limit, scope=scope, query=query)


def annotate_node(path: str, tags: Sequence[str] | str = (), *, brief: str = "", node_type: Optional[str] = None,
                  state: str = "active", source: str = "agent", confidence: str = "verified",
                  seed_score: float = 0.0, evidence: Optional[Any] = None, relation: Optional[Any] = None,
                  enforce_tag_gate: bool = True) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn()
    return store.annotate_node(conn, path, tags, brief=brief, node_type=node_type, state=state, source=source,
                               confidence=confidence, seed_score=seed_score, evidence=evidence, relation=relation,
                               enforce_tag_gate=enforce_tag_gate, fts_ok=fts)


def annotate(path: str, tags: Sequence[str] | str = (), *, brief: str = "", source: str = "agent", state: str = "active") -> Dict[str, Any]:
    return annotate_node(path, tags, brief=brief, source=source, state=state, confidence="verified")


def recall(query: str, *, limit: int = 10, include_dormant: bool = False, include_retired: bool = False,
           node_types: Optional[Sequence[str]] = None, verbose: bool = False) -> List[Dict[str, Any]]:
    conn, fts, _ = _ensure_conn()
    return store.recall(conn, query, limit=limit, include_dormant=include_dormant, include_retired=include_retired,
                        node_types=node_types, fts_ok=fts, verbose=verbose)


def locate(query: str, *, limit: int = 10, scope: Optional[str] = None) -> Dict[str, Any]:
    sem = recall(query, limit=limit, include_dormant=False, verbose=False)
    scoped: List[Dict[str, Any]] = []
    for hit in sem[:3]:
        if hit.get("node_type") == "dir":
            try:
                scoped.extend(search_files(query, scope=hit["path"], limit=max(3, limit // 2)))
            except Exception as e:
                scoped.append({"error": str(e), "scope": hit.get("path")})
    fs: List[Dict[str, Any]] = []
    if len(sem) < max(3, limit // 2) and not scoped:
        try: fs = search_files(query, limit=limit, scope=scope)
        except Exception as e: fs = [{"error": str(e)}]
    return {"semantic_hits": sem, "scoped_filesystem_hits": scoped[:limit], "fallback_filesystem_hits": fs[:limit], "next": "Read top file hits; if semantic miss/noisy, run miss_recovery_batch then apply_index_plan."}


def mark_used(path: str, *, matched_tags: Optional[Sequence[str]] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn()
    return store.mark_used(conn, path, matched_tags=matched_tags, fts_ok=fts)


def promote(path: str, *, target_state: str = "active", tag: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.set_state(conn, path, target_state, tag=tag, fts_ok=fts)


def demote(path: str, *, target_state: str = "cold", tag: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.set_state(conn, path, target_state, tag=tag, fts_ok=fts)


def decay(*, active_days: float = 30, warm_days: float = 90) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.decay(conn, active_days=active_days, warm_days=warm_days, fts_ok=fts)


def check_stale(path: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.check_stale(conn, path, fts_ok=fts)


def rebalance(*, max_nodes: int = 1000, max_active: int = 220) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return store.rebalance(conn, max_nodes=max_nodes, max_active=max_active, fts_ok=fts)


# Agent-driven cold start ----------------------------------------------------

def begin_cold_start(*, target_nodes: int = 1000, max_active: int = 220, scope: Optional[str] = None,
                     agent_queries: Optional[Sequence[str]] = None, memory_text: str = "", purpose: Optional[str] = None,
                     recent_limit: int = 2500, limit_per_query: int = 160, parent_levels: int = 2,
                     auto_prepare_search: bool = True) -> Dict[str, Any]:
    """Stage candidates for an Agent-labeled cold start. Does not finish until batches are labeled."""
    if auto_prepare_search:
        prep = ensure_search_ready(start=True, patch=True)
        if not prep.get("ok"):
            return {"ok": False, "stage": "ensure_search_ready", "prepare_result": prep}
    conn, _, _ = _ensure_conn()
    return builder.prepare_cold_start(conn, target_nodes=target_nodes, max_active=max_active, scope=scope,
                                      agent_queries=agent_queries, memory_text=memory_text, purpose=purpose,
                                      recent_limit=recent_limit, limit_per_query=limit_per_query,
                                      parent_levels=parent_levels, ignored=store.ignored_paths(conn))


def cold_start_batch(session_id: str, *, batch_size: int = 50) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.cold_start_batch(conn, session_id, batch_size=batch_size)


def apply_index_plan(plan: Sequence[Dict[str, Any]], *, default_state: str = "warm", default_source: str = "agent-builder",
                     enforce_tag_gate: bool = True, session_id: Optional[str] = None) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn()
    return builder.apply_index_plan(conn, plan, default_state=default_state, default_source=default_source,
                                    enforce_tag_gate=enforce_tag_gate, fts_ok=fts, session_id=session_id)


def finish_cold_start(session_id: str, *, max_nodes: int = 1000, max_active: int = 220) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.finish_cold_start(conn, session_id, max_nodes=max_nodes, max_active=max_active, fts_ok=fts)


def cold_start_status(session_id: str) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn()
    sess = conn.execute("SELECT * FROM build_sessions WHERE session_id=?", (session_id,)).fetchone()
    if not sess: return {"ok": False, "error": "session not found", "session_id": session_id}
    pending = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='pending'", (session_id,)).fetchone()[0]
    applied = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='applied'", (session_id,)).fetchone()[0]
    skipped = conn.execute("SELECT COUNT(*) FROM build_items WHERE session_id=? AND status='skipped'", (session_id,)).fetchone()[0]
    return {"ok": True, "session_id": session_id, "status": sess["status"], "pending": pending, "applied": applied, "skipped": skipped, "target_nodes": sess["target_nodes"], "max_active": sess["max_active"]}


def label_worklist(*, limit: int = 80, node_types: Optional[Sequence[str]] = None) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return builder.label_worklist(conn, limit=limit, node_types=node_types)


def miss_recovery_batch(query: str, *, memory_text: str = "", scope: Optional[str] = None, limit: int = 80) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return builder.miss_recovery_batch(conn, query, memory_text=memory_text, scope=scope, limit=limit)


def add_ignored_path(path: str, *, reason: str = "", path_type: str = "prefix", source: str = "agent") -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return store.add_ignored_path(conn, path, reason=reason, path_type=path_type, source=source)


def ignored_paths() -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.ignored_paths(conn)


def audit_index(*, fix: bool = False) -> Dict[str, Any]:
    conn, fts, _ = _ensure_conn(); return builder.audit_index(conn, fix=fix, fts_ok=fts)


# Inspection/export ----------------------------------------------------------

def stats() -> Dict[str, Any]:
    conn, fts, path = _ensure_conn(); return store.stats(conn, fts_ok=fts, db_path=path, es_ok=everything.resolve_es_exe() is not None)


def facets(*, limit: int = 30) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn(); return store.facets(conn, limit=limit)


def list_candidates(*, state: Optional[str] = None, node_type: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_candidates(conn, state=state, node_type=node_type, limit=limit)


def list_by_tag(tag: str, *, include_dormant: bool = False, include_retired: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_by_tag(conn, tag, include_dormant=include_dormant, include_retired=include_retired, limit=limit)


def list_under_parent(parent: str, *, include_dormant: bool = False, include_retired: bool = False, limit: int = 50) -> List[Dict[str, Any]]:
    conn, _, _ = _ensure_conn(); return store.list_under_parent(conn, parent, include_dormant=include_dormant, include_retired=include_retired, limit=limit)


def export_jsonl(output_path: Optional[str] = None) -> Dict[str, Any]:
    conn, _, _ = _ensure_conn()
    if output_path:
        with open(output_path, "w", encoding="utf-8") as fh: n = store.export_jsonl(conn, fh)
        return {"ok": True, "path": os.path.abspath(output_path), "lines": n}
    n = store.export_jsonl(conn, sys.stdout); return {"ok": True, "path": "-", "lines": n}


def print_json(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))
